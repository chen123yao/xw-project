<script>
	import store from '@/store/store.js';
	import {	$api	} from '@/config/api.js';
	import permision from "@/js_sdk/wa-permission/permission.js"
	var xwPluginModule = uni.requireNativePlugin("XwPlugin")
	export default {
		globalData: {
			store
		},
		onLaunch: function() {
			uni.setStorageSync('is_refresToken',true)
			plus.screen.lockOrientation("portrait-primary")
			if (this.$store.state.platform =='android') {
				plus.navigator.hideSystemNavigation();
				this.requestAndroidPermission('android.permission.READ_PHONE_STATE')
			} else if (this.$store.state.platform =='ios') {
				this.$common.registerAsyncFunc()
			}
			this.$common.getExtendAsyncFunc("yqinfo","setyqinfo")
			this.$common.getExtendAsyncFunc("channel","setClientId")
			this.$store.commit("setSystemInfoSync", uni.getSystemInfoSync());
			let fontSrc = plus.io.convertLocalFileSystemURL('/static/fonts/iconfont.ttf')
			var domModule = weex.requireModule("dom");
			domModule.addRule('fontFace', {
				'fontFamily': 'iconfont',
				'src': "url('file:/" + fontSrc + "')"
			})
			// setTimeout(() => {
			// 	console.log('倒计时结束');
			// 	this.$isResolve()
			// },5000);
			// this.autoLogin()
			// this.channelIDSyncFunc()
		},
		onShow() {
			console.log('app显示');
		},
		onHide: function() {
			console.log('App Hide')
		},
		
		methods: {
			// 自动登录
			autoLogin() {
				let Store = getApp().globalData.store
				// const Author = uni.getStorageSync('AUTHOR');
				console.log('Store',Store.state.user_token)
				this.$store.commit("setUserInfo", {});
				if(uni.getStorageSync('account') && uni.getStorageSync('mobile')){
					$api.post("api.member/mobileReg", {
						mobile:uni.getStorageSync('account'),
						code:1234
					}).then(res => {
						console.log('res',res)
						// 将登录获取的数据记录下来
						if (res.data.code == 200) {
							if (res.data.data) {
								uni.setStorageSync('account',uni.getStorageSync('account'))
								uni.setStorageSync('mobile', uni.getStorageSync('account'))
								uni.setStorageSync('Author', res.data.data.token)
								this.$store.commit("setUserToken", res.data.data.token)
								// 存储用户信息
								this.$common.getuserInfo();
								console.log('111111111',this.$isResolve())
								this.$isResolve()
							}
						} else {
							uni.showToast({
								title: res.data.msg,
								icon: 'none'
							})
						}
					})
					.catch(error=>{
						console.log('error',error)
					})
				}else{
					// 清空本地存储的登录数据
					this.$store.commit('setUserToken', {});
					this.$store.commit('setUserInfo', {});
					uni.setStorageSync('mem-openid', '')
					uni.setStorageSync('account', '')
					uni.setStorageSync('password', '')
					uni.setStorageSync('mobile','')
					uni.setStorageSync('Author', '')
					// uni.reLaunch({
					// 	url: '/pages/view/login/login',
					// })
				}
			// 	this.$store.commit("setUserInfo", {});
			// 	console.log(uni.getStorageSync('password'),'uni.getStorageSync',$api);
			// 	if (uni.getStorageSync('account') && uni.getStorageSync('password')) {
			// 		let username = uni.getStorageSync('account')
			// 		let password = uni.getStorageSync('password')
			// 		$api.get("user/login", {
			// 			'account': username,
			// 			'password': password,
			// 			equipmentCode: this.$store.state.equipmentCode
			// 		}).then(res => {
			// 			console.log(res,'res');
			// 			if (res.data.code == 200) {
			// 				// 将登录获取的数据记录下来
			// 				this.$store.commit("setUserToken", res.data.data.user_token)
			// 				// 获取用户信息
			// 				this.$common.getuserInfo();
			// 			}
			// 		})
			// 	} else if (uni.getStorageSync('mem-openid')) {
			// 		$api.get("user/login", {
			// 			"mem-openid": uni.getStorageSync('mem-openid'),
			// 			"account": uni.getStorageSync('account'),
			// 			"mem-oauth_type": uni.getStorageSync('mem-oauth_type'),
			// 		}).then(res => {
			// 			console.log(res,'mem-openidmem-openid')
			// 			if (res.data.code == 200) {
			// 				// 将登录获取的数据记录下来
			// 				this.$store.commit("setUserToken", res.data.data.user_token)
			// 				// 获取用户信息
			// 				this.$common.getuserInfo();
			// 			}
			// 		})
			
			
			// 	} else if (uni.getStorageSync('sms-mobile')) {
			// 		$api.get("v8/user/loginm", {
			// 			"sms-mobile": uni.getStorageSync('sms-mobile'),
			// 			"sms-phone": '1',
			// 			"sms-type": '2',
			// 		}).then(res => {
			// 			console.log(res, 'sms-mobilesms-mobilesms-mobile')
			// 			// 将登录获取的数据记录下来
			// 			if (res.data.code == 200) {
			// 				if (res.data.data.is_pwd) {
			// 					uni.setStorageSync('account', res.data.data.username)
			// 					uni.setStorageSync('sms-mobile',uni.getStorageSync('sms-mobile'))
			// 					this.$store.commit("setUserToken", res.data.data.user_token)
			// 					// 获取用户信息
			// 					this.$common.getuserInfo();
			// 				}
			// 			}
			// 		})
			// 	} else {
			// 		// 清空本地存储的登录数据
			// 		this.$store.commit('setUserToken', {});
			// 		this.$store.commit('setUserInfo', {});
			// 		uni.setStorageSync('mem-openid', '')
			// 		uni.setStorageSync('account', '')
			// 		uni.setStorageSync('password', '')
			// 		uni.setStorageSync('sms-mobile','')
			// 		uni.navigateTo({
			// 			url: '/pages/view/login/login',
			// 		})
			
			// 	}
			
			},
			// 获取channelId
			channelIDSyncFunc() {
				let ret;         
				let udid;
				switch (uni.getSystemInfoSync().platform) {
					case "android":
						let getXWID = uni.requireNativePlugin("GetXWID")
						ret = getXWID.channelIDSyncFunc();
						// console.log(ret,'retretretretrets')
						if (ret.channelid != 0) {
							this.$store.commit('setClientId', ret.channelid);
						} else {
							this.$store.commit('setClientId', 4231);
						}
						break;
					case "ios":
						let channelModule = uni.requireNativePlugin("DCChannelUniPlugin-ChannelModule");
						ret = channelModule.channelIdSyncFunc({
							'name': 'uni-app',
							'age': 1
						}) || 4231
						this.$store.commit('setClientId', ret);
						udid = channelModule.udidSyncFunc({
							'name': 'uni-app',
							'age': 1
						}) || ''
						// this.$store.commit('setUdid', udid);       
						console.log(udid,'udidudidudid')
						break;
					default:
						break;
				}
			},
			async requestAndroidPermission(permisionID) {
				console.log('权限获取');
			    var result = await permision.requestAndroidPermission(permisionID)
			    var strStatus
					console.log(result);
			    if (result == 1) {
			        strStatus = "已获得授权"
							this.$common.registerAsyncFunc()
			    } else if (result == 0) {
			        strStatus = "未获得授权"
			    } else {
			        strStatus = "被永久拒绝权限"
			    }
			    // uni.showModal({
			    //     content: permisionID + strStatus,
			    //     showCancel: false
			    // });
			},
			
		}
	}
</script>

<style>
	/*每个页面公共css */
</style>
