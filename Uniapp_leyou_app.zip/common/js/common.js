/*
 * 全局公用方法
 */
import Vue from 'vue'
import Store from "@/store/store.js"
import common from "@/common/js/common.js"
// import Store from '@/store/store';
import {
	$api
} from '@/config/api.js';
import md5 from 'js-md5'
import mutations from '../../store/mutations';
var xwPluginModule = uni.requireNativePlugin("XwPlugin")
export default {

	//登出
	logOut() {       
	    // $api.get('/user/logout')
		// 清空本地存储的登录数据
		uni.setStorageSync('account', '')
		uni.setStorageSync('password', '')
		uni.setStorageSync('mobile', '')
		uni.setStorageSync('mem-openid', '')
		Store.commit('setUserToken', {});
		Store.commit('setUserInfo', {});
		uni.reLaunch({
			url: '/pages/view/login/login'
		})
	},
	// 置换token
	refresTokenRequest(){
		const is_refresToken = uni.getStorageSync('is_refresToken');
		console.log('is_refresToken',is_refresToken)
		const Author = uni.getStorageSync('Author');
		let Store = getApp().globalData.store
		return new Promise(function(resolve, reject) {
			// 执行登录后不刷新token
			if(!is_refresToken){
				// 存储用户信息
				common.getuserInfo();
				resolve()
			}else{
				console.log('Author',Author)
				Store.commit("setUserInfo", {});
				$api.post("api.member/tokenReg",{
					token:Author
				}).then(res => {
					console.log('res>>>',res)
					if (res.data.code == 200) {
						uni.setStorageSync('account',res.data.data.account)
						uni.setStorageSync('mobile', res.data.data.mobile)
						uni.setStorageSync('Author', res.data.data.token)
						Store.commit("setUserToken", res.data.data.token)
						// 存储用户信息
						common.getuserInfo();
						resolve();
					}else{
						reject();
					}
				})
				.catch(error=>{
					reject();
					console.log('error',error)
				})
			}
		})
	},
	// 自动登录
	autoLogin(){
		 return new Promise(function(resolve, reject) {
			 console.log('999');
			 let Store = getApp().globalData.store
			 const Author = uni.getStorageSync('AUTHOR');
			 Store.commit("setUserInfo", {});
			 let account = uni.getStorageSync('mobile')
			 let password = uni.getStorageSync('password')
			 console.log('password',password,uni.getStorageSync('password'))
			 if(uni.getStorageSync('account') && uni.getStorageSync('mobile')){
			 	$api.post("api.member/accountLogin", {
			 		account:account,
					password:password,
			 	}).then(res => {
			 		// 将登录获取的数据记录下来
			 		if (res.data.code == 200) {
			 			if (res.data.data) {
			 				uni.setStorageSync('account',uni.getStorageSync('account'))
			 				uni.setStorageSync('mobile', uni.getStorageSync('mobile'))
			 				uni.setStorageSync('Author', res.data.data.token)
			 				Store.commit("setUserToken", res.data.data.token)
			 				// 存储用户信息
			 				common.getuserInfo();
							resolve();
			 			}
			 		} else {
						reject();
			 		}
			 	})
			 	.catch(error=>{
					reject();
			 		console.log('error',error)
			 	})
			 }else{
			 	// 清空本地存储的登录数据
			 	Store.commit('setUserToken', {});
			 	Store.commit('setUserInfo', {});
			 	uni.setStorageSync('mem-openid', '')
			 	uni.setStorageSync('account', '')
			 	uni.setStorageSync('password', '')
			 	uni.setStorageSync('mobile','')
			 	uni.setStorageSync('Author', '')
				reject();
			 }
		 })
	},
	routeJump(pathurl){
		let url = null;
		switch (pathurl){
			case 1:
				url = '/pages/index/daily-raffle' 		//天天抽奖
				break;
			case 2:
				url = '/pages/my/blindBox/index'		//开盲盒
				break;
			case 3:
				url = '/pages/index/invite'		//立即邀请
				break;
			case 4:
				url = '/pages/demoGame/index'		//游戏试玩
				break;
			case 5:
				url = '/pages/my/buyGiftBag/index'			//元宝礼包
				break;
			case 6:
				url = '/pages/index/captureTreasure/index'			//夺宝
				break;
			case 7:
				url = '/pages/my/withdrawDeposit/index'				//提现
				break;
			case 8:
				url = '/pages/index/playGift/index'				//试玩大礼包
				break;
			case 9:
				url = ''				//绑定广告
				break;
			default:
				break;
		}
		if(pathurl == 4){
			uni.switchTab({
				url:url
			})
		}else{
			uni.navigateTo({
				url:url
			})
		}
	},
	
	// 获取用户信息
	getuserInfo() {
		console.log('用户信息');
		return $api.get("api.member/info").then(res => {
			console.log('common',res)
			let username = uni.getStorageSync('account')||uni.getStorageSync('mobile');
			res = res.data
			if (res.code == 200) {
				// 当记录的用户登录账户与登录之后返回的账户不匹配时，就不允许登录成功
				if (username == res.data.base.mobile || username == res.data.base.account) {
					getApp().globalData.store.commit('setUserInfo', res.data);
					// console.log('res>>>',res.data)
					// Store.commit("setUserInfo", res.data.data)
					console.log('Store',Store.state)
				} else {	
			    // this.logOut()
				}
			} else {
				this.logOut()
			}
		})
		.catch(error=>{
			console.log('error',error)
			this.logOut()
		})
	},
	// 保存账号信息
	saveAccountInfo(data){
		let accountInfo = uni.getStorageSync('accountInfo') ? uni.getStorageSync('accountInfo') : []
		if(accountInfo){
			// 账号信息有值，保留三条数据
			accountInfo.forEach((item,index)=>{
				if(item.account == data.account && item.type == data.type){
					accountInfo.splice(index,1)
				}
			})
			accountInfo.unshift(data)
			if(accountInfo.length >=4){
				accountInfo.pop();
			}
		}else{
			accountInfo.unshift(data)
		}
		uni.setStorageSync('accountInfo',accountInfo)
	},
	// 获取多游信息
	getDYInfo(){
		let dyInfo = null;
		let Store = getApp().globalData.store
		console.log('信息',Store.state.userInfo,'deviceidinfo',Store.state.deviceidinfo)
		dyInfo = {
			'media_id' : uni.getSystemInfoSync().platform == 'ios' ? 'dy_59641614' : 'dy_59640977',
			'user_id' : Store.state.userInfo.base.id,
			'device_type' : uni.getSystemInfoSync().platform == 'ios' ? '1' : '2',
			'key' : uni.getSystemInfoSync().platform == 'ios' ? 'c12adfb031a6b80cff07d07ec97b45a5' : '3d6e5a26cc2b3e1b71815e6de899edba',
			'device_ids' : encodeURIComponent(JSON.stringify({
				"1":Store.state.deviceidinfo.IMEI,
				"7":Store.state.deviceidinfo.OAID,
				"4":Store.state.deviceidinfo.idfa
			}))
		}
		let sign = md5('device_ids='+ dyInfo.device_ids + '&device_type=' + dyInfo.device_type +'&media_id=' + dyInfo.media_id + '&user_id='+ dyInfo.user_id +'&key=' + dyInfo.key)
		dyInfo.sign = sign
		return dyInfo
	},
	number(value) {
		return /^[\+-]?(\d+\.?\d*|\.\d+|\d\.\d+e\+\d+)$/.test(value)
	},
	
	getPx(value, unit = false) {
		if (this.number(value)) {
			return unit ? `${value}px` : Number(value)
		}
		// 如果带有rpx，先取出其数值部分，再转为px值
		if (/(rpx|upx)$/.test(value)) {
			return unit ? `${uni.upx2px(parseInt(value))}px` : Number(uni.upx2px(parseInt(value)))
		}
		return unit ? `${parseInt(value)}px` : parseInt(value)
	},

	//获取节点
	getEl(el) {
		if (typeof el === 'string' || typeof el === 'number') return el;
		if (WXEnvironment) {
			return el.ref;
		} else {
			return el instanceof HTMLElement ? el : el.$el;
		}
	},
	// 节流函数：规定在一个单位时间内，只能触发一次函数。如果这个单位时间内触发多次函数，只有一次生效
	// throttle(canRun, func, wait) {
	// 	return function() {
	// 		console.log(canRun, 'canRuncanRun')
	// 		if (!canRun) return;
	// 		canRun = false;
	// 		setTimeout(() => {
	// 			func.apply(this, arguments);
	// 			canRun = true;
	// 			return canRun;
	// 		}, wait);
	// 		return canRun;
	// 	};
	// },
	// 判断是否登录，评论时需要先登录
	isLogin() {	
		if (Object.keys(getApp().globalData.store.state.userInfo).length == 0) {
			uni.showToast({
				title: '您还未登录，快去登录吧~',
				icon: 'none',
				success: () => {
					setTimeout(() => {
						uni.navigateTo({
							url: '/pages/view/login/login',
						})
						return false;
					}, 600)
				}
			})
		} else {
			return true;
		}
	},

	//复制 
	copyText(text) {
		uni.setClipboardData({
			data: text,
		})
	},
	/* 深拷贝 */
	getClone(obj) {
		if (obj === null) return null
		if (typeof obj !== 'object') return obj;
		if (obj.constructor === Date) return new Date(obj);
		if (obj.constructor === RegExp) return new RegExp(obj);
		var newObj = new obj.constructor(); //保持继承链
		for (var key in obj) {
			if (obj.hasOwnProperty(key)) { //不遍历其原型链上的属性
				var val = obj[key];
				// newObj[key] = typeof val === 'object' ? arguments.callee(val) : val; // 使用arguments.callee解除与函数名的耦合
			}
		}
		return newObj;
	},
	// 预览图片
	previewImage(index, arr) {
		//uniapp预览图片
		uni.previewImage({
			current: index, //预览图片的下标
			urls: arr, //预览图片的地址，必须要数组形式，如果不是数组形式就转换成数组形式就可以
			indicator: 'number'
		});
	},
	getNatve() {
		const infoSync = Store.state.infoSync
		const system = Store.state.infoSync.platform
		console.log(infoSync, 'infoSync')
		const navheight = 0


	},
	gaussBlur(imgData) {
		var pixes = imgData.data;
		var width = imgData.width;
		var height = imgData.height;
		var gaussMatrix = [],
			gaussSum = 0,
			x, y,
			r, g, b, a,
			i, j, k, len;

		var radius = 10;
		var sigma = 5;

		a = 1 / (Math.sqrt(2 * Math.PI) * sigma);
		b = -1 / (2 * sigma * sigma);
		//生成高斯矩阵
		for (i = 0, x = -radius; x <= radius; x++, i++) {
			g = a * Math.exp(b * x * x);
			gaussMatrix[i] = g;
			gaussSum += g;

		}

		//归一化, 保证高斯矩阵的值在[0,1]之间
		for (i = 0, len = gaussMatrix.length; i < len; i++) {
			gaussMatrix[i] /= gaussSum;
		}
		//x 方向一维高斯运算
		for (y = 0; y < height; y++) {
			for (x = 0; x < width; x++) {
				r = g = b = a = 0;
				gaussSum = 0;
				for (j = -radius; j <= radius; j++) {
					k = x + j;
					if (k >= 0 && k < width) { //确保 k 没超出 x 的范围
						//r,g,b,a 四个一组
						i = (y * width + k) * 4;
						r += pixes[i] * gaussMatrix[j + radius];
						g += pixes[i + 1] * gaussMatrix[j + radius];
						b += pixes[i + 2] * gaussMatrix[j + radius];
						// a += pixes[i + 3] * gaussMatrix[j];
						gaussSum += gaussMatrix[j + radius];
					}
				}
				i = (y * width + x) * 4;
				// 除以 gaussSum 是为了消除处于边缘的像素, 高斯运算不足的问题
				// console.log(gaussSum)
				pixes[i] = r / gaussSum;
				pixes[i + 1] = g / gaussSum;
				pixes[i + 2] = b / gaussSum;
				// pixes[i + 3] = a ;
			}
		}
		//y 方向一维高斯运算
		for (x = 0; x < width; x++) {
			for (y = 0; y < height; y++) {
				r = g = b = a = 0;
				gaussSum = 0;
				for (j = -radius; j <= radius; j++) {
					k = y + j;
					if (k >= 0 && k < height) { //确保 k 没超出 y 的范围
						i = (k * width + x) * 4;
						r += pixes[i] * gaussMatrix[j + radius];
						g += pixes[i + 1] * gaussMatrix[j + radius];
						b += pixes[i + 2] * gaussMatrix[j + radius];
						// a += pixes[i + 3] * gaussMatrix[j];
						gaussSum += gaussMatrix[j + radius];
					}
				}
				i = (y * width + x) * 4;
				pixes[i] = r / gaussSum;
				pixes[i + 1] = g / gaussSum;
				pixes[i + 2] = b / gaussSum;
			}
		}
		return imgData;
	},

	//
	setVideoUrl(url) {
		if (url && (url.indexOf('rs.sy12306.com') == -1)) {
			return url;
		}
		let host_str = 'rs.sy12306.com'
		let host_arr = host_str.split('.')
		host_str = host_arr[host_arr.length-1].toString()
		// console.log(url,'mp4_url');
		let arr = url.split('?');
		console.log(arr[0],'arr');
		
		
		let arr1 = arr[0].split(host_str);
		console.log(arr1[1], 'arr1');
		
		let time = Date.parse( new Date());//获取到毫秒的时间戳，精确到毫秒
		// console.log(time, 'time');
		time = time / 1000;//精确到秒
		// console.log(time, 'time');
		
		const newUrl = arr1[1] + '-' + time.toString() + '-0-0-' + Store.state.auth_key + '5vk33mpbbot9hvcfiw';
		// console.log(newUrl, 'newUrl');
		
		const newUrl_md5 = md5(newUrl);
		// console.log(newUrl_md5, 'newUrl_md5');
		
		const videoUrl = arr1[0] + host_str + arr1[1] + '?auth_key=' + time.toString() + '-0-0-' + newUrl_md5;
		// console.log(videoUrl, 'videoUrl');

		return videoUrl;
	},

	// 随机字符串
	randomString(len) {
		len = len || 32;
		let $chars = 'ABCDEFGHJKMNPQRSTWXYZabcdefhijkmnprstwxyz2345678';    /****默认去掉了容易混淆的字符oOLl,9gq,Vv,Uu,I1****/
		let maxPos = $chars.length;
		let pwd = '';
		for (let i = 0; i < len; i++) {
			pwd += $chars.charAt(Math.floor(Math.random() * maxPos));
		}
		return pwd;
	},

	// 生成下载鉴权sign
	downLoadUrl_sign() {
		let key = 'QyWbpzcfbJgtppSA';
		let code = this.randomString(5);
		let timestamp = Date.parse(new Date()) / 1000;
		let sign_key = String(timestamp.toString() + key + code);
		let sign1 = md5(code + timestamp + sign_key);
		let sign = code + '-' + timestamp + '-' + sign1;
		return sign;
	},

	//获取设备信息及oaid需先调用注册函数
	registerAsyncFunc(){
		console.log('注册');
		switch(uni.getSystemInfoSync().platform) {
			case "android":
				xwPluginModule.registerAsyncFunc(
					res=>{
						console.log(res,'执行安卓方法');
						setTimeout(()=>{					
							common.getdeviceinfoFunc()
							common.getdeviceidinfoFunc()
						},300)
					}
				)
				break;
			case "ios":
				console.log('执行IOS方法1122');
				xwPluginModule.getDeviceInfoAsyncFunc({},
					res=>{
						let deviceinfo = res
						Store.commit('setDeviceIdInfo', deviceinfo);
					}
				);
				break;
			default:
				break;
		}
	},
	//获取设备手机信息
	getdeviceinfoFunc(){
		xwPluginModule.deciceinfoAsyncFunc(res => {
			console.log(res);
			let deviceinfo = JSON.parse(res.deviceinfo)
			Store.commit('setDeviceInfo', deviceinfo);
		});
	},
	//获取设备id相关信息
	getdeviceidinfoFunc(){
		xwPluginModule.deciceidAsyncFunc(res => {
			console.log(res);
			let deviceid = JSON.parse(res.deviceid)
			Store.commit('setDeviceIdInfo', deviceid);
		});
	},
	//获取安卓META-INF目录下的文件内容(邀请信息)
	getExtendAsyncFunc(type,mutationsType){
		switch(uni.getSystemInfoSync().platform){
			case "android":
				xwPluginModule.getExtendAsyncFunc(type,
					res=>{
						console.log(res.extendinfo,'res.extendinfo');
						Store.commit(mutationsType,res.extendinfo)
					}
				)
				break;
			case "ios":
				xwPluginModule.getExtendAsyncFunc({
						'keyword': type+'_'
					},
					res=>{
						// console.log(res);
						Store.commit(mutationsType,res)
						// uni.showToast({
						// 	title: res,
						// 	icon: "none",
						// 	duration: 3000
						// })
					}
				);
				break;
			default:
				break;
		}
	},
	// //获取安卓META-INF目录下的文件内容(获取渠道)
	// getChannelIdFunc(){
	// 	switch(uni.getSystemInfoSync().platform){
	// 		case "android":
	// 			xwPluginModule.getExtendAsyncFunc("channel",
	// 				res=>{
	// 					console.log(res.extendinfo,'res.extendinfo>>>');
	// 					if(res.extendinfo){
	// 						Store.commit('setClientId',res.extendinfo)
	// 					}
	// 				}
	// 			)
	// 			break;
	// 		case "ios":
	// 			break;
	// 		default:
	// 			break;
	// 	}
	// },
}
