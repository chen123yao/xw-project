export default {
	filters: {
		mobileHide(val) {
			return String(val).replace(/(\d{3})\d{4}(\d{4})/, '$1****$2')
		}
	}
}