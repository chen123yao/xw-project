/*
 * 这里修改state中的数据
 */

export default {
	setEquipmentCode(state, data) {
		state.equipmentCode = data;
	},
	setClientId(state, data) {
		state.client_id = data
	},
	setUserInfo(state, data) {
		state.userInfo = data
	},
	setRefresh(state, data) {
		state.isRefresh = data
	},
	setUserFormat(state, data) {
		state.userFormat = data
	},
	setUserToken(state, data) {
		state.user_token = data
	},
	setServiceList(state, data){
		state.serviceList = data
	},
	setScrollTop(state, data){
		state.scrollTop = data
	},
	setActiveList(state, data) {
		state.activeList = data
	},
	setSystemInfoSync(state, data) {
		state.systemInfoSync = data
		state.platform = data.platform
		state.myWidth = data.windowWidth
		state.myHeight = data.windowHeight * (750 / data.windowWidth)
		state.mySHeight = (data.screenHeight - 50) * (750 / data.windowWidth)
		state.statusBarHeight = data.statusBarHeight * (750 / data.windowWidth)
	},
	setDeviceInfo(state,data) {
		state.deviceinfo = data
	},
	setDeviceIdInfo(state,data) {
		state.deviceidinfo = data
	},
	setyqinfo(state,data) {
		state.yqinfo = data
	}
}
