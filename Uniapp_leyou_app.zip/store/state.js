/*
 * 这里存放公共数据状态
 */
// 版本环境
export default {
	// api请求头
	// httpAPI:'https://leyou.yiyiyou.net/', //测试服接口地址
	httpAPI: "https://api.leyou.123youxi.com/",   // 正式服接口地址
	// 系统信息
	systemInfoSync: uni.getSystemInfoSync(),
	// app运行的平台
	platform: uni.getSystemInfoSync().platform,
	// 热更最后一位
	sp: 3,
	// 设备码
	equipmentCode: "",
	// 设备高度 rpx
	myHeight: uni.getSystemInfoSync().windowHeight * (750 / uni.getSystemInfoSync().windowWidth),
	// 设备宽度 px
	myWidth: uni.getSystemInfoSync().windowWidth,
	// 导航栏高度 rpx
	statusBarHeight: uni.getSystemInfoSync().statusBarHeight * (750 / uni.getSystemInfoSync().windowWidth),
	// 屏幕高度 rpx
	mySHeight: (uni.getSystemInfoSync().screenHeight-50) * (750 / uni.getSystemInfoSync().windowWidth),
	
	// app_id
	app_id: uni.getSystemInfoSync().platform=='android'?100:101,
	// client_id
	client_id: 100000,
	// 是否刷新用户信息
	isRefresh:false,
	// 用户信息
	userInfo: {},
	// 用户定制数据
	userFormat: {},
	// cc 记录登录token
	user_token: '',
	downLoadList: [],
	yqinfo: null,  //邀请信息
	deviceinfo: {},  //设备手机信息
	deviceidinfo: {} ,//设备ID信息
	activeList:[]	//活动开关信息
}

