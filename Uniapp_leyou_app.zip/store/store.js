import Vue from 'vue'
import Vuex from 'vuex'
Vue.use(Vuex);

import state from "./state.js"
import mutations from "./mutations.js"

const store = new Vuex.Store({
	state,
	mutations,
	actions:{
		navFilter({},data) {
			let list = state.activeList
			let index = list.findIndex(item=> item.id == data.id)
			let url = data.url
			if(list[index].status == 1){
				uni.navigateTo({
					url
				})
			}else{
				uni.showToast({
					title:'活动已结束',
					icon:'none'
				})
			}
		}
	}
})

export default store
