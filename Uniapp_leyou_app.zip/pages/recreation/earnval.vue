<template>
	<view class="container">
		<view class="">
			<scroll-view scroll-y="true" class="scroll-Y">
				<view class="m-v-30">
					<swiper class="h-260" @change="changeSwiper" :current="swiper_index" previous-margin="40rpx" next-margin="40rpx">
						<swiper-item v-for="(item,index) in swiperList" :key="index">
							<view class="swiper_box m-h-15">
								<image class="swiper_bgImg" :src="`../../static/images/recreation/earnval/level_bg${index+1}.png`"></image>
								<view class="left_box">
									<view class="d_flex f-a-c">
										<text class="current_level" :class="'current_bgColor'+ (index+1)">{{ userInfo.wallet.vip_lv ==item.level ? '当前星级' : (userInfo.wallet.vip_lv < item.level) ? '未达成' :'已达成'}}</text>
										<text v-if="userInfo.wallet.vip_lv ==item.level" class="fz-30" :class="'fontColor'+ (index+1)">{{ item.level | formatLevel }}</text>
									</view>
									<view class="m-l-30" v-if="userInfo.wallet.vip_lv == item.level">
										<view class="m-t-30" v-if="!swiperList[index+1]">
											<text class="fz-50 fz-w" :class="'fontColor'+ (index+1)">已达到最高等级</text>
										</view>
										<view class="d_flex f-c m-l-30" v-else>
											<text class="fz-24 m-t-20" :class="'fontColor'+ (index+1)">升级还需{{ (swiperList[index+1].threshold - userInfo.wallet.earnval) }}经验值</text>
											<view class="d_column m-v-20">
												<u-line-progress :percentage="(((userInfo.wallet.earnval) / (swiperList[index+1].threshold))* 100)" :showText="false" :inactiveColor="index | progressColor" :activeColor="index | progressActiveColor"  />
											</view>
											<view class="d_flex f-r-c-b">
												<text @click="handleRouter('/pages/my/detail/earnvalDetail')" class="fz-28" :class="'fontColor'+ (index+1)">{{ userInfo.wallet.earnval }}/{{ (swiperList[index+1].threshold) }}</text>
												<view class="d_flex f-r f-a-c" @click="popup_type = 1">
													<text class="fz-26 m-r-5" :class="'fontColor'+ (index+1)">保级至{{ next_retain }}</text>
													<u-icon name="info-circle" size="25" :color="index | progressColor" bold></u-icon>
												</view>
											</view>
										</view>
									</view>
									<view v-else class="f-c m-l-30 m-t-30">
										<text class="fz-50 fz-w" :class="'fontColor'+ (index+1)">{{ item.level | formatLevel }}</text>
										<text class="fz-26" :class="'fontColor'+ (index+1)">{{ (userInfo.wallet.vip_lv < item.level) ? `经验值达到${ item.threshold }可升级` : '已超越该等级' }}</text>
									</view>
								</view>
								<image class="level_img" :src="`../../static/images/recreation/earnval/level_icon${index}.png`" mode="widthFix"></image>
							</view>
						</swiper-item>
					</swiper>
				</view>
				<view class="earnval_box">
					<!-- 当前权益 -->
					<view class="rights">
						<view class="f-r-c-b">
							<text class="fz-32 c-3 fz-w">当前权益</text>
							<view class="d_flex f-a-c" @click="handleRouter('/pages/recreation/levelRights',0)">
								<text class="fz-24 c-6">权益介绍</text>
								<u-icon name="arrow-right" size="25" color="#333" bold></u-icon>
							</view>
						</view>
						<view class="f-r f-a-c m-v-20">
							<view @click="handleRouter('/pages/recreation/levelRights',index)" class="rights_item p-r m-r-30" v-for="(item,index) in list" :key="index">
								<image class="img" :src="(swiper_index==0 && index < 2) ? `../../static/images/recreation/earnval/levelRights_icon${index+1}.png` : `../../static/images/recreation/earnval/levelRights_activeIcon${index+1}.png`"></image>
								<text class="fz-28 fz-w m-v-5" :class="(swiper_index==0 && index < 2) ? 'c-9' : 'c-3'">{{ item.title }}</text>
								<text class="fz-22" :class="(swiper_index==0 && index < 2) ? 'c-9' : 'fontColor'">{{ item.info }}</text>
								<text v-if="(swiper_index >0 && index < 2)" class="text">{{ swiper_index }}星</text>
							</view>
						</view>
					</view>
					<!-- 任务 -->
					<view class="task_box">
						<view class="m-v-30">
							<text class="fz-36 c-3 fz-w">每日升级任务</text>
						</view>
						<view class="task_box_item" v-for="(item,index) in taskList" :key="index">
							<view class="f-1 f-c">
								<text class="fz-28 c-3 fz-w">{{ item.name }}</text>
								<view class="f-r f-a-c m-t-10">
									<view class="f-r f-a-e" v-if="item.badge">
										<image class="h-40 w-56" src="@/static/images/recreation/zs.png"></image>
										<text class="fz-24 fz-w" style="color: #F3700f;">x{{ item.badge }}</text>
									</view>
									<view class="f-r f-a-e m-l-10" v-if="item.earnval">
										<image class="h-40 w-59"  src="@/static/images/recreation/exp1.png"></image>
										<text class="fz-24 fz-w" style="color: #F3700f;">x{{ item.earnval }}</text>
									</view>
								</view>
							</view>
							<view @click="receive(item)" class="task_box_btn" :class="(item.status==0 || item.status==1) ? 'active' : 'default' ">
								<text class="fz-28 c-f">{{ item.status==0 ? '去完成' : item.status==1 ? '可领奖' : '已完成' }}</text>
							</view>
						</view>
					</view>
				</view>
			</scroll-view>
		</view>
		<view>
			<u-popup :show="popup_type == 1" mode="center" bgColor="transparent" overlayOpacity="0.8">
				<view class="popup_box f-j-c f-a-c">
					<view class="f-c f-j-c f-a-c">
						<text class="fz-30 c-3 fz-w">活跃要求</text>
						<view class="f-c m-v-30">
							<text class="fz-28 c-3 lh-40">系统每隔30天根据用户活跃经验值和当前等级发放对应的活跃礼包</text>
						</view>
						<view class="popup_btn" @click="popup_type = 0">
							<text class="fz-30 c-f">确认</text>
						</view>
					</view>
				</view>
			</u-popup>
		</view>
	</view>
</template>

<script>
	import common from "@/common/js/common.js";
	import {	$api	} from '@/config/api.js';
	import { mapState , mapMutations } from 'vuex';
	export default {
		data() {
			return {
				list:[{
					title:'升级奖励',
					info:'钻石/提现劵'
				},{
					title:'活跃奖励',
					info:'钻石/提现劵'
				}],
				next_retain:'',
				taskList:[],
				swiperList:[],
				swiper_index:0,
				popup_type:0
			}
		},
		computed: {
			...mapState(['userInfo','mySHeight','statusBarHeight'])
		},
		filters:{
			formatLevel(value){
				switch (value){
					case 0:
						return '普通用户'
						break;
					case 1:
						return '一星用户'
						break;
					case 2:
						return '二星用户'
						break;
					case 3:
						return '三星用户'
						break;
					case 4:
						return '四星用户'
						break;
					case 5:
						return '五星用户'
						break;
					case 6:
						return '六星用户'
						break;
					case 7:
						return '七星用户'
						break;
					case 8:
						return '八星用户'
						break;
					default:
						break;
				}
			},
			progressColor(index){
				if(index == 0){
					return '#181818'
				}else if(index == 1){
					return '#1d1d1d'
				}else if(index == 2){
					return '#002418'
				}else if(index == 3){
					return '#001b30'
				}else if(index == 4){
					return '#140036'
				}else if(index == 5){
					return '#5b3100'
				}else if(index == 6){
					return '#500000'
				}else if(index == 7){
					return '#4a3600'
				}else if(index == 8){
					return '#dac07d'
				}
			},
			progressActiveColor(index){
				if(index == 0){
					return '#f5f5f5'
				}else if(index == 1){
					return '#f5f5f5'
				}else if(index == 2){
					return '#d8fff2'
				}else if(index == 3){
					return '#c6e6ff'
				}else if(index == 4){
					return '#decaff'
				}else if(index == 5){
					return '#ffddb5'
				}else if(index == 6){
					return '#ffcbcb'
				}else if(index == 7){
					return '#fff2d1'
				}else if(index == 8){
					return '#fff4d7'
				}
			}
		},
		onLoad() {
			console.log('userInfo',this.userInfo)
			this.swiper_index = this.userInfo.wallet.vip_lv
			this.getList();
			this.getTaskList()
		},
		methods:{
			getList(){
				$api.post("api.star/equity").then(res=>{
					console.log('res',res)
					res = res.data
					if(res.code ==200){
						this.swiperList = res.data.list
						this.next_retain = res.data.next_retain
					}else{
						uni.showToast({
							title:res.msg,
							icon:'none'
						})
					}
				})
				.catch(error=>{
					uni.showToast({
						title:'请求失败，请稍后再试',
						icon:'none'
					})
					console.error(error)
				})
			},
			getTaskList(){
				$api.post("api.star/task").then(res=>{
					console.log('res',res)
					res = res.data
					if(res.code ==200){
						this.taskList = res.data.list
					}else{
						uni.showToast({
							title:res.msg,
							icon:'none'
						})
					}
				})
				.catch(error=>{
					uni.showToast({
						title:'请求失败，请稍后再试',
						icon:'none'
					})
					console.error(error)
				})
			},
			changeSwiper(e){
				this.swiper_index = e.detail.current
			},
			handleRouter(url,index=null){
				if(index>=0){
					uni.navigateTo({
						url: url +'?index='+ index
					})
				}else{
					uni.navigateTo({
						url: url
					})
				}
			},
			handleClick(){
				
			},
			// 领取任务奖励
			receive(data){
				if(data.status==2){
					return
				}else if(data.status==0){
					common.routeJump(data.pathurl)
					this.task_popup = false
				}else{
					$api.post("api.star/task_comp",{
						id:data.id
					}).then(res=>{
						console.log('res',res)
						res = res.data
						if(res.code ==200){
							this.taskList.forEach((item,index)=>{
								if(item.id == res.data.id){
									item.status = 2
								}
							})
							$api.post("api.member/info").then(res=>{
								res = res.data
								if(res.code == 200){
									this.$store.commit("setUserInfo", res.data)
								}
							})
						}else{
							uni.showToast({
								title:res.msg,
								icon:'none'
							})
						}
					})
					.catch(error=>{
						uni.showToast({
							title:'请求失败，请稍后再试',
							icon:'none'
						})
						console.error(error)
					})
				}
			},
		}
	}
</script>

<style lang="scss" scoped>
.container{
	flex: 1;
	background-color: #333;
}
.d_flex{
	display: flex;
}
.d_column{
	display: flex;
	flex-direction: column;
}
.swiper_box{
	position: relative;
	display: flex;
	align-items: center;
	justify-content: space-between;
	height: 260rpx;
	border-radius: 20rpx;
	// background-color: #ffd6cd;
	padding: 20rpx 20rpx 20rpx 0;
	.swiper_bgImg{
		position: absolute;
		width: 650rpx;
		height: 260rpx;
		top: 0;
		left: 0;
		z-index: 1;
	}
	.left_box{
		width: 550rpx;
		height: 260rpx;
		display: flex;
		flex-direction: column;
		margin-right: 20rpx;
		z-index: 2;
	}
	.current_level{
		border-radius: 0 20rpx 20rpx 0;
		padding: 5rpx 20rpx 5rpx 10rpx;
		margin-right: 6rpx;
		font-size: 22rpx;
		color: #FFFFFF;
		box-sizing: border-box;
	}
	.current_bgColor1{
		background-color: #7a7a7a;
	}
	.current_bgColor2{
		background-color: #191919;
	}
	.current_bgColor3{
		background-color: #4d917a;
	}
	.current_bgColor4{
		background-color: #4a708c;
	}
	.current_bgColor5{
		background-color: #6c5297;
	}
	.current_bgColor6{
		background-color: #e57c00;
	}
	.current_bgColor7{
		background-color: #cd2f2f;
	}
	.current_bgColor8{
		background-color: #cea640;
	}
	.current_bgColor9{
		background-color: #a58e53;
	}
	.fontColor1{
		color: #181818;
	}
	.fontColor2{
		color: #1d1d1d;
	}
	.fontColor3{
		color: #002418;
	}
	.fontColor4{
		color: #001b30;
	}
	.fontColor5{
		color: #140036;
	}
	.fontColor6{
		color: #5b3100;
	}
	.fontColor7{
		color: #500000;
	}
	.fontColor8{
		color: #4a3600;
	}
	.fontColor9{
		color: #dac07d;
	}
	.level_img{
		width: 200rpx;
		z-index: 2;
		margin-bottom: 30rpx;
	}
}
.earnval_box{
	background-color: #F2F2F2;
	border-radius: 30rpx 30rpx 0 0;
	padding: 30rpx 30rpx 50rpx 30rpx;
	box-sizing: border-box;
	.rights{
		background-color: #FFFFFF;
		border-radius: 10rpx;
		box-sizing: border-box;
		padding: 25rpx 30rpx;
		.rights_item{
			width: 150rpx;
			display: flex;
			flex-direction: column;
			align-items: center;
			.img{
				width: 60rpx;
				height: 60rpx;
			}
			.text{
				position: absolute;
				top: 0;
				right: 20rpx;
				padding: 3rpx 12rpx;
				border-radius: 20rpx;
				background-color: #FF0000;
				font-size: 20rpx;
				line-height: 25rpx;
				text-align: center;
				color: #FFFFFF;
			}
			.fontColor{
				color: #ffaa00;
			}
		}
	}
}
// 任务列表
.task_box{
	.task_box_img{
		display: flex;
		align-items: center;
		justify-content: center;
	}
	&_item{
		background-color: #FFFFFF;
		border-radius: 20rpx;
		margin-bottom: 20rpx;
		padding: 30rpx 20rpx;
		display: flex;
		flex-direction: row;
		flex-wrap: wrap;
		align-items: center;
		justify-content: space-between;
	}
	&_img{
		width: 70rpx;
		height: 70rpx;
		margin-right: 20rpx;
		background-color: #F3F3F3;
		border-radius: 70rpx;
		align-items: center;
		justify-content: center;
	}
	&_btn{
		width: 130rpx;
		height: 50rpx;
		border-radius: 30rpx;
		display: flex;
		align-items: center;
		justify-content: center;
	}
	.active{
		background-color: #FF6040;
	}
	.default{
		background-color: #DCDCDC;
	}
}
// 弹出层
.popup_box{
	width: 550rpx;
	padding: 60rpx 50rpx 30rpx;
	border-radius: 30rpx;
	background-color: #FFFFFF;
	align-items: center;
	justify-content: center;
	.popup_btn{
		width: 450rpx;
		height: 60rpx;
		line-height: 60rpx;
		text-align: center;
		align-items: center;
		justify-content: center;
		background-color: #FF5927;
		border-radius: 50rpx;
	}
}
</style>