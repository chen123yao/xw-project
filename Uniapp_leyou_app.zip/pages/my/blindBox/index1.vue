<template>
	<view class="container f-c">
		<nvue-navBar bgColor="#fff" title="开盲盒领惊喜大奖" txtColor="#333" backIconColor="#333"></nvue-navBar>
		<view class="blindBox f-c">
			<view class="table">
				<view class="item f-c" :class="{active:currentIndex==index}" @click="handleActive(0,index)" v-for="(item,index) in pageData" :key="index">
					<text class="fz-28 c-f">{{item.name}}</text>
				</view>
			</view>
			<view class="swiper-box f-c">
				<swiper class="swiper f-c" :current="currentIndex" @change="change" next-margin="100rpx" previous-margin="150rpx">
					<swiper-item v-for="(item,index) in pageData" :key="index">
						<view class="swiper-item f-c">
							<image :src="item.icon" mode="aspectFit" style="width: 100%;"></image>
						</view>
					</swiper-item>
				</swiper>
				<view class="swiperBtn f-c" style="left: 32rpx;" @click="handleActive(1)"></view>
				<view class="swiperBtn f-c" style="right: 32rpx;" @click="handleActive(2)"></view>
			</view>
			<view class="withDraw f-c">
				<view class="f-r p-r p-h-10" style="height: 50rpx;align-items: center;">
					<view class="ingot-box f-c">
						<text class="fz-28" style="color: #1676b2;">{{userInfo.wallet.ingot}}</text>
					</view>
					<image src="@/static/images/mall/egg1.png" mode="heightFix" class="egg-img"></image>
				</view>
				<view class="f-r f-a-c m-t-20">
					<view class="p-10 f-j-c f-c">
						<text class="c-f">本</text>
						<text class="c-f">期</text>
						<text class="c-f">奖</text>
						<text class="c-f">品</text>
					</view>
					<view class="f-1 p-20 f-c" style="background-color: #6a9ff1;">						
						<scroll-view class="prize-list" scroll-x="true" v-if="pageData.length">
							<view class="item" v-for="(item,index) in pageData[currentIndex].award_cfg">
								<image :src="item.icon" mode="aspectFit" class="w-100 h-100" style="display: block;margin: 0 auto;"></image>
								<view class="f-r-c-c">
									<text class="fz-28 c-theme t-a-c" style="white-space: normal;">{{item.title}}</text>
								</view>
							</view>
						</scroll-view>
					</view>
				</view>
				<view class="withDraw-btn">
					<view class="w-100"></view>
					<view class="f-1 f-r-c-c btn" @click="openBlindBox()">
						<text class="t-a-c" v-if="pageData.length">{{pageData[currentIndex].ingot}}元宝开盲盒</text>
					</view>
					<view class="record" @click="handleRouter('/pages/my/blindBox/blindBoxRecord')">
						<text class="fz-28 c-f t-a-c">盲盒记录</text>
					</view>
				</view>
			</view>
		</view>
		<view class="tips-box">
			<text class="t-a-c c-f">活动攻略</text>
			<view class="m-t-40">
				<rich-text :nodes="tips"></rich-text>
			</view>
		</view>
	</view>
</template>

<script>
	import {	$api	} from '@/config/api.js';
	import { mapState } from 'vuex';
	import common from "@/common/js/common.js";
	export default {
		data() {
			return {
				pageData: [],
				currentIndex: 0,
				blindBoxId: 1,
				tips: ''
			}
		},
		computed: {
			...mapState(['userInfo']),
		},
		methods: {
			handleRouter(url){
				uni.navigateTo({
					url
				})
			},
			getPageData() {		//盲盒数据
				$api.get("api.blindbox/index").then(res=>{
					console.log(res);
					if(res.data.code == 200) {
						this.pageData = res.data.data.list
						this.blindBoxId = this.pageData[0].id
						this.tips = res.data.data.tips
					}
				}).catch(err=>{
					console.log(err);
				})
			},
			handleActive(type,index) {
				if(type==1) {
					this.currentIndex--
					if(this.currentIndex<=0) {
						this.currentIndex =0
					}
				} else if(type==2) {
					this.currentIndex++
					if(this.currentIndex>=this.pageData.length-1) {
						this.currentIndex = this.pageData.length-1
					}
				} else {
					this.currentIndex = index
				}
				this.blindBoxId = this.pageData[this.currentIndex].id
			},
			change(e) {
				this.currentIndex = e.detail.current
				this.blindBoxId = this.pageData[this.currentIndex].id
			},
			openBlindBox() {
				$api.get("api.blindbox/open",{id:this.blindBoxId}).then(res=>{
					console.log(res,'中奖信息');
					if(res.data.code == 200) {
						uni.showToast({
							title: res.data.data.title,
							icon: 'none'
						})
						common.getuserInfo()
					} else {
						uni.showToast({
							title: res.data.msg,
							icon: 'none'
						})
					}
				}).catch(err=>{
					console.log(err);
				})
			}
		},
		onLoad(){
			this.getPageData()
		}
	}
</script>

<style lang="scss"  scoped>
.blindBox {
	height: 1200rpx;
	align-items: center;
	background-color: aqua;
	.table {
		width: 500rpx;
		height: 64rpx;
		/*  #ifndef  APP-NVUE  */
		display: flex;
		box-sizing: border-box;
		/*  #endif  */
		flex-direction: row;
		align-items: center;
		justify-content: center;
		margin-top: 160rpx;
		border: 4rpx solid #fff;
		border-radius: 68rpx;
		.item {
			flex: 1;
			height: 60rpx;
			align-items: center;
			justify-content: center;
			border-radius: 68rpx;
			&.active {
				background-color: #feae01;
			}
		}
	}
	.swiper-box {
		width: 750rpx;
		padding: 40rpx;
		position: relative;
		align-items: center;
		.swiper {
			width: 750rpx;
			height: 400rpx;
			.swiper-item {
				width: 450rpx;
				height: 360rpx;
			}
		}
		.swiperBtn {
			position: absolute;
			top: 180rpx;
			width: 80rpx;
			height: 80rpx;
			background-color: blue;
		}
	}
	.withDraw {
		width: 686rpx;
		.ingot-box {
			width: 260rpx;
			height: 30rpx;
			justify-content: center;
			background-color: #94d1f6;
			border-radius: 30rpx;
			padding-left: 40rpx;
		}
		.egg-img {
			position: absolute;
			left: 0;
			top: 0;
			height: 50rpx;
		}
		.prize-list {
			/*  #ifndef  APP-NVUE  */
			width: 600rpx;
			display: flex;
			overflow: hidden;
			box-sizing: border-box;
			/*  #endif  */
			flex-direction: row;
			align-items: flex-start;
			justify-content: flex-start;
			height: 200rpx;
			white-space: nowrap;
			.item {
				display: inline-block;
				width: 190rpx;
				height: 200rpx;
				padding: 20rpx 30rpx 10rpx;
				/*  #ifndef  APP-NVUE  */
				box-sizing: border-box;
				overflow: hidden;
				/*  #endif  */
				text-align: center;
				margin-right: 10rpx;
				border-radius: 10rpx;
				background-color: #fff;
			}
		}
		.withDraw-btn {
			height: 160rpx;
			display: flex;
			justify-content: space-between;
			align-items: flex-end;
			.btn {
				height: 140rpx;
				background-image: linear-gradient(to right,#fa8d93,#65cbfa);
			}
			.record {
				width: 160rpx;
				height: 60rpx;
				display: flex;
				align-items: center;
				justify-content: center;
			}
		}
	}
}
.tips-box {
	display: flex;
	flex-direction: column;
	align-items: center;
	padding: 60rpx;
	background-color: #b5dff7;
}
</style>