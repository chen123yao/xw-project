import Request from '@/utils/luch-request/index.js'
import Store from "@/store/store.js"
import common from "@/common/js/common.js";


const api = new Request()
export {
	api
}

api.setConfig((config) => {
	/* config 为默认全局配置*/
	config.baseURL = Store.state.httpAPI  /* 根域名 */
	config.header = {
		'X-Requested-With': 'XMLHttpRequest',
		'xwHerderToken':'xwHerderToken',
		"Accept": "application/json",
		"Content-Type": "application/json; charset=UTF-8"
	}
	return config
})
//请求前拦截
api.interceptors.request.use((config) => { // 可使用async await 做异步操作
  let Store = getApp().globalData.store
	config.header = {
		...config.header,
		paramsInfo: JSON.stringify({
			...Store.state.deviceinfo,  //设备手机信息
			...Store.state.deviceidinfo,  //设备id信息			
		}),
		yqinfo: Store.state.yqinfo
	}
	config.params = {
		format: 'json',
		token: Store.state.user_token,
		client_id: Store.state.client_id, // 渠道号  Store.state.client_id
		app_id: Store.state.app_id, // 手机号 100  101   Store.state.app_id
		ts: Date.parse(new Date()),
		...config.params
	}
	//获取存储的token
	// const token = uni.getStorageSync('token');
	// config.header.token = token;
	return config
}, config => { // 可使用async await 做异步操作
	return Promise.reject(config)
})


// 请求后拦截器

api.interceptors.response.use(
  response => {
	if(response.data.code ==10401 || response.data.code == 10402){
		const jump = uni.getStorageSync('jump')
		if(!jump){
			setTimeout(()=>{
				uni.showToast({
					title:response.data.msg,
					icon:'none',
					success:res=>{
						common.logOut();
					}
				})
			},300)
			uni.setStorageSync('jump',true)
		}
	}
    return response
},error=>{
	console.log('error',error)
	//未登录时清空缓存跳转
	if(response.data.code ==10401 || response.data.code == 10402){
		common.logOut();
	}
	return Promise.reject(error)
})
