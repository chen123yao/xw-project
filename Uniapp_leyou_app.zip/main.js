import App from './App'

// #ifndef VUE3

// cc 引入全局公共方法-common
import common from "@/common/js/common.js"
Vue.prototype.$common = common

// cc 引入全局请求-api
import api from "@/config/api.js"
Vue.prototype.$api = api

// cc 引入vuex
import store from "@/store/store.js"
Vue.prototype.$store = store

// cc 引入ui组件
import uView from "@/uni_modules/uview-ui";
Vue.use(uView)

// 调用setConfig方法，方法内部会进行对象属性深度合并，可以放心嵌套配置
// 需要在Vue.use(uView)之后执行
uni.$u.setConfig({
	// 修改$u.config对象的属性
	config: {
		// 修改默认单位为rpx，相当于执行 uni.$u.config.unit = 'rpx'
		unit: 'rpx'
	}
})

// cc 引入全局的过滤器 filter
import filters from "@/common/js/filters.js"
for (let i in filters) {
	Vue.filter(i, filters[i])
}

import Vue from 'vue'
// 让app的onLaunch先执行，主要是用来进行登录
Vue.prototype.$onLaunched = new Promise(resolve => {
    Vue.prototype.$isResolve = resolve
})
Vue.config.productionTip = false
App.mpType = 'app'
const app = new Vue({
    ...App
})
app.$mount()
// #endif

// #ifdef VUE3
import { createSSRApp } from 'vue'
export function createApp() {
  const app = createSSRApp(App)
  return {
    app
  }
}
// #endif