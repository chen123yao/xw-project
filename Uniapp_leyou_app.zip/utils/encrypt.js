import { JSEncrypt } from 'jsencrypt'

// 公钥
const key = `-----BEGIN PUBLIC KEY-----
MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDgEWQPSN9Kd1LOLRlS1YB0SM5d
zTwRSNKS2SaCJKDHAS6a57wXHb/LhWlas55HpQxfzS5xPUtVX3f0MqnDvP3a/80a
MscaZKuPkyKODMXUIFj+7dKcIfOL+CMhsf7Q7T88TsSSKVr4T04fARFgO6F3GxhA
Te+IjykX6+cu56SnMwIDAQAB
-----END PUBLIC KEY-----`

// 加密
export function setEncrypt (msg) {
  const jsencrypt = new JSEncrypt()
  jsencrypt.setPublicKey(key)
  return jsencrypt.encrypt(msg)
}

