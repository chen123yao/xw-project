/*
 * 全局公用方法
 */

import Router from '@/router'
import Store from '@/store/store';
import uniCopy from '@/js_sdk/xb-copy/uni-copy.js'
const crypto = require('crypto');

export default {
	// 数组去重
	arrayDuplicate(arr) {
		let result = []
		let obj = {}
		for (let i of arr) {
			if (!obj[i]) {
				result.push(i)
				obj[i] = 1
			}
		}
		return result
	},
	// 保留小数
	keepDecimal(value, num) {
		return Number(value).toFixed(num);
	},
	// 复制
	copy(content) {
		uniCopy({
			content: content,
			success: res => {
				uni.showToast({
					title: "复制成功"
				})
			}
		})
	},
	// 路由跳转
	routerTo(params) {
		Router.push(params);
	},
	nativeRouterTo(params) {
		uni.navigateTo({
			...params,
			animationType: "pop-in",
			animationDuration: 300
		})
	},
	// 返回
	routerBack(index = 1) {
		uni.navigateBack({
			delta: index
		})
	},
	// 跳转到tab页面
	routerToTab(params) {
		uni.switchTab(params);
	},
	// 检测是否登录
	isLogin() {
		if (!Store.state.loginInfo.user_token) {
			Router.push({
				name: "login"
			});
			return false;
		}
	},
	//加密
	aesEncrypt(data, key) {
		try {
			var salt = key.toString() + 'dyyz'; // 定义盐值
			const cipher = crypto.createCipher('aes192', salt); // 采用aes192加密方式
			var crypted = cipher.update(data, 'utf8', 'hex'); // 加密
			crypted += cipher.final('hex');
			return crypted;
		} catch (e) { // 加捕获是为了在验证失败的时候，直接让用户重新登陆
			// alert("检测到存在安全异常，请检查当前网络环境并重新登录！");
			// window.location.href = '/login'
		}

	},
	
	//解密
	aesDecrypt(encrypted, key) {
		try {
			var salt = key.toString() + 'dyyz'; // 定义盐值
			const decipher = crypto.createDecipher('aes192', salt); // 解密 aes192
			var decrypted = decipher.update(encrypted, 'hex', 'utf8'); //解密
			decrypted += decipher.final('utf8');
			return decrypted;
		} catch (e) { // 加捕获是为了在验证失败的时候，直接让用户重新登陆
			// console.log("error*-**--*-")
			// alert("检测到存在安全异常，请检查当前网络环境并重新登录！");
			// window.location.href = '/login';
		}
	},

	// 时间格式
	dateFormat(value, fmt) {
		let getDate = new Date(value * 1000);
		let o = {
			"M+": getDate.getMonth() + 1,
			"d+": getDate.getDate(),
			"h+": getDate.getHours(),
			"m+": getDate.getMinutes(),
			"s+": getDate.getSeconds(),
			"q+": Math.floor((getDate.getMonth() + 3) / 3),
			S: getDate.getMilliseconds(),
		};
		if (/(y+)/.test(fmt)) {
			fmt = fmt.replace(
				RegExp.$1,
				(getDate.getFullYear() + "").substr(4 - RegExp.$1.length)
			);
		}
		for (let k in o) {
			if (new RegExp("(" + k + ")").test(fmt)) {
				fmt = fmt.replace(
					RegExp.$1,
					RegExp.$1.length === 1 ?
					o[k] :
					("00" + o[k]).substr(("" + o[k]).length)
				);
			}
		}
		return fmt;
	},
	// 标签显示万+
	numberTag(val) {
		let str;
		switch (true) {
			case val < 1000:
				str = val;
				break;
			case val >= 1000 && val < 10000:
				str = Math.floor(val / 1000) + "千+";
				break;
			case val >= 10000 && val < val < 1000000:
				str = Math.floor(val / 10000) + "万+";
				break;
			case val >= 1000000:
				str = Math.floor(val / 1000000) + "百万+";
				break;
		}

		return str;
	},
	// 读取主域名
	getDomainName() {
		let link = location.host;
		let arr = link.split('.');

		// 判断是否是数字开头域名
		if (!isNaN(arr[0])) {
			arr.splice(0, 2)
			link = arr.join('.');
		} else if (arr[0] == 'm') {
			arr.shift();
			link = arr.join('.');
		}
		return link;
	},

	// 存入本地数据
	setStorage(key, data) {
		uni.setStorageSync(key, data);
	},
	// 导出本地数据
	getStorage(key) {
		return uni.getStorageSync(key);
	},
	// 移除本地数据
	removeStorage(key) {
		uni.removeStorageSync(key);
	},
	// 对象数组去重
	uniqObj(arr) {
		var result = [];
		var obj = {};
		for (var i = 0; i < arr.length; i++) {
			if (!obj[arr[i].game_id]) {
				result.push(arr[i]);
				obj[arr[i].game_id] = true;
			}
		}
		return result;
	},

	// 判断图片是不是带有http
	hasHttp(url) {
		let str = url.substr(0, 4);
		if (str != 'http' && str != 'Http') {
			str = 'http:' + url;
			return str;
		}
		return url;
	},

	// 防抖函数：触发高频事件后一段时间（wait）只会执行一次函数，如果指定时间（wait）内高频事件再次被触发，则重新计算时间。
	debounce(func, wait) {
		let timeout = null;
		return function() {
			let context = this;
			let args = arguments;
			if (timeout) clearTimeout(timeout);
			timeout = setTimeout(() => {
				func.apply(context, args)
			}, wait);
		}
	},
	// 节流函数：规定在一个单位时间内，只能触发一次函数。如果这个单位时间内触发多次函数，只有一次生效
	throttle(func, wait) {
		let timeout = null;
		return function() {
			let context = this;
			let args = arguments;
			if (!timeout) {
				timeout = setTimeout(() => {
					timeout = null;
					func.apply(context, args)
				}, wait)
			}
		}
	},
	// 预览图片
	previewImage(index, arr) {
		//uniapp预览图片
		uni.previewImage({
			current: index, //预览图片的下标
			urls: arr, //预览图片的地址，必须要数组形式，如果不是数组形式就转换成数组形式就可以
			indicator: 'number'
		});
	}


}
