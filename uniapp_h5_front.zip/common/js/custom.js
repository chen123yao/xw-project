/*
* 全局定制方法
*/

import Router from '@/router'
import Store from '@/store/store';
import Common from "./common.js";

import md5 from 'js-md5'

export default {
	setGameDownLoad(item){
		// 将要下载的游戏存储起来（storage和vuex）
		// 1.获取下载游戏记录
		let gamesDownload = Common.getStorage('gamesDownload');
		let storeDownload = Store.state.gameProgressList;
		let downTasksArray = Store.state.downTasks;
		if(gamesDownload){
			gamesDownload = JSON.parse(gamesDownload);
		}else{
			gamesDownload = [];
		}
		
		// 遍历数组，如果点击下载的这个game_id已经存在，则不执行以下操作，防止对同一个游戏同时进行多次下载
		let hasGameId = gamesDownload.some((val,index)=>{
			return val.game_id == item.game_id
		})
		
		if(!hasGameId){
			// 1.游戏加入数组
			gamesDownload.push(item);
			storeDownload.push({
				game_id: item.game_id,
				downStatus: 0,
				downStatusText: "准备下载",
				filename: ""
			})
			downTasksArray.push({
				game_id: item.game_id,
				downloadTask: null
			})
			// 2.将数组转换为字符串
			gamesDownload = JSON.stringify(gamesDownload);
			// 3.将字符串存入storage和vuex
			Common.setStorage('gamesDownload', gamesDownload)
			Store.commit('setGameProgressList', storeDownload)
			Store.commit('setDownTasks', downTasksArray)
		}
	},
	
	// 随机字符串
	randomString(len) {
		len = len || 32;
		let $chars = 'ABCDEFGHJKMNPQRSTWXYZabcdefhijkmnprstwxyz2345678';    /****默认去掉了容易混淆的字符oOLl,9gq,Vv,Uu,I1****/
		let maxPos = $chars.length;
		let pwd = '';
		for (let i = 0; i < len; i++) {
			pwd += $chars.charAt(Math.floor(Math.random() * maxPos));
		}
		return pwd;
	},
	
	// 生成下载鉴权sign
	downLoadUrl_sign() {
		let key = 'QyWbpzcfbJgtppSA';
		let code = this.randomString(5);
		let timestamp = Date.parse(new Date()) / 1000;
		let sign_key = String(timestamp.toString() + key + code);
		let sign1 = md5(code + timestamp + sign_key);
		let sign = code + '-' + timestamp + '-' + sign1;
		return sign;
	}
}