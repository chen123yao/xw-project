/*
 * tab-swiper公用部分混入
 */
import {
	mapState
} from "vuex";
export const myStore = {
	computed: {
		...mapState({
			platform: "platform",
			systemInfoSync: "systemInfoSync",
			equipmentCode: "equipmentCode",
			userFormat: "userFormat",
			loginInfo: "loginInfo",
			userInfo: "userInfo",
			client_id: "client_id",
			game_id: "game_id",
			httpAPI: "httpAPI"
		}),
		
		equipmentCode(){
			return this.$store.state.equipmentCode.split(",")[0]
		}
	}
}

export const mySwiperTab = {
	data() {
		return {
			tabsCurrent: 0,
			swiperCurrent: 0,
		}
	},
	methods: {
		// 切换tab页面
		tabsChange(index) {
			this.tabsCurrent = index;
			this.swiperCurrent = index;
		},
		// swiper-item左右移动，通知tabs的滑块跟随移动
		transition(e) {
			let dx = e.detail.dx;
			this.$refs.uTabs.setDx(dx);
		},
		// 由于swiper的内部机制问题，快速切换swiper不会触发dx的连续变化，需要在结束时重置状态
		// swiper滑动结束，分别设置tabs和swiper的状态
		animationfinish(e) {
			let current = e.detail.current;
			this.$refs.uTabs.setFinishCurrent(current);
			this.swiperCurrent = current;
			this.tabsCurrent = current;
		},
	}
}

export const myLoading = {
	data() {
		return {
			iconType: 'flower',
			loadText: {
				loadmore: '点击或上拉加载更多',
				loading: '努力加载中',
				nomore: '实在没有了',
				
			}
		}
	}
}

export const tagTypes = {
	data(){
		return {
			tagTypes: [ "error", "success","warning", "primary","info"]
		}
	}
}

export const colors = {
	data(){
		return {
			colors: [
				"#f0932b",
				"#f9ca24",
				"#22a6b3",
				"#a29bfe",
				"#eb4d4b",
			]
		}
	}
}
