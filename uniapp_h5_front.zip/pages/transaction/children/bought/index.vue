<!-- 我买到的 -->
<template>
	<view class="container">
		<scroll-view scroll-y="true" style="width:100%;height:100%" @scrolltolower="loadMore" lower-threshold="100">
			<u-tabs :list="list" :is-scroll="false" :current="current" active-color="#ff8500" bg-color="#f5f5f5" @change="change"></u-tabs>

			<xw-saleorderlist :list="pageData"></xw-saleorderlist>
			
			<u-loadmore bg-color="#f5f5f5" :status="status" :icon-type="iconType" :load-text="loadText" @loadmore="loadMore"
			 v-if="pageData.length" />
		</scroll-view>
	</view>
</template>

<script>
	import {
		myLoading
	} from "@/common/js/mixin.js";

	export default {
		mixins: [myLoading],
		data() {
			return {
				list: [{
					name: "全部",
					status: 0
				}, {
					name: "待付款",
					status: 1
				}, {
					name: "已付款",
					status: 2
				}],
				current: 0,
				status: "loadmore",

				params: {
					page: 1,
					offset: 20,
					status: 0
				},
				pageData: []
			}
		},
		methods: {
			// 获取订单信息
			getData(params) {
				this.$api({
					url: "account/order/list",
					method: "GET",
					data: params
				}).then(res => {
					this.pageData = this.pageData.concat(res.data.data.list);
					if (res.data.data.list.length < params.offset) {
						this.status = "nomore"
					}
				})
			},
			// 切换分栏
			change(index) {
				this.current = index;
				this.resetData(index);
				this.getData(this.params);
			},
			// 重置数据
			resetData(index) {
				this.params = {
					page: 1,
					offset: 20,
					status: index
				};
				this.pageData = []
			},
			// 加载更多
			loadMore() {
				this.status = "loading";
				this.params.page++;
				this.getData(this.params);
			}
		},
		created() {
			this.getData(this.params);
		}
	}
</script>

<style lang="scss" scoped>
	.container {
		width: 100%;
		height: 100%;
	}
</style>
