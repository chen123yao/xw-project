<!-- 交易须知 -->
<template>
	<view class="container">
		<iframe :src="url" frameborder="0" width="100%" height="100%">暂无数据</iframe>
	</view>
</template>

<script>
	export default {
		computed: {
			url() {
				return this.httpAPI + '/account/deal/agreement?client_id=' + this.client_id;
			}
		}
	}
</script>
