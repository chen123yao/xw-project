<!-- 买号 -->
<template>
	<view>
		<u-row>
			<u-col span="5.5">
				<u-search placeholder="游戏搜索" :show-action="false" height="70" bg-color="#fff" :disabled="true" @click="common.routerTo({path: '/pages/views/search/index', query: {type: '交易'}})"></u-search>
			</u-col>
			<u-col span="5.5">
				<u-input v-model="value" type="text" :disabled="true" placeholder="最新上架" @click="show = true" :custom-style="customStyle"
				 input-align="center" placeholder-style="color:#909399" />
				<u-action-sheet :list="options" v-model="show" @click="sortSelect"></u-action-sheet>
			</u-col>
			<u-col span="1">
				<u-image src="@/static/image/wenhao.png" width="50" height="50" class="fr" @click="common.routerTo({name: 'instruction'})"></u-image>
			</u-col>
		</u-row>

		<xw-salelist v-if="transactionList.length" :list="transactionList"></xw-salelist>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				value: "",
				show: false,
				options: [{
					text: "最新上架",
					sort_type: 1
				}, {
					text: "价格由高到低",
					sort_type: 2
				}, {
					text: "价格由低到高",
					sort_type: 3
				}],

				customStyle: {
					'background': '#fff',
					'border-radius': '30rpx',
					padding: '0 10rpx',
					color: '#909399',
				},

				params: {
					page: 1,
					offset: 20,
					status: 2,
					sort_type: 1
				},
				transactionList: []
			}
		},
		methods: {
			getData(params) {
				this.$api({
					url: "account/goods/list",
					methods: "GET",
					data: params
				}).then(res => {
					this.transactionList = res.data.data.list
				})
			},
			sortSelect(index) {
				this.value = this.options[index].text;
				this.params.sort_type = this.options[index].sort_type;
				this.getData(this.params);
			}
		},
		created() {
			this.getData(this.params)
		}
	}
</script>

<style lang="scss" scoped>
</style>
