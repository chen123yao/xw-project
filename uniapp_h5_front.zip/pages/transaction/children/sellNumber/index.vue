<!-- 卖号 -->
<template>
	<view class="container">

		<view class="main">
			<u-cell-group>
				<u-cell-item title="添加游戏" :value="form.gamename" bg-color="#f5f5f5" @click="common.routerTo({name:'addGame'})"></u-cell-item>
				<u-cell-item title="添加小号" :arrow="false" bg-color="#f5f5f5">
					<view slot="right-icon">
						<u-input v-model="form.role_name" type="select" @click="numShow = true" placeholder="" placeholder-style="text-align:right;"
						 input-align="right" :custom-style="{color: '#909399'}" />
						<u-action-sheet :list="numOptions" v-model="numShow" @click="selectNumList"></u-action-sheet>
					</view>
				</u-cell-item>
				<u-cell-item title="添加区服" :arrow="false" bg-color="#f5f5f5">
					<view slot="right-icon">
						<u-input v-model="form.server_name" type="select" @click="serShow = true" placeholder="" placeholder-style="text-align:right;"
						 input-align="right" :custom-style="{color: '#909399'}" />
						<u-action-sheet :list="serOptions" v-model="serShow" @click="selectSerList"></u-action-sheet>
					</view>
				</u-cell-item>
				<u-cell-item title="价格" :arrow="false" bg-color="#f5f5f5">
					<u-input v-model="form.price" type="number" placeholder="请填写金额,最低6元" placeholder-style="text-align:right;" slot="right-icon"
					 input-align="right" />
				</u-cell-item>
				<u-cell-item title="标题" :arrow="false" bg-color="#f5f5f5">
					<u-input v-model="form.title" type="text" placeholder="请输入核心卖点" placeholder-style="text-align:right;" slot="right-icon"
					 input-align="right" />
				</u-cell-item>
				<u-cell-item title="描述" :arrow="false" bg-color="#f5f5f5" :border-bottom="false"></u-cell-item>
			</u-cell-group>
			<view style="padding:0 30rpx;margin-bottom:30rpx;">
				<u-input v-model="form.description" type="textarea" placeholder="可描述角色等级，装备，属性等，10-199字，完善描述可以快速有效的促成交易哦"></u-input>
			</view>

			<view>
				<u-upload ref="uUpload" :action="httpAPI + 'asset/upload'" upload-text="3-6张图片" max-count="6" @on-success="uploadSuccess" @on-remove="uploadRemove"
				 style="background-color: #fff;"></u-upload>
			</view>

			<!-- 卖家须知 -->
			<u-modal v-model="showNotice" title="卖家须知" :show-cancel-button="true" confirm-text="确认出售" confirm-color="#ff8500"
			 cancel-text="放弃出售" @confirm="verification">
				<view class="slot-content">
					<view>1.提交出售申请后，该小号在该游戏中所有区服的角色都将移除，无法登陆；</view>
					<view>2.上架的小号可以在买家购买前下架并取消出售，取消后会回到您的账号下。</view>
					<view>3.客服在审核过程中会根据情况对游戏截图，描述进行适当补充。</view>
					<view>4.一旦售出，不可恢复。</view>
					<view>5.售出将获得平台币，余款已平台币的形式转至该账号下，平台币不可提现，只能用于平台支付。</view>
				</view>
			</u-modal>

			<!-- 短信验证 -->
			<u-modal v-model="showVerification" title="卖家须知" :show-cancel-button="true" confirm-color="#ff8500" @confirm="handleSellOut">
				<view class="slot-content">
					<view>已经向您的手机号：{{userInfo.mobile}}发送验证码</view>
					<view>
						<u-field v-model="form['sms-code']" placeholder="请填写验证码" placeholder-style="color: #c0c4d4;" label-width="0">
							<u-button size="mini" slot="right" type="warning" @click="getCode">{{codeText}}</u-button>
						</u-field>
						<u-verification-code ref="uCode" @change="codeChange" unique-key="page-2" start-text="获取验证码" end-text="获取验证码"></u-verification-code>
					</view>
				</view>
			</u-modal>
		</view>

		<view class="btn">
			<xw-button @click="submitReview">提交审核</xw-button>
		</view>
	</view>
</template>

<script>
	import { mapState } from "vuex"
	export default {
		data() {
			return {
				form: {
					gamename: "选择游戏",
					role_name: "",
					mg_mem_id: "",
					mg_role_id: "",
					server_name: "",
					server_id: "",
					price: "",
					title: "",
					description: "",
					image: "",
					"sms-code": ""
				},

				numShow: false,
				numOptions: [],

				serShow: false,
				serOptions: [],

				fileList: [],

				showNotice: false,
				showVerification: false,

				codeText: "",
			}
		},
		computed: {
			selectedGame(){
				return this.$store.state.selectedGame;
			}
		},
		methods: {
			// 获取小号列表
			getNum(params) {
				this.$api({
					url: "user/account/list?game_id=6038",
					method: "GET",
					data: params
				}).then(res => {
					for (let val of res.data.data.list) {
						val["text"] = val.nickname + ":" + val.id;
					}
					this.numOptions = res.data.data.list;
				})
			},
			// 获取区服列表
			getServer(params) {
				this.$api({
					url: "user/server/list?mg_mem_id=464",
					method: "GET",
					data: params
				}).then(res => {
					if (res.data.data.list.length) {
						for (let val of res.data.data.list) {
							val["text"] = val.server_name;
						}
						this.serOptions = res.data.data.list;
					} else {
						uni.showToast({
							title: "该小号获取不到区服信息"
						})
					}
				})
			},
			// 选择小号
			selectNumList(index) {
				this.form.role_name = this.numOptions[index].text;
				this.form.mg_mem_id = this.numOptions[index].mg_mem_id;
				// 获取区服信息
				this.getServer({
					mg_mem_id: this.numOptions[index].mg_mem_id
				})
			},
			// 选择区服
			selectSerList(index) {
				this.form.server_name = this.serOptions[index].text;
				this.form.mg_role_id = this.serOptions[index].mg_role_id;
				this.form.server_id = this.serOptions[index].server_id;
			},
			// 图片上传
			uploadSuccess(data) {
				this.fileList.push(data.data.url);
				this.form.image = JSON.stringify(this.fileList);
			},
			// 图片删除
			uploadRemove(index) {
				this.fileList.splice(index, 1)
				this.form.image = JSON.stringify(this.fileList);
			},
			// 卖家须知
			submitReview() {
				let title;
				switch (true) {
					case this.form.gamename == '选择游戏':
						title = "请添加游戏";
						break;
					case !this.form.role_name:
						title = "请添加小号";
						break;
					case !this.form.server_name:
						title = "请添加区服";
						break;
					case Number(this.form.price) < 6:
						title = "价格输入不对";
						break;
					case !this.form.description:
						title = "请输入描述信息";
						break;
					case this.fileList.length < 3:
						title = "图片数量不足";
						break;
					case this.userInfo.mobile.length == 0:
						uni.showModal({
							title: "请先绑定手机号",
							complete() {
								this.common.routerTo({
									name: 'changeMobile'
								});
							}
						})
						return;
					default:
						this.showNotice = true;
						return;
				}
				uni.showToast({
					title
				})
			},
			// 短信验证
			verification() {
				this.showNotice = false;
				this.showVerification = true;
			},
			codeChange(text) {
				this.codeText = text;
			},
			// 发送短信验证码
			getCode() {
				let that = this;
				if (this.$refs.uCode.canGetCode) {
					// 模拟向后端请求验证码
					uni.showLoading({
						title: '正在获取验证码',
						success() {
							that.$api({
								url: "v8/sms/send",
								method: "GET",
								data: {
									"sms-type": 4,
									"sms-mobile": that.userInfo.mobile
								}
							}).then(res => {
								uni.showToast({
									title: res.data.msg,
									icon: "none"
								})
								
								if(res.data.code == 200){
									uni.hideLoading();
									that.$refs.uCode.start();
								}
							})
						}
					})
				} else {
					this.$u.toast('倒计时结束后再发送');
				}
			},
			// 确认出售
			handleSellOut() {
				this.$api({
					url: "account/goods/sell",
					method: "GET",
					data: {
						...this.form,
						"sms-type": 4,
						"sms-mobile": this.userInfo.mobile
					}
				}).then(res => {
				 	this.showVerification = false;
					uni.showToast({
						title: "出售成功"
					})
					this.resetForm();
				})
			},
			// 重置表单
			resetForm() {
				this.form = {
					gamename: "选择游戏",
					role_name: "",
					mg_mem_id: "",
					mg_role_id: "",
					server_name: "",
					server_id: "",
					price: "",
					title: "",
					description: "",
					image: "",
					"sms-code": ""
				};
			}
		},
		
		watch: {
			selectedGame: {
				handler(val) {
					this.resetForm();
					if (val.game_id) {
						this.form.gamename = val.gamename;
						this.getNum({
							game_id: val.game_id
						})
					}
				},
				immediate: true
			}
		}
	}
</script>

<style lang="scss" scoped>
	.container {
		position: relative;
		display: flex;
		flex-direction: column;
		
		.main {
			flex: 1;
			overflow-y: auto;
		}

		.btn {
			width: 100%;
			height: 100rpx;
			padding-top: 15rpx;
			box-sizing: border-box;
		}

		// 弹出窗口
		.slot-content {
			padding: $xw-padding-base;
			font-size: $xw-font-size-md;
			color: $xw-font-auxiliary-color;
			line-height: 40rpx;
		}
	}
</style>
