<!-- 交易 -->
<template>
	<view>
		<u-tabs :list="list" :is-scroll="false" :current="current" active-color="#ff8500" bg-color="#f5f5f5" @change="change"></u-tabs>

		<view>
			<!-- 正在出售 -->
			<xw-salestatuslist :list="pageData" v-if="current == 0" @updata="getData(params)"></xw-salestatuslist>

			<!-- 已经出售 -->
			<xw-salestatuslist :list="pageData" v-else-if="current == 1"></xw-salestatuslist>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				list: [{
					name: "正在出售",
					status: 2
				}, {
					name: "已经出售",
					status: 4
				}],
				current: 0,

				params: {
					page: 1,
					offset: 20,
					is_me_sell: 2,
					status: 2
				},
				pageData: []
			}
		},
		methods: {
			getData(params) {
				this.$api({
					url: "account/goods/list",
					method: "GET",
					data: params
				}).then(res => {
					this.pageData = res.data.data.list;
				})
			},
			change(index) {
				this.current = index;
				if(this.current == 0){
					this.params.status = 2
				}else {
					this.params.status = 4;
				}
				this.getData(this.params)
			}
		},
		created() {
			this.getData(this.params)
		}
	}
</script>

<style lang="scss" scoped>
</style>
