<template>
	<view class="container" :style="{ paddingTop: `${$store.state.systemInfoSync.statusBarHeight}px` }">
		<view class="status_bar" :style="{ height: `${$store.state.systemInfoSync.statusBarHeight}px` }"></view>

		<u-tabs :list="list" :is-scroll="false" :current="current" active-color="#ff8500" @change="change"></u-tabs>

		<view class="main">
			<!-- 买号页面 -->
			<xw-buyNumber v-if="current == 0"></xw-buyNumber>
			<!-- 卖号页面 -->
			<xw-sellNumber v-else-if="current == 1"></xw-sellNumber>
			<!-- 交易页面 -->
			<xw-soldOut v-else-if="current == 2"></xw-soldOut>
			<!-- 我买到的页面 -->
			<xw-bought v-else-if="current == 3"></xw-bought>
		</view>

	</view>
</template>

<script>
	import buyNumber from "./children/buyNumber/index.vue";
	import sellNumber from "./children/sellNumber/index.vue";
	import soldOut from "./children/soldOut/index.vue";
	import bought from "./children/bought/index.vue";

	export default {
		components: {
			"xw-buyNumber": buyNumber,
			"xw-sellNumber": sellNumber,
			"xw-soldOut": soldOut,
			"xw-bought": bought
		},
		data() {
			return {
				list: [{
					name: "买号"
				}, {
					name: "卖号"
				}, {
					name: "交易"
				}, {
					name: "我买到的"
				}],
				current: 0,
			}
		},

		methods: {
			change(index) {
				if (this.loginInfo.user_token) {
					this.current = index;
				} else {
					this.common.routerTo({
						name: "login"
					})
				}
			}
		}
	}
</script>

<style lang="scss" scoped>
	.container {
		display: flex;
		flex-direction: column;

		.main {
			flex: 1;
			padding: $xw-padding-md;
			overflow-y: scroll;
		}
	}
</style>
