<!-- 新游推荐 -->
<template>
	<view class="container">
		<!-- 这里是状态栏 -->
		<view class="status_bar">
			<view class="background"></view>
		</view>
		<!-- 导航部分 -->
		<nav class="nav">
			<view class="back">
				<u-icon name="arrow-left" color="#fff" size="40" @click="$Router.back(1)"></u-icon>
			</view>
			{{topic.title}}
		</nav>

		<!-- 游戏列表部分 -->
		<view class="main">
			<scroll-view scroll-y style="height: 100%;width: 100%;" lower-threshold="100" @scrolltolower="loadMore" v-if="pageData.count">

				<view class="navImage" v-if='topic.img'>
					<image :src="topic.img" mode="widthFix"></image>
				</view>
				<xw-gamelist :list="pageData.list">
					<template #game="slotObj">
						<view class="tags">
							<u-tag :text="common.numberTag(slotObj.data.downcnt || slotObj.data.user_cnt)" size="mini" mode="dark" type="success"
							 style="margin-right: 10rpx;"></u-tag>
							<u-tag v-for="(item,index) in slotObj.data.type" :key="index" :text="item" v-if="index<3" size="mini" mode="plain"
							 shape="circleRight" color="#ff8500" style="margin-right: 10rpx;"></u-tag>
						</view>
					</template>
				</xw-gamelist>
				<u-loadmore bg-color="#f5f5f5" :status="status" :icon-type="iconType" :load-text="loadText" @loadmore="loadMore" />
			</scroll-view>

			<xw-nodata v-else>暂无相关游戏</xw-nodata>
		</view>
	</view>
</template>

<script>
	import {
		myLoading
	} from "@/common/js/mixin.js";

	export default {
		data() {
			return {
				topic: {},

				pageData: {
					count: 0,
					list: [{
						game_id: 'down',
						gamename: '盒子下载',
						rate: 1,
						icon:'',
						classify:14,
						user_cnt:11000,
						type:["策略","卡牌","三国","..."]
					}]
				},
				status: "loadmore",
			}
		},
		methods: {
			getData() {
				this.$api({
					url: this.topic.url,
					data: this.topic.data
				}).then(res => {
					this.pageData.count = res.data.data.count;
					this.pageData.list = this.pageData.list.concat(res.data.data.list);
					this.pageData.list[0].icon=this.userFormat.icon
				})


			},
			loadMore() {
				if (this.pageData.count > this.pageData.list.length) {
					this.status = "loading";
					this.topic.data.page++;
					this.getData();
				} else {
					this.status = "nomore";
				}
			}
		},
		// 接收参数
		onLoad(option) {

			this.topic = {
				title: option.title,
				url: option.url,
				img: option.img || '',
				data: {
					page: 1,
					offset: 20,
					topic_id: option.topic_id,
					remd: option.remd,
					keywords: option.keywords || '',
					client_id: option.option || '',
					tags: option.tags || '',


				}
			}
			this.getData();
		},
		mixins: [myLoading],
	}
</script>

<style lang="scss" scoped>
	.container {
		display: flex;
		flex-direction: column;
		overflow: hidden;

		.navImage {
			width: 100%;

			margin-bottom: 10rpx;

		}

		// 标题部分
		.nav {
			width: 100%;
			height: 50px;
			color: #fff;
			font-size: 32rpx;
			background: #ff8500;
			line-height: 50px;
			position: relative;

			.back {
				position: absolute;
				top: 0;
				left: 20rpx;
			}

		}

		.main {
			flex: 1;
			overflow-y: scroll;
		}
	}
</style>
