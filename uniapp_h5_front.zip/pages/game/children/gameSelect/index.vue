<template>
  <view class="gameSelect">

    <!-- 头部推荐游戏 -->
    <view class="header" @click="common.routerTo({path: '/pages/views/gameDetail/index', query: {game_id: formData.game_id}})" v-if="formData">
      <!-- 背景大图部分 -->

      <view class="background progressive">
        <image :src="index.image" width="100%" height='100%' mode="scaleToFill" v-for="(index,key) in $store.state.images" :key='key' v-if="imgs.game_id==index.game_id"></image>
        <!-- <image v-progressive="formData.image" :src="formData.home_img_imagestyle2" width="100%" height='100%' mode="scaleToFill"></image> -->
      </view>
      <!-- 游戏介绍部分 -->
      <view class="gameDetail">

        <h1 class="gamename">{{formData.game_name}}</h1>
        <view class="gameType">
          <text class="type" v-for="(v,i) in formData.type" :key="i">{{v}}</text>
          <text class="dian" v-if="formData.classify!==5">·</text>
          <text v-if="formData.classify!==5">{{formData.size}}</text>
        </view>
        <view class="tags" v-if="formData.selling_point">
          <u-tag :text="v" mode="dark" :bg-color="bgColor[i]" class="tag" v-for="(v,i) in formData.selling_point.split(',')" :key="i" />
        </view>
      </view>
    </view>

    <!-- 主体游戏分类 -->
    <view class="gameClassify">
      <!-- 小图标部分 -->
      <u-row class="column">
       <u-col :span="3" class="item" @click="installNow" v-if="$store.state.systemInfoSync.statusBarHeight == 0">
          <image :src="userFormat.icon" style="width: 94rpx;height: 87rpx;padding-top: 14rpx;margin-bottom: 1rpx"></image>
          <view class="text">盒子下载</view>
        </u-col>
        <u-col :span="3" class="item" @click="common.routerTo({name: 'myTask'})">
          <image src="../../../../static/image/home_task.png" class="image"></image>
          <view class="text">任务赚金</view>
        </u-col>
        <u-col :span="3" class="item" @click="common.routerTo({name: 'myGift'})">
          <image src="../../../../static/image/home_coupon.png" class="image"></image>
          <view class="text">领包中心</view>
        </u-col>
        <!-- 				<u-col :span="3" class="item" @click="common.routerTo({name: 'myIntegral'})">
					<image src="../../../../static/image/home_integral.png" class="image"></image>
					<view class="text">积分夺宝</view>
				</u-col> -->
        <u-col :span="3" class="item" @click="common.routerTo({name: 'information'})">
          <image src="../../../../static/image/home_info.png" class="image"></image>
          <view class="text">游戏资讯</view>
        </u-col>
      </u-row>
      <!-- type1：网游热搜 -->
      <view id="type1" v-if="Object.keys(pageData).length">
        <!-- title -->
        <view class="myTitle">
          <u-row>
            <u-col span="0.5">

              <view class="titleLine">

              </view>
            </u-col>
            <u-col span="9.5">

              <view class="titleView">
                精品好游
              </view>
            </u-col>
            <!-- 	<u-col span="2">
							<view class="more" @click="common.nativeRouterTo({url: '/pages/game/children/gameTopic/index?title=网游热搜&url=game/list&remd=3'})">
								更多<u-icon name="arrow-right" size="28"></u-icon>
							</view>
						</u-col> -->
          </u-row>
        </view>

        <u-row>
          <u-col span="12">
            <!-- <view v-if="index<4"> -->
            <!-- <xw-conciseGame :data="item" types></xw-conciseGame> -->
            <!-- <xw-BoutiqueGame :data='newPageH5Data' ></xw-BoutiqueGame> -->

            <xw-swipers></xw-swipers>

          </u-col>
        </u-row>
      </view>
      <!-- type2：热门 -->
      <view id="type3" v-if="Object.keys(pageSpecialData).length">
        <!-- title -->
        <view class="myTitle">
          <u-row>
            <u-col span="0.5">

              <view class="titleLine">

              </view>
            </u-col>
            <u-col span="9.5">
              <view class="titleView">
                {{pageSpecialData.list[0].topic_name}}
              </view>
            </u-col>
            <u-col span="2">
              <view class="more"
                @click="common.nativeRouterTo({url: '/pages/game/children/gameTopic/index?title='+ pageSpecialData.list[0].topic_name+ '&url=game/special/games&topic_id='+ pageSpecialData.list[0].topic_id+'&img='+pageSpecialData.list[0].image})">
                更多<u-icon name="arrow-right" size="28"></u-icon>
              </view>
            </u-col>
          </u-row>
        </view>

        <u-row>
          <u-col>
            <!-- <u-col @click="common.routerTo({path: '/pages/views/gameDetail/index', query: {game_id: pageSpecialData.list[0].game_id}})"> -->
            <u-swiper :list="pageSpecialData.list" height="400" mode='none' @click="togame"></u-swiper>
            <!-- <u-image :src="pageSpecialData.list[0].image" mode="widthFix" border-radius="30"></u-image> -->
          </u-col>
        </u-row>
      </view>
      <!-- {{pageSpecialData.list[0]}} -->
      <!-- type3：火爆 -->
      <view id="type2" v-if="Object.keys(pageSpecialData).length">
        <!-- title -->
        <view class="myTitle">
          <u-row>
            <u-col span="0.5">
              <view class="titleLine">
              </view>
            </u-col>
            <u-col span="9.5">
              <view class="titleView">
                {{pageSpecialData.list[1].topic_name}}
              </view>
            </u-col>
            <u-col span="2">
              <view class="more"
                @click="common.nativeRouterTo({url: '/pages/game/children/gameTopic/index?title='+ pageSpecialData.list[1].topic_name+ '&url=game/special/games&topic_id='+ pageSpecialData.list[1].topic_id})">
                更多<u-icon name="arrow-right" size="28"></u-icon>
              </view>
            </u-col>
          </u-row>
        </view>

        <xw-gameLiSwiper :swiperHeight="'560rpx'" :data="pageSpecialData.list[0]" :autoplay="true"></xw-gameLiSwiper>
      </view>
      <!-- type4：推荐 -->
      <view id="type4" v-if="Object.keys(pageSpecialData).length">
        <!-- title -->
        <view class="myTitle">
          <u-row>
            <u-col span="0.5">
              <view class="titleLine">

              </view>
            </u-col>
            <u-col span="9.5">
              <view class="titleView">
                {{pageSpecialData.list[2].topic_name}}
              </view>
            </u-col>
            <u-col span="2">
              <view class="more"
                @click="common.nativeRouterTo({url: '/pages/game/children/gameTopic/index?title='+ pageSpecialData.list[2].topic_name+ '&url=game/special/games&topic_id='+ pageSpecialData.list[2].topic_id})">
                更多<u-icon name="arrow-right" size="28"></u-icon>
              </view>
            </u-col>
          </u-row>
        </view>

        <xw-gameVerticalCardSwiper :data="pageSpecialData.list[2]"></xw-gameVerticalCardSwiper>
      </view>
      <!-- type8：疯狂送连抽 -->
      <view>
        <!-- title -->
        <view class="myTitle">
          <u-row>
            <u-col span="0.5">

              <view class="titleLine">

              </view>
            </u-col>
            <u-col span="9.5">
              <view class="titleView">
                疯狂送连抽
              </view>
            </u-col>
            <!-- 	<u-col span="2">
							<view class="more" @click="common.nativeRouterTo({url: '/pages/game/children/gameTopic/index?title='+ pageSpecialData.list[0].topic_name+ '&url=game/special/games&topic_id='+ pageSpecialData.list[0].topic_id})">
								更多<u-icon name="arrow-right" size="28"></u-icon>
							</view>
						</u-col> -->
          </u-row>
        </view>

        <u-row>
          <u-col @click="common.nativeRouterTo({url: '/pages/game/children/gameTopic/index?title=疯狂送连抽&url=game/search&img='+imag[0]+'&keywords=抽'})">

            <u-image :src="imag[0]" mode="widthFix" border-radius="30"></u-image>
          </u-col>
        </u-row>

      </view>

      <!-- type3：新游 -->
      <view id="type5" v-if="Object.keys(pageSpecialData).length">
        <!-- title -->
        <view class="myTitle">
          <u-row>
            <u-col span="0.5">

              <view class="titleLine">

              </view>
            </u-col>
            <u-col span="9.5">
              <view class="titleView">
                {{pageSpecialData.list[3].topic_name}}
              </view>
            </u-col>
            <u-col span="2">
              <view class="more"
                @click="common.nativeRouterTo({url: '/pages/game/children/gameTopic/index?title='+ pageSpecialData.list[3].topic_name+ '&url=game/special/games&topic_id='+ pageSpecialData.list[3].topic_id})">
                更多<u-icon name="arrow-right" size="28"></u-icon>
              </view>
            </u-col>
          </u-row>
        </view>

        <xw-gameLiSwiper :swiperHeight="'560rpx'" :data="pageSpecialData.list[3]"></xw-gameLiSwiper>
      </view>

      <!-- type5：精品-对应轮播 -->
      <!-- 		<view id="type6" v-if="Object.keys(pageData).length">
				<xw-title>精品</xw-title>
				<xw-gameCardSwiper :data="pageData.hometopper"></xw-gameCardSwiper>
			</view> -->
      <!-- type6：画质精选 -->

      <view id="type10" v-if="Object.keys(pageSpecialData).length">
        <xw-title>画质精选</xw-title>
        <xw-gameCard :data="pageSpecialData.list[1]"></xw-gameCard>
      </view>

      <!-- type: 开服 -->
      <view id="type8" v-if="serviceData.length">
        <view class="myTitle">
          <u-row>
            <u-col span="0.5">

              <view class="titleLine">

              </view>
            </u-col>
            <u-col span="9.5">
              <view class="titleView">
                今日开服
              </view>
            </u-col>
            <u-col span="2">
              <view class="more" @click="common.routerToTab({url: '/pages/service/index'})">
                更多<u-icon name="arrow-right" size="28"></u-icon>
              </view>
            </u-col>
          </u-row>
        </view>

        <xw-serviceLiSwiper :data="serviceData"></xw-serviceLiSwiper>
      </view>

      <!--  充值有折扣-->

      <view id="type14" v-if="Object.keys(pageSpecialData).length">
        <!-- title -->
        <view class="myTitle">
          <u-row>
            <u-col span="0.5">

              <view class="titleLine">

              </view>
            </u-col>
            <u-col span="9.5">
              <view class="titleView">
                充值有折扣
              </view>
            </u-col>

          </u-row>
        </view>

        <u-row>
          <u-col @click="common.nativeRouterTo({url: '/pages/game/children/gameTopic/index?title=折扣游戏&url=game/multilist&img='+imag[1]+'&tags=1375'+'&client_id='+client_id})">
            <u-image :src="imag[1]" mode="widthFix" border-radius="30"></u-image>
          </u-col>
        </u-row>
      </view>

      <!-- type7：H5 -->
      <view id="type7" v-if="Object.keys(pageH5Data).length">
        <!-- title -->
        <view class="myTitle">
          <u-row>
            <u-col span="0.5">
              <view class="titleLine"></view>
            </u-col>
            <u-col span="9.5">
              <view class="titleView">
                {{pageH5Data.list[0].topic_name}}
              </view>
            </u-col>
            <u-col span="2">
              <view class="more" @click="common.nativeRouterTo({url: '/pages/game/children/gameTopic/index?title='+ pageH5Data.list[0].topic_name +'&url=game/special/games&topic_id='+ pageH5Data.list[0].topic_id})">
                更多<u-icon name="arrow-right" size="28"></u-icon>
              </view>
            </u-col>
          </u-row>
        </view>

        <u-row>
          <u-col span="4" v-for="(item,index) in newPageH5Data" :key="index">
            <view v-if="index<6">
              <xw-conciseGame badge :data="item"></xw-conciseGame>
            </view>
          </u-col>
        </u-row>
      </view>

      <!-- type: 标签 -->
      <view id="type12">
        <view class="myTitle">
          <u-row>
            <u-col span="0.5">

              <view class="titleLine">

              </view>
            </u-col>
            <u-col span="9.5">
              <view class="titleView">
                热门分类
              </view>
            </u-col>

          </u-row>
        </view>
        <u-row>
          <u-col span="3" v-if="value<8" :cate="index" v-for=" (index,value) in cate" :key='index.id'>
            <xw-button style="display: inline-block;" :value="index.name" :item="{classify:13,index:value,id:index.id}"></xw-button>
          </u-col>
        </u-row>
      </view>

      <view id="type11" class="huanyipi" style="margin-top: 80rpx;color=#A4A1A2;font-size: 28rpx;">
        -------- 更多游戏请到游戏大厅中查看 --------
      </view>

    </view>
  </view>
</template>

<script>
import {
  mapState
} from "vuex";

export default {
  data() {
    return {
      bgColor: [
        "#74b9ff",
        "#fab1a0",
        "#a29bfe",
        "#81ecec"
      ],
      imag: [
        '/static/image/wuxianlianchou.png',
        '/static/image/chongzhizhikou.png'

      ],
      imgs: {},
      formData: null,
      // 首页数据
      pageData: {},
      // 专题数据
      pageSpecialData: {},
      // H5数据
      pageH5Data: {},
      // 画质精选数据
      pageVideoData: {},
      // 开服表
      serviceData: [],
      // 参数
      params: [],
      cate: [],
      img: new Image(),

      newPageH5Data: [],
      hometopper: {}

    }
  },
  computed: {
    ...mapState({
      pageRecommendData: "pageRecommendData"
    }),

  },

  methods: {
    // 顶部大图推荐
    getRecommendData() {
      this.$api({
        url: "home/slidegif",
        method: "GET"
      }).then(res => {
        if (res.data.data) {
          this.formData = {
            ...res.data.data.hometopper
          }
          this.imgs = {
            game_id: res.data.data.hometopper.game_id,
            image: res.data.data.hometopper.image
          }
          // console.log(this.imgs,'imgsimgsimgsimgsimgs')
          this.$store.commit('setPageRecommendData', res.data.data.hometopper)
          this.$store.commit('setImages', {
            game_id: res.data.data.hometopper.game_id,
            image: res.data.data.hometopper.image
          })
        }
      })
    },
    //精选分类
    getInitData() {
      this.$api({
        url: "game/getcategory",
        method: "GET",
      }).then(res => {
        this.cate = res.data.data.cate;

      })


    },
    getRandomArrayElements(arr, count) {
      var shuffled = arr.slice(0),
        i = arr.length,
        min = i - count,
        temp, index;
      while (i-- > min) {
        index = Math.floor((i + 1) * Math.random());
        temp = shuffled[index];
        shuffled[index] = shuffled[i];
        shuffled[i] = temp;
      }
      return shuffled.slice(min);
    },
    // 首页轮播、文字轮播、热搜轮播
    getData() {
      this.$api({
        url: "home/index",
        method: "GET"
      }).then(res => {
        this.pageData = res.data.data;
      })
    },
    // 首页专区数据
    getSpecialData() {
      this.$api({
        url: "game/speciallist",
        method: "GET",
        data: {
          classify: 3,
          offset: 20,
          page: 1
        }
      }).then(res => {
        this.pageSpecialData = res.data.data;

      })
    },
    // 首页H5游戏数据
    getH5GameData() {
      this.$api({
        url: "home/h5",
        method: "GET",
      }).then(res => {
        this.pageH5Data = res.data.data;

        this.newPageH5Data = this.getRandomArrayElements(res.data.data.list[0].game_list, 6)
      })
    },
    // 画质精选数据
    getVideoCardData() {
      this.$api({
        url: "home/slideMp4",
        method: "GET"
      }).then(res => {
        this.pageVideoData = res.data.data;
      })
    },
    // 开服表
    getServiceData() {
      this.$api({
        url: "gameserver/list",
        methods: "GET",
        data: {
          offset: 10,
          page: 1,
          server_type: 1,
        }
      }).then(res => {
        this.serviceData = res.data.data.list;
      })
    },
    getimgData() {
      this.getRecommendData();
      return new Promise((resolve, reject) => {
        resolve({
          triggered: false
        })
      })
    },
    // 立即下载
    installNow() {
      window.open(this.userFormat.down_app_url);
    },
    togame(i) {
      console.log(i);
      this.common.routerTo({ path: '/pages/views/gameDetail/index', query: { game_id: this.pageSpecialData.list[i].game_id } })
    }
  },
  watch: {
    client_id: {
      handler(val) {
        if (val != "") {
          this.getData();
          this.getInitData()
          this.getRecommendData()

          this.getSpecialData();
          // this.getInitData();

          this.getH5GameData();
          this.getServiceData();
        }
      },
      immediate: true
    }
  }
}
</script>

<style lang="scss" scoped>
.gameSelect {
  // 头部游戏展示
  .item {
	  flex: 1!important;
  }
  .header {
    width: 100%;
    height: 700rpx;
    display: flex;
    align-items: flex-end;
    position: relative;

    // 背景大图
    .background {
      width: 100%;
      height: 100%;
      position: absolute;
      top: 0;
      left: 0;
      z-index: 0;
    }

    // 游戏简介
    .gameDetail {
      position: relative;
      z-index: 10;
      width: 100%;
      height: 160rpx;
      color: #fff;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      overflow: hidden;

      .gamename,
      .gameType,
      .tags {
        @include text-overflow(1);
      }

      .gamename {
        flex: 1;
      }

      .gameType {
        flex: 1;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 24rpx;

        .type {
          margin-right: 10rpx;
        }

        .dian {
          margin: 0 10rpx;
        }
      }

      .tags {
        flex: 1;

        .tag {
          margin-right: 10rpx;
        }
      }
    }
  }

  // title
  .myTitle {
    width: 100%;
    height: 60rpx;
    line-height: 60rpx;
    margin: 30rpx 0 20rpx;

    .more {
      color: $xw-font-auxiliary-color;
      font-size: 24rpx;
    }
  }

  .huanyipi {
    color: #7c7c7c;
    display: flex;
    flex-direction: row;
    justify-content: center;
    align-content: center;

    .huanyipiImg {
      width: 34rpx;
      height: 34rpx;
      margin: 4rpx 20rpx 0 0;
    }

    .huanyipiImg:hover {
      transform: rotate(90deg);
      -ms-transform: rotate(90deg);
      /* IE 9 */
      -moz-transform: rotate(90deg);
      /* Firefox */
      -webkit-transform: rotate(90deg);
      /* Safari 和 Chrome */
      -o-transform: rotate(90deg);
      /* Opera */
      transition-duration: 0.5s;
    }
  }

  // 游戏分类
  .gameClassify {
    position: relative;
    z-index: 5;
    width: 100%;
    padding: 20rpx 10rpx;
    border-top-left-radius: 20rpx;
    border-top-right-radius: 20rpx;
    background: #fff;
    box-shadow: 0px -50px 34px 25px rgba(0, 0, 0, 0.7);

    .column {
      .item {
        height: 160rpx;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        align-items: center;

        .image {
          width: 100rpx;
          height: 100rpx;
        }

        .text {
          font-weight: 300;
          color: #000;
        }
      }
    }
  }
}
</style>
