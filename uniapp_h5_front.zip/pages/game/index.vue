<template>
  <view class="container" :style="{ paddingTop: `${$store.state.systemInfoSync.statusBarHeight}px` }" :class="isUps == true ? 'prevent' : 'normal'">
		<!-- {{systemInfoSync.statusBarHeight}} -->
		<view class="status_bar" :style="{ height: `${$store.state.systemInfoSync.statusBarHeight}px` }"></view>
		
		<!-- {{info}} -->
		<!-- <view style="position: fixed; top: 0; z-index: 30; background-color: #fff;">
			<text>{{$store.state.isSafari }}</text>
			<text>{{$store.state.systemInfoSync.statusBarHeight}}</text>
			<text>{{$store.state.isSafari && $store.state.systemInfoSync.statusBarHeight == 0 ? 'true' : 'false'}}</text>
			<text>{{info}}</text>
		</view> -->
		<!-- {{$store.state.systemInfoSync}} -->
    <!-- 主体内容部分 -->
		<!-- <view style="background-color: #F0F0F0;line-height: 20rpx;"></view> -->
    <view class="main">
      <scroll-view scroll-y="true" class="scroll">

        <!-- 搜索悬浮球 -->
        <view class="search" @click="common.routerTo({path: '/pages/views/search/index', query: {type: '游戏'}})">
          <!-- <image src="@/static/image/search.png" width="100%" mode="widthFix"></image> -->
          <view class="">
            <u-icon name="search" color=#FFFFFF size="38"></u-icon>
            <text style="white-space:nowrap;" v-if="userFormat.name.length<4">{{userFormat.name}}</text>
            <text v-else-if="userFormat.name.length>=4">搜索</text>
          </view>
        </view>

        <!-- 微信引导页 -->
        <view class="weChat" v-if="isWeChat">
          <image src="../../static/image/wechart.png" width="80%" mode="widthFix" class="yindaoye"></image>
        </view>

        <!-- 用户定制信息展示 -->
        <!-- <xw-downlabel></xw-downlabel> -->

        <!-- 页面的内容 -->
        <xw-gameSelect ref="gameSelect"></xw-gameSelect>
      </scroll-view>
    </view>
		
		<view class="down" v-if="$store.state.isSafari && $store.state.systemInfoSync.statusBarHeight == 0">
			<!-- <u-button class="btn" size="medium" :plain="false" @click.stop="h5Play">
				<slot>下载到桌面</slot>
			</u-button> -->
			
			<button class="newBtn" size="mini" @click="openPopup">
				<slot>下载到桌面</slot>
			</button>
		</view>
		
		<!-- <view class="popup_overlay" v-if="isUps" :style="{ height: `${$store.state.systemInfoSync.screenHeight}px` }"></view> -->
		
		<!-- 普通弹窗 -->
		<uni-popup class="popup" ref="popup" type="bottom" background-color="#fff" @change="change" :style="{ height: `${$store.state.systemInfoSync.screenHeight}px` }">
			<view class="popup-content" style="position: relative;">
				<image src="../../static/image/popup_bg.gif" width="100%" mode="widthFix"></image>
				<image :src="$store.state.userFormat.icon" mode="widthFix" style="position:absolute;"
					:style="{ left: `${iconLeft}px`, top: `${iconTop}px`, width: `${iconWidth}px` }"></image>
				<!-- <view class="" style="position:absolute;" :style="{ left: `0px`, top: `${textTop}px`, width: `100%` }">
					<div class="" style="color: #666; font-size: 16px;font-weight: 700; justify-content: center; text-align: center;white-space: nowrap;width: 100%;"  
						:style="{ transform: `scale(${scale})` }">
						{{$store.state.userFormat.name}}
					</div>
				</view>
				
				<view class="smallIconView" style="position:absolute;" :style="{ left: `50%`, transform: `translateX(-50%)`, top: `${iconTop_small}px`, width: `${iconWidth_small}px` }">
					<image class="smallIcon" :src="$store.state.userFormat.icon" mode="widthFix" ></image>
				</view>
				<image src="../../static/image/icon_light.png" mode="widthFix" style="position:absolute;transform: translateZ(2px)"
					:style="{ left: `50%`, transform: `translateX(-50%)`, top: `${lightTop}px`, width: `${lightWidth}px` }"></image> -->
				<image src="../../static/image/btn_close.png" mode="widthFix" style="position:absolute;"
					:style="{ right: `${btnRight}px`, top: `${btnTop}px`, width: `${btnWidth}px` }" @click="close_popup"></image>
				<!-- <image src="../../static/image/lightAnimation.gif" mode="widthFix" style="position:absolute;"
					:style="{ left: `${animateLeft}px`, bottom: `${animateBottom}px`, width: `${animateWidth}px` }"></image> -->
				<!-- <text style="position:absolute; left:0%;top:4%; ">{{$store.state.systemInfoSync}}</text> -->
				<image class="arrows" src="../../static/image/arrows.png" mode="widthFix" style="position:absolute; left:50%;bottom:4%; transform:translate(-50%)"
					:style="{ width: `${arrowsWidth}px` }"></image>
			</view>
		</uni-popup>
		
  </view>
</template>

<script>
import gameSelect from "./children/gameSelect/index.vue";

export default {
	metaInfo () {
		return {
			meta:[{
				name: "apple-mobile-web-app-title",
				content: this.$store.state.userFormat.name
			},
			{
				name: "apple-mobile-web-app-capable" ,
				content: "yes"
			}],
			link:[{
				rel: "apple-touch-icon-precomposed",
				href: this.$store.state.userFormat.icon_webclip || this.$store.state.userFormat.icon_share || this.$store.state.userFormat.icon
			}]
		}
	},
  components: {
    "xw-gameSelect": gameSelect,
  },
  data() {
    return {
      triggered: false,
      _freshing: false,
			info: {},
			isUps: false
    }
  },
  computed: {
    isWeChat() {
      let flag = navigator.userAgent.toLowerCase().match(/MicroMessenger/i) == "micromessenger"
      return flag
    },
		scale() {
			return this.$store.state.systemInfoSync.screenWidth / 750;
		},
		iconWidth() {
			let scale = this.$store.state.systemInfoSync.screenWidth / 750;
			return 80 * scale;
		},
		textLeft() {
			let scale = this.$store.state.systemInfoSync.screenWidth / 750;
			return (302 + 50) * scale;
		},
		iconTop() {
			let scale = this.$store.state.systemInfoSync.screenWidth / 750;
			return 88 * scale;
		},
		iconLeft() {
			let scale = this.$store.state.systemInfoSync.screenWidth / 750;
			return 80 * scale;
		},
		textTop() {
			let scale = this.$store.state.systemInfoSync.screenWidth / 750;
			return 230 * scale;
		},
		iconWidth_small() {
			let scale = this.$store.state.systemInfoSync.screenWidth / 750;
			return 28 * scale;
		},
		iconTop_small() {
			let scale = this.$store.state.systemInfoSync.screenWidth / 750;
			return 304 * scale;
		},
		lightWidth() {
			let scale = this.$store.state.systemInfoSync.screenWidth / 750;
			return 80 * scale;
		},
		lightTop() {
			let scale = this.$store.state.systemInfoSync.screenWidth / 750;
			return 228 * scale;
		},
		btnWidth() {
			let scale = this.$store.state.systemInfoSync.screenWidth / 750;
			return 34 * scale;
		},
		btnRight() {
			let scale = this.$store.state.systemInfoSync.screenWidth / 750;
			return 44 * scale;
		},
		animateWidth() {
			let scale = this.$store.state.systemInfoSync.screenWidth / 750;
			return 18 * scale;
		},
		animateLeft() {
			let scale = this.$store.state.systemInfoSync.screenWidth / 750;
			return 171 * scale;
		},
		animateBottom() {
			let scale = this.$store.state.systemInfoSync.screenWidth / 750;
			return 220 * scale;
		},
		btnTop() {
			let scale = this.$store.state.systemInfoSync.screenWidth / 750;
			return 38 * scale;
		},
		arrowsWidth() {
			let scale = this.$store.state.systemInfoSync.screenWidth / 750;
			return 54 * scale;
		}
  },
  methods: {
		close_popup(){
			this.$refs.popup.close();
			// uni.showTabBar();
		},
		change(e) {
			if (!e.show) {
				this.isUps = false;
				// uni.showTabBar();
			}
			console.log('当前模式：' + e.type + ',状态：' + e.show);
		},
		openPopup() {
			// uni.hideTabBar();
			this.isUps = true;
			this.$refs.popup.open('top');
		},
    // 自定义下拉刷新
    onRefresh() {
      if (this._freshing) return;
      this._freshing = true;
      //界面下拉触发，triggered可能不是true，要设为true
      !this.triggered ? this.triggered = true : undefined;
      this.$refs['gameSelect'].getimgData().then(res => {
        this.triggered = res.triggered
      })
			
			// this.info = uni.getSystemInfoSync();
    },
    // 重置
    onRestore() {
      this._freshing = false;
			// this.info = uni.getSystemInfoSync();
    }
  },
	mounted() {
		// this.info = navigator.userAgent
		// uni.hideTabBar();
	}
}
</script>

<style lang="scss" scoped>
	@mixin flex {
		/* #ifndef APP-NVUE */
		display: flex;
		/* #endif */
		flex-direction: row;
	}
	
	.normal{
		height: auto !important;
	}
	
	.prevent {
		height: 100% !important;
	}
	
	.smallIconView {
		z-index: 50;
		.smallIcon {
			transform: rotateX(30deg);
			-webkit-transform: rotateX(30); /* Safari and Chrome */
		}
	}
	
	.arrows {
		-webkit-animation: rightan 1s infinite;
		-webkit-animation-fill-mode: both;
	}
	
	@-webkit-keyframes rightan
	{
		from
		{
			bottom: 4%;
			opacity: 0;
		}
		to
		{
			bottom: 1%;
			opacity: 1;
		}
	}
	
	
.container {
  overflow: hidden;
  // display: flex;
  position: relative;

  .weChat {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    z-index: 999999;
    background: rgba(0, 0, 0, 0.8);

    .yindaoye {
      max-width: 500px;
      margin: auto;
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
    }
  }

  // 蒙层
  .mantle {
    position: absolute;
    top: 0;
    left: 0;
    bottom: 0;
    right: 0;
    z-index: 100;
  }

  // 导航
  .nav {
    width: 100%;
    height: 50px;
    position: absolute;
    top: var(--status-bar-height);
    left: 0;
    z-index: 10;
    display: flex;
    justify-content: center;
    align-items: center;

    .nav-tab {
      font-size: 36rpx;

      .nav-text {
        color: #fff;
        margin-right: 20rpx;
      }

      .nav-active {
        font-size: 44rpx;
        font-weight: 700;
      }
    }

    .font-btn {
      position: absolute;
      right: 0;
      top: 0;
      height: 50px;
      line-height: 50px;
      display: flex;
      justify-content: center;
      align-items: center;

      .icon {
        margin-right: 30rpx;
      }
    }
  }

  .navShow {
    padding-top: var(--status-bar-height);
    position: fixed;
    top: 0;
    background: #ff8500;

    .font-btn {
      top: var(--status-bar-height);
    }
  }

  .main {
    flex: 1;
    width: 100%;
    height: 100%;

    .scroll {
      width: 100%;
      height: 100%;
      position: relative;
			// overflow: scroll;
			
      .search {
        height: 70rpx;
        display: block;
        position: fixed;
        justify-content: center;
        border: 1px solid rgba(233, 233, 233, 0.9);
        line-height: 70rpx;
        background-color: rgba(233, 233, 233, 0.6);
        padding: 0 20rpx;
        // left: 50%;
        right: 0;
        top: 120rpx;
        border-radius: 60rpx;
        margin-right: 20rpx;
        z-index: 20;

        text {
          margin-left: 3rpx;
          font-size: 30rpx;
          color: #ffffff;
        }
      }
    }
  }

	.down {
		position: fixed;
		bottom: 80px;
		width: 100%;
		align-content: center;
		z-index: 99;
		
		.btn {
			width: 120px;
			height: 40px;
			color: $xw-font-white-color;
			// margin-left: -$xw-padding-sm;
			padding: $xw-padding-sm 0 !important;
			background: $xw-bg-btn-color;
			border-radius: 40rpx;
			margin-bottom: 5px;
		}
		
		.newBtn {
			background: $xw-bg-btn-color !important;
			color: #fff;
			border-radius: 40rpx;
			border: none !important;
			// margin-left: -50rpx;
			padding: 10rpx 20rpx;
			width: 120px;
			height: 40px;
			margin-bottom: 5px;
		}
	}
	
	.popup_overlay {
		z-index: 88;
		// position: fixed;
		// bottom: 0;
		// top: 0;
		// left: 0;
		width: 100%;
		// height: 100%;
		background-color: rgba(0,0,0,.7);
	}
	
	.popup {
		z-index: 99;
		position: fixed !important;
		bottom: 0px !important;
		width: 100%;
	}
}

@media screen and (max-width: 480px) {
  .search {
    // margin-left: 100px !important;
  }
}
@media screen and (max-width: 380px) {
}
</style>
