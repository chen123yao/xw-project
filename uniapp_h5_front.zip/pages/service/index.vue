<template>
	<view class="container" :style="{ paddingTop: `${$store.state.systemInfoSync.statusBarHeight}px`, height: `${$store.state.systemInfoSync.screenHeight}px` }">
		<view class="status_bar" :style="{ height: `${$store.state.systemInfoSync.statusBarHeight}px` }"></view>
			<!-- 这里是状态栏 -->
			<!-- <view class="background"> -->
			<!-- <view class="backTitle"> -->
			<!-- <text>开 服 表</text> -->
			<!-- <text style="font-weight: 300;font-size: 15px;margin:0  -130px 0 50px;" @click="handleTitle">类型筛选 ▼</text> -->
			<!-- </view> -->
			<!-- </view> -->
			<!-- <xw-modle :isShow='isShow' @close='close' :cate='cate'></xw-modle> -->
		<u-tabs-swiper :current="tabsCurrent" @change="tabsChange" active-color="#fff" inactive-color="#fff" height='120' font-size='34'
			bg-color="#FF8500" :show-bar="false" bar-width="80" swiperWidth="750" :is-scroll="false" ref="uTabs" :list="tabsList">
		</u-tabs-swiper>
		<swiper class="swiper" :current="swiperCurrent" @transition="transition" @animationfinish="animationfinish">
			<swiper-item class="swiper-item" v-for="(item,index) in pageData" :key="index">
				<scroll-view scroll-y style="height: 100%;width: 100%;" @scrolltolower="loadMore" lower-threshold="100" v-if="item.count">
					<!-- <xw-timeOpen v-if="swiperCurrent!==2"></xw-timeOpen> -->
					<xw-gamelist :list="item.list" :type='swiperCurrent' :lt='1'>
						<template #service="slotObj">
							<text class="soltText" >{{slotObj.data.ser_name}}</text> <text class="soltText" >
							·</text><text class="soltText"  >{{slotObj.data.start_time | dateFormat('yyyy-MM-dd hh:mm')}}</text>
						</template>
					</xw-gamelist>
					<u-loadmore bg-color="#f5f5f5" :status="status[index]" :icon-type="iconType" :load-text="loadText" @loadmore="loadMore" />
				</scroll-view>

				<xw-nodata v-else></xw-nodata>
			</swiper-item>
		</swiper>

	</view>
</template>

<script>
	import {
		mySwiperTab,
		myLoading
	} from "@/common/js/mixin.js"

	export default {
		data() {
			return {
				tabsList: [{
					name: '今日开服'
				}, {
					name: '即将开服'
				}, {
					name: '历史开服'
				}],

				status: [
					"loadmore",
					"loadmore",
					"loadmore"
				],
				isShow: false,
				cate: [],

				params: [{
						offset: 20,
						page: 1,
						server_type: 1,
					},
					{
						offset: 20,
						page: 1,
						server_type: 2,
					},
					{
						offset: 20,
						page: 1,
						server_type: 3,
					},
				],

				pageData: [{
						count: 0,
						list: []
					},
					{
						count: 0,
						list: []
					},
					{
						count: 0,
						list: []
					},
				]
			}
		},
		methods: {
			getData(params = {}) {
				this.$api({
					url: "gameserver/list",
					methods: "GET",
					data: params
				}).then(res => {
					this.pageData[params.server_type - 1].count = res.data.data.count;
					this.pageData[params.server_type - 1].list = this.pageData[params.server_type - 1].list.concat(res.data.data.list);
					if (res.data.data.list.length < params.offset) {
						this.status[params.server_type - 1] = "nomore";
					} else {
						this.status[params.server_type - 1] = "loading";
					}
				})
			},
			getInitData() {
				this.$api({
					url: "game/getcategory",
					method: "GET",
				}).then(res => {
					this.cate = res.data.data.cate;
				})
			},
			// scroll-view到底部加载更多
			loadMore() {
				this.status[this.tabsCurrent] = "loadmore";
				this.params[this.tabsCurrent].page++;
				this.getData(this.params[this.tabsCurrent]);
			},
			//点击筛选
			handleTitle() {

				this.isShow = true;
			},
			close(type) {

				this.isShow = type
			},
			tabsChange(index) {
				this.swiperCurrent = index;
			}
		},
		created() {
			this.getData(this.params[0]);
			this.getData(this.params[1]);
			this.getData(this.params[2]);
			this.getInitData()
		},
		mixins: [mySwiperTab, myLoading],
	}
</script>

<style lang="scss" scoped>
	.swiper {
		height: calc(100% - 100rpx);
		.soltText {
			color: #FF5539;
			margin-right: 6rpx;
			font-size: 22rpx;

		}
	}

	.background {
		height: 60px;
		background-color: #ff8500;
		line-height: 60px;

		.backTitle {
			text {
				color: #FFFFFF;
				font-size: 24rpx;
				font-weight: 600;
			}

		}
	}
</style>
