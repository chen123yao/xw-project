<!-- 我的钱包 -->
<template>
	<view class="container">
		<view class="top">
			<view class="text">平台币余额</view>
			<view class="balance">{{userInfo.ptb_cnt}}</view>
			<u-tag v-if="client_id==4231" text="充 值" type="warning" shape="circle" mode="light" class="tag" @click="common.routerTo({name: 'rechange'})" />
		</view>
		<u-cell-group class="group">
			<u-cell-item title="充值记录" bg-color="#f5f5f5" @click="common.routerTo({ path: '/pages/my/children/platformRecord/index', query: {index: 0}})">
				<image src="@/static/image/mine_icon_pingtaibihuoqujilu.png" mode="widthFix" slot="icon" class="image"></image>
			</u-cell-item>
			<u-cell-item title="消费记录" bg-color="#f5f5f5" @click="common.routerTo({ path: '/pages/my/children/platformRecord/index', query: {index: 1}})">
				<image src="@/static/image/mine_icon_pingtaibixiaofeijilu.png" mode="widthFix" slot="icon" class="image"></image>
			</u-cell-item>
		</u-cell-group>
	</view>
</template>

<script>
	export default {
		data(){
			return {
				
			}
		},
		methods: {
			
		},
		
	}
</script>

<style lang="scss" scoped>
	.container {
		.top {
			text-align: center;
			margin-bottom: $xw-margin-lg;
			
			.text {
				line-height: 100rpx;
			}
			
			.balance {
				font-size: $xw-font-size-super;
				font-weight: $xw-font-weight-bold;
				margin: $xw-margin-lg auto;
			}
			
			.tag {
				width: 30%;
				padding: $xw-padding-md 0;
			}
		}
		
		.group {
			
			.image {
				width: 60rpx;
				margin-right: $xw-margin-md;
			}
		}
		
		
	}
</style>

