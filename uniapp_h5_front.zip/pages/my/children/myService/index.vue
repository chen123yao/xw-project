<!-- 客服 -->
<template>
  <view class="container">
    <view class="top">
      <view class="h1">客服中心</view>
      <view class="time">09:00 -- 17:00</view>
    </view>
    <view class="bottom">
      <view class="qq">
        <image src="@/static/image/QQ.png" mode="widthFix" class="image"></image>
        <!-- <a href="tencent://message/?uin=849344326&Site=Sambow&Menu=yes">QQ在线咨询</a> -->
        <!-- <a href="http://wpa.qq.com/msgrd?v=3&uin=849344326&site=qq&menu=yes">QQ在线咨询</a> -->
        <!-- <a href="mqq://im/chat?chat_type=wpa&uin=849344326&version=1&src_type=web">QQ在线咨询</a> -->
        <view class="text">游戏客服QQ：{{userFormat.QQ_customerService}}</view>
        <view class="btn">
          <a :href="'mqq://im/chat?chat_type=wpa&uin='+userFormat.QQ_customerService+'&version=1&src_type=web'">去联系</a>
        </view>
      </view>
      <view class="mobile">
        <image src="@/static/image/mobile.png" mode="widthFix" class="image"></image>
        <view class="text">游戏客服电话：{{userFormat.footer_mobile}}</view>
        <view class="btn">
          <a :href="'tel:'+userFormat.footer_mobile">拨打</a>
        </view>

      </view>
      <view class="weixin">
        <image src="@/static/image/weixin.png" mode="widthFix" class="image"></image>
        <view class="text">游戏客服微信：{{userFormat.footer_wechat_number}}</view>
        <view class="btn" @click="common.copy(userFormat.footer_wechat_number)">复制</view>
        <image :src="userFormat.footer_wechatCode_number" class="erweima" mode="widthFix"></image>
      </view>
    </view>
  </view>
</template>

<script>
export default {

}
</script>

<style lang="scss" scoped>
.container {
  display: flex;
  flex-direction: column;

  .top {
    width: 100%;
    height: 300rpx;
    background: $xw-bg-success-color;
    text-align: center;
    color: $xw-font-white-color;
    line-height: 1.7;
    display: flex;
    flex-direction: column;

    .h1 {
      flex: 1;
      font-size: $xw-font-size-super;
    }

    .time {
      flex: 1;
    }
  }

  .bottom {
    flex: 1;
    text-align: center;
    display: flex;
    flex-direction: column;

    .qq {
      flex: 1;
    }

    .mobile {
      flex: 1;
    }

    .image {
      width: 12%;
      margin: $xw-margin-lg auto;
      margin-bottom: 16rpx;
    }

    .weixin {
      flex: 2;

      .erweima {
        width: 40%;
        margin: $xw-margin-md auto;
      }
    }

  }
  .btn{
    padding: 10rpx 15rpx;
    background-color: #ff8500;
    width: 20%;
    margin: 10rpx auto;
    border-radius: 40rpx;
    color: #fff;
    a{
      text-decoration:none;
      color: #fff;
    }
  }
}
</style>
