<!-- 消息列表 -->
<template>
	<view class="container">
		<view v-if="pageData.length">
			<scroll-view scroll-y style="height: 100%;width: 100%;" lower-threshold="100" @scrolltolower="loadMore">
				<view class="card" v-for="(item, index) in pageData" :key="index">
					<u-row>
						<u-col style="padding:0">
							<image :src="item.thumbnail" mode="widthFix" class="image" @click="common.routerTo({path: '/pages/my/children/activeDetail/index', query: {id: item.id}})"></image>
						</u-col>
					</u-row>
					<u-row>
						<u-col>
							<view class="h2 text1" @click="common.routerTo({path: '/pages/my/children/activeDetail/index', query: {id: item.id}})">{{item.title}}</view>
						</u-col>
					</u-row>
					<u-row class="text">
						<u-col span="4">
							<u-tag text="未读" type="error" shape="circle" mode="dark" v-if="item.readed == 1" />
							<u-tag text="已读" type="info" shape="circle" mode="dark" v-else />
						</u-col>
						<u-col span="8" style="text-align: right;">
							发布时间：{{item.create_time | dateFormat("yyyy-MM-dd hh:mm")}}
						</u-col>
					</u-row>
				</view>

				<u-loadmore bg-color="#f5f5f5" :status="status" :icon-type="iconType" :load-text="loadText" @loadmore="loadMore" />
			</scroll-view>
		</view>

		<xw-nodata v-else>暂无消息</xw-nodata>

	</view>
</template>

<script>
	import {
		myLoading
	} from "@/common/js/mixin.js";

	export default {
		data() {
			return {
				params: {
					page: 1,
					offset: 20,
					type: 1
				},
				pageData: [],

				status: "loadmore"
			}
		},
		methods: {
			getPageData(params) {
				this.$api({
					url: "msg/list",
					method: "GET",
					data: params
				}).then(res => {
					this.pageData = this.pageData.concat(res.data.data.list);
					if (res.data.data.list.length < params.offset) {
						this.status = "nomore";
					} else {
						this.status = "loadmore";
					}
				})
			},
			loadMore() {
				this.status = "loading";
				this.params.page++;
				this.getPageData(this.params);
			}
		},
		onLoad(options) {
			this.params.type = options.type;
			this.getPageData(this.params);
		},
		mixins: [myLoading]
	}
</script>

<style lang="scss" scoped>
	.container {
		padding: $xw-padding-base;

		.card {
			width: 100%;
			height: 500rpx;
			box-shadow: 0 0 6px 2px rgba(0, 0, 0, .1);
			border-radius: $xw-border-radius-base;
			margin-bottom: $xw-margin-base;

			.image {
				width: 100%;
				height: 340rpx !important;
				border-top-left-radius: 20rpx;
				border-top-right-radius: 20rpx;
			}

			.h2 {
				line-height: 75rpx;
			}

			.text {
				line-height: 75rpx;
				font-size: $xw-font-size-sm;
				color: $xw-font-base-color;
			}
		}
	}
</style>
