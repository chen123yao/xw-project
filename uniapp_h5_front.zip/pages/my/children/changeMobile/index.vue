<!-- 修改手机号 -->
<template>
	<view class="container">
		<!-- 未绑定 -->
		<view class="noBind" v-show="!isBind">
			<u-form :model="form1" ref="uForm" :border-bottom="false" label-width="150" style="margin-bottom: 40rpx;">
				<u-form-item label="手机号">
					<u-input v-model="form1['sms-mobile']" :border="true" placeholder="请输入手机号" />
				</u-form-item>
				<u-field v-model="form1['sms-code']" placeholder="请填写验证码" placeholder-style="color: #c0c4d4;">
					<u-button size="mini" slot="right" type="warning" @click="getCode1">{{codeText1}}</u-button>
				</u-field>
				<u-verification-code ref="uCode1" @change="codeChange1" unique-key="page-1" start-text="获取验证码" end-text="获取验证码"></u-verification-code>
			</u-form>
			<xw-button @click="handleBind1">完成绑定</xw-button>
		</view>

		<!-- 已绑定 -->
		<view class="hasBind" v-show="isBind">
			<view class="text">
				<view class="h2">当前绑定手机号：{{userInfo.mobile}}</view>
				<view class="txt">需要验证已绑定的手机号码，才能换绑新手机号码，请先验证。</view>
			</view>
			<u-form :model="form2" ref="uForm" :border-bottom="false" style="margin: 40rpx 0;">
				<u-field v-model="form2['sms-code']" placeholder="请填写验证码" placeholder-style="color: #c0c4d4;" label-width="0">
					<u-button size="mini" slot="right" type="warning" @click="getCode2">{{codeText2}}</u-button>
				</u-field>
				<u-verification-code ref="uCode2" @change="codeChange2" unique-key="page-2" start-text="获取验证码" end-text="获取验证码"></u-verification-code>
			</u-form>
			<xw-button @click="handleBind2">验证号码</xw-button>
		</view>

	</view>
</template>

<script>
	export default {
		data() {
			return {
				isBind: true,

				codeText1: "",
				form1: {
					"sms-mobile": "",
					"sms-code": "",
					"sms-type": 4,
				},

				codeText2: "",
				form2: {
					"sms-code": "",
					"sms-type": 4
				}
			}
		},
		methods: {
			codeChange1(text) {
				this.codeText1 = text;
			},
			getCode1() {
				if(!this.form1['sms-mobile']){
					uni.showToast({
						title: "请输入手机号",
						icon: "none"
					})
					return ;
				}
				let that = this;
				if (this.$refs.uCode1.canGetCode) {
					// 模拟向后端请求验证码
					uni.showLoading({
						title: '正在获取验证码',
						success() {
							that.$api({
								url: "v8/sms/send",
								method: "GET",
								data: that.form1
							}).then(res => {
								uni.showToast({
									title: res.data.msg,
									icon: "none"
								})
								
								if(res.data.code == 200){
									uni.hideLoading();
									that.$refs.uCode1.start();
								}
							})
						}
					})
				} else {
					this.$u.toast('倒计时结束后再发送');
				}
			},
			// 完成绑定
			handleBind1() {
				this.$api({
					url: "user/phone/bind",
					method: "GET",
					data: {
						mobile: this.form1["sms-mobile"],
						code: this.form1["sms-code"]
					}
				}).then(res => {
					uni.showToast({
						title: "绑定成功",
					})
					this.getUserInfo();
					this.$Router.back(1);
				})
			},

			codeChange2(text) {
				this.codeText2 = text;
			},
			getCode2() {
				let that = this;
				if (this.$refs.uCode2.canGetCode) {
					// 模拟向后端请求验证码
					uni.showLoading({
						title: '正在获取验证码',
						success() {
							that.$api({
								url: "v8/sms/send",
								method: "GET",
								data: {
									"sms-mobile": that.userInfo.mobile,
									...that.form2
								}
							}).then(res => {
								uni.showToast({
									title: res.data.msg,
									icon: "none"
								})
								
								if(res.data.code == 200){
									uni.hideLoading();
									that.$refs.uCode2.start();
								}
							})
						}
					})
				} else {
					this.$u.toast('倒计时结束后再发送');
				}
			},
			// 验证号码
			handleBind2() {
				this.$api({
					url: "user/phone/unbind",
					method: "GET",
					data: {
						mobile: this.userInfo.mobile,
						code: this.form2['sms-code']
					}
				}).then(res => {
					uni.showToast({
						title: "解绑成功",
					})
					this.isBind = false;

					this.$refs.uCode2.reset();
				})
			}
		},

		created() {
			if (this.userInfo.has_bind_mobile == 1) {
				this.isBind = false;
			} else {
				this.isBind = true;
			}
		}
	}
</script>

<style lang="scss" scoped>
	.container {
		padding: $xw-padding-base;

		.text {

			.txt {
				font-size: $xw-font-size-sm;
				color: $xw-font-light-color;
				line-height: 2;
			}
		}
	}
</style>
