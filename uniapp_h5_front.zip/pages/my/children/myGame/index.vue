<!-- 我的游戏 -->
<template>
	<view class="container">

		<u-tabs :list="list" :is-scroll="false" :current="current" @change="handleChange" active-color="#ff8500" class="head"></u-tabs>
		
		<view class="main">
			<scroll-view scroll-y style="height: 100%;width: 100%;" @scrolltolower="loadMore" lower-threshold="100" v-if="pageData[current].list.length">
				<u-cell-group>
					<u-cell-item :title="item.gamename" :center="true" bg-color="#f5f5f5" :label="item.account_cnt + '个小号'"
					 :title-style="{'font-size': '32rpx','font-weight':'700'}" :label-style="{'font-weight': 400}" v-for="(item,index) in pageData[current].list"
					 :key="index" @click="common.routerTo({path: '/pages/views/gameDetail/index', query: {game_id: item.game_id}})">
						<image slot="icon" :src="item.game_icon" class="icon" mode="widthFix"></image>
					</u-cell-item>
				</u-cell-group>
			
				<u-loadmore bg-color="#f5f5f5" :status="status[current]" :icon-type="iconType" :load-text="loadText" @loadmore="loadMore" />
			</scroll-view>
			
			<xw-nodata v-else></xw-nodata>
		</view>
	</view>
</template>

<script>
	import {
		myLoading
	} from "@/common/js/mixin.js"

	export default {
		data() {
			return {
				list: [{
					name: "手游"
				}, {
					name: "H5"
				}],
				current: 0,

				params: [{
					page: 1,
					offset: 20,
					is_h5: 0
				}, {
					page: 1,
					offset: 20,
					is_h5: 1
				}],

				pageData: [{
					count: 0,
					list: []
				}, {
					count: 0,
					list: []
				}],

				status: [
					"loadmore",
					"loadmore"
				]
			}
		},
		methods: {
			getPageData(params) {
				this.$api({
					url: "account/gamelist",
					method: "GET",
					data: params
				}).then(res => {
				console.log(res,'resresresres')
					this.pageData[params.is_h5].count = res.data.data.count;
					this.pageData[params.is_h5].list = this.pageData[params.is_h5].list.concat(res.data.data.list);
					if (res.data.data.list.length < params.offset) {
						this.status[params.is_h5] = "nomore";
					} else {
						this.status[params.is_h5] = "loadmore";
					}
				})
			},
			loadMore() {
				this.status[this.current] = "loading";
				this.params[this.current].page++;
				this.getPageData(this.params[this.current])
			},
			handleChange(index) {
				this.current = index;
			}
		},
		created() {
			this.getPageData(this.params[0])
			this.getPageData(this.params[1])
		},
		mixins: [myLoading]
	}
</script>

<style lang="scss" scoped>
	.container {
		display: flex;
		flex-direction: column;
		
		.icon {
			width: 120rpx;
			margin-right: $xw-margin-sm;
		}
		
		.head {
			width: 100%;
			height: 100rpx;
		}
		
		.main {
			flex: 1;
			overflow-y: scroll;
		}
	}
</style>
