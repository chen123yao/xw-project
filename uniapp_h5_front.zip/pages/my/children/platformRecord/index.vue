<!-- 平台币记录 -->
<template>
	<view class="container">
		<u-tabs :list="list" :is-scroll="false" :current="current" @change="handleChange" active-color="#ff8500" class="tab"></u-tabs>

		<!-- 充值记录 -->
		<view class="rechargeRecord" v-if="current == 0">
			<scroll-view scroll-y style="height: 100%;width: 100%;" lower-threshold="100" @scrolltolower="loadMoreRecharge">
				<view v-if="pageData[0].list.length">
					<xw-orderlist :list="pageData[0].list">
						<template #ptb="data">
							<view>获得平台币：{{data.data.ptb_cnt}}</view>
						</template>
					</xw-orderlist>
					<u-loadmore bg-color="#f5f5f5" :status="status[0]" :icon-type="iconType" :load-text="loadText" @loadmore="loadMoreRecharge" />
				</view>
				<xw-nodata v-else>无充值记录</xw-nodata>
			</scroll-view>
		</view>


		<!-- 消费记录 -->
		<view class="consumRecord" v-else>
			<scroll-view scroll-y style="height: 100%;width: 100%;" lower-threshold="100" @scrolltolower="loadMoreConsum">
				<view v-if="pageData[1].list.length">
					<xw-orderlist :list="pageData[1].list">
						<template #gamename="data">
							<view>游戏名称：{{data.data.gamename}}</view>
						</template>
					</xw-orderlist>
					<u-loadmore bg-color="#f5f5f5" :status="status[1]" :icon-type="iconType" :load-text="loadText" @loadmore="loadMoreConsum" />
				</view>
				<xw-nodata v-else>无消费记录</xw-nodata>
			</scroll-view>
		</view>
	</view>
</template>

<script>
	import {
		myLoading
	} from "@/common/js/mixin.js";

	export default {
		data() {
			return {
				list: [{
						name: "充值记录"
					},
					{
						name: "消费记录"
					}
				],
				current: 0,

				params: [{
					page: 1,
					offset: 20,
				}, {
					page: 1,
					offset: 20
				}],

				pageData: [{
					count: 0,
					list: []
				}, {
					count: 0,
					list: []
				}],

				status: [
					"loadmore",
					"loadmore"
				]
			}
		},
		methods: {
			// 获取充值记录
			getRechargeData(params) {
				this.$api({
					url: "app/ptb/recharge/record_list",
					method: "GET",
					data: params
				}).then(res => {
					this.pageData[0].count = res.data.data.count;
					this.pageData[0].list = this.pageData[0].list.concat(res.data.data.list);
					if (res.data.data.list.length < params.offset) {
						this.status[0] = "nomore";
					} else {
						this.status[0] = "loadmore";
					}
				})
			},
			loadMoreRecharge() {
				this.status[0] = "loading";
				this.params[0].page++;
				this.getRechargeData(this.params[0])
			},
			// 获取消费记录
			getConsumData(params) {
				this.$api({
					url: "app/sdk/order/list",
					method: "GET",
					data: params
				}).then(res => {
					this.pageData[1].count = res.data.data.count;
					this.pageData[1].list = this.pageData[1].list.concat(res.data.data.list);
					if (res.data.data.list.length < params.offset) {
						this.status[1] = "nomore";
					} else {
						this.status[1] = "loadmore";
					}
				})
			},
			loadMoreConsum() {
				this.status[1] = "loading";
				this.params[1].page++;
				this.getConsumData(this.params[1])
			},
			handleChange(index) {
				this.current = index;
			}
		},
		onLoad(option) {
			this.current = option.index;
			this.getRechargeData(this.params[0]);
			this.getConsumData(this.params[1]);
		},
		mixins: [myLoading]
	}
</script>

<style lang="scss" scoped>
	.container {}
</style>
