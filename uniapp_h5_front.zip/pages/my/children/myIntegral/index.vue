<!-- 我的积分 -->
<template>
	<view class="container">
		<view class="top">
			<view class="text">当前剩余积分</view>
			<view class="balance">{{userInfo.my_integral}}</view>
			<u-tag text="兑换平台币" type="warning" shape="circle" mode="light" class="tag" @click="common.routerTo({name: 'exchangePlatform'})" />
		</view>
		<u-cell-group>
			<u-cell-item title="记录明细" bg-color="#f5f5f5" @click="common.routerTo({name: 'integralRecord'})">
				<image src="@/static/image/jifen.png" slot="icon" mode="widthFix" class="image"></image>
			</u-cell-item>
		</u-cell-group>
	</view>
</template>

<script>
	export default {

	}
</script>

<style lang="scss" scoped>
	.container {
		.top {
			text-align: center;
			margin-bottom: $xw-margin-lg;

			.text {
				line-height: 100rpx;
			}

			.balance {
				font-size: $xw-font-size-super;
				font-weight: $xw-font-weight-bold;
				margin: $xw-margin-lg auto;
			}

			.tag {
				width: 30%;
				padding: $xw-padding-md 0;
			}
		}

		.image {
			width: 60rpx;
			margin-right: $xw-margin-md;
		}
	}
</style>
