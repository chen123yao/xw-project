<!-- 积分记录 -->
<template>
	<view class="container">
		<u-tabs :list="list" :is-scroll="false" :current="current" @change="handleChange" active-color="#ff8500"></u-tabs>

		<scroll-view scroll-y style="height: 100%;width: 100%;" @scrolltolower="loadMoreObtain" lower-threshold="100" v-if="current == 0">
			<view class="accessRecord">
				<view v-if="pageData[0].list.length">
					<u-cell-group>
						<u-cell-item :title="item.ia_name" :title-style="{'font-weight': '600'}" :label="common.dateFormat(item.create_time, 'yyyy-MM-dd hh:mm')"
						 :label-style="{'font-weight': '400'}" :value="'+'+item.integral+'积分'" :arrow="false" :value-style="{'color':'#ff8500','font-size':'40rpx','line-height':'100rpx'}"
						 bg-color="#f5f5f5" v-for="(item,index) in pageData[0].list" :key="index"></u-cell-item>
					</u-cell-group>
					<u-loadmore bg-color="#f5f5f5" :status="status[0]" :icon-type="iconType" :load-text="loadText" @loadmore="loadMoreObtain" />
				</view>

				<xw-nodata v-else>暂无获取记录</xw-nodata>
			</view>
		</scroll-view>

		<scroll-view scroll-y style="height: 100%;width: 100%;" @scrolltolower="loadMoreExchange" lower-threshold="100" v-if="current == 1">
			<view class="exchangeRecord">
				<view v-if="pageData[1].list.length">
					<u-cell-group>
						<u-cell-item :title="item.goods_name" :title-style="{'font-weight': '600'}" :label="common.dateFormat(item.create_time, 'yyyy-MM-dd hh:mm')"
						 :label-style="{'font-weight': '400'}" :value="'-'+item.integral+'积分'" :value-style="{'color':'#ff8500','font-size':'40rpx','line-height':'100rpx'}"
						 bg-color="#f5f5f5" :center="true" v-for="(item,index) in pageData[1].list" :key="index" @click="common.routerTo({path: '/pages/my/children/exchangeDetail/index', query: {order_id: item.order_id}})"></u-cell-item>
					</u-cell-group>

					<u-loadmore bg-color="#f5f5f5" :status="status[1]" :icon-type="iconType" :load-text="loadText" @loadmore="loadMoreExchange" />
				</view>

				<xw-nodata v-else>暂无兑换记录</xw-nodata>
			</view>
		</scroll-view>
	</view>
</template>

<script>
	import {
		myLoading
	} from "@/common/js/mixin.js"
	export default {
		data() {
			return {
				list: [{
					name: "获取记录"
				}, {
					name: "兑换记录"
				}],
				current: 0,

				params: [{
					page: 1,
					offset: 20,
					itg_type: 1
				}, {
					page: 1,
					offset: 20
				}],

				pageData: [{
						count: 0,
						list: []
					},
					{
						count: 0,
						list: []
					}
				],

				status: [
					"loadmore",
					"loadmore"
				]
			}
		},
		methods: {
			// 获取记录
			getObtainData(params) {
				this.$api({
					url: "app/user/itg/list",
					method: "GET",
					data: params
				}).then(res => {
					this.pageData[0].count = res.data.data.count;
					this.pageData[0].list = this.pageData[0].list.concat(res.data.data.list);
					if (res.data.data.list.length < params.offset) {
						this.status[0] = "nomore";
					} else {
						this.status[0] = "loadmore";
					}
				})
			},
			loadMoreObtain() {
				this.status[0] = "loading";
				this.params[0].page++;
				this.getObtainData(this.params[0]);
			},
			// 兑换记录
			getExchangeData(params) {
				this.$api({
					url: "app/shop/goods/exchange_list",
					method: "GET",
					data: {
						...params,
						token: this.loginInfo.user_token
					}
				}).then(res => {
					this.pageData[1].count = res.data.data.count;
					this.pageData[1].list = this.pageData[1].list.concat(res.data.data.list);
					if (res.data.data.list.length < params.offset) {
						this.status[1] = "nomore";
					} else {
						this.status[1] = "loadmore";
					}
				})
			},
			loadMoreExchange() {
				this.status[1] = "loading";
				this.params[1].page++;
				this.getExchangeData(this.params[1]);
			},
			handleChange(index) {
				this.current = index;
			}
		},
		created() {
			this.getObtainData(this.params[0]);
			this.getExchangeData(this.params[1]);
		},
		mixins: [myLoading]
	}
</script>

