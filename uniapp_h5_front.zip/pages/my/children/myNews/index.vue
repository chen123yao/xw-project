<!-- 消息列表 -->
<template>
	<view class="container">
		<view v-if="pageData.list.length">
			<scroll-view scroll-y style="height: 100%;width: 100%;" lower-threshold="100" @scrolltolower="loadMore">
				<view class="card" v-for="(item, index) in pageData.list" :key="index" @click="common.routerTo({path: '/pages/my/children/activeDetail/index', query: {id: item.id}})">
					<h3 class="text1">{{item.title}}</h3>
					<view class="content" v-html="item.content"></view>
					<u-row class="text">
						<u-col span="4">
							<u-tag text="未读" type="error" shape="circle" mode="dark" font-size="24rpx" v-if="item.readed == 1" />
							<u-tag text="已读" type="info" shape="circle" mode="dark" v-else />
						</u-col>
						<u-col span="8" style="text-align: right;">
							{{item.create_time | dateFormat("yyyy-MM-dd hh:mm")}}
						</u-col>
					</u-row>
				</view>

				<u-loadmore font-size="20" bg-color="#f5f5f5" :status="status" :icon-type="iconType" v-if="pageData.list.length>9"
				 :load-text="loadText" @loadmore="loadMore" />
			</scroll-view>
		</view>

		<xw-nodata v-else>暂无消息</xw-nodata>

	</view>
</template>

<script>
	import {
		myLoading
	} from "@/common/js/mixin.js";

	export default {
		data() {
			return {
				params: {
					page: 1,
					offset: 20,
					type: 2
				},
				pageData: {
					count: 0,
					list: []
				},

				status: "loadmore"
			}
		},
		methods: {
			getPageData() {
				this.$api({
					url: "msg/list",
					method: "GET",
					data: this.params
				}).then(res => {
					this.pageData.list = this.pageData.list.concat(res.data.data.list);
					if (res.data.data.list.length < this.params.offset) {
						this.status = "nomore";
					} else {
						this.status = "loadmore";
					}
				})
			},
			loadMore() {
				if (this.pageData.count > this.pageData.list.length) {
					this.status = "loading";
					this.params.page++;
					this.getPageData(this.params);
				} else {
					this.status = "nomore";
				}
			}
		},
		mounted() {
			this.getPageData();
		},
		mixins: [myLoading]
	}
</script>

<style lang="scss" scoped>
	.container {
		text-align: left;

		.card {
			padding: 6px;
			box-shadow: 0 0 6px 2px rgba(0, 0, 0, .1);
			border-radius: $xw-border-radius-base;
			margin: $xw-margin-base;

			.image {
				width: 100%;
				height: 340rpx !important;
				border-top-left-radius: 20rpx;
				border-top-right-radius: 20rpx;
			}

			.h2 {
				color: #303133;
				line-height: 75rpx;
			}

			.text {
				line-height: 75rpx;
				font-size: $xw-font-size-sm;
				color: $xw-font-base-color;
			}
			
			.content {
				color: #606266;
				padding: 6px;
			}
		}
	}
</style>
