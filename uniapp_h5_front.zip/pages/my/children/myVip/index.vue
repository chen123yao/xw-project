<template>
	<view class="container">
		<view class="top-bar"  :style="{marginTop:statusBarHeight+'px'}">
			<u-icon name="arrow-left" color="#fff" size="48" class="arrow-left" @click="common.routerBack()"></u-icon>
			<text style="font-size: 40rpx;color: #fff;font-weight: bold;">会员中心</text>
			<view class=""></view>
		</view>
		<view class="top-card" :style="{width:myWidth-32+'px'}" v-if="userVip&&vipLevelData.length">
			<view class="user-info flex">
				<image :src="/http/i.test(userInfo.avatar)?userInfo.avatar:'https:'+userInfo.avatar" mode="scaleToFill" 
				style="width: 90rpx;height: 90rpx;margin-right: 18rpx;border-radius: 90rpx;"></image>
				<view class="flex" style="margin-top: 10rpx;align-items: center;">
					<text class="user-name">{{userInfo.nickname}}</text>
					<view class="vip-level flex">
						<text class="vip-tet">VIP</text>
						<text class="vip-tet1" style="margin: 0 4rpx;">·</text>
						<text class="vip-tet1">{{userVip.nickgrade}}</text>
					</view>
				</view>
			</view>
			<view class="level-number">
				<view style="display:flex;align-items: center;">
					<text style="font-size: 46rpx;color: #f5dba5;">{{Number(userVip.mem_total_amount).toFixed(0)}}</text>
					<view style="margin-left: 14rpx;margin-top: 10rpx;">
						<text style="font-size: 24rpx;line-height: 20rpx;color: #f5dba5;" v-if="userVip.grade<vipLevelData[vipLevelData.length-1].grade">距离下一等级还差{{nextLevelNum}}</text>
						<text style="font-size: 24rpx;line-height: 20rpx;color: #f5dba5;" v-if="userVip.grade>vipLevelData[vipLevelData.length-1].grade">已达到最高等级</text>
					</view>
				</view>
				<view class="" style="position: relative;margin-top: 10rpx;display: flex;">
					<u-line-progress :percent="percent" active-color="linear-gradient(to right, #e8c67d, #fae3b3)" inactive-color="#3f2f05" height="24" :show-percent="false"
					 :round="true" style="width: 320rpx;">
					</u-line-progress>
					<view style="width: 320rpx;height: 10px;padding: 0 14rpx;position: absolute;left: 0;top: 0;display: flex;align-items: center;justify-content: space-between;box-sizing: border-box;">
						<text style="font-size: 12px;line-height: 10px;color: #333;transform-origin: left;transform: scale(0.9);">v{{userVip.grade}}</text>
					</view>
				</view>
			</view>
			<image src="@/static/image/role-ys.png" mode="heightFix" class="card-bg" ></image>
		</view>
		<view class="content" :style="{width:myWidth+'px'}">
			<view class="bg-color" :style="{width:myWidth+'px'}"></view>
			<view class="" style="position: relative;">				
				<image src="@/static/image/mem-bg.png" mode="scaleToFill" :style="{width:myWidth+'px'}" style="height: 940rpx;"></image>
				<view class="scroll-view" :style="{width:myWidth/1.4+'px'}">	
					<view style="display:flex;">
							<text class="mem-title item-flex">累计充值</text>
							<text class="mem-title item-flex">等级</text>
							<text class="mem-title item-flex2">说明</text>
					</view>
					<scroll-view scroll-y="true" :show-scrollbar="false" style="height: 340rpx;">
						<view class="vip-level-item flex" v-for="(item,index) in vipLevelData" :key="index" :style="{marginTop:!index?'20rpx':'32rpx'}">
							<text class="item-txt item-flex">{{item.accrue_amount}}元</text>
							<text class="item-txt item-flex">VIP · {{item.nickgrade}}</text>
							<text class="item-txt item-txt1 item-flex2">{{item.description}}</text>
						</view>
					</scroll-view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				userVip: null,
				vipLevelData: [],
				percent: 0,
				nextLevelNum: 0,
			}
		},
		computed: {
			myWidth() {
				return uni.getSystemInfoSync().windowWidth
			},
			myHeight() {
				return uni.getSystemInfoSync().windowHeight * (750 / uni.getSystemInfoSync().windowWidth)
			},
			statusBarHeight() {
				return uni.getSystemInfoSync().statusBarHeight
			},
		},
		methods: {
			getVipData() {
				this.$api({
					url: "vip/mem_grade",
						method: "GET",
						data: {
							mem_id: this.userInfo.mem_id
						}
					}).then(res=>{
					if(res.data.code == 200) {
						this.userVip = res.data.data.user_info
						this.vipLevelData =  res.data.data.rate_list
						let mem_amount = this.userVip.mem_total_amount
						console.log(mem_amount);
						this.vipLevelData.forEach((item,index)=> {
							if(Number(mem_amount)>=this.vipLevelData[this.vipLevelData.length-1].accrue_amount) {
								this.percent = 100
							} else if(Number(mem_amount)>=item.accrue_amount) {
								this.percent = (((Number(mem_amount)-item.accrue_amount) / (this.vipLevelData[index+1].accrue_amount - this.vipLevelData[index].accrue_amount))*100).toFixed(0)
								this.nextLevelNum = (this.vipLevelData[index+1].accrue_amount - Number(mem_amount)).toFixed(0)
							} else if(Number(mem_amount)<this.vipLevelData[0].accrue_amount) {
								this.percent = ((Number(mem_amount)/this.vipLevelData[0].accrue_amount)*100).toFixed(0)
								this.nextLevelNum = (this.vipLevelData[0].accrue_amount - Number(mem_amount)).toFixed(0)
							}
						})
					}
				})
			},
		},
		onShow(){
			this.getVipData()
		}
	}
</script>

<style lang="scss">
.container {
	position: relative;
	min-height: 1400rpx;
	box-sizing: border-box;
	background-image: linear-gradient(to right, #272727, #353535);
	// background-image: linear-gradient(to right, #e8c67d, #fae3b3);
	.flex {
		display:flex;
		align-items: flex-start;
	}
	.top-bar {
		position: relative;
		display:flex;
		align-items: center;
		justify-content: center;
		padding: 0 16px;
		height: 88rpx;
		.arrow-left {
			position: absolute;
			left: 16px;
		}
	}
	.top-card {
		position: relative;
		height: 280rpx;
		margin-left: 16px;
		margin-top: 32rpx;
		padding: 32rpx;
		border-radius: 20rpx;
		box-sizing: border-box;
		background-image: linear-gradient(to right, #6b4d4d, #947373);
		.user-info {
			.user-name {
				font-size: 36rpx;
				color: #fff;
				font-weight: bold;
			}
			.vip-level {
				display:flex;
				margin-left: 16rpx;
				padding: 0 10rpx;
				height: 30rpx;
				border-radius: 30rpx;
				background-color: #3f2f05;
				.vip-tet {
					font-size: 18rpx;
					font-weight: 600;
					line-height: 30rpx;
					color: #fdcf00;
				}
				.vip-tet1 {
					font-size: 20rpx;
					font-weight: 600;
					line-height: 28rpx;
					color: #fdcf00;
				}
			}
		}
		.level-number {
			margin-top: 30rpx;
			.circle {
				width: 12rpx;
				height: 12rpx;
				border-radius: 14rpx;
				margin:12rpx 0 -12rpx;
				background-color: #fb3e41;
			}
		}
		.card-bg {
			position: absolute;
			right: 0;
			bottom: 0;
			height: 240rpx;
		}
	}
	.content {
		position: absolute;
		left: 0;
		bottom: 0;
		.bg-color {			
			position: absolute;
			left: 0;
			bottom: 0;
			height: 780rpx;
			border-radius: 40rpx 40rpx 0 0;
			background-color: #fff;
		}
		.scroll-view {
			position: absolute;
			top: 200rpx;
			left: 110rpx;
			.vip-level-item {
				margin-top: 32rpx;
			}
			.mem-title {
				font-size: 30rpx;
				font-weight: bold;
				text-align: center;
				color: #333;
			}
			.item-flex {
				flex: 1;
			}
			.item-flex2 {
				flex: 1.8;
			}
			.item-txt {
				text-align: center;
				font-size: 24rpx;
				color: #333;
			}
			.item-txt1 {
				font-size: 18rpx;
			}
		}
	}
}
</style>
