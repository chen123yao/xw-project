<!-- 我的礼包 -->
<template>
	<view class="container">
		<scroll-view scroll-y style="height: 100%;width: 100%;" lower-threshold="100" @scrolltolower="loadMore">
			<view v-if="pageData.length">
				<xw-giftlist :list="pageData"></xw-giftlist>
				<u-loadmore bg-color="#f5f5f5" :status="status" :icon-type="iconType" :load-text="loadText" @loadmore="loadMore" />
			</view>
			<xw-nodata v-else></xw-nodata>
		</scroll-view>
	</view>
</template>

<script>
	import {
		myLoading
	} from "@/common/js/mixin.js";

	export default {
		data() {
			return {
				params: {
					page: 1,
					offset: 15,
				},
				status: "loadmore",
				pageData: []
			}
		},
		methods: {
			getPageData(params) {
				this.$api({
					url: "user/gift/list",
					method: "GET",
					data: params
				}).then(res => {
					this.pageData = this.pageData.concat(res.data.data.list);
					if (res.data.data.list.length < params.offset) {
						this.status = "nomore";
					} else {
						this.status = "loadmore";
					}
				})
			},
			loadMore() {
				this.status = "loading";
				this.params.page++;
				this.getPageData(this.params);
			}
		},
		created() {
			this.getPageData(this.params);
		},
		mixins: [myLoading]
	}
</script>

<style lang="scss" scoped>
</style>
