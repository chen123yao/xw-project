<!-- 任务中心 -->
<template>
	<view class="container" v-if="pageData">
		<view class="dailyTask task">
			<h2>日常任务</h2>
			<u-cell-group>
				<u-cell-item :title="item.ia_name" :arrow="false" :label="item.ia_desc" v-for="(item, index) in pageData.daily.list"
				 :key="index" :center="true">
					<image :src="item.icon" mode="widthFix" slot="icon" class="image"></image>
					<u-button slot="right-icon" size="mini" type="primary" shape="circle" class="btn" :class="{'btn2': item.finish_flag == 2}"
					 v-if="item.ia_code == 'sign'" @click="signIn">{{item.finish_flag == 1 ? '领&emsp;取' : '已完成'}}</u-button>
					<u-button slot="right-icon" size="mini" type="primary" shape="circle" class="btn1" :class="{'btn2': item.finish_flag == 2}"
					 @click="handleClick(item.ia_id)" v-else>{{item.finish_flag == 1 ? '去完成' : '已完成'}}</u-button>
				</u-cell-item>
			</u-cell-group>
		</view>
		<view class="newbieTask task">
			<h2>新手任务</h2>
			<u-cell-group>
				<u-cell-item :title="item.ia_name" :arrow="false" :label="item.ia_desc" v-for="(item,index) in pageData.one.list"
				 :key="index" :center="true">
					<image :src="item.icon" mode="widthFix" slot="icon" class="image"></image>
					<u-button slot="right-icon" size="mini" type="primary" shape="circle" class="btn1" :class="{'btn2': item.finish_flag == 2}">{{item.finish_flag == 1 ? '去完成' : '已完成'}}</u-button>
				</u-cell-item>
			</u-cell-group>
		</view>

		<u-toast ref="uToast" />
	</view>
</template>

<script>
	export default {
		data() {
			return {
				pageData: null
			}
		},
		methods: {
			getPageData() {
				this.$api({
					url: "app/integral/task/home",
					method: "GET",
				}).then(res => {
					this.pageData = res.data.data;
				})
			},
			// 签到
			signIn() {
				this.$api({
					url: "user/sign/add",
					method: "GET",
					data: {
						token: this.loginInfo.user_token
					}
				}).then(res => {
					this.getPageData();
					this.$refs.uToast.show({
						title: '签到成功',
						type: 'success',
					})
				})
			},
			// “去完成”按钮点击事件
			handleClick(ia_id) {
				switch (ia_id) {
					// 每日新游
					case 27:
						this.common.routerTo({
							name: "gameTopic",
							params: {
								title: '网游热搜',
								url: 'game/list',
								method: 'GET',
								data: {
									page: 1,
									offset: 20,
									remd: 3
								}
							}
						});
						break;
				}
			}
		},
		created() {
			this.getPageData();
		}
	}
</script>

<style lang="scss" scoped>
	.container {
		background: url(@/static/image/task_banner.png) no-repeat;
		background-size: contain;
		overflow: auto;

		.task {
			width: 90%;
			padding: $xw-padding-base $xw-padding-sm;
			background: $xw-bg-white-color;
			border-radius: $xw-border-radius-base;
			box-shadow: 2px 0 10px 0 rgba(0, 0, 0, .5);
			margin: $xw-margin-lg auto;
		}

		.dailyTask {
			margin-top: $xw-margin-md*13;
		}

		.image {
			width: 100rpx;
			margin-right: $xw-margin-sm;
		}

		.btn {
			background: $xw-bg-warning-color;
		}

		.btn1 {
			color: $xw-font-white-color;
			background: $xw-bg-success-color;
		}

		.btn2 {
			color: $xw-font-white-color;
			background: $xw-bg-light-color;
		}
	}
</style>
