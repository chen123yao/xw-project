<!-- 实名认证 -->
<template>
	<view class="container">
		<view class="text">
			<view class="h3">根据国家规定，游戏用户需要进行实名认证。</view>
			<view>信息仅用于认证且绝对保密</view>
			<view>未成年人游戏支付额度有限制</view>
		</view>
		
		<!-- 已认证 -->
		<view v-if="hasIdentify && pageData">
			<view class="info">姓名：{{pageData.real_name}}</view>
			<view class="info">身份证号：{{pageData.id_card}}</view>
			<text class="again" @click="hasIdentify = false">重新认证</text>
		</view>
		<view v-else>
			<u-form :model="form" ref="uForm">
				<u-form-item>
					<u-input v-model="form.realname" :border="true" placeholder="请输入您的真实姓名" />
				</u-form-item>
				<u-form-item>
					<u-input type="select" v-model="form.label" :border="true" placeholder="请选择证件" @click="select.show = true" />
					<u-select v-model="select.show" :list="select.list" @confirm="handleSelect"></u-select>
				</u-form-item>
				<u-form-item>
					<u-input v-model="form.idcard" :border="true" placeholder="请输入您的证件号码" />
				</u-form-item>
			</u-form>
			
			<u-toast ref="uToast" />
			
			<xw-button @click="getPageData">确 认</xw-button>
		</view>
		
	</view>
</template>

<script>
	export default {
		data() {
			return {
				hasIdentify: false,
				
				pageData: null,
				
				form: {
					realname: "",
					type: "",
					label: "",
					idcard: ""
				},

				select: {
					show: false,
					list: [{
						value: 1,
						label: "大陆居民身份证"
					}, {
						value: 2,
						label: "台胞证"
					}]
				}
			}
		},
		methods: {
			getPageData() {
				this.$api({
					url: "wap/identify/set",
					method: "GET",
					data: this.form
				}).then(res => {
					this.$refs.uToast.show({
						title: '认证成功',
						type: 'success',
						back: true
					})

					this.getUserInfo();
				})
			},
			handleSelect(arr) {
				this.form.label = arr[0].label;
				this.form.type = arr[0].value;
			},
			// 获取认证信息
			getIdentify(){
				this.$api({
					url: "wap/identify/info",
					method: "GET"
				}).then(res=>{
					this.pageData = res.data.data;
				})
			}
		},
		created(){
			if(this.userInfo.has_identify == 2){
				this.hasIdentify = true;
				this.getIdentify();
			}else{
				this.hasIdentify = false
			}
		}
	}
</script>

<style lang="scss" scoped>
	.container {
		padding: $xw-padding-base;

		.text {
			color: $xw-font-light-color;
			line-height: 1.7;
			margin-bottom: 30rpx;

			.h3 {
				color: $xw-font-main-color;
			}
		}
		
		.info {
			font-size: 32rpx;
			line-height: 50rpx;
		}
		
		.again {
			color: #ff8500;
			line-height: 50rpx;
			margin-top: 30rpx;
			text-decoration: underline;
		}
	}
</style>
