<!-- 兑换详情页面 -->
<template>
	<view class="container" v-if="pageData">
		<u-cell-group>
			<u-cell-item title="订单编号" :arrow="false" :value="pageData.order_id" bg-color="#f5f5f5"></u-cell-item>
			<u-cell-item title="交易时间" :arrow="false" :value="common.dateFormat(pageData.update_time, 'yyyy-MM-dd hh:mm')"
			 bg-color="#f5f5f5"></u-cell-item>
			<u-cell-item title="兑换商品" :arrow="false" :value="pageData.goods_name" bg-color="#f5f5f5"></u-cell-item>
			<u-cell-item title="所需积分" :arrow="false" :value="pageData.integral" bg-color="#f5f5f5"></u-cell-item>
			<u-cell-item title="收货地址" :arrow="false" :value="pageData.address" bg-color="#f5f5f5"></u-cell-item>
			<u-cell-item title="联系方式" :arrow="false" :value="pageData.mobile" bg-color="#f5f5f5"></u-cell-item>
			<u-cell-item title="发货状态" :arrow="false" :value="pageData.shipping_status" bg-color="#f5f5f5"></u-cell-item>
			<u-cell-item title="说明" :arrow="false" :value="pageData.admin_note" bg-color="#f5f5f5"></u-cell-item>
		</u-cell-group>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				pageData: null
			}
		},
		methods: {
			getPageData(params) {
				this.$api({
					url: "app/shop/goods/exchange_detail",
					method: "GET",
					data: params
				}).then(res => {
					this.pageData = res.data.data
				})
			},
		},
		onLoad(options) {
			this.getPageData({
				order_id: options.order_id
			})
		}
	}
</script>

