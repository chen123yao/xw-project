<template>
	<view class="bigackground">
		<view class="bigturntable">
			<view class="paomadeng" ref='paomadeng'>
				<text v-for="(item,index) in 10" :key='index'></text>
			</view>
			<view class="paomadeng" ref='paomadeng1' style="top: 37%;">
				<text v-for="(item,index) in 10" :key='index'></text>
			</view>
			<!-- <image src="@/static/image/bigturntablebgi.png" mode="widthFix" class="bgi" style="width:100%;" /> -->
			<image src="@/static/image/dzp-cd.png" mode="widthFix" style="width:100%;" />
			<image src="@/static/image/dzp-zt.png" mode="widthFix" class="dzpzt" style="width:70%;" />
			<view class="dzpjh" v-if="is_free==1">您有一次免费抽奖机会</view>
			<view class="dzpjh" v-else>您今天免费次数已用完</view>
			<view class="my_integral">我的积分：{{userInfo.my_integral}}</view>
			<view class="bigturntable-zp">
				<LuckyGrid style="margin:0 auto;" ref="LuckDraw" width="300px" height="300px" :prizes="prizes"
					:buttons="buttons" :blocks="blocks" :default-config="defaultConfig" :default-style="defaultStyle"
					:active-style="activeStyle" @start="startCallBack" @end="endCallBack" />
			</view>
			<xw-popup v-model="show" mode="center" border-radius="20" width="100%" :mask-close-able='false'>
				<!-- 兑换抽奖机会 -->
				<view class="dzp-tc" v-if="handleShow">
					<image class="dzp-tck" src="@/static/image/dzp-tck.png" style="width:100%" />
					<view class="dzp-tc-content">
						<image src="@/static/image/dzp-jf.png" mode="widthFix" style="width:100rpx;" />
						<view class="dzp-tc-content-text1">幸运大转盘1次抽奖</view>
						<view class="dzp-tc-content-text2">你将消耗50积分</view>
						<view class="dzp-tc-content-text3" v-if="userInfo.my_integral<50">
							<u-icon name="info-circle-fill" color="#ff8500" size="28"></u-icon>
							<text>您的积分不足，快去完成任务赚钱吧</text>
						</view>
						<view class="dzp-tc-content-text4">
							<button style="background-color: #a1a1a1;" @click="active = true;show=false">我再想想</button>
							<button :style="{backgroundColor:userInfo.my_integral<50?'#a1a1a1':'#ff8500'}"
								@click="handleClick" :disabled="userInfo.my_integral<50">确认兑换</button>
						</view>
					</view>
				</view>
				<!-- 未中奖 -->
				<view class="dzp-tc1" v-else-if="order.is_win==2">
					<image class="dzp-tck" src="@/static/image/dzp-wzj.png" style="width:100%;" />
					<view class="dzp-tc-content">
						<image src="@/static/image/0.png" mode="widthFix" style="width:300rpx;" />
						<view class="dzp-tc-content-xx">{{order.prize_name}}</view>
						<u-button type="primary" shape='circle' @click="handleNo">再接再厉</u-button>
					</view>
				</view>
				<!-- 中奖 -->
				<view class="dzp-tc2" v-else>
					<image class="dzp-tck" src="@/static/image/dzp-zj.png" style="width:100%;" />
					<image class="guang" :src="guangimg" />
					<view class="dzp-tc-content">
						<image :src="order.prize_img" mode="widthFix" style="width:300rpx;" />
						<view class="dzp-tc-content-xx">{{order.prize_name}}</view>
						<u-button type="primary" shape='circle' @click="handleReceive">立即领取</u-button>
					</view>
					<!-- <view class="dzp-dh">
          <image class="gy" src="@/static/image/dzp-gy.png" style="width:100rpx;height:900rpx;" />
          <image class="gy" src="@/static/image/dzp-gy.png" style="width:100rpx;height:900rpx;" />
          <image class="gy" src="@/static/image/dzp-gy.png" style="width:100rpx;height:900rpx;" />
          <image class="gy" src="@/static/image/dzp-gy.png" style="width:100rpx;height:900rpx;" />
          <image class="gy" src="@/static/image/dzp-gy.png" style="width:100rpx;height:900rpx;" />
          <image class="gy" src="@/static/image/dzp-gy.png" style="width:100rpx;height:900rpx;" />
          <image class="gy" src="@/static/image/dzp-gy.png" style="width:100rpx;height:900rpx;" />
        </view> -->
				</view>
			</xw-popup>
			<view class="myrule" ref="myrules">
				<text>抽奖规则：</text>
				<text> 1 .每天一次免费抽奖机会，每日零点重置</text>
				<text> 2 .每日一次免费机会用完后，50积分每次</text>
			</view>

		</view>
	</view>
</template>

<script>
	import LuckyGrid from "@/components/uni-luck-draw/lucky-grid";

	export default {
		components: {
			LuckyGrid,
		},
		data() {
			return {
				luckyNum: 0,
				pageData: "",
				timeer: "",
				prizeRecord: "",
				order: "",
				guangimg: "",
				is_free: "",
				handleShow: true,
				active: true,
				prizes: [],
				blocks: [{
						padding: "30 12",
						background: "#ffc27a",
						borderRadius: 16,
					},
					{
						padding: "4px",
						background: "#ED6A36",
						borderRadius: 23,
					},
					{
						padding: "4px",
						background: "#ED6A36",
						borderRadius: 20,
					},
				],
				defaultConfig: {
					gutter: 5,
				},
				defaultStyle: {
					borderRadius: 15,
					fontColor: "#DF424B",
					fontSize: "14px",
					textAlign: "center",
					background: "#fff",
					// shadow: '0 5 1 #ebf1f4'
				},
				activeStyle: {
					background: "#fcf368",
					shadow: "2 2 9 #FE0E0D",
					fontColor: "#FE0E0D",
				},
				show: false,
			};
		},
		onReady() {
			this.$refs.paomadeng.$el.style.marginBottom =
				this.systemInfoSync.windowHeight -
				this.$refs.paomadeng1.$el.offsetTop -
				290 +
				"px";
			this.$refs.myrules.$el.style.marginBottom =
				this.systemInfoSync.windowHeight -
				this.$refs.paomadeng1.$el.offsetTop -
				350 +
				"px";

			let i = 0;
			this.timeer = setInterval(() => {
				if (i % 2) {
					this.$refs.paomadeng.$children.map((item, index) => {
						item.$el.style.backgroundColor = "#fefefe";
						if (index % 2) {
							item.$el.style.backgroundColor = "#FED639";
						}
					});
					this.$refs.paomadeng1.$children.map((item, index) => {
						item.$el.style.backgroundColor = "#fefefe";
						if (index % 2) {
							item.$el.style.backgroundColor = "#FED639";
						}
					});
					this.guangimg = require("@/static/image/guang.png");
				} else {
					this.$refs.paomadeng.$children.map((item, index) => {
						item.$el.style.backgroundColor = "#FED639";
						if (index % 2) {
							item.$el.style.backgroundColor = "#fefefe";
						}
					});

					this.$refs.paomadeng1.$children.map((item, index) => {
						item.$el.style.backgroundColor = "#FED639";
						if (index % 2) {
							item.$el.style.backgroundColor = "#fefefe";
						}
					});
					this.guangimg = require("@/static/image/guang1.png");
				}

				i++;
			}, 500);
		},
		computed: {
			buttons() {
				return [{
					x: 1,
					y: 1,
					imgs: [{
						src: "../../../../static/image/cjbutton.png",
						width: "90%",
						top: "0%",
					}, ],
					background: "#FFAD1D",
					shadow: "0 0 1 #e89b4f",
					fonts: [{
							text: `抽奖`,
							fontColor: "#fff",
							top: "20%",
							fontSize: "26",
							fontWeight: "700",
						},
						{
							text: `50积分/次`,
							fontColor: "#fff",
							top: "60%",
							fontSize: "13",
						},
					],
				}, ];
			},
		},
		onLoad(option) {
			if (Object.keys(option).length > 0) {
				this.common.setStorage("mem-username", "");
				this.common.setStorage("mem-password", "");
				this.$store.commit("setLoginInfo", {});
				this.$store.commit("setUserInfo", {});
				this.$store.commit("setLoginInfo", {
					user_token: option.user_token,
				});
				setTimeout(() => {
					this.getUserInfo(option.user_token);
				}, 300);
			}
		},
		onUnload() {
			clearInterval(this.timeer);
		},
		methods: {
			getUserInfo(user_token) {
			
				this.$api({
					url: "user/detail",
					method: "GET",
					data: {
						token: user_token,
					},
				}).then((res) => {
					this.$store.commit("setUserInfo", res.data.data);
					setTimeout(() => {
						this.getPrizeList();
					}, 200);
				});
			},
			//领取接口
			handleReceive() {
				uni.showToast({
					icon: "none",
					title: "领取成功！",
					success: () => {
						setTimeout(() => {
							this.getUserInfo();
							this.show = false;
							setTimeout(() => {
								this.handleShow = true;
							}, 100);
						}, 200);
					},
				});
			},
			handleNo() {
				this.show = false;
				this.getPrizeList();
			},
			getPrizeList() {
				//请求奖品列表
				this.$api({
					url: "app/shop/big_wheel_list",
					data: {
						mg_mem_id: this.userInfo.mem_id,
					},
				}).then((res) => {
					this.is_free = res.data.data.is_free;
					this.pageData = res.data.data.list.sort((a, b) => {
						return a.prize_order - b.prize_order;
					});
					this.pageData = res.data.data.list;
					const prizes = [];
					this.luckyNum = 10;
					let axis = [
						[0, 0],
						[1, 0],
						[2, 0],
						[2, 1],
						[2, 2],
						[1, 2],
						[0, 2],
						[0, 1],
					];
					for (let i = 0; i < 8; i++) {
						let item = this.pageData[i];
						prizes.push({
							index: i,
							x: axis[i][0],
							y: axis[i][1],
							prize_order: item.prize_order,
							fonts: [{
								text: item.prize_name,
								top: "72%",
								fontSize: "12",
								fontColor: "#ff8500",
							}, ],
							imgs: [{
								src: item.prize_img,
								width: "76%",
							}, ],
						});
					}
					this.prizes = prizes;
				});
			},
			startCallBack() {
				if (this.active) {
					if (this.is_free == 1) {
						this.handleClick();
					} else {
						this.show = true;
						this.handleShow = true;
					}
					this.getPrizeList();
					this.active = false;
				}
			},
			//确认抽奖
			handleClick() {
				this.show = false;
				if (this.is_free == 2) {
					this.userInfo.my_integral = this.userInfo.my_integral - 50;
				}
				this.$api({
					url: "app/shop/lucky_draw",
					data: {
						is_free: this.is_free,
						mem_id: this.userInfo.mem_id,
					},
				}).then((res) => {
					this.order = res.data.data;
					this.$refs.LuckDraw.play();
					this.handleShow = false;
					let timer = setTimeout(() => {
						this.$refs.LuckDraw.stop(this.order.prize_order - 1);
					}, 3000);
				});
			},
			endCallBack(prize) {
				this.show = true;
				this.getUserInfo();
				this.prizeRecord = prize.fonts[0];
				this.active = true;
				this.getPrizeList();
			},
		},
	};
</script>

<style lang="scss" scoped>
	.bigackground {
		// background: url(~@/static/image/bigturntablebgi.png) no-repeat;
		background: url("~@/static/image/bigturntablebgi.png") center no-repeat;
		background-size: 100%;
		background-position: 0 0;
		width: 100%;
		height: 100vh;
		overflow: hidden;
		background-color: #f7a085;

		.bigturntable {
			position: relative;
			height: 100%;

			.paomadeng {
				width: 70%;
				position: absolute;
				left: 50%;
				height: 40rpx;
				bottom: 0;
				// margin-bottom: 32%;
				transform: translateX(-50%);
				// background-color: red;
				z-index: 100;
				display: flex;
				justify-content: space-around;

				text {
					width: 20rpx;
					height: 20rpx;
					border-radius: 50%;
				}
			}

			.myrule {
				position: absolute;
				bottom: 0;
				left: 42%;
				transform: translateX(-50%);
				color: #a85f3d;
				font-size: 22rpx;
				display: flex;
				flex-direction: column;

				text {
					white-space: nowrap;
				}
			}

			.bgi {
				position: absolute;
				// height: 100vh;
			}

			.dzpzt {
				position: absolute;
				top: 32%;
				left: 50%;
				transform: translateX(-50%);
			}

			.dzpjh {
				position: absolute;
				top: 31.5%;
				left: 50%;
				transform: translateX(-50%);
				color: #a85f3d;
				font-size: 30rpx;
				letter-spacing: 4rpx;
				font-weight: 600;
			}

			.my_integral {
				position: absolute;
				top: 34%;
				left: 50%;
				transform: translateX(-50%);
				color: #a85f3d;
				letter-spacing: 2rpx;
				font-size: 22rpx;
			}

			.bigturntable-zp {
				position: absolute;
				top: 36%;
				left: 50%;
				transform: translateX(-50%);

				// z-index: 9;
			}

			.dzp-tc,
			.dzp-tc1,
			.dzp-tc2 {
				position: relative;
				height: 100%;
				overflow: hidden;

				.dzp-tck {
					position: absolute;
				}

				.dzp-tc-content {
					position: absolute;
					width: 80%;
					height: 60%;
					padding: 40rpx 0;
					display: flex;
					flex-direction: column;
					align-items: center;
					// text-align: center;
					// background-color: red;
					top: 28%;
					left: 50%;
					z-index: 10;
					transform: translateX(-50%);

					// view:nth-child(1) {
					// }
					// view:nth-child(2) {
					// }
					.dzp-tc-content-text1 {
						margin-top: 10rpx;
					}

					.dzp-tc-content-text2 {
						color: red;
					}

					.dzp-tc-content-text3 {
						margin-top: 40rpx;

						text {
							color: #ff8500;
						}
					}

					.dzp-tc-content-text4 {
						margin-top: 40rpx;
						width: 80%;
						display: flex;
						justify-content: space-between;

						button {
							padding: 10rpx 40rpx;
							line-height: 40rpx;
							font-size: 24rpx;
							color: #fff;
							border: none;
							border-radius: 10rpx;
						}
					}
				}
			}

			.dzp-tc {
				height: 700rpx;
			}

			.guang {
				position: absolute;
				z-index: -1;
				top: -5%;
				width: 100%;
				height: 40%;
			}

			.dzp-tc1,
			.dzp-tc2 {
				height: 1000rpx;

				.dzp-tc-content {
					top: 50%;

					.dzp-tc-content-xx {
						margin-top: -40rpx;
						margin-bottom: 40rpx;
						color: #ff8500;
					}
				}
			}

			// .dzp-tc2:before {
			// 	content: '';
			// 	position: absolute;
			// 	width: 100rpx;
			// 	height: 400rpx;
			// 	background-color: red;
			// 	top: 0;
			// 	left: 50%;
			// 	z-index: 11;

			// 	transform: rotate3d(5, 4, 4, 72deg);

			// 	// -webkit-transform: rotateX(120deg);
			// 	/* Safari 与 Chrome */
			// 	// translate3d(x,y,z)
			// 	// transform:rotate(30deg);
			// 	// transform: rotateX(120deg);
			// 	transform: rotate3d(30deg)
			// }

			.dzp-tc2 {
				position: relative;
				transform-style: preserve-3d;

				.dzp-tc-content {
					top: 48%;

					.dzp-tc-content-xx {
						margin-top: 0;
						margin-bottom: 20rpx;
						color: #ff8500;
					}
				}

				.dzp-dh {
					position: absolute;
					top: -200rpx;
					left: 50%;
					transform: translateX(-50%);
					text-align: center;
					display: flex;
					z-index: -1;

					.gy {
						position: absolute;
						left: 50%;
						transform: translateX(-50%);

						&:nth-child(1) {
							transform: rotate(-65deg);
							margin-top: 40rpx;
						}

						&:nth-child(2) {
							transform: rotate(-35deg);
							margin-top: 30rpx;
						}

						&:nth-child(3) {
							transform: rotate(-15deg);
							padding-top: 20rpx;
						}

						&:nth-child(4) {
							transform: rotate(0deg);
						}

						&:nth-child(5) {
							transform: rotate(15deg);
							padding-top: 20rpx;
						}

						&:nth-child(6) {
							transform: rotate(35deg);
							margin-top: 30rpx;
						}

						&:nth-child(7) {
							transform: rotate(65deg);
							margin-top: 40rpx;
						}
					}
				}
			}
		}
	}

	@media screen and (max-height: 750px) {
		.bigturntable>.paomadeng:nth-child(2) {
			top: 45% !important;
		}

		// .myrule {
		// 	margin-bottom: 6% !important;
		// }

		.dzpjh {
			top: 36% !important;
		}

		.my_integral {
			top: 39% !important;
		}

		.bigturntable-zp {
			top: 43% !important;
		}

		.dzpzt {
			top: 37% !important;
		}
	}
</style>
