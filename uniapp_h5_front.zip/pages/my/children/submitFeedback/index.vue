<!-- 意见反馈 -->
<template>
	<view class="container">
		<u-form :model="form" ref="uForm">
			<u-form-item>
				<u-input v-model="form.content" type="textarea" :border="true" placeholder="提出你宝贵的意见或建议有助于我们提供更好的服务" height="240" />
			</u-form-item>
			<u-form-item>
				<u-input v-model="form.linkman" type="number" :border="true" placeholder="请留下你的手机号" />
			</u-form-item>
		</u-form>

		<u-toast ref="uToast" />

		<xw-button @click="getPageData">提 交</xw-button>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				form: {
					content: "",
					linkman: ""
				}
			}
		},
		methods: {
			getPageData(params) {
				this.$api({
					url: "game/feedback",
					method: "GET",
					data: this.form
				}).then(res => {
					this.$refs.uToast.show({
						title: '提交成功',
						type: 'success',
						back: true
					})

				})
			}
		},
	}
</script>

<style lang="scss" scoped>
	.container {
		padding: $xw-padding-base;
	}
</style>
