<!-- 我的账号 -->
<template>
	<view class="container">
		<u-cell-group>
			<u-cell-item title="头像" class="avatar" bg-color="#f5f5f5" :arrow="false">
				<u-avatar :src="userInfo.avatar" mode="circle" size="mini" @click="changeAvatar"></u-avatar>
			</u-cell-item>
			<u-cell-item title="昵称" :value="userInfo.nickname" bg-color="#f5f5f5" @click="nickName.show = true"></u-cell-item>
			<u-cell-item title="手机号" :value="userInfo.has_bind_mobile == 2 ? userInfo.mobile : '待绑定'" bg-color="#f5f5f5" @click="common.routerTo({name: 'changeMobile'})"></u-cell-item>
			<u-cell-item title="密码修改" bg-color="#f5f5f5" @click="common.routerTo({name: 'changePassword'})"></u-cell-item>
			<u-cell-item title="实名认证" :value="userInfo.has_identify == 2 ? '已认证' : '待认证'" bg-color="#f5f5f5" @click="common.routerTo({name: 'changeRealname'})"></u-cell-item>
		</u-cell-group>
		<!-- 修改昵称弹框 -->
		<u-modal v-model="nickName.show" :mask-close-able="true" confirm-color="#ff8500" :show-cancel-button="true" @confirm="changeNickname">
			<view class="nickName">
				<u-input v-model="nickName.value" :border="true" placeholder="请输入昵称"></u-input>
			</view>

		</u-modal>
	</view>
</template>


<script>
	export default {
		data() {
			return {
				nickName: {
					value: "",
					show: false,
				},
			}
		},
		methods: {
			// 进入图库选图上传
			changeAvatar() {
				let that = this;
				uni.chooseImage({
					count: 1,
					sizeType: ['compressed'], //可以指定是原图还是压缩图，默认二者都有
					sourceType: ['album'], //从相册选择
					success(file) {
						uni.uploadFile({
							url: that.httpAPI + "asset/upload",
							files: [{
								name: "file",
								uri: file.tempFilePaths[0]
							}],
							success(res) {
								let avatar = JSON.parse(res.data).data.url;
								that.avatarUpload({
									avatar: avatar
								})
							},
						})
					}
				})
			},
			// 头像数据上传
			avatarUpload(params) {
				this.$api({
					url: "user/avatar/update",
					method: "GET",
					data: params
				}).then(res => {
					this.getUserInfo();
				})
			},
			// 修改用户昵称
			changeNickname() {
				this.$api({
					url: "user/nickname/update",
					method: "GET",
					data: {
						nickname: this.nickName.value,
					}
				}).then(res => {
					this.getUserInfo();
				})
			},
		},
		// 导航栏自定义按钮点击监听
		onNavigationBarButtonTap() {
			this.$api({
				url: "user/logout",
				method: "GET",
			}).then(res => {
				// 返回上一页
				uni.navigateBack({
					delta: 1
				})
				// 清空本地存储的登录数据
				this.$store.commit('setInit', {});
				this.$store.commit('setLoginInfo', {});
				this.$store.commit('setUserInfo', {});
				this.common.setStorage('mem-username','')
				this.common.setStorage('mem-password','')
				
			})
		}
	}
</script>

<style lang="scss" scoped>
	.container {
		.u-cell {
			line-height: 48rpx;
		}

		.avatar {
			padding-bottom: 0;
			position: relative;

			.avatarUpload {
				width: 70rpx;
				height: 70rpx;
				position: absolute;
				right: 40rpx;
				top: 20rpx;
				background: transparent;
			}
		}

		.nickName {
			padding: $xw-padding-md;
		}
	}
</style>
