<!-- 兑换平台币 -->
<template>
	<view class="container">
		<u-cell-group>
			<u-cell-item title="我的积分" :value="userInfo.my_integral" :arrow="false" bg-color="#f5f5f5" :value-style="{'color': '#ff8500'}"
			 style="padding: 30rpx 0;"></u-cell-item>
			<u-cell-item title="兑换平台币" value="(100积分 = 1平台币)" :arrow="false" bg-color="#f5f5f5" style="padding: 30rpx 0;"></u-cell-item>
		</u-cell-group>
		<u-input v-model="ptb_cnt" :border="true" border-color="#ff8500" placeholder="请输入平台币数量" class="input"></u-input>
		<view class="text">
			需消耗：<text class="jifen">{{integral}}积分</text>
		</view>
		<u-toast ref="uToast" />
		<xw-button @click="exchangePtb">兑 换</xw-button>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				ptb_cnt: ""
			}
		},
		computed: {
			integral() {
				return this.ptb_cnt * 100 || 0;
			}
		},
		methods: {
			exchangePtb() {
				this.$api({
					url: "app/shop/goods/exchange_ptb",
					methods: "GET",
					data: {
						ptb_cnt: this.ptb_cnt
					}
				}).then(res => {
					this.getUserInfo();
					this.$refs.uToast.show({
						title: '兑换成功',
						type: 'success',
					})
					this.ptb_cnt=''
					
				})
			}
		}
	}
</script>

<style lang="scss" scoped>
	.container {
		padding: $xw-padding-base;

		.input {
			margin: $xw-margin-base auto;
		}

		.text {
			margin-bottom: $xw-margin-md;
			color: $xw-font-auxiliary-color;

			.jifen {
				color: $xw-font-primary-color;
			}
		}
	}
</style>
