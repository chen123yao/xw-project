<!-- 修改密码 -->
<template>
	<view class="container">
		<u-form :model="form" ref="uForm">
			<u-form-item>
				<u-input v-model="form.oldpwd" type="password" :border="true" placeholder="请输入原密码" />
			</u-form-item>
			<u-form-item>
				<u-input v-model="form.newpwd" type="password" :border="true" placeholder="请输入新密码" />
			</u-form-item>
			<u-form-item>
				<u-input v-model="form.newpwdAgain" type="password" :border="true" placeholder="请再次输入新密码" />
			</u-form-item>
		</u-form>

		<u-toast ref="uToast" />

		<xw-button @click="getPageData">确 认</xw-button>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				form: {
					oldpwd: "",
					newpwd: "",
					newpwdAgain: ""
				}
			}
		},
		methods: {
			getPageData() {
				if(this.form.newpwd != this.form.newpwdAgain){
					this.$refs.uToast.show({
						title: '输入新密码不一致',
						type: 'error',
					})
					return ;
				}
				this.$api({
					url: "user/passwd/update",
					method: "GET",
					data: this.form
				}).then(res => {
					this.$refs.uToast.show({
						title: '修改成功',
						type: 'success',
						back: true
					})
				})
			}
		}
	}
</script>

<style lang="scss" scoped>
	.container {
		padding: $xw-padding-base;
	}
</style>
