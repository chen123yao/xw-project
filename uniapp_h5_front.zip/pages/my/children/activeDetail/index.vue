<!-- 活动详情页面 -->
<template>
	<view class="container">
		<iframe :src="url" frameborder="0" seamless>暂无数据</iframe>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				url: ""
			}
		},
		onLoad(options) {
			this.url =
				this.httpAPI + "msg/detail?agent-ch=&agent-sub_ch=&app_id=100&client_id=398&device-brand=samsung&device-device_id=355757010361547&device-disk_space=780058624-388091904&device-has_sim=2&device-imsi=&device-ip=172.17.99.15&device-is_break=1&device-is_charge=1&device-latitude=&device-longitude=&device-mac=36:15:2F:BD:28:1D&device-model=SM-G955F&device-net=WIFI&device-open_time=1311&device-os=android&device-os_version=Android5.1.1&device-screen=900*1600&device-screen_luminance=102&device-userua=Mozilla/5.0(Linux;Android5.1.1;SM-G955FBuild/JLS36C;wv)AppleWebKit/537.36(KHTML,likeGecko)Version/4.0Chrome/74.0.3729.136MobileSafari/537.36&game-app_ver=1.2&game-h_ver=398&game-sdk_ver=&id=" +
				options.id +
				"&sign=24253cbce47f8ede2262c51f14e9c9b0&token=" +
				this.loginInfo.user_token +
				"&ts=1578102023194";
		}
	}
</script>

<style lang="scss" scoped>
	.container {
		iframe {
			width: 100%;
			height: 100%;
		}
	}
</style>
