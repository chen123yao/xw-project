<template>
	<view class="container" :style="{ paddingTop: `${$store.state.systemInfoSync.statusBarHeight}px`, height: `${$store.state.systemInfoSync.screenHeight}px` }">
		<view class="status_bar" :style="{ height: `${$store.state.systemInfoSync.statusBarHeight}px` }"></view>
		<view class="head">
			<view class="setting clearfix">
				<view class="icon">
					<u-image :lazy-load="false" src="../../static/image/mylitNews.png" width="40" height="40"
						@click="common.routerTo({name: 'myNews'})"></u-image>
					<view class="circle" v-if="news_count"></view>
				</view>
				<u-image :lazy-load="false" src="../../static/image/search1.png" width="40" height="40" class="icon"
					@click="common.routerTo({path: '/pages/views/search/index', query: {type: '游戏'}})"></u-image>
				<!-- <image src="../../static/image/mylitNews.png" mode="widthFix" class="fr" style="width: 40rpx;" @click="common.routerTo({name: 'myNews'})"></image> -->
				<!-- <image src="../../static/image/search1.png" mode="widthFix" class="fr" style="width: 40rpx;margin-right:30rpx;" @click="common.routerTo({path: '/pages/views/search/index', query: {type: '游戏'}})"></image> -->
			</view>

			<u-row class="login">
				<u-col span="11" @click="common.routerTo({name: 'myAccount'})">
					<view class="avatar">
						<view class="">
							<u-avatar :src="userInfo.avatar" v-if="loginInfo.user_token" size="large"></u-avatar>
							<u-avatar src="@/static/image/myAvatar.png" size="large" v-else></u-avatar>
						</view>
						<view class="avatartext">
							<view class="txt">
								<text v-if="loginInfo.user_token">{{userInfo.nickname}}</text>
								<text v-else>点击登录</text>
							</view>
						</view>
						<view class="vip-box" style="height: 120rpx;display: flex;align-items: center;">							
							<view class="vip" v-if="vipData" @click.stop="common.routerTo({name: 'myVip'})">
								<text class="vip-tet">VIP </text>
								<text class="vip-tet1" style="margin: 0 4rpx;">·</text>
								<text class="vip-tet1">{{vipData.nickgrade}}</text>
							</view>
						</view>
					</view>
				</u-col>
			</u-row>

			<u-row class="recharge">
				<u-col span="1.2">
					<image src="../../static/image/ptbyue.png" mode="widthFix" style="width: 40rpx;margin-top: 10rpx;">
					</image>
				</u-col>
				<u-col span="7.2" class="txt" style="color: #FFF4D0;" @click="common.routerTo({name: 'myWallet'})">
					<text>平台币余额：</text>
					<text v-if="loginInfo.user_token"
						style="text-overflow:ellipsis;white-space: nowrap;overflow: hidden;">{{userInfo.ptb_cnt}}</text>
					<text v-else>--</text>
				</u-col>
				<!-- <u-col span="3.5">
					<u-tag :text="loginInfo.user_token?'充值':'立即开通'" mode="plain" shape="circle" color="#36280E" class="fr userTag"
					 @click="common.routerTo({name: 'myWallet'})" />
				</u-col> -->
			</u-row>
		</view>
		<view class="body">
			<view class="bodyView">常用功能</view>
			<u-grid :col="4" :border="false">
				<u-grid-item @click="installNow" v-if="$store.state.systemInfoSync.statusBarHeight == 0">
					<image :src="userFormat.icon" mode="widthFix"></image>
					<view class="grid-text">盒子下载</view>
				</u-grid-item>
				<u-grid-item @click="common.routerTo({name: 'myAccount'})">
					<image src="@/static/image/myAccount.png" mode="widthFix"></image>
					<view class="grid-text">账户管理</view>
				</u-grid-item>
				<u-grid-item @click="common.routerTo({name: 'myTask'})">
					<image src="@/static/image/myTask.png" mode="widthFix"></image>
					<view class="grid-text">任务中心</view>
				</u-grid-item>
				<u-grid-item @click="common.routerTo({name: 'myIntegral'})">
					<image src="@/static/image/myIntegral.png" mode="widthFix"></image>
					<view class="grid-text">我的积分</view>
				</u-grid-item>
				<u-grid-item @click="common.routerTo({name: 'myGift'})">
					<image src="@/static/image/myGift.png" mode="widthFix"></image>
					<view class="grid-text">我的礼包</view>
				</u-grid-item>
				<!-- 	<u-grid-item @click="common.routerTo({name: 'myLittle'})">
					<image src="@/static/image/myLittle.png" mode="widthFix"></image>
					<view class="grid-text">小号交易</view>
				</u-grid-item> -->
				<u-grid-item @click="common.routerTo({name: 'information'})">
					<image src="@/static/image/myInformation.png" mode="widthFix"></image>
					<view class="grid-text">游戏资讯</view>
				</u-grid-item>
				<u-grid-item @click="common.routerTo({name: 'myGame'})">
					<image src="@/static/image/myGame.png" mode="widthFix"></image>
					<view class="grid-text">我的游戏</view>
				</u-grid-item>
				<u-grid-item @click="common.routerTo({name: 'submitFeedback'})">
					<image src="@/static/image/fankui.png" mode="widthFix"></image>
					<view class="grid-text">消息反馈</view>
				</u-grid-item>
			<!-- 	<u-grid-item @click="common.routerTo({name: 'bigTurntable'})">
					<image src="@/static/image/fankui.png" mode="widthFix"></image>
					<view class="grid-text">转盘</view>
				</u-grid-item>
				<u-grid-item @click="common.routerTo({name: 'selete'})">
					<image src="@/static/image/fankui.png" mode="widthFix"></image>
					<view class="grid-text">精选</view>
				</u-grid-item> -->
				
				
				
			</u-grid>
		</view>
		<view class="body little" style="border-radius: 3px;">
			<u-grid :col="2" :border="false" align="center">
				<u-grid-item>
					<image src="@/static/image/myVersion.png" mode="widthFix"></image>
					<view class="grid-text">{{client_id}}</view>
				</u-grid-item>
				<u-grid-item @click="common.routerTo({name: 'myService'})" class="little_view">
					<image src="@/static/image/myService.png" mode="widthFix"></image>
					<view class="grid-text">客服中心</view>
				</u-grid-item>
			</u-grid>
		</view>
	</view>
</template>

<script>
	export default {
		name: "my",
		data() {
			return {
				news_count: 0,
				vipData: null
			}
		},
		computed: {
			token() {
				return this.$store.state.loginInfo.user_token
			}
		},
		watch: {
			userInfo: {
				handler(val) {
					if (Object.keys(val).length) {						
						this.getVipData()
					}
				}
			}
		},
		methods: {
			getVipData() {
				this.$api({
					url: "vip/mem_grade",
						method: "GET",
						data: {
							mem_id: this.userInfo.mem_id
						}
					}).then(res=>{
					console.log(res);
					if(res.data.code == 200) {
						this.vipData = res.data.data.user_info
					}
				})
			},
			installNow() {
				window.open(this.userFormat.down_app_url);
			},
			getPageData() {
				this.$api({
					url: "msg/list",
					method: "GET",
					data: {
						page: 1,
						offset: 20,
						type: 2
					}
				}).then(res => {
					if (res.data.code == 200) {
						this.news_count = res.data.data.unread_count;
					}
				})
			},
		},
		onTabItemTap() {
			if (this.token) {
				this.getPageData();
				this.getVipData()
			}
		},
		onShow() {
			this.getVipData()
		}
	}
</script>

<style lang="scss" scoped>
	.container {
		width: 100%;
		height: 100%;
		overflow: auto;
		display: flex;
		flex-direction: column;
		justify-content: flex-start;
		align-items: center;
		background-color: #f5f5f5;

		.head {
			width: 100%;
			height: 400rpx;
			background: url(@/static/image/myBg.png) center no-repeat;
			background-size: 100% 100%;
			padding: $xw-padding-base $xw-padding-base 0;
			display: flex;
			flex-direction: column;

			.setting {
				flex: 1;
				display: flex;
				justify-content: flex-end;

				.icon {
					margin: 0 20rpx;
					position: relative;

					.circle {
						position: absolute;
						top: -2px;
						right: -2px;
						width: 4px;
						height: 4px;
						border-radius: 50%;
						background: red;
					}
				}
			}

			.login {
				flex: 6;

				.avatar {
					display: flex;
					justify-content: flex-start;
					align-items: content;
					line-height: 120rpx;

					image {
						width: 200rpx;
					}

					.avatartext {
						margin-left: 30rpx;
						color: #434240;

						.txt {
							font-weight: 600;
							font-size: 32rpx;

						}
					}
					.vip {
						display: flex;
						margin-left: 32rpx;
						padding: 0 10rpx;
						height: 30rpx;
						border-radius: 30rpx;
						background-color: #3f2f05;
					}
					.vip-tet {
						font-size: 18rpx;
						font-weight: 600;
						line-height: 30rpx;
						color: #fdcf00;
					}
					.vip-tet1 {
						font-size: 20rpx;
						font-weight: 600;
						line-height: 28rpx;
						color: #fdcf00;
					}
				}


			}

			.userTag {
				background-image: linear-gradient(to right, #FFEFD4, #FFE3BD, #FFD9AB);
				white-space: nowrap
			}

			.recharge {
				// flex: 2.1;
				color: $xw-font-primary-color;
				font-size: $xw-font-size-base;
				padding: 12rpx $xw-padding-md;
				box-sizing: border-box;
				border-top-left-radius: 12rpx;
				border-top-right-radius: 12rpx;
				background: url(../../static/image/yuedi.png) center no-repeat;
				background-size: 110%;

				text {
					font-size: 28rpx;

				}

			}
		}

		.body {
			margin-top: 20rpx;
			width: 90%;
			border-radius: 3rpx;
			border-top-left-radius: 22rpx;
			border-top-right-radius: 22rpx;
			padding: 6px 8px 2px 8px;
			box-sizing: border-box;
			box-shadow: 0 0 9px 3px #e3e3e3;
			background-color: #fff;

			.bodyView {
				margin: 23rpx 0 23rpx -78%;
				font-size: 32rpx;
				font-weight: 600;
			}

			image {
				width: 70rpx;
			}

			.grid-text {
				margin-top: 20rpx;
			}
		}


	}
</style>
