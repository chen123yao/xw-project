<!-- 搜索页面 -->
<template>
	<view class="container" :style="{ paddingTop: `${$store.state.systemInfoSync.statusBarHeight}px`, height: `${$store.state.systemInfoSync.screenHeight - 80}px` }">
		<view class="status_bar" :style="{ height: `${$store.state.systemInfoSync.statusBarHeight}px` }"></view>
		<view class="search">
			<u-icon name="arrow-left" color="#aaa" size="40" class="icon" @click="common.routerBack(1)"></u-icon>
			<u-search border-color='#f3f3f3' placeholder="搜索游戏" v-model="params.keywords" @custom="handleSearch(params.keywords)"
			 @search="handleSearch(params.keywords)" @change="handleChange(params.keywords)" shape="round" clearabled bg-color="#fff"
			 :action-style="{color: '#ff8500'}"></u-search>
		</view>
		<!-- 盒子下载展示 -->
		<view class="h5-download" v-if="$store.state.systemInfoSync.statusBarHeight == 0">
			<!-- <pre>			{{userFormat}}</pre> -->
			<image src="../../../static/image/h5downal2.png" mode="widthFix" style="border-radius: 20rpx;"></image>
			<view class="h5-download-content">
				<view class="h5-download-content-top">
					<image :src="userFormat.icon" mode="widthFix" style="width: 100rpx;"></image>
					<view class="h5-download-content-top-text">
						<view class="h5-download-content-top-text-title">{{userFormat.name}}盒子</view>
						<view class="h5-download-content-top-text-slogan">{{userFormat.slogan}}</view>
					</view>
				</view>
				<view style="width: 18%;">
					<xw-button @click="installNow" :item='{classify:8}' style="padding: 0;">立即安装</xw-button>
				</view>
			</view>
		</view>
		<view class="h5-download" v-else>
			<image src="../../../static/image/h5downal4.png" mode="widthFix" style="border-radius: 20rpx;"></image>
		</view>
		<!-- 这里展示历史搜索 -->
		<view class="history" v-if="!pageData">
			<view class="title clearfix">
				<u-tag text="历史" mode="dark" shape="circleRight" type="warning" />
				<text class="fr" @click="removeHistory">清空全部</text>
			</view>
			<view class="tags">
				<u-tag :text="'盒子下载'" mode="dark" shape="circle" bg-color="#d2cbcb" class="tag" @click='installNow'></u-tag>
				<u-tag :text="item" mode="dark" shape="circle" bg-color="#d2cbcb" v-for="(item,index) in historyData" :key="index"
				 class="tag" @click="handleSearch(item)" />
			</view>
		</view>
		<!-- 这里展示搜索之后得到的数据 -->
		<view class="gameList" v-else>
			<view v-if="$Route.query.type == '游戏'">
				<xw-gamelist :list="pageData.list" v-if="pageData.count">
					<template #game="slotObj">
						<view class="tags">
							<u-tag :text="common.numberTag(slotObj.data.downcnt)" mode="dark" type="success" style="margin-right: 10rpx;"></u-tag>
							<u-tag v-for="(item,index) in slotObj.data.type" :key="index" :text="item" size="mini" v-if="index<3" mode="plain"
							 shape="circleRight" color="#ff8500" style="margin-right: 10rpx;"></u-tag>
						</view>
					</template>
				</xw-gamelist>
				<xw-nodata v-else>无相关游戏数据</xw-nodata>
			</view>
			<view v-else-if="$Route.query.type == '交易'">
				<xw-salelist v-if="pageData.list.length" :list="pageData.list"></xw-salelist>
				<xw-nodata v-else>无相关交易数据</xw-nodata>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				params: {
					page: 1,
					offset: 30,
					keywords: ""
				},
				pageData: null,
				historyData: [],

				text: ""
			}
		},
		methods: {
			// 游戏搜索：获取关键字搜索结果
			getGameData(params) {
				switch (this.$Route.query.type) {
					case "游戏":
						this.$api({
							url: "game/search",
							method: "GET",
							data: params
						}).then(res => {
							this.pageData = res.data.data;
						})
						break;
					case "交易":
						this.$api({
							url: "account/goods/list",
							method: "GET",
							data: {
								status: 2,
								page: params.page,
								offset: params.offset,
								keyword: params.keywords
							}
						}).then(res => {
							this.pageData = res.data.data;
						})
						break;
				}
			},
			// 获取搜索历史
			getHistory() {
				this.historyData = this.common.getStorage("history") || [];
			},
			// 设置搜索历史
			setHistory(keywords) {
				this.historyData.push(keywords);
				this.historyData = this.common.arrayDuplicate(this.historyData);
				this.common.setStorage("history", this.historyData);
			},
			// 清除搜索历史
			removeHistory() {
				this.common.removeStorage('history');
				this.getHistory();
			},
			// 搜索
			handleSearch(keywords) {
				// 数据存入本地
				this.setHistory(keywords);
				// 关键字搜索
				this.params.keywords = keywords;
				this.getGameData(this.params)
			},
			// keyword发生变化
			handleChange(keywords) {
				if (!keywords) {
					this.pageData = null
				}
			},
			installNow() {
				window.open(this.userFormat.down_app_url);
			}
		},
		created() {
			this.getHistory();
		}
	}
</script>

<style lang="scss" scoped>
	.container {
		text-align: left;

		.search {
			width: 100%;
			height: 100rpx;
			padding: 0 $xw-padding-sm;
			display: flex;
			justify-content: center;
			align-items: center;

			.icon {
				width: 60rpx;
				height: 100rpx;
			}
		}

		.h5-download {
			position: relative;
			padding: 30rpx;
			padding-top: 0;

			.h5-download-content {
				display: flex;
				align-items: center;
				position: absolute;
				bottom: 40rpx;
				left: 50%;
				transform: translateX(-50%);
				width: 92%;
				height: 18%;
				border-radius: 0 0 20rpx 20rpx;
				padding: 10rpx;
				// background-color: rgba(0,0,0,.3);
				background-image: linear-gradient(rgba(0, 0, 0, .3), rgba(0, 0, 0, .8));

				.h5-download-content-top {
					width: 92%;
					margin: 0 auto;
					display: flex;
					align-items: center;
					padding-bottom: 14rpx;


					.h5-download-content-top-text {
						margin-left: 20rpx;
						color: #fff;

						.h5-download-content-top-text-title {
							font-size: 46rpx;
							font-weight: 500;
						}

						.h5-download-content-top-text-slogan {
							font-size: 22rpx;
						}
					}
				}


			}
		}

		.history {
			padding: 0 $xw-padding-sm;

			.title {
				height: 60rpx;
				line-height: 60rpx;
				font-size: $xw-font-size-sm;
				margin: 20rpx auto;
			}

			.tags {
				padding: $xw-padding-md;

				.tag {
					margin: $xw-margin-sm;
				}
			}
		}

		.gameList {
			height: 100%;

			.tags {
				@include text-overflow(1);
			}
		}
	}
</style>
