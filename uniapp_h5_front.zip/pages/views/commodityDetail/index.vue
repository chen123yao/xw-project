<!-- 商品详情 -->
<template>
	<view v-if="pageData" class="container">
		<u-row gutter="20" class="game">
			<u-col span="3">
				<u-image :src="pageData.game_icon" width="140" height="140"></u-image>
			</u-col>
			<u-col span="8" class="h2 gamename">{{pageData.gamename}}</u-col>
			<u-col span="1" style="text-align: right;" @click="common.routerTo({path: '/pages/views/gameDetail/index', query: {'game_id': pageData.game_id}})">
				<u-icon name="arrow-right" color="#888" size="28"></u-icon>
			</u-col>
		</u-row>
		<u-row class="xiaohao">
			<u-col span="8" class="id">
				<view class="role_id">小号ID：<text class="fw">{{pageData.role_id}}</text></view>
				<view>区号：<text class="fw">{{pageData.server_id}}</text></view>
			</u-col>
			<u-col span="4" class="price">
				￥{{pageData.price | keepOne(2)}}
			</u-col>
			<u-col class="time">
				<u-row>
					<u-col span="5" style="padding-left:0;">
						累计充值：{{pageData.sum_money}}元
					</u-col>
					<u-col span="7" style="text-align: right;padding-right:0;">
						上架时间：{{pageData.create_time | dateFormat("yyyy-MM-dd hh:mm")}}
					</u-col>
				</u-row>
			</u-col>
		</u-row>
		<u-row class="desc">
			<u-col class="h3">
				卖家描述：
			</u-col>
			<u-col class="text">
				{{pageData.description}}
			</u-col>
			<u-col span="4" class="image" v-for="(item,index) in images" :key="index">
				<u-image :src="item" width="100%" mode="widthFix"></u-image>
			</u-col>
		</u-row>
		<u-row class="btn">
			<u-col>
				<xw-button @click="show = true">立即购买</xw-button>
			</u-col>
		</u-row>

		<!-- 买家须知 -->
		<u-modal v-model="show" title="买家须知" :show-cancel-button="true" confirm-color="#ff8500" :content-style="{textAlign: 'left'}"
		 @confirm="common.routerTo({path: '/pages/views/payMethods/index', query: {goods_id: pageData.goods_id}})">
			<view class="slot-content">
				<view>1.角色信息已经通过官方核验；</view>
				<view>2.购买角色直接转入您的账号，购买后登录游戏即可查收角色；若未见请在悬浮球内切换小号。</view>
				<view>3.因时间因素造成的角色数据变化（如排行榜），玩家需理解并接受；</view>
				<view>4.购买后不可退货</view>
			</view>
		</u-modal>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				pageData: null,
				show: false,
			}
		},
		computed: {
			images() {
				if (JSON.parse(this.pageData.image).length == 1) {
					return JSON.parse(this.pageData.image)[0].split(",")
				} else {
					return JSON.parse(this.pageData.image)
				}
			}
		},
		methods: {
			getData(params) {
				this.$api({
					url: "account/goods/detail",
					method: "GET",
					data: params
				}).then(res => {
					this.pageData = res.data.data;
				})
			},
		},
		onLoad(options) {
			this.getData({
				goods_id: options.goods_id
			})
		}
	}
</script>


<style lang="scss" scoped>
	.container {
		padding: $xw-padding-sm $xw-padding-base;
		position: relative;

		.game {
			width: 100%;
			padding: $xw-padding-md 0;
			border-bottom: 5px solid $xw-border-primary-color;

			.gamename {
				@include text-overflow(1);
			}
		}

		.xiaohao {
			padding: $xw-padding-base 0 $xw-padding-sm;
			border-bottom: 5px solid $xw-border-primary-color;

			.id {
				line-height: 40rpx;

				.role_id {
					@include text-overflow(1);
				}

				.fw {
					font-weight: $xw-font-weight-bold;
				}
			}

			.price {
				font-weight: $xw-font-weight-bold;
				font-size: $xw-font-size-lg;
				color: $xw-font-success-color;
				text-align: right !important;
			}

			.time {
				font-size: $xw-font-size-sm;
				line-height: 50rpx;
				border-top: 1px solid $xw-border-primary-color;
				margin-top: $xw-margin-sm;
			}
		}

		.desc {
			padding: $xw-padding-base 0;

			.text {
				font-size: $xw-font-size-sm;
				color: $xw-font-base-color;
				line-height: 40rpx;
			}

			.image {
				margin-top: $xw-margin-base;
			}
		}

		.btn {
			width: 100%;
			position: absolute;
			bottom: 10rpx;
			left: 0;
		}

		// 弹出窗口
		.slot-content {
			padding: $xw-padding-base;
			font-size: $xw-font-size-md;
			color: $xw-font-auxiliary-color;
			line-height: 40rpx;
		}
	}
</style>
