<!-- 支付方式 -->
<template>
	<view class="container">
		<view class='text'>请选择你的支付方式</view>
		<u-cell-group v-if="payMethods">
			<u-cell-item :title="item.name" bg-color="#f5f5f5" :center="true" @click="handlePay(item.payway)" v-for="(item,index) in payMethods"
			 :key="index">
				<u-image :src="item.icon" slot="icon" width="100" height="100" style="margin-right: 30rpx;"></u-image>
			</u-cell-item>
		</u-cell-group>
	</view>
</template>

<script>
	export default {
		onLoad(options) {
			this.goods_id = options.goods_id;
			this.order_id = options.order_id || "";
			this.order_token = options.order_token || "";
		},
		data() {
			return {
				goods_id: 0,
				order_id: "",
				order_token: "",

				payMethods: null,
				payway: "",
				order: {} // 下单之后的返回值
			}
		},
		methods: {
			// 获取支付方式
			getPayMethods() {
				this.$api({
					url: "account/pay/payway",
					method: "GET",
				}).then(res => {
					this.payMethods = res.data.data;
				})
			},
			// 点击支付
			handlePay(payway) {
				this.payway = payway;

				if (!this.order_id) {
					this.placeOrder();
				} else {
					this.initiatePay(this.order_id, this.order_token);
				}
			},
			// 第一步：下单
			placeOrder() {

				this.$api({
					url: "account/goods/buy",
					method: "GET",
					data: {
						payway: this.payway,
						goods_id: this.goods_id
					}
				}).then(res => {
					if(res.data.code == 200){
						this.order = res.data.data;
						this.initiatePay(this.order.order_id, this.order.token);
					}else{
						uni.showToast({
							title: '下单失败'
						})
					}
				})
			},
			// 第二步：发起支付
			initiatePay(order_id, order_token) {
				this.$api({
					url: "account/goods/pay?goods_id=81",
					method: "GET",
					data: {
						goods_id: this.goods_id,
						payway: this.payway,
						order_id: order_id,
						pay_token: order_token
					}
				}).then(res => {
					if ("alipayh5" == res.data.data.pay_type) {
						if (uni.getSystemInfoSync().platform == 'ios') {
							// window.location.href = res.data.data.token;
							plus.runtime.openURL(res.data.data.token,function(res){
								
							})
						} else {
							plus.runtime.openURL(res.data.data.btoken,function(res){
								
							})
						}
					}
					if ("wxpayh5" == res.data.data.pay_type) {
						plus.runtime.openURL(res.data.data.btoken,function(res){
							
						})
					}

					this.orderStatus();
				})
			},
			// 监听订单状态
			orderStatus() {
				this.$api({
					url: "/account/order/queryj",
					method: "GET",
					data: {
						order_id: this.order.order_id
					}
				}).then(res => {
					if (res.data.data.status == 2) {
						uni.showToast({
							title: res.data.msg
						})
					} else {
						setTimeout(() => {
							this.orderStatus();
						}, 3000);
					}
				})
			}
		},
		created() {
			this.getPayMethods();
		}
	}
</script>

<style lang="scss" scoped>
	.container {
		.text {
			color: $xw-font-auxiliary-color;
			padding: $xw-padding-lg $xw-padding-base;
		}
	}
</style>
