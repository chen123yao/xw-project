<!-- 礼包详情页面 -->
<template>
	<view class="container" v-if="pageData">
		<u-row class="game">
			<u-col span="2.5">
				<image :src="pageData.icon" mode="widthFix" class="icon"></image>
			</u-col>
			<u-col span="7.5" class="progress">
				<view class="h3 gamename">{{pageData.game_name}}</view>
				<u-line-progress active-color="#ff8500" :striped="true" :show-percent="false" :percent="percent" height="10" :striped-active="true"></u-line-progress>
				<view class="surplus">剩余{{percent}}%</view>
			</u-col>
			<u-col span="2" class="btn">
				<xw-button @click="getGift">{{pageData.code ? '复 制' : '领 取'}}</xw-button>
			</u-col>
		</u-row>
		<u-gap height="20" bg-color="#fff"></u-gap>
		<view class="content">
			<u-section title="礼包内容" :right="false" font-size="36" line-color="#ff8500"></u-section>
			<view class="desc">{{pageData.content}}</view>
			<u-section title="使用方法" :right="false" font-size="36" line-color="#ff8500"></u-section>
			<view class="desc">{{pageData.func}}</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				params: {
					gift_id: 0
				},
				pageData: null,
			}
		},
		computed: {
			percent(){
				return this.pageData.remain_cnt / this.pageData.total_cnt *100;
			}
		},
		methods: {
			getData(params) {
				this.$api({
					url: 'gift/detail',
					method: "GET",
					data: params
				}).then(res => {
					this.pageData = res.data.data;
				})
			},
			// 领取礼包  
			getGift(){
				if(this.pageData.code) {
					this.common.copy(this.pageData.code);
				} else {
					this.$api({
						url: "user/gift/add?gift_id=6",
						method: "GET",
						data: {
							gift_id: this.pageData.gift_id
						}
					}).then(res=>{
						uni.showToast({
							title: "领取成功"
						})
						// 刷新页面数据
						this.getData(this.params)
					})
					
				}
				
			}
		},
		onLoad(option) {
			this.params.gift_id = option.gift_id;
			this.getData(this.params);
		},
	}
</script>

<style lang="scss" scoped>
	.container {
		.game {
			padding: $xw-padding-base;

			.icon {
				width: 100%;
			}
			
			.progress {
				overflow: hidden;
				
				.gamename {
					@include text-overflow(1);
				}
			}
			
			.surplus {
				font-size: $xw-font-size-sm;
				color: $xw-font-primary-color;
			}
		}
		
		.content {
			padding: $xw-padding-base;
			text-align: left;
			
			.desc {
				padding: $xw-padding-md $xw-padding-base;
				color: $xw-font-base-color;
				margin-bottom: $xw-margin-base;
			}
		}
	}
</style>
