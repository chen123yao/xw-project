<template>
  <view class="share">
    <u-image src="@/static/image/1.png" mode="widthFix" class="share-bgi"></u-image>
    <u-image src="@/static/image/2.png" mode="widthFix" class="share-bgi"></u-image>
    <u-image src="@/static/image/3.png" mode="widthFix" class="share-bgi"></u-image>
    <u-image src="@/static/image/4.png" mode="widthFix" class="share-bgi" @click="toRegister"></u-image>
    <u-image src="@/static/image/5.png" mode="widthFix" class="share-bgi"></u-image>
    <u-image src="@/static/image/6.png" mode="widthFix" class="share-bgi"></u-image>
    <u-image src="@/static/image/7.png" mode="widthFix" class="share-bgi"></u-image>
    <u-image src="@/static/image/8.png" mode="widthFix" class="share-bgi"></u-image>
    <u-image src="@/static/image/9.png" mode="widthFix" class="share-bgi"></u-image>
    <u-image src="@/static/image/10.png" mode="widthFix" class="share-bgi"></u-image>
  </view>
</template>

<script>
export default {
  data() {
    return {
      mem_id: ""
    }
  },
  methods: {
    toRegister() {
      this.common.routerTo({ path: "/pages/views/registerShare/index", query: { mem_id: this.mem_id } })
    }
  },
  created() {
    this.mem_id = this.$route.query.mem_id
  },
}
</script>

<style lang="scss" scoped>
.share {
  width: 100%;
  height: 100%;
  font-size: 0;
  .share-bgi {
    width: 100%;
  }
}
</style>