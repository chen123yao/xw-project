<!-- 资讯详情页面 -->
<template>
	<view class="container" v-if="pageData">
		<view class="icon">
			<view class="h2">{{pageData.excerpt}}</view>
		</view>
		<view class="desc">
			<view v-html="pageData.content"></view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				pageData: null
			}
		},
		methods: {
			getData(params) {
				this.$api({
					url: "news/detail",
					method: "GET",
					data: params
				}).then(res => {
					this.pageData = res.data.data.data;
				})
			}
		},
		onLoad(option) {
			this.getData({
				news_id: option.news_id
			})
		}
	}
</script>

<style lang="scss" scoped>
	.container {
		padding: $xw-padding-md;
		overflow: auto;

		.icon {
			text-align: center;
			margin: $xw-margin-sm auto;

			image {
				width: 30%;
			}
		}

		.desc {
			text-align: left;

			img {
				width: 100% !important;
			}
		}
	}
</style>
