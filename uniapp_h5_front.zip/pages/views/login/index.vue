<!-- 登录页面 -->
<template>
	<view class="container">
		<view class="h1">
			欢迎登录
		</view>
		<u-form :model="form" ref="uForm" label-width="120" :border-bottom="false" label-align="right">
			<u-form-item label="用户名">
				<u-input v-model="form['mem-username']" @focus='isShow=false' @blur='isShow=true'
					placeholder="请输入账号或手机号" :border="true" />
			</u-form-item>
			<u-form-item label="密 码">
				<u-input v-model="form['mem-password']" @focus='isShow=false' @blur='isShow=true' type="password"
					placeholder="请输入密码" :border="true" />
			</u-form-item>
		</u-form>
		<view class="forgotPsd clearfix">
			<text class="fr" @click="common.routerTo({name: 'forgetPwd'})">忘记密码</text>
		</view>
		<view class="btn">
			<xw-button @click="doLogin">登 录</xw-button>
		</view>
		<view v-if='isShow' class="bottom">注册即表示同意<text class="txt">《平台服务协议》</text></view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				form: {
					"mem-username": "",
					"mem-password": ""
				},
				isShow: true,
				// 转接页面
				redirect: "",
			}
		},
		methods: {
			doLogin() {
				this.$api({
					url: "user/login",
					method: "GET",
					data: {
						...this.form,
						equipmentCode: this.equipmentCode
					}
				}).then(res => {
					if (res.data.code == 200) {
						// 将登录获取的数据记录下来
						this.$store.commit("setLoginInfo", res.data.data)
						// 将用户名密码记录在本地
						this.common.setStorage('mem-username', this.form["mem-username"])
						this.common.setStorage('mem-password', this.form["mem-password"])

						uni.showToast({
							title: res.data.msg
						})
						// 返回上一页
						setTimeout(() => {
							uni.navigateBack({
								delta: 1
							})
						}, 1000)

						// 获取用户信息
						this.getUserInfo();
						// this.getAboutInfo();
					} else {
						uni.showToast({
							icon: 'none',
							title: res.data.msg
						})
					}

				})
			}
		},
		// 监听导航栏自定义按钮的点击事件
		onNavigationBarButtonTap() {
			this.common.routerTo({
				name: 'register'
			})
		},
		onLoad(options) {
			this.redirect = options.redirect;
		},
		created() {
			this.form["mem-username"] = this.common.getStorage('mem-username') || "";
			this.form["mem-password"] = this.common.getStorage('mem-password') || "";
		}
	}
</script>

<style lang="scss" scoped>
	.container {
		padding: $xw-padding-base;
		position: relative;

		.forgotPsd {
			font-size: $xw-font-size-sm;

			.fr {
				color: $xw-font-primary-color;
			}
		}

		.btn {
			width: 60%;
			margin: $xw-margin-md*3 auto;
		}

		.bottom {
			width: 100%;
			position: absolute;
			bottom: 40rpx;
			text-align: center;
			font-size: $xw-font-size-sm;

			.txt {
				color: $xw-font-primary-color;
			}
		}
	}
</style>
