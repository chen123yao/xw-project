<!-- 游戏详情页面 -->
<template>
  <view class="container" v-if="pageData" :style="{ paddingTop: `${$store.state.systemInfoSync.statusBarHeight}px` }">
		<view class="status_bar" :style="{ height: `${$store.state.systemInfoSync.statusBarHeight}px` }"></view>
    <!-- 顶部自定义导航栏 -->
    <u-row class="navbar" :style="{'background': 'rgba(255,133,0,'+ bg +')', top: `${$store.state.systemInfoSync.statusBarHeight}px`}">
      <u-col span="6">
        <u-icon name="arrow-left" color="#fff" :style="{'background': 'rgba(0,0,0,'+ (0.6-bg) +')'}" size="40" class="back" @click="routerTo"></u-icon>
      </u-col>
    </u-row>
    <!-- 顶部 -->
    <view class="top">
      <!-- 顶部图片 -->
      <image :src="pageData.hot_image" mode="widthFix"></image>
    </view>
    <!-- 游戏简介 -->
    <u-row class="game">
      <u-col span="2.3">
        <u-image :src="pageData.icon" width='140' height="140" mode="widthFix"></u-image>
      </u-col>
      <u-col span="7" class="desc">
        <view class="gamename">{{pageData.gamename}}</view>
        <view class="tags">
          <u-tag :text="pageData.size" mode="dark" size="mini" v-if="pageData.size.substr(0,1)!=0"></u-tag>
          <u-tag :text="item" :type="tagTypes[index]" size="mini" mode="dark" v-for="(item,index) in pageData.type" :key="index"></u-tag>
        </view>
        <view class="size">
          <image src="/static/image/pingfen.png" mode="widthFix"></image>
          <text style="color: #FF8500;">{{(pageData.star_cnt).toFixed(1)}}分</text>
          <text class="dian" v-if="pageData.gc_id">·</text>
          <text v-if="pageData.gc_id">{{pageData.gc_id}}出品</text>
          <view v-if="pageData.popularity_cnt">
            <text>{{pageData.popularity_cnt}}在玩</text>
          </view>
        </view>
      </u-col>
      <u-col span="2">
        <view class="myRate" v-if="pageData.rate&&pageData.rate<1">
          <image src="/static/image/zhekouda.png" mode="widthFix"></image>
          <text>{{(pageData.rate*10).toFixed(1) + '折'}}</text>
        </view>
      </u-col>

    </u-row>
    <!-- 游戏介绍 -->
    <u-read-more :toggle="true" show-height="200" color="#ff8500" style="background-color: #f3f3f3;">
      <rich-text :nodes="pageData.desc"></rich-text>
      <!-- 图片展示 -->
      <view class="images">
        <swiper class="swiper" display-multiple-items="3" style="height:450rpx;margin:10rpx 0;">
          <swiper-item v-for="(item,index) in pageData.image" :key="index" class="item" style="text-indent: 10rpx;">
            <image :src="item" width="100%" @click="common.previewImage(index,pageData.image)" mode="widthFix"></image>
          </swiper-item>
        </swiper>
      </view>
    </u-read-more>
    <!-- 分栏 -->
    <u-tabs :list="newList" :is-scroll="false" :current="current" active-color="#ff8500" :show-bar="false" @change="handleChange" v-if="newList.length>0"></u-tabs>
    <view class="tabContent" v-if="newList&&newList.length>0">
      <!-- 1.福利 -->
      <xw-gamewelfare :news='pageData.post.activity' :list="pageData.gift" v-if='(pageData.gift.length>0||pageData.post.activity.count>0)&&current==0'></xw-gamewelfare>
      <!-- 2.返利 -->
      <xw-gamerebate :news='pageData.post.rebate' v-if="newList.filter(item=> item.type=='rebate').length>0&&newList.filter(item=> item.type=='rebate')[0].current==current">
      </xw-gamerebate>
      <!-- 3.vip表 -->
      <xw-gameviptable :news='pageData.post.viptable' v-if="newList.filter(item=> item.type=='viptable' ).length>0&&newList.filter(item=> item.type=='viptable' )[0].current==current">
      </xw-gameviptable>
      <!-- 5.开服 -->
      <xw-gameServer :list="pageData.serlistNew.list" v-if="pageData.serlistNew.list.length>0&&newList.filter(item=> item.type=='newServer')[0].current==current">
      </xw-gameServer>
      <!-- 4.资讯 -->
      <xw-gameInfo :list="pageData.post.news.list" v-if="newList.filter(item=> item.type=='news').length>0&& newList.filter(item=> item.type=='news')[0].current==current">
      </xw-gameInfo>
      <!-- </u-read-more> -->
    </view>
    <!-- 热评 -->
    <xw-gameComment :data="pageData" :pages='pages'></xw-gameComment>
    <!-- <xw-gameGift :list="pageData.gift"></xw-gameGift> -->
    <!-- 底部下载按钮 -->
    <view class="button">
      <xw-button :item="pageData"></xw-button>
    </view>
  </view>
</template>


<script>
import {
  tagTypes,
  colors
} from "@/common/js/mixin.js";

import gameComment from "./children/gameComment/index.vue";
import gameInfo from "./children/gameInfo/index.vue";
import gameTransation from "./children/gameTransation/index.vue";
import gameServer from "./children/gameServer/index.vue";
// import gameGift from "./children/gameGift/index.vue";
import gamewelfare from "./children/gamewelfare/index.vue";
import gamerebate from "./children/gamerebate/index.vue"
import gameviptable from "./children/gameviptable/index.vue"

export default {
  mixins: [tagTypes, colors],
  components: {
    "xw-gameComment": gameComment,
    "xw-gameInfo": gameInfo,
    "xw-gameTransation": gameTransation,
    "xw-gameServer": gameServer,
    // "xw-gameGift": gameGift,
    "xw-gamewelfare": gamewelfare,
    "xw-gamerebate": gamerebate,
    "xw-gameviptable": gameviptable
  },
  data() {
    return {
      // 顶部导航栏背景
      bg: 0,
      pages: 0,
      // 页面数据
      params: {
        game_id: 0
      },
      pageData: null,

      // 判断是不是引导页来的 0 不是， 1 是
      guidePage: 0,

      // tab
      list: [{
        name: "福利",
        type: 'activity',

      }, {
        name: "返利",
        type: 'rebate',

      }, {
        name: "vip表",
        type: 'viptable',

      }, {
        name: "新服",
        type: 'newServer'
      }, {
        name: "攻略资讯",
        type: 'news'
      }],
      current: 0,
      transactionList: null,
    }
  },
  computed: {
    iframe_url() {
      return 'http://page.hnyfqj.cn/active/gameVideo?state=play&muted=1&video_url=' + this.pageData.mp4_url +
        '&hot_image=' + encodeURIComponent(this.pageData.hot_image)
    },
    newList() {
      let post = {
        ...this.pageData.post,
        newServer: {
          ...this.pageData.serlistNew
        }
      }
      let count = 0
      let a = []
      this.list.filter(item => {
        if (post[item.type].count > 0 || (this.pageData.gift.length > 0 && (item.type == 'activity') ?
          true : false)) {

          a.push({
            ...item,
            current: count
          })
          count++
        }
      })
      console.log(a)
      return a
    }
  },
  methods: {
    // 获取游戏数据
    getData(params = {}) {
      this.$api({
        url: "game/detail",
        method: "GET",
        data: params
      }).then(res => {
        this.pageData = res.data.data;
        console.log(this.pageData)
      })
    },
    // 分栏切换
    handleChange(index) {
      this.current = index;
    },
    // 返回上一页
    routerTo() {
      if (this.guidePage == 0) {
        this.$Router.back(1)
      } else if (this.guidePage == 1) {
        uni.reLaunch({
          url: "/pages/game/index"
        })
      }
    }
  },
  onReachBottom() {
    this.pages++

  },
  // 接收参数
  onLoad(option) {
    this.params.game_id = option.game_id;
    this.getData(this.params);

    this.guidePage = option.guidePage || 0;
  },
  // 监听滚动
  onPageScroll(object) {
    this.bg = object.scrollTop / 500;
  }
}
</script>

<style lang="scss" scoped>
uni-page-body {
  height: 0;
}
.container {
  position: relative;
  background-color: #f5f5f5;
  padding: 0 4rpx;

  .back {
    padding: 6rpx;
    // background-color: rgba(0, 0, 0, .3);
    border-radius: 50%;
  }
  .navbar {
    width: 100%;
    position: fixed;
    top: 0;
    left: 50%;
    transform: translateX(-50%);
    z-index: 10;
    padding: 20rpx 0;

    .share {
      float: right;
    }
  }

  .top {
    width: 100%;

    image {
      width: 100%;
    }

    .iframe {
      width: 100%;
    }
  }

  .myRate {
    position: relative;

    text {
      position: absolute;
      padding: 0 2rpx;
      left: 50%;
      top: 50%;
      margin-left: -35rpx;
      margin-top: -33rpx;
      font-size: 26rpx;
      color: #ffffff;
    }

    image {
      margin-top: -60rpx;
      height: 80rpx;
      width: 100rpx;
    }
  }

  .game {
    padding: $xw-padding-md;
    background-color: #fff;

    .gamename {
      font-size: 34rpx;
      font-weight: 600;
    }

    .desc {
      overflow: hidden;
      line-height: 50rpx;

      .gamename,
      .tags,
      .size {
        @include text-overflow(2);
      }

      .tags {
        .u-tag {
          margin-right: 8rpx;
        }
      }

      .size {
        color: $xw-font-base-color;
        font-size: $xw-font-size-md;
        display: flex;
        align-items: center;
        width: 100%;
        text-overflow: ellipsis;

        image {
          width: 30rpx !important;
        }

        text {
          margin-left: 8rpx;
          font-size: 20rpx;
          white-space: nowrap;
        }
      }
    }
  }

  .tabContent {
    border-top: 16rpx solid #f5f5f5;
    padding-bottom: $xw-padding-md * 6;
    background-color: #fff;
  }

  .button {
    width: 100%;
    // max-width: 500px;
    padding: $xw-padding-md;
    background: $xw-bg-white-color;
    position: fixed;
    bottom: 0;
    left: 50%;
    transform: translateX(-50%);
    z-index: 10;
  }
}
@media screen and (min-width: 600px) {
  .myRate {
    image {
      margin-top: -20rpx !important;
      height: 180rpx !important;
      width: 150rpx !important;
    }

    text {
      margin-left: -30rpx !important;
      margin-top: -5rpx !important;
      font-weight: 600 !important;
    }
  }
}
</style>
