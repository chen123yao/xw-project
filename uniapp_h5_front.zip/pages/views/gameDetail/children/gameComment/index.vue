<!-- 1.热评 -->
<template>
  <view class="container" v-if="data">
    <!-- 游戏介绍 -->
    <!-- <u-read-more :toggle="true" show-height="200" color="#ff8500">
      <rich-text :nodes="data.desc"></rich-text> -->

    <!-- 图片展示 -->
    <!-- <view class="images">
        <swiper class="swiper" display-multiple-items="3">
          <swiper-item v-for="(item,index) in data.image" :key="index" class="item">
            <image :src="item" width="100%" mode="widthFix" @click="common.previewImage(index,data.image)"></image>
          </swiper-item>
        </swiper>
      </view>
    </u-read-more> -->

    <!-- 评论评分 -->
    <view class="comment">
      <view class="h2" style="padding-left:10rpx">点击留下点评论吧</view>
      <u-rate :count="rate.count" v-model="rate.value" active-color="#ff8500" gutter="16" min-count="1" size="36" class="rate"></u-rate>
      <u-input v-model="rate.comment" type="textarea" :border="true" placeholder="请输入你想表达的内容..." height="200" @focus="common.isLogin"></u-input>
      <view class="clearfix">
        <view class="btn">
          <xw-button @click="publicComment">发 表</xw-button>
        </view>
      </view>
    </view>
    <!-- 评论列表 -->
    <u-gap height="20" bg-color="#fff"></u-gap>
    <view class="commentList">
      <!-- <scroll-view scroll-y="true" @scrolltolower="loadMore" lower-threshold="100" style="width:100%;height:1400rpx;"> -->
      <xw-commentlist :list="commentData" @clickSupport="resetData"></xw-commentlist>
      <u-loadmore bg-color="#f5f5f5" :status="status" :icon-type="iconType" :load-text="loadText" @loadmore="loadMore" v-if="commentData.length" />
      <!-- </scroll-view> -->
    </view>
    <u-toast ref="uToast" />
  </view>
</template>


<script>
import {
  myLoading
} from "@/common/js/mixin.js";

export default {
  props: {
    data: {
      type: Object,
      default: null
    },
    pages: {
      default: 0
    }
  },
  data() {
    return {
      // 评分
      rate: {
        count: 5,
        value: 5,
        comment: ""
      },

      // 评论
      commentParams: {
        page: 1,
        offset: 20,
        type_name: "game",
        object_id: 0
      },
      commentData: [],
      status: "loadmore"
    }
  },
  methods: {
    // 获取评论数据
    getCommentData(params) {
      this.$api({
        url: "v8/comments/list",
        method: "GET",
        data: params
      }).then(res => {
        console.log(res.data.data.list);
        res.data.data.list.forEach(val => {
          if (this.isJSON(val.content)) {
            val.content = JSON.parse(val.content)
          }
        });
        this.commentData = this.commentData.concat(res.data.data.list);
        if (res.data.data.list.length < params.offset) {
          this.status = "nomore";
        }
      })
    },
    //判断是否是json字符串
    isJSON(str) {
      if (typeof str == 'string') {
        try {
          JSON.parse(str)
          return true
        } catch (e) {
          return false
        }
      } else {
        return false
      }
    },
    // 加载更多评论
    loadMore() {
      this.status = "loading"
      this.commentParams.page++;
      this.getCommentData(this.commentParams)
    },
    // 重置数据
    resetData() {
      this.commentParams['page'] = 1;
      this.commentData = [];
      this.getCommentData(this.commentParams)
    },
    // 提交评论
    publicComment() {
      this.$api({
        url: "v8/comments/add",
        method: "GET",
        data: {
          object_id: this.commentParams.object_id,
          star_cnt: this.rate.value * 2,
          content: this.rate.comment,
          type_name: "game"
        }
      }).then(res => {
        this.$refs.uToast.show({
          title: '发表成功',
          type: 'success',
        })
        // 重置输入框
        this.rate.comment = "";
        this.resetData();
      })
    }
  },
  created() {
    this.commentParams.object_id = this.$Route.query.game_id
    this.getCommentData(this.commentParams)
  },
  mixins: [myLoading],
  watch: {
    pages(val) {
      this.loadMore()

    }
  }
}

</script>

<style lang="scss" scoped>
.container {
  padding: $xw-padding-md;

  .images {
    padding: $xw-padding-sm;

    .item {
      padding: 0 $xw-padding-sm;
    }
  }

  .text {
    padding: $xw-padding-sm;
    color: $xw-font-base-color;
  }

  .rate {
    margin: $xw-margin-md auto;
  }

  .comment {
    text-align: center;
    background-color: #f5f5f5;
    margin: $xw-margin-base auto;
    padding: 20rpx $xw-padding-sm;
  }

  .btn {
    width: 20%;
    margin: $xw-margin-base $xw-margin-sm;
    float: right;
  }

  .commentList {
    background-color: #f5f5f5;
    padding: 120rpx 0;
    color: $xw-font-base-color;
    text-align: center;
  }
}
</style>
