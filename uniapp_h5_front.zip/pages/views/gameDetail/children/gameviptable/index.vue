<!-- 1.vip -->
<template>
  <view>
    <view class="activity container" v-if="news.count>0&&newData">
      <!-- <view class="title">vip表</view> -->
      <view style="text-align:left;font-weight: 700;">{{newData.title}}</view>
      <view style="text-align:left;margin: 10rpx 0 10rpx 10rpx;font-size:24rpx;">{{newData.pub_time| dateFormat("yyyy-MM-dd hh:mm")}}</view>
      <view class="content" v-html="newData.content"></view>
    </view>
    <xw-nodata v-else>暂无vip表</xw-nodata>
  </view>

</template>

<script>
export default {
  props: {
    news: {
      type: Object,
      default: () => {
        return {}
      }
    }
  },
  data() {
    return {
      newData: null
    }
  },
  created() {
    if (this.news.count > 0) {
      this.getDescData({ news_id: this.news.list[0].news_id })
    }
  },
  methods: {
    async getDescData(prams) {
      let { data } = await this.$api({ url: "news/detail", method: "GET", data: prams })
      if (data.code == 200) {
        this.newData = data.data.data
        console.log(this.newData);
      }
    }
  },
}
</script>

<style lang="scss" scoped>
.activity {
  margin: 20rpx 0;
  padding: 20rpx;

  .new-title {
    font-weight: 700;
    text-align: center;
  }
  .new-time {
    margin: 10rpx 0 20rpx 0;
    text-align: center;
    color: #ccc;
  }
  .title {
    text-align: left;
    padding-left: 16rpx;
    margin-bottom: 20rpx;
    border-left: 10rpx solid rgb(255, 133, 0);
    font-weight: 700;
    font-size: 30rpx;
  }
}
//格式
.content /deep/ table {
  margin: auto;
  width: 95% !important;
  // border: 1rpx solid #ddd;
  width: 200px;
  border-spacing: 0; /*去掉单元格间隙*/
  border-top: 1px solid #ddd;
  border-left: 1px solid #ddd;
  tr {
    border: 1rpx solid #ddd;
    td {
      text-align: center;
      border-bottom: 1px solid #ddd;

      border-right: 1px solid #ddd;
      height: 35px !important;
      p {
        width: 100%;
      }
    }
  }
  tr:nth-child(even) {
    background-color: #f2f4f7;
  }
}
</style>
