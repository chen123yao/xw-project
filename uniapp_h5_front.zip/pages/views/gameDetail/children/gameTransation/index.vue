<!-- 2.交易 -->
<template>
	<view v-if="pageData" class="container">
		<xw-salelist v-if="pageData.length" :list="pageData"></xw-salelist>
		<xw-nodata v-else>暂无交易数据</xw-nodata>
	</view>
</template>

<script>
	export default {
		props: {
			gameId: {
				type: [Number, String],
				default: 0
			}
		},
		data(){
			return {
				params: {
					page: 1,
					offset: 20,
					status: 2,
					game_id: "",
				},
				pageData: []
			}
		},
		methods: {
			getData(params){
				this.$api({
					url: "account/goods/list",
					method: "GET",
					data: params
				}).then(res=>{
					this.pageData = res.data.data.list;
				})
			}
		},
		created(){
			this.params.game_id = this.game_id;
			this.getData(this.params);
		}
	}
</script>

<style lang="scss" scoped>
	.container {
		padding: $xw-padding-md;
	}
</style>
