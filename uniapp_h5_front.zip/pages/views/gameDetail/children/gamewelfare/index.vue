<!-- 1.福利 -->
<template>
	<view>
		<view class="activity container" v-if="news.list.length>0">
			<view class="title">游戏福利</view>

			<!-- <u-read-more :toggle="true" show-height="200" color="#ff8500"> -->
			<!--  <view class="new-title">{{newData.title}}</view>
        <view class="new-time">{{news.list[0].pub_time}}</view> -->

			<!-- </u-read-more> -->
			<view>
				<u-collapse :item-style="itemStyle" v-if="newData">
					<u-collapse-item :title="item.title" @change="handleClick(item.news_id,index)" :open='active==index'
						v-for="(item, index) in news.list" :index="index" :key="item.news_id">
						<view style="font-weight:400;margin:10rpx 0">{{item.pub_time}}</view>
						<view class="content" v-html="newData.content" style="text-align:left;font-size:26rpx;"></view>
					</u-collapse-item>
				</u-collapse>
			</view>

		</view>
		<view class="container" v-if="list.length>0">
			<view class="title">礼包</view>
			<view v-if="list.length">
				<u-row class="giftList" v-for="(item,index) in list" :key="index">
					<u-col span="2">
						<xw-image :src="item.icon"></xw-image>
					</u-col>
					<u-col span="7.6" class="desc">
						<h4 class="name">{{item.gift_name}}(<text
								style="color:#ff8500;">{{item.remain_cnt}}</text>/<text
								style="color:#ff8500;">{{item.total_cnt}}</text>)</h4>
						<view class="info">{{item.content}}</view>
					</u-col>
					<u-col span="2.3" class="tags">
						<u-tag text="领取" type="warning"
							@click="common.routerTo({path: '/pages/views/giftDetail/index', query: {gift_id: item.gift_id}})" />
					</u-col>
				</u-row>
			</view>
			<xw-nodata v-else>暂无礼包数据</xw-nodata>
		</view>
	</view>

</template>

<script>
	export default {
		props: {
			list: {
				type: Array,
				default: () => {}
			},
			news: {
				type: Object,
			}
		},
		data() {
			return {
				newData: null,
				pageData: null,
				active: 0,
				itemStyle: {
					fontSize: '20rpx',
					fontWeight: '600'
				}
			}
		},
		methods: {
			getData() {
				if (this.news.list.length > 0) {
					this.$api({
						url: "news/detail",
						method: "GET",
						data: {
							news_id: this.news.list[0].news_id
						}
					}).then(res => {

						this.newData = res.data.data.data;
					})

				}

			},
			handleClick(params, index) {
				if (this.active == index) {
					this.active = NaN
				} else {
					this.active = index
				}

				// this.active = index
				this.newData = "";
				this.$api({
					url: "news/detail",
					method: "GET",
					data: {
						news_id: params
					}
				}).then(res => {

					this.newData = res.data.data.data;
				})
			}

		},
		watch: {
			news: {
				handler(val) {
					this.pageData = val;
					this.getData();
				},
				immediate: true,
			},
		}
	}
</script>

<style lang="scss" scoped>
	.activity {
		margin: 20rpx 0;

		.new-title {
			font-weight: 700;
			text-align: center;
		}

		.new-time {
			margin: 10rpx 0 20rpx 0;
			text-align: center;
			color: #ccc;
		}

		.title {
			text-align: left;
			padding-left: 16rpx;
			margin-bottom: 20rpx;
			border-left: 10rpx solid rgb(255, 133, 0);
			font-weight: 700;
			font-size: 30rpx;
		}
	}

	.container {
		padding: $xw-padding-md;

		.title {
			text-align: left;
			padding-left: 16rpx;
			margin-bottom: 20rpx;
			border-left: 10rpx solid rgb(255, 133, 0);
			font-weight: 700;
			font-size: 30rpx;
		}

		.giftList {
			line-height: 40rpx;

			.desc {
				overflow: hidden;

				.name,
				.info {
					@include text-overflow(1);
				}

				.info {
					font-size: $xw-font-size-sm;
					color: $xw-font-base-color;
					margin-top: 10rpx;
				}
			}

			.tags {
				text-align: right !important;
			}
		}
	}

	//文章格式
	.content /deep/ p {
		margin: 0 auto;
		width: 95%;
		word-break: break-all;
		color: #000;
		line-height: 200%;

		img {
			width: 100% !important;
			height: 100% !important;
		}
	}

	.content /deep/ table {
		margin: auto;
		width: 95% !important;

		tr {
			td {
				text-align: center;
				border: 1px solid #ddd;
				// white-space: nowrap;

				height: 35px !important;

				p {
					width: 100%;
				}
			}
		}

		tr:nth-child(even) {
			background-color: #f2f4f7;
		}
	}
</style>
