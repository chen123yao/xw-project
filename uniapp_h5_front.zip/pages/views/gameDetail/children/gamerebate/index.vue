<!-- 1.返利 -->
<template>
  <view>
    <view class="activity container" v-if="news.count>0&&newData">
      <view class="title">游戏返利</view>
      <view>
        <u-collapse :item-style="itemStyle" v-if="newData">

          <u-collapse-item :title="item.title" @change="handleClick(item.news_id,index)" :open='active==index' v-for="(item, index) in news.list" :index="index" :key="item.news_id">
            <view style="font-weight:400;margin:10rpx 0">{{item.pub_time}}</view>
            <!-- <rich-text :nodes="newData.content" style="text-align:left;font-size:26rpx;"></rich-text> -->
            <view class="content" v-html="newData.content" style="text-align:left;font-size:26rpx;"></view>
          </u-collapse-item>
        </u-collapse>
      </view>

    </view>
    <xw-nodata v-else>暂无游戏返利</xw-nodata>
    <!-- 123345 -->
  </view>

</template>

<script>
export default {
  props: {
    // list: {
    //   type: Array,
    //   default: []
    // },
    news: {
      type: Object,
    }
  },
  data() {
    return {
      newData: null,
      pageData: null,
      active: 0,
      itemStyle: {
        fontSize: '20rpx',
        fontWeight: '600'
      }
    }
  },
  methods: {
    getData() {
      if (this.news.list.length > 0) {
        this.$api({
          url: "news/detail",
          method: "GET",
          data: { news_id: this.news.list[0].news_id }
        }).then(res => {

          this.newData = res.data.data.data;
        })

      }

    },
    handleClick(params, index) {
      if (this.active == index) {
        this.active = NaN
      } else {
        this.active = index
      }
      // this.active = index
      this.newData = "";
      this.$api({
        url: "news/detail",
        method: "GET",
        data: { news_id: params }
      }).then(res => {

        this.newData = res.data.data.data;
      })
    }

  },
  watch: {
    news: {
      handler(val) {
        this.pageData = val;
        this.getData();
      },
      immediate: true,
    },
  }
}
</script>

<style lang="scss" scoped>
.activity {
  margin: 20rpx 0;
  .new-title {
    font-weight: 700;
    text-align: center;
  }
  .new-time {
    margin: 10rpx 0 20rpx 0;
    text-align: center;
    color: #ccc;
  }
  .title {
    text-align: left;
    padding-left: 16rpx;
    margin-bottom: 20rpx;
    border-left: 10rpx solid rgb(255, 133, 0);
    font-weight: 700;
    font-size: 30rpx;
  }
}
	//文章格式
	.content /deep/ p {
		margin: 0 auto;
		width: 95%;
		word-break: break-all;
		color: #000;
		line-height: 200%;

		img {
			width: 100% !important;
			height: 100% !important;
		}
	}

	.content /deep/ table {
		margin: auto;
		width: 95% !important;

		tr {
			td {
				text-align: center;
				border: 1px solid #ddd;
				// white-space: nowrap;

				height: 35px !important;

				p {
					width: 100%;
				}
			}
		}

		tr:nth-child(even) {
			background-color: #f2f4f7;
		}
	}
</style>
