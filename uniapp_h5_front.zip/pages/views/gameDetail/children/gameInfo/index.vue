<!-- 游戏资讯 -->
<template>
	<view class="container">
		<view v-if="list.length">
			<u-row align="top" v-for="(item,index) in list" :index="index" :key="index">
				<u-col span="5" class="item">
					<u-image :src="item.image" width="100%" height="180rpx"></u-image>
				</u-col>
				<u-col span="7" @click.native="common.routerTo({ path: '/pages/views/infoDetail/index', query: { news_id: item.news_id}})">
					<view class="title">{{item.title}}</view>
					<view class="desc">{{item.desc}}</view>
					<view class="clearfix read">
						<view class="fl"><u-icon name="eye-fill" color="#ff8500" size="28"></u-icon>{{item.read}}</view>
						<text class="fr">{{item.pub_time}}</text>
					</view>
				</u-col>
			</u-row>
		</view>
		<xw-nodata v-else>暂无相关资讯</xw-nodata>
	</view>
</template>

<script>
	export default {
		props: {
			list: {
				type: Array,
				default: []
			}
		}
	}
</script>

<style lang="scss" scoped>
	.container {
		padding: $xw-padding-md;
		
		.item {
			margin: $xw-margin-md 0;
		}
		
		.title {
			@include text-overflow(1);
			line-height: 60rpx;
		}
		
		.desc {
			@include text-overflow(3);
		}
		
		.desc,
		.read {
			height: 90rpx;
			line-height: 30rpx;
			font-size: $xw-font-size-sm;
			color: $xw-font-auxiliary-color;
		}
		
		.read {
			line-height: 40rpx;
			height: 40rpx;
		}
	}
	
</style>
