<!-- 4.开服 -->
<template>
	<view>
		<view v-if="list.length">
			<u-row gutter="20" class="list">
				<u-col span="10" offset="1" v-for="(item,index) in list" :key="index" class="item text1" :class="{'timeout': item.start_time*1000 < (new Date()).getTime()}">
					<view class="tbody">
						
					
					<view class="startTime" v-if="item.start_time*1000 >= new Date(new Date().toLocaleDateString()).getTime()&&item.start_time*1000 <new Date(new Date(new Date().toLocaleDateString()).getTime() + 24 * 3600000) "> 今 日  {{item.start_time | dateFormat("hh:mm")}}</view>
					<view v-else class="startTime"> {{item.start_time | dateFormat("yyyy-MM-dd hh:mm")}}</view>
					  <view class=" serverName">
					  	{{item.server_name}}
					  </view>
					  </view>
					
				</u-col>
			</u-row>
		</view>
		<!-- <xw-nodata v-else>暂无开服数据</xw-nodata> -->
	</view>
</template>

<script>
	export default {
		props: {
			list: {
				type: Array,
				default: []
			}
		}
	}
</script>

<style lang="scss" scoped>
	.list {
		padding: $xw-padding-base;

		.item {
			padding: $xw-padding-md !important;
			margin: $xw-margin-sm;

			// color: $xw-font-white-color;
			// background: $xw-bg-warning-color;
      color: #FF8500;
      background-color: #FFE7CC;
			border-radius: $xw-border-radius-lg;
			text-align: center !important;
		}

		.timeout {
			// color: $xw-font-white-color;
			// background: $xw-bg-light-color;
      color: #B19999;
      background-color: #F5F5F5;
		}
		.tbody{
			font-size: 24rpx;
			display: flex;
			justify-content: space-around;
			.startTime{
				flex: 0.6;
			}
		}
	}
</style>
