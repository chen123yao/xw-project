<!-- 5.礼包 -->
<template>
	<view class="container">
		<view v-if="list.length">
			<u-row class="giftList" v-for="(item,index) in list" :key="index">
				<u-col span="2">
					<xw-image :src="item.icon"></xw-image>
				</u-col>
				<u-col span="7.6" class="desc">
					<h4 class="name">{{item.gift_name}}(<text style="color:#ff8500;">{{item.remain_cnt}}</text>/<text style="color:#ff8500;">{{item.total_cnt}}</text>)</h4>
					<view class="info">{{item.content}}</view>
				</u-col>
				<u-col span="2.3" class="tags">
					<u-tag text="领取" type="warning" @click="common.routerTo({path: '/pages/views/giftDetail/index', query: {gift_id: item.gift_id}})" />
				</u-col>
			</u-row>
		</view>
		<xw-nodata v-else>暂无礼包数据</xw-nodata>
	</view>
</template>

<script>
	export default {
		props: {
			list: {
				type: Array,
				default: []
			}
		}
	}
</script>

<style lang="scss" scoped>
	.container {
		padding: $xw-padding-md;

		.giftList {
			line-height: 40rpx;

			.desc {
				overflow: hidden;
				
				.name,
				.info {
					@include text-overflow(1);
				}
				
				.info {
					font-size: $xw-font-size-sm;
					color: $xw-font-base-color;
					margin-top: 10rpx;
				}
			}
			
			.tags {
				text-align: right!important;
			}
		}
	}
</style>
