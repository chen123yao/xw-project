<!-- 忘记密码 -->
<template>
	<view class="container">
		<view class="status_bar"></view>
		<!-- 第一步：验证码 -->
		<u-form :model="form1" ref="uForm" label-width="150" :border-bottom="false" label-align="right" v-if="show">
			<u-form-item label="手机号">
				<u-input v-model="form1['sms-mobile']" placeholder="请输入手机号" :border="true" />
			</u-form-item>
		<!-- 	<u-field v-model="form1['sms-code']" placeholder="请填写验证码" placeholder-style="color: #c0c4d4;">
				<u-button size="mini" slot="right" type="warning" @click="getCode">{{codeText}}</u-button>
			</u-field> -->
			<u-form-item label="验证码">
				<u-input v-model="form1['sms-code']" placeholder="请填写验证码" :border="true" style="margin-right: 30rpx;"/>
				<u-button size="mini" slot="right" type="warning" @click="getCode">{{codeText}}</u-button>
			</u-form-item>
			
			
			<u-verification-code ref="uCode" @change="codeChange"></u-verification-code>
			<view class="btn">
				<xw-button @click="handleConfirm">确 定</xw-button>
			</view>
		</u-form>

		<!-- 第二步：修改密码 -->
		<u-form :model="form2" ref="uForm" label-width="150" :border-bottom="false" label-align="right" v-else>
			<u-form-item label="重置密码">
				<u-input v-model="form2.password" type="password" placeholder="请输入新密码" :border="true" />
			</u-form-item>
			<u-form-item label="确认密码">
				<u-input v-model="form2.passwordAgain" type="password" placeholder="请再次输入新密码" :border="true" />
			</u-form-item>
			<view class="btn">
				<xw-button @click="submitPassword">提 交</xw-button>
			</view>
		</u-form>

		<!-- 底部文字提示 -->
		<view class="bottom">此功能只适用于手机用户，其他账号请前往官网找回，<br />或点击<text class="lianxi" @click="common.routerTo({name: 'myService'})">联系客服</text></view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				show: true,
				codeText: "",
				form1: {
					"sms-mobile": "",
					"sms-code": "",
					"sms-type": 5
				},
				form2: {
					password: "",
					passwordAgain: "",
					verify_token: ""
				}
			}
		},
		methods: {
			codeChange(text) {
				this.codeText = text;
			},
			// 发送验证码
			getCode() {
				let that = this;
				if(!this.form1['sms-mobile']){
					uni.showToast({
						title: "请输入手机号",
						icon: "none"
					})
					return ;
				}
				if (this.$refs.uCode.canGetCode) {
					// 模拟向后端请求验证码
					uni.showLoading({
						title: '正在获取验证码',
						success() {
							that.$api({
								url: "findpwd/sms/send",
								method: "GET",
								data: that.form1
							}).then(res => {
								uni.showToast({
									title: res.data.msg,
									icon: "none"
								})
								
								if(res.data.code == 200){
									uni.hideLoading();
									that.$refs.uCode.start();
								}
							})
						}
					})
				} else {
					this.$u.toast('倒计时结束后再发送');
				}
			},
			// 确认验证码
			handleConfirm() {
				this.$api({
					url: "findpwd/sms/check",
					method: "GET",
					data: this.form1
				}).then(res => {
					this.show = false;
					this.form2.verify_token = res.data.data.verify_token;
				})
			},
			// 提交密码修改
			submitPassword() {
				if (this.form2.password != this.form2.passwordAgain) {
					uni.showToast({
						title: "输入密码不一致"
					})
					return;
				}
				this.$api({
					url: "findpwd/password/reset",
					method: "GET",
					data: this.form2
				}).then(res => {
					uni.showToast({
						title: res.data.msg,
						success: () => {
							setTimeout(()=>{
								this.$Router.back(1);
							},1000)
						}
					})
					
				})
			}
		}
	}
</script>

<style lang="scss" scoped>
	.container {
		padding: $xw-padding-base;
		position: relative;

		.btn {
			width: 60%;
			margin: $xw-margin-md*3 auto $xw-margin-sm;
		}

		.bottom {
			width: 100%;
			position: absolute;
			bottom: 40rpx;
			text-align: center;
			font-size: $xw-font-size-sm;

			.lianxi {
				color: $xw-font-primary-color;
				text-decoration: underline;
			}
		}
	}
</style>
