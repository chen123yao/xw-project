<template>
	<view class="container">
		<u-tabs-swiper :current="tabsCurrent" @change="tabsChange" active-color="#ff8500" bar-width="80" swiperWidth="750"
		 :is-scroll="false" ref="uTabs" :list="tabsList"></u-tabs-swiper>
		<view class="main">
			<swiper class="swiper" :current="swiperCurrent" @transition="transition" @animationfinish="animationfinish" duration='0'>
				<swiper-item class="swiper-item" v-for="(item,index) in pageData" :key="index">
					<scroll-view scroll-y style="height: 100%;width: 100%;" @scrolltolower="onreachBottom" lower-threshold="100" v-if="item.count">
						<xw-infolist :list="item"></xw-infolist>
						<u-loadmore :status="status[index]" bg-color="#f5f5f5" :icon-type="iconType" :load-text="loadText" @loadmore="onreachBottom" />
					</scroll-view>
			
					<xw-nodata v-else>暂无相关数据</xw-nodata>
				</swiper-item>
			</swiper>
		</view>
		
	</view>
</template>

<script>
	import {
		mySwiperTab,
		myLoading
	} from "@/common/js/mixin.js"

	export default {
		data() {
			return {
				tabsList: [{
					name: '资讯'
				}, {
					name: '活动'
				}, {
					name: '攻略'
				}],
				tabsCurrent: 0,
				swiperCurrent: 0,

				status: [
					"loadmore",
					"loadmore",
					"loadmore"
				],

				params: [{
						offset: 20,
						page: 1,
						type: 1
					},
					{
						offset: 20,
						page: 1,
						type: 2
					},
					{
						offset: 20,
						page: 1,
						type: 3
					}
				],

				pageData: [{
						count: 0,
						list: []
					},
					{
						count: 0,
						list: []
					},
					{
						count: 0,
						list: []
					}
				],

			}
		},
		methods: {
			getData(params = {}) {
				this.$api({
					url: "news/list",
					method: "GET",
					data: params
				}).then(res => {
					this.pageData[params.type - 1].count = res.data.data.count;
					this.pageData[params.type - 1].list = this.pageData[params.type - 1].list.concat(res.data.data.list)
					if (res.data.data.list.length < params.offset) {
						this.status[params.type - 1] = "nomore";
					} else {
						this.status[params.type - 1] = "loading";
					}
				})
			},
			// scroll-view到底部加载更多
			onreachBottom() {
				this.status[this.tabsCurrent] = "loadmore";
				this.params[this.tabsCurrent].page++;
				this.getData(this.params[this.tabsCurrent]);
			}
		},
		created() {
			this.getData(this.params[0]);
			this.getData(this.params[1]);
			this.getData(this.params[2]);
		},
		mixins: [mySwiperTab, myLoading],
	}
</script>

<style lang="scss" scoped>
	.container {
		display: flex;
		flex-direction: column;
		
		.main {
			flex: 1;
			display: flex;
			
			.swiper {
				width: 100%;
				height:100%;
			}
		}
	}
</style>
