<!-- 注册页面 -->
<template>
  <view class="container">
    <view>
      <view class="h1">欢迎注册</view>
    </view>
    <!-- 用户名注册 -->
    <view v-if="register == 1">
      <u-form :model="form1" ref="uForm" label-width="150" :border-bottom="false" label-align="right">
        <u-form-item label="用户名">
          <u-input @focus='isShow=false' @blur='isShow=true' v-model="form1['mem-username']" placeholder="请输入注册账号" :border="true" />
        </u-form-item>
        <u-form-item label="密 码">
          <u-input @focus='isShow=false' @blur='isShow=true' v-model="form1['mem-password']" type="password" placeholder="请输入密码" :border="true" />
        </u-form-item>
        <u-form-item label="确认密码">
          <u-input @focus='isShow=false' @blur='isShow=true' v-model="form1.passwordAgain" type="password" placeholder="请确认密码" :border="true" />
        </u-form-item>
      </u-form>
      <view class="mobile clearfix">
        <text class="fr" @click="changeRegister">{{text}}</text>
      </view>
      <view class="btn">
        <xw-button @click="register1">注 册</xw-button>
      </view>
    </view>

    <!-- 手机号注册 -->
    <view v-else-if="register == 2">
      <u-form :model="form2" ref="uForm" label-width="150" :border-bottom="false" label-align="right">
        <u-form-item label="手机号">
          <u-input @focus='isShow=false' @blur='isShow=true' v-model="form2['sms-mobile']" placeholder="请输入手机号" :border="true" />
        </u-form-item>
        <!-- 	<u-field @focus='isShow=false' @blur='isShow=true' v-model="form2['sms-code']"  placeholder="请填写验证码" :border-bottom="false" placeholder-style="color: #c0c4d4;">
					<u-button size="mini" slot="right" type="warning" @click="getCode">{{codeText}}</u-button>
				</u-field> -->
        <u-form-item label="验证码">
          <u-input v-model="form2['sms-code']" placeholder="请填写验证码" :border="true" style="margin-right: 30rpx;" />
          <u-button size="mini" slot="right" type="warning" @click="getCode">{{codeText}}</u-button>
        </u-form-item>
        <u-verification-code ref="uCode" @change="codeChange"></u-verification-code>
        <u-form-item label="密 码">
          <u-input @focus='isShow=false' @blur='isShow=true' v-model="form2['mem-password']" type="password" placeholder="请输入密码" :border="true" />
        </u-form-item>
      </u-form>
      <view class="mobile clearfix">
        <text class="fr" @click="changeRegister">{{text}}</text>
      </view>
      <view class="btn">
        <xw-button @click="register2">注 册</xw-button>
      </view>
    </view>

    <view v-if="isShow" class="bottom">注册即表示同意<text class="txt">《平台服务协议》</text></view>
  </view>
</template>

<script>
export default {
  data() {
    return {
      register: 1,
      text: "手机号注册",

      form1: {
        "mem-username": "",
        "mem-password": "",
        passwordAgain: ""
      },
      isShow: true,
      codeText: "",
      form2: {
        "sms-mobile": "",
        "sms-code": "",
        "mem-password": "",
        "sms-type": 1
      }
    }
  },
  methods: {
    // 用户名注册
    register1() {
      if (this.form1['mem-password'] != this.form1.passwordAgain) {
        uni.showToast({
          title: "输入密码不一致",
          icon: 'loading'
        })
        setTimeout(function () {
          uni.hideLoading();

        }, 1000);
        return;
      }

      this.$api({
        url: "user/register",
        method: "GET",
        data: {
          ...this.form1,
          equipmentCode: this.equipmentCode
        }
      }).then(res => {
        console.log(res.data);
        if (res.data.code == 200) {
          uni.showToast({
            title: "注册成功",
          })
          this.doLogin({
            'mem-username': this.form1['mem-username'],
            'mem-password': this.form1['mem-password'],
            equipmentCode: this.equipmentCode
          });
        } else {
          uni.showToast({
            title: res.data.msg,
          })
        }


      })
    },
    // 手机号注册
    register2() {

      this.$api({
        url: "user/mobile/register",
        method: "GET",
        data: {
          ...this.form2,
          equipmentCode: this.equipmentCode
        }
      }).then(res => {
        if (res.data.code == 200) {

          uni.showToast({
            title: "注册成功",
          })
          this.doLogin({
            'mem-username': this.form2['sms-mobile'],
            'mem-password': this.form2['mem-password'],
            equipmentCode: this.equipmentCode
          })
        } else {
          uni.showToast({
            title: res.data.msg,
          })
        }
      })
    },
    doLogin(form) {
      this.$api({
        url: "user/login",
        method: "GET",
        data: form
      }).then(res => {
        console.log(res, 'resresresresres')
        // 将登录获取的数据记录下来
        this.$store.commit("setLoginInfo", res.data.data)
        // 将用户名密码记录在本地
        this.common.setStorage('mem-username', form["mem-username"])
        this.common.setStorage('mem-password', form["mem-password"])

        // 返回我的页面
        this.$Router.replaceAll({
          path: "/pages/my/index"
        })
        // 获取用户信息
        this.getUserInfo();
      })
    },
    changeRegister() {
      switch (this.register) {
        case 1:
          this.register = 2;
          this.text = "用户名注册";
          break;
        case 2:
          this.register = 1;
          this.text = "手机号注册";
          break;
      }
    },
    codeChange(text) {
      this.codeText = text;
    },
    getCode() {
      if (!this.form2['sms-mobile']) {
        uni.showToast({
          title: "请输入手机号",
          icon: "none"
        })
        return;
      }

      let that = this;
      if (this.$refs.uCode.canGetCode) {
        // 模拟向后端请求验证码
        uni.showLoading({
          title: '正在获取验证码',
          success() {
            that.$api({
              url: "v8/sms/send",
              method: "GET",
              data: that.form2
            }).then(res => {
              uni.showToast({
                title: res.data.msg,
                icon: "none"
              })

              if (res.data.code == 200) {
                uni.hideLoading();
                that.$refs.uCode.start();
              }
            })
          }
        })
      } else {
        this.$u.toast('倒计时结束后再发送');
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.container {
  padding: $xw-padding-base;
  position: relative;

  .mobile {
    font-size: $xw-font-size-sm;

    .fr {
      color: $xw-font-primary-color;
    }
  }

  .btn {
    width: 60%;
    margin: $xw-margin-md * 3 auto;
  }

  .bottom {
    width: 100%;
    position: absolute;
    bottom: 40rpx;
    text-align: center;
    font-size: $xw-font-size-sm;

    .txt {
      color: $xw-font-primary-color;
    }
  }
}
</style>
