<!-- h5游戏开玩 -->
<template>
	<view class="container">
		<!-- <iframe :src="game_url" frameborder="0" scrolling="no"></iframe> -->

		<web-view :webview-styles="webviewStyles" :src="game_url"></web-view>
		<image src="../../../static/image/loading.gif" width="40%" mode="widthFix" class="image"></image>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				game_url: "",
				webviewStyles: {
					width: "100%",
					height: "100%"
				}
			}
		},
		onLoad(options) {
			
		this.game_url = this.common.aesDecrypt(options.game_url, "aaa");
		console.log(this.game_url,'this.game_url')
			

		},

	}
</script>

<style lang="scss" scoped>
	.container {
		position: relative;
		overflow: hidden;

		iframe {
			width: 100%;
			height: 100%;
			position: absolute;
			top: 0;
			left: 0;
			z-index: 100;
		}

		.image {
			position: absolute;
			top: 50%;
			left: 50%;
			transform: translate(-50%, -50%);
		}
	}
</style>
