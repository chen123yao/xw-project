<!-- 分类 -->
<template>
	<view class="infoClassify">
		<!-- 左侧边栏 -->
		<view class="slideBar" v-if="cate.length">
			<view v-for="(item,index) in cate" :key="index" class="slide" :class="{active: item.id == activeIndex}" @click="changeCate(item.id)">
				<view class="text">{{item.name}}</view>
			</view>
		</view>
		<!-- 游戏列表栏 -->
		<view class="gameList">
			<view class="games">
				<scroll-view scroll-y style="height: 100%;width: 100%;" @scrolltolower="loadMore" lower-threshold="100">
					<view v-if="activeIndex != 0 && pageData.length">
						<xw-gameLi v-for="(item, index) in pageData" :key="index" :data="item" badge>
							<view class="fl" slot="desc" style="font-size:24rpx;margin-right:10rpx;" v-if="item">
								<u-icon name="chat" size="32" color="#ff8500"></u-icon>
								{{item.downcnt || item.user_cnt}}下载
							</view>
						</xw-gameLi>
						<u-loadmore bg-color="#fff" :status="status" :icon-type="iconType" :load-text="loadText" v-if="count>=8" />
					</view>
					<xw-nodata v-else></xw-nodata>
				</scroll-view>
			</view>
		</view>
	</view>
</template>

<script>
	import {
		mySwiperTab,
		myLoading
	} from "@/common/js/mixin.js"
	export default {
		name: "newInfoClassify",
		mixins: [mySwiperTab, myLoading],
		data() {
			return {
				// 左边侧边栏
				activeIndex: 10,
				// 第一页参数
				paramsTab1: {
					page: 1,
					offset: 15,
					is_h5: 0,
					/* 是否为H5，1为H5，其他均为否 */
					sort: 0,
					/* 排行类型， 0,（对应ui默认排序 畅销榜） 1,（对应ui最新上架 新游推荐榜） 2,（对应热门游戏  h5热搜榜或网游下载榜） 3，（只在进入搜索页面时显示热搜榜，不分h5和网游）*/
					tags: 0,
					/* 游戏分类 可以逗号隔开 分类id   目前的盒子界面只能选一个 */
					cates: 10,
					/* 游戏类型 可以逗号隔开 类型id 目前的盒子界面只能选一个*/
					is_mp4: 0,
				},
				count: 0,

				pageData: [],
				cates: 10,
			}

		},
		props: {
			cate: {
				type: Array,
				default: []
			},
			is_h5: {
				type: Number,
				default: 0
			},
			tabs: {
				type: Number,
				default: 0
			},
			catest: {
				type: Number,
				default: 0
			},


		},
		computed: {

		},
		methods: {
			changeCate(id) {
				this.activeIndex = id;
				this.paramsTab1.page = 1;
				this.paramsTab1.cates = id
				this.pageData = [];
				this.getPageData(this.paramsTab1);
				this.status = "loadmore";
			},
			// 根据筛选条件获取游戏列表数据
			getPageData(params) {
				this.$api({
					url: "game/multilist",
					method: "GET",
					data: params
				}).then(res => {
					// console.log(res.data, 111)
					this.count = res.data.data.count;
					this.pageData = this.pageData.concat(res.data.data.list);
					this.getLonding(res.data.data.list, params)

				})
			},
			loadMore() {
				if (this.count > this.pageData.length) {
					this.status = "loading";
					this.paramsTab1.page++;
					this.getPageData(this.paramsTab1);
				}
			},
			getLonding(data, params) {
				if (data) {
					if (data.length < params.offset) {
						this.status = "nomore";
					} else {
						this.status = "loadmore";
					}

				}
			},
		},
		created() {
			if(this.catest){
				this.paramsTab1.cates = this.catest
				this.activeIndex = this.catest
			}
			uni.$on('cates', (res) => {
				this.cates = res.cates
				this.changeCate(this.cates)
			})

		},

		watch: {
			is_h5: {
				handler(val) {
					this.paramsTab1.is_h5 = val
					this.pageData = [];
					this.paramsTab1.page=1;
					this.getPageData(this.paramsTab1)
				},
				immediate: true

			},
			tabs: {
				handler(val) {
					this.paramsTab1.tags = val
					this.pageData = [];
					this.getPageData(this.paramsTab1)
				},
				immediate: false

			},
			cates: {
				handler(val) {
					this.paramsTab1.cates = val
					this.activeIndex = val
					this.pageData = [];

					this.getPageData(this.paramsTab1)

				},
				immediate: false
			}

		}
	}
</script>

<style lang="scss" scoped>
	.infoClassify {
		width: 100%;
		height: 100%;
		display: flex;

		// 左边侧边栏
		.slideBar {
			width: 130rpx;
			height: 100%;
			overflow-y: scroll;
			color: #636e72;
			background: #f5f5f5;

			.slide {
				height: 100rpx;
				line-height: 100rpx;
				transition: all 0.3s;
			}

			.slide.active {
				background: #fff;
				color: #ff8500;
				font-size: 32rpx;
				font-weight: 600;
				padding-top: 20rpx;

				.text {
					height: 60rpx;
					line-height: 60rpx;
					border-left: 4px solid #ff8500;
				}
			}
		}

		// 右边游戏列表展示
		.gameList {
			flex: 1;
			background: #fff;
			display: flex;
			flex-direction: column;

			// 顶部筛选条件
			.screen {
				width: 100%;
				height: 100rpx;
				line-height: 100rpx;
				display: flex;
				justify-content: space-around;

				.type {
					flex: 1;
					color: #636e72;
				}

				.type.active {
					color: #ff8500;
				}
			}

			// 主体游戏展示
			.games {
				flex: 1;
				overflow-y: scroll;
			}
		}
	}
</style>
