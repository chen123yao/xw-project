<!-- 热门榜 -->
<template>
	<view class="rank">
		<view v-if="list.length">
			<xw-gameLi download :rankIndex="index+1" v-for="(item,index) in list" :key="index" :data="item" :isshow="true"></xw-gameLi>
		</view>
		<xw-nodata v-else></xw-nodata>
	</view>
</template>

<script>
	export default {
		name: "myHotRank",
		props: {
			list: {
				type: Array,
				default: []
			}
		}
	}
</script>

<style lang="scss" scoped>
	
</style>