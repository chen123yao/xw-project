<!-- 分类 -->
<template>
	<view class="infoClassify">
		<!-- 左侧边栏 -->
		<view class="slideBar" v-if="cate.length">
			<view v-for="(item,index) in cate" :key="index" class="slide" :class="{active: item.id == activeIndex}" @click="changeCate(item.id)"
			 v-if="item.id != 0">
				<view class="text">{{item.name}}</view>
			</view>
		</view>
		<!-- 游戏列表栏 -->
		<view class="gameList">
			<!-- 三栏筛选条件 -->
			<!-- 	<view class="screen" v-if="activeIndex != 0">
				
				<text class="type" v-for="(item,index) in typeList" :key="Math.random() + index" :class="{active: item.id == typeActiveIndex}"
				 @click="changeRankType(item.id)">{{item.name}}</text>
			</view> -->
			<!-- 游戏列表展示区 -->
			<view class="games">
				<scroll-view scroll-y style="height: 100%;width: 100%;" @scrolltolower="loadMore" lower-threshold="100">
					<view v-if="activeIndex != 0 && pageData.length">
						<xw-gameLi v-for="(item, index) in pageData" :key="index" :data="item" badge>
							<view class="fl" slot="desc" style="font-size:24rpx;margin-right:10rpx;" v-if="item">
								<u-icon name="chat" size="32" color="#ff8500"></u-icon>
								{{item.downcnt || item.user_cnt}}下载
							</view>
						</xw-gameLi>
						<u-loadmore bg-color="#fff" :status="status" :icon-type="iconType" :load-text="loadText" v-if="count>=8" />
					</view>
					<xw-nodata v-else></xw-nodata>
				</scroll-view>
			</view>
		</view>
	</view>
</template>

<script>
	import {
		mySwiperTab,
		myLoading
	} from "@/common/js/mixin.js"
	export default {
		name: "myInfoClassify",
		mixins: [mySwiperTab, myLoading],
		props: {
			cate: {
				type: Array,
				default: []
			},
			count: Number,
			list: {
				type: Array,
				default: []
			},
			id: {
				type: Number,
				default: 0
			},
			videoPlay: Boolean
		},
		data() {
			return {
				// 页面展示数据
				pageData: [],
				videoState: [],

				// 播放的视频的index
				videoPlayIndex: 0,

				// 左边侧边栏
				activeIndex: 10,
				// 右边顶部筛选条件
				typeActiveIndex: 0,
				typeList: [{
					id: 0,
					name: "默认排序"
				}, {
					id: 1,
					name: "最新上架"
				}, {
					id: 2,
					name: "热门游戏"
				}],

				status: "loadmore"
			}
		},
		methods: {
			changeCate(id) {
				this.activeIndex = id;
				this.$emit("changeCate", this.activeIndex)
				this.status = "loadmore";
			},
			changeRankType(id) {
				this.typeActiveIndex = id;
				this.$emit("changeRankType", this.typeActiveIndex)
				this.status = "loadmore";
			},
			// 加载更多 scroll-view到底部加载更多
			loadMore() {
				if (this.count > this.pageData.length) {
					this.status = "loading";
					this.$emit('loadData')
				} else {
					this.status = "nomore";
				}
			},
			// iframe点击切换播放和暂停事件
			iframeClick(game_id) {
				for (let index in this.videoState) {
					// 先让所有的都变成暂停
					this.$set(this.videoState, index, {
						game_id: this.videoState[index].game_id,
						state: "pause"
					})
					// 然后让指定game_id的游戏变成播放
					if (this.videoState[index].game_id == game_id) {
						this.videoPlayIndex = index;
						this.$set(this.videoState, index, {
							game_id: this.videoState[index].game_id,
							state: "play"
						})
					}
				}
			}
		},
		watch: {
			list: {
				handler(val) {
					this.pageData = val;
					if (val.length && this.activeIndex == 0) {
						for (let item of this.pageData) {
							item.state = "pause"
							this.videoState.push({
								game_id: item.game_id,
								state: "pause"
							})
						}
						this.pageData[this.videoPlayIndex].state = "play";
						this.videoState[this.videoPlayIndex].state = "play";
					}
				},
				immediate: true
			},
			videoPlayIndex(val, oldVal) {
				if (this.activeIndex == 0) {
					// 直接设置数组元素是无法监听到其变化的，所以通过这种vue可监听的方式设置即可
					this.$set(this.videoState, val, {
						game_id: this.videoState[val].game_id,
						state: "play"
					})
					this.$set(this.videoState, oldVal, {
						game_id: this.videoState[oldVal].game_id,
						state: "pause"
					})
				}
			},
			id(val) {
				if (this.id !== 0) {
					this.activeIndex = val
					this.$emit("changeCate", this.activeIndex)
				}
			}

		},
		
		created() {

		}

	}
</script>

<style lang="scss" scoped>
	.infoClassify {
		width: 100%;
		height: 100%;
		display: flex;

		// 左边侧边栏
		.slideBar {
			width: 130rpx;
			height: 100%;
			overflow-y: scroll;
			color: #636e72;
			background: #f5f5f5;

			.slide {
				height: 100rpx;
				line-height: 100rpx;
				transition: all 0.3s;
			}

			.slide.active {
				background: #fff;
				color: #ff8500;
				font-size: 32rpx;
				font-weight: 600;
				padding-top: 20rpx;

				.text {
					height: 60rpx;
					line-height: 60rpx;
					border-left: 4px solid #ff8500;
				}
			}

		}

		// 右边游戏列表展示
		.gameList {
			flex: 1;
			background: #fff;
			display: flex;
			flex-direction: column;

			// 顶部筛选条件
			.screen {
				width: 100%;
				height: 100rpx;
				line-height: 100rpx;
				display: flex;
				justify-content: space-around;

				.type {
					flex: 1;
					color: #636e72;
				}

				.type.active {
					color: #ff8500;
				}
			}

			// 主体游戏展示
			.games {
				flex: 1;
				overflow-y: scroll;
			}
		}
	}
</style>
