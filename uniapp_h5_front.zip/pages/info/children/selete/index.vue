<template>
	<view class="BoutiqueGame">
		<scroll-view scroll-y style="height: 100%;width: 100%;" @scrolltolower="loadMore(0)" lower-threshold="100"
			@scroll="scrollMonitor">
			<xw-gameLiVideo v-for="(v,i) in pageData" :key="i" :state="videoState[i].state" :data="v"
				:refId="'iframe_'+v.game_id" :videoPlay="true" :videoPlayShow="Math.abs(videoPlayIndex - i) <= 1"
				@iframeClick="iframeClick"></xw-gameLiVideo> -->
			<u-loadmore bg-color="#fff" :status="status" :icon-type="iconType" :load-text="loadText"
				v-if="pageData.length>=6" font-size="20" />

		</scroll-view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
           pageData:null
			}
		},

		methods: {
			getPageData(params) {
				this.$api({
					url: "game/multilist",
					method: "GET",
					data: params
				}).then(res => {
					this.count = res.data.data.count;
					this.pageData = this.pageData.concat(res.data.data.list);
					if (res.data.data.list.length < params.offset) {
						this.status = "nomore";
					} else {
						this.status = "loadmore";
					}
				})
			},
		}
	}
</script>

<style lang="scss" scoped>
</style>
