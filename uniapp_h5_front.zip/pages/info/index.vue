<template>
	<view class="container" :style="{ paddingTop: `${$store.state.systemInfoSync.statusBarHeight}px`, 
		height: `${$store.state.systemInfoSync.screenHeight}px` }">
		<!-- 这里是状态栏 -->
		<view class="status_bar" :style="{ height: `${$store.state.systemInfoSync.statusBarHeight}px` }"></view>

		<!-- 标题部分 -->
		<nav class="nav">
			<view class="tabs">
				<xw-select :list="tags" v-if="tags.length" activeColor="#ff8500" inactiveColor="#606266" close-on-click-mask
				 @changeTags="changeTags"></xw-select>
			</view>
			<view class="swicth">
				<xw-switch @change="switchChange"></xw-switch>
			</view>
			<view class="btns">
				<!-- <u-icon name="download" color="#fff" size="40" class="icon" @click="common.routerTo({path: '/pages/views/search/index', query: {type: '游戏'}})"></u-icon> -->
				<u-icon name="search" color="#fff" size="40" class="icon" @click="common.routerTo({path: '/pages/views/search/index', query: {type: '游戏'}})"></u-icon>
			</view>
		</nav>

		<!-- 主体内容 -->
		<view class="main" :style="{ height: `${$store.state.systemInfoSync.statusBarHeight}px` }">
			<view class="tabs">
				<u-tabs-swiper :current="tabsCurrent" @change="tabsChange" inactive-color='#818181' active-color="#ff8500"
				 :show-bar="true" bar-width="80" swiperWidth="750" :is-scroll="false" ref="uTabs" :list="tabsList">
				</u-tabs-swiper>
			</view>

			<swiper class="swiper"  :current="swiperCurrent" transition="none" @animationfinish="animationfinish" duration="10">
				<!-- 分类 -->
				<swiper-item class="swiper-item">
					<xw-newinfoClassify :cate="cate" :is_h5='paramsTab1.is_h5' :catest=toCates :tabs='paramsTab1.tags'></xw-newinfoClassify>
					<!--    <xw-infoClassify :cate="cate" :count="count" :id='$route.query.cates' :list="pageData" @changeCate="changeCate"
					 @loadData="loadTab1Data" @changeRankType="changeRankType" :videoPlay="videoPlay"></xw-infoClassify> -->

				</swiper-item>

				<!-- 热门榜 -->
				<swiper-item class="swiper-item">
					<scroll-view scroll-y style="height: 100%;width: 100%;" @scrolltolower="loadMore" lower-threshold="100">
						<xw-hotBackground :type='1'></xw-hotBackground>
						<xw-hotRings :list="pageData1.slice(0,3)"></xw-hotRings>
						<xw-rank :list="pageData1.slice(4)"></xw-rank>
						<u-loadmore bg-color="#f5f5f5" :status="status" :icon-type="iconType" :load-text="loadText" v-if="pageData.length"
						 @loadmore="loadMore" />
					</scroll-view>
				</swiper-item>

				<!-- 新游榜 -->
				<swiper-item class="swiper-item">
					<scroll-view scroll-y style="height: 100%;width: 100%;" @scrolltolower="loadMore" lower-threshold="100">
						<xw-hotBackground></xw-hotBackground>
						<xw-hotRings :list="pageData2.slice(0,3)"></xw-hotRings>
						<xw-rank :list="pageData2.slice(4)"></xw-rank>
						<u-loadmore bg-color="#f5f5f5" :status="status" :icon-type="iconType" :load-text="loadText" v-if="pageData.length"
						 @loadmore="loadMore" />
					</scroll-view>
				</swiper-item>

			</swiper>
		</view>

	</view>
</template>

<script>
	import {
		mySwiperTab,
		myLoading
	} from "@/common/js/mixin.js"

	import infoClassify from "./children/infoClassify/index.vue";
	import newinfoClassify from "./children/newinfoClassify/index.vue";
	import rank from "./children/gameRank/index.vue";

	export default {
		mixins: [mySwiperTab, myLoading],
		components: {
			"xw-infoClassify": infoClassify,
			"xw-newinfoClassify": newinfoClassify,
			"xw-rank": rank,
		},
		data() {
			return {
				toCates:0,
				// 第一页参数
				paramsTab1: {
					page: 1,
					offset: 15,
					is_h5: 0,
					/* 是否为H5，1为H5，其他均为否 */
					sort: 0,
					/* 排行类型， 0,（对应ui默认排序 畅销榜） 1,（对应ui最新上架 新游推荐榜） 2,（对应热门游戏  h5热搜榜或网游下载榜） 3，（只在进入搜索页面时显示热搜榜，不分h5和网游）*/
					tags: 0,
					/* 游戏分类 可以逗号隔开 分类id   目前的盒子界面只能选一个 */
					cates: 10,
					/* 游戏类型 可以逗号隔开 类型id 目前的盒子界面只能选一个*/
					is_mp4: 0,
				},
				

				// 热门榜
				paramsTab2: {
					page: 1,
					offset: 20,
					is_h5: 0,
					sort: 2,
					tags: 0,
				},

				// 新游榜
				paramsTab3: {
					page: 1,
					offset: 20,
					is_h5: 0,
					sort: 1,
					tags: 0,
				},
				routeId: '',
				tabsList: [{
					name: '分类'
				}, {
					name: '热门榜'
				}, {
					name: '新游榜'
				}],

				// 顶部分类
				tags: [],

				// 侧边栏分类
				cate: [],

				count: 0,
				count1: 0,
				count2: 0,
				pageData: [],
				pageData1: [],
				pageData2: [],
				newPageData: [],
				hotNewPageData: [],
				status: "loadmore",

				// 视频组件的播放
				videoPlay: ""
			}
		},
		methods: {

			// 切换tab页面
			tabsChange(index) {
				this.swiperCurrent = index;
				
			},
			// 初始化顶部下拉列表和侧边栏分类数据
			getInitData(params = {}) {
				this.$api({
					url: "game/getcategory",
					method: "GET",
				}).then(res => {
					this.tags = res.data.data.tags;
					this.cate = res.data.data.cate;
					this.tags.unshift({
						id: 0,
						name: "全部"
					})
					// this.cate.unshift({
					// 	id: 0,
					// 	name: "精选"
					// })
				})

			},
			// 根据筛选条件获取游戏列表数据
			getPageData(params) {
				this.$api({
					url: "game/multilist",
					method: "GET",
					data: params
				}).then(res => {
					this.count = res.data.data.count;
					this.pageData = this.pageData.concat(res.data.data.list);
					this.newPageData = this.pageData.slice(0, 3);
					this.hotNewPageData = this.pageData.slice(3);
					this.getLonding(res.data.data.list, params)

				})
			},
			getLonding(data, params) {
				if (data) {
					if (data.length < params.offset) {
						this.status = "nomore";
					} else {
						this.status = "loadmore";
					}

				}
			},
			getPageData1() {
				this.$api({
					url: "game/multilist",
					method: "GET",
					data: this.paramsTab2
				}).then(res => {
					this.count1 = res.data.data.count
					this.pageData1 = this.pageData1.concat(res.data.data.list);
					this.getLonding(res.data.data.list, this.paramsTab2)

				})
			},
			getPageData2() {
				this.$api({
					url: "game/multilist",
					method: "GET",
					data: this.paramsTab3
				}).then(res => {
					this.count2 = res.data.data.count
					this.pageData2 = this.pageData2.concat(res.data.data.list);
					this.getLonding(res.data.data.list, this.paramsTab3)

				})
			},

			// tags筛选条件
			changeTags(tags) {
				this.paramsTab1.tags = tags;
				this.paramsTab2.tags = tags;
				this.paramsTab3.tags = tags;
				this.resetParams();
			},
			// is_h5筛选条件
			switchChange(is_h5) {
				this.paramsTab1.is_h5 = is_h5;
				this.paramsTab2.is_h5 = is_h5;
				this.paramsTab3.is_h5 = is_h5;
				this.resetParams();
			},
			// cate筛选条件
			changeCate(cates) {
				this.paramsTab1.cates = cates;
				if (this.paramsTab1.cates == 0) {
					this.paramsTab1.is_mp4 = 1;
				} else {
					this.paramsTab1.is_mp4 = 0;
				}
				this.paramsTab1.page = 1;
				this.pageData = [];
				// this.getPageData(this.paramsTab1);
			},
			// sort筛选条件
			changeRankType(sort) {
				this.paramsTab1.sort = sort;
				this.paramsTab1.page = 1;
				this.pageData = [];
				// this.getPageData(this.paramsTab1);
			},
			// 上拉加载tab1的数据
			loadTab1Data() {
				this.paramsTab1.page++;
				// this.getPageData(this.paramsTab1);
			},
			// scroll-view到底部加载更多
			loadMore() {
				if (this.count > this.pageData.length) {
					this.status = "loading";
					this.paramsTab1.page++;
					this.getPageData(this.paramsTab1);
				} else if (this.count1 > this.pageData1.length) {
					this.status = "loading";
					this.paramsTab2.page++;
					this.getPageData1(this.paramsTab2);
				} else if (this.count2 > this.pageData2.length) {
					this.status = "loading";
					this.paramsTab3.page++;
					this.getPageData2(this.paramsTab3);
				} else {
					this.status = "nomore";
				}
			},

			// 重置搜索条件
			resetParams() {
				this.pageData = [];
				this.pageData1 = [];
				this.pageData2 = [];
				this.paramsTab2.page=1;
				this.paramsTab3.page=1;
				// this.getPageData(this.paramsTab1);
				this.getPageData1(this.paramsTab2);
				this.getPageData2(this.paramsTab3);

			}
		},
		created() {
			this.getInitData();
			this.getPageData1();
			this.getPageData2()
		},
		onLoad(options) {
			
			this.toCates = parseInt(options.cates) 

		},

		// 通过监听页面的显示与隐藏来让视频播放与暂停
		onShow() {
			this.videoPlay = true;

		},
		onHide() {
			this.videoPlay = false;
		},
		onTabItemTap() {
			uni.setTabBarStyle({
				backgroundColor: "#fff"
			})
		},
	}
</script>

<style lang="scss" scoped>
	.container {
		display: flex;
		flex-direction: column;
		// height: auto !important;

		// 标题部分
		.nav {
			width: 100%;
			// height: 65px;
			padding:  20rpx 0;
			color: #fff;
			font-size: 32rpx;
			background: #ff8500;
			position: relative;
			display: flex;
			justify-content: space-between;
			align-items: center;

			.tabs {
				flex: 1;
			}

			.swicth {
				flex: 2;
			}

			.btns {
				flex: 1;
				display: flex;
				justify-content: flex-end;

				.icon {
					margin-right: 20rpx;
				}
			}
		}

		// 内容部分
		.main {
			flex: 1;
			display: flex;
			flex-direction: column;
			padding-bottom: calc(var(--window-bottom));
			// padding-bottom: 80px;

			.tabs {
				width: 100%;
				// height: 41px;
				border-bottom: 1px solid #ecf0f1;
			}

			.swiper {
				flex: 1;
			}
		}
	}

	u-tabs-swiper {
		transition: none !important;
	}
</style>
