<!-- 游戏列表组件 -->
<template>
	<view v-if="list.length">
		<u-row class="list" gutter="10" v-for="(item, index) in list" :key="index">
			<u-col span="2.6"  @click="toUrl(item.game_id)">
				<image :src="item.icon" width="80%" mode="widthFix" class="icon"></image>
			</u-col>
			<u-col span="7" class="desc" @click="toUrl(item.game_id)">
				<view class="title">
					<text :style="{maxWidth:item.rate<1?'70%':''}">{{item.gamename}}</text>
					<text class="badge" v-if="item.rate&&item.rate!=1">{{(item.rate*10).toFixed(1) + '折'}}</text>
				</view>
				<view class="oneword">

					<text style="font-size: 20rpx;" v-for="(i,v) in item.type" :key='v' v-if="v<3"> {{i}}</text> <text
						style="font-size: 20rpx;" v-if="platform=='android'&&item.classify==3"
						class="type">{{item.size}}</text>
				</view>
				<view class="text">
					<!-- 游戏页的type -->
					<slot name="game" v-bind:data="item"></slot>
					<!-- 开服页的time -->
					<slot name="service" v-bind:data="item"></slot>
					<!-- <text class="timeText" v-if="lt==1">· {{item.start_time | dateFormat('yyyy-MM-dd hh:mm')}}</text> -->
				</view>
			</u-col>
			<u-col span="2.4">
				<xw-button :item="item"></xw-button>
			</u-col>
		</u-row>
	</view>
</template>

<script>
	export default {
		props: {
			list: {
				type: Array,
				default: []
			},
			type: {
				type: Number,
				default: 0
			},
			lt: {
				type: Number,
				default: 0
			},
		},
		methods: {
			toUrl(game_id) {
				if (game_id == 'down') {
					window.open(this.userFormat.down_app_url);
				} else {
					this.common.routerTo({
						path: '/pages/views/gameDetail/index',
						query: {
							game_id: game_id
						}
					})
				}
			}
		}
	}
</script>

<style lang="scss" scoped>
	.list {
		margin: $xw-margin-sm $xw-margin-md;
		max-height: 150rpx;
		border-bottom: 1px solid #ECECEC;

		.icon {
			max-width: 140rpx;
		}

		.desc {
			overflow: hidden;

			.title {
				white-space: nowrap;
				display: flex;
				align-items: center;

				.badge {
					background: url('../../static/image/zhekou.png') center no-repeat;
					-webkit-background-size: contain;
					background-size: contain;
					padding: 10rpx 8rpx 8rpx 20rpx;

				}
			}
			.title>text:nth-child(1) {
				font-weight: 600;
				font-size: 28rpx;
				@include uni-overflow;

			}

			.title>text:nth-child(2) {
				font-size: 22rpx;
				white-space: nowrap;
				color: #fff;
				margin-left: 10rpx;
			}


			.text {
				span {
					font-size: 22rpx !important;
				}

				.timeText {
					color: #FF5539;

					margin-left: 12rpx;
					height: 18rpx !important;

				}

			}

			h2,
			.text,
			.oneword {
				@include text-overflow(1);
				line-height: 50rpx;

				text {
					margin-right: 3px;
					font-size: 18rpx;
					color: #7C7C7C;


				}



			}

			.oneword {
				// font-size: $xw-font-size-sm;
			}
		}
	}
</style>
