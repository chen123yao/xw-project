<!-- 交易列表 -->
<template>
	<view class="container">
		<u-row gutter="16" v-for="(item,index) in list" :key="index" class="list">
			<u-col span="3.5">
				<u-image :src="JSON.parse(item.image)[0].split(',')[0]" width="100%" height="180"></u-image>
			</u-col>
			<u-col span="6">
				<u-row class="desc">
					<u-col class="h2">{{item.gamename}}</u-col>
					<u-col class="server">区服：{{item.server_name}}</u-col>
					<u-col class="price">￥{{item.price | KeepOne(2)}}</u-col>
				</u-row>
			</u-col>
			<u-col span="2.5">
				<xw-button @click="common.routerTo({ path: '/pages/views/commodityDetail/index', query: {goods_id: item.goods_id}})">去购买</xw-button>
			</u-col>
		</u-row>
	</view>
</template>

<script>
	export default {
		props: {
			list: {
				type: Array,
				default: []
			}
		},
	}
</script>

<style lang="scss" scoped>
	.container {
		padding: $xw-padding-base 0;
		
		.list {
			margin-bottom: $xw-margin-base;
		}

		.desc {

			.h2,
			.server,
			.price {
				@include text-overflow(1);
				line-height: 60rpx;
			}

			.server {
				color: $xw-font-base-color;
			}

			.price {
				font-size: 36rpx;
				font-weight: $xw-font-weight-bold;
				color: $xw-font-success-color;
			}
		}
	}
</style>
