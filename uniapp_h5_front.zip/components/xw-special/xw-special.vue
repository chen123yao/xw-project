<!-- 专区组件 -->
<template>
	<view class="special" v-if="list">
		<view class="item" v-for="(item, index) in list.list" :key="index">
			<view class="top">
				<u-section :title="item.topic_name" sub-title="查看更多" :show-line="false" font-size="36" @click="getMore(index)"></u-section>
			</view>
			<view class="text">{{item.description}}</view>
			<view class="list">
				<view class="game1">
					<view class="image">
						<u-image :src="item.image" width="100%" height="400" border-radius="30"></u-image>
						<view class="shadow"></view>
					</view>
					<view class="detail">
						<u-row gutter="10">
							<u-col span="3">
								<xw-image :src="item.icon" class="icon"></xw-image>
							</u-col>
							<u-col span="6.5" class="desc" @click="common.routerTo({path: '/pages/views/gameDetail/index', query: { game_id: item.game_id}})">
								<view class="h1">{{item.game_name}}</view>
								<view class="tags">
									<u-tag :text="common.numberTag(item.user_cnt)" size="mini" mode="dark" type="success" style="margin-right: 10rpx;"></u-tag>
									<u-tag v-for="(item,index) in item.type" :key="index" :text="item" size="mini" mode="plain" color="#ff8500"
									 shape="circleRight" style="margin-right:10rpx;"></u-tag>
								</view>
								<view class="oneWord">
									{{item.one_word}}
								</view>
							</u-col>
							<u-col span="2.4" class="btn">
								<xw-button :value="item.classify == 5 ? '开 玩' : '下 载'" @click="common.routerTo({path: '/pages/views/gameDetail/index', query: { game_id: item.game_id}})"></xw-button>
							</u-col>
						</u-row>
					</view>
				</view>
				<xw-gamelist :list="item.game_list">
					<template #game="slotObj">
						<view class="tags">
							<u-tag :text="common.numberTag(slotObj.data.user_cnt)" size="mini" mode="dark" type="success" style="margin-right: 10rpx;"></u-tag>
							<u-tag v-for="(item,index) in slotObj.data.type" :key="index" :text="item" size="mini" mode="plain" shape="circleRight"
							 color="#ff8500" style="margin-right: 10rpx;"></u-tag>
						</view>
					</template>
				</xw-gamelist>
			</view>
		</view>
	</view>
</template>


<script>
	export default {
		props: {
			list: {
				type: Object,
				default: null
			}
		},
		methods: {
			getMore(index) {
				this.$emit('getTabsIndex', index + 1);
			}
		},
	}
</script>

<style lang="scss" scoped>
	.special {
		.item {
			margin: $xw-margin-lg auto;
			border-radius: $xw-border-radius-base;
			background: $xw-bg-white-color;
			padding: $xw-padding-base;

			.tags {
				line-height: 60rpx;
			}

			.list {

				.game1 {
					position: relative;
					margin-bottom: $xw-margin-md*6;

					.image {
						width: 100%;
						height: 400rpx;
						position: relative;

						.shadow {
							position: absolute;
							top: 0;
							left: 0;
							width: 100%;
							height: 100%;
							border-radius: $xw-border-radius-lg;
							box-shadow: 0px -50px 50px rgba(0, 0, 0, 0.7) inset;
						}
					}

					.detail {
						width: 100%;
						margin: $xw-margin-base 0;
						padding: 0 $xw-padding-md;
						position: absolute;
						bottom: -120rpx;
						left: 0;

						.icon {
							width: 100%;
						}

						.desc {
							overflow: hidden;
							
							.h1,
							.tags,
							.oneWord {
								@include text-overflow(1);
							}
							

							.h1 {
								color: $xw-font-white-color;
								line-height: 60rpx;
							}

							.oneWord {
								font-size: $xw-font-size-sm;
							}
						}
					}

					.btn {
						padding-top: 60rpx !important;
					}
				}

				.tags {
					line-height: 50rpx;
					color: $xw-font-auxiliary-color;
				}
			}
		}
	}
</style>
