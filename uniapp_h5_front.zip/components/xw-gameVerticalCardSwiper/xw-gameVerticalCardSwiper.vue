<template>
	<view class="gameCardSwiper" v-if="data">
		<swiper class="swiper" :circular="true">
			<swiper-item class="swiper-item" v-for="(item,index) in data.game_list" :key="index">
				<xw-gameVerticalCard :data="item"></xw-gameVerticalCard>
			</swiper-item>
		</swiper>
	</view>
</template>

<script>
	export default {
		name: "myGameVerticalCardSwiper",
		props: {
			data: {
				type: Object,
				default: null
			}
		}
	}
</script>

<style lang="scss" scoped>
	.gameCardSwiper {
		width: 100%;
		height: 100%;
		
		.swiper {
			width: 100%;
			height: 400rpx;
			
			.swiper-item {
				width: 40%!important;
				padding-right: 2%;
				box-sizing: border-box;
			}
		}
	}
</style>