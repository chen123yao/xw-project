<!-- 开服表swiper组件 -->
<template>
	<view class="serviceLiSwiper" v-if="data.length">
		<swiper class="swiper" :circular="true">
			<swiper-item class="swiper-item" v-for="(item,index) in data" :key="index">
				<xw-serviceLi :data="item"></xw-serviceLi>
			</swiper-item>
		</swiper>
	</view>
</template>

<script>
	export default {
		name: "myServiceLiSwiper",
		props: {
			data: {
				type: Array,
				default: []
			}
		}
	}
</script>

<style lang="scss" scoped>
	.serviceLiSwiper {
		
		width: 100%;
		height: 100%;
		
		.swiper {
			width: 100%;
			height: 380rpx;
			padding-top: 30rpx;
			margin-top: 20rpx;
			

			
			.swiper-item {
				width: 30%!important;
				box-sizing: border-box;
				padding: 10rpx;
				overflow: none !important;
			}
		}
	}

</style>
