<!-- 开服表swiper组件 -->
<template>
	<view class="serviceLiSwiper" v-if="data.length">
		<swiper class="swiper" :circular="true">
			<swiper-item class="swiper-item" v-for="(item,index) in data" :key="index">
				<xw-transitionLi :data="item"></xw-transitionLi>
			</swiper-item>
		</swiper>
	</view>
</template>

<script>
	export default {
		name: "myServiceLiSwiper",
		props: {
			data: {
				type: Array,
				default: []
			}
		}
	}
</script>

<style lang="scss" scoped>
	.serviceLiSwiper {
		width: 100%;
		height: 100%;
		
		.swiper {
			width: 100%;
			height: 300rpx;
			
			.swiper-item {
				width: 30%!important;
				box-sizing: border-box;
				padding: 10rpx;
			}
		}
	}
</style>
