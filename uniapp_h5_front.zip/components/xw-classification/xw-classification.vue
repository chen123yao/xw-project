<template>
	<view class="classification">
		<view class="cationButton">	
	
   <u-button  size="medium" style="padding:10rpx 40rpx ;width:20%;margin:10rpx" 
      type="success"
   v-for="index in cate" :key='index.id'>{{index.name}}</u-button>
   
		</view>
	</view>
</template>

<script>
	export default {
		name: "myClassification",
		props: ['cate','type'],
		data:{
			return:{
				
			}
		},
		computed:{
			
		},
		method:{
// :type="index.id==3||index.id==10?'primary':index.id==52||index.id==58|
// |index.id==87?'success':index.id==89|
// |index.id==88?'success':index.id==754||index.id==751?'warning':'error'"
		
	}
		};
	
</script>

<style lang="scss" scoped>
	.cationButton{
		display: flex;
             
		flex-wrap:wrap;
		justify-content: center;
		

	}
	

</style>
