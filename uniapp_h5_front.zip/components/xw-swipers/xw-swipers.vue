<!-- 自定义轮播图 -->
<template>
	<view class="swiper" @touchstart="touchStart" @touchend="touchEnd">
		<view v-for="(item,index) in dataList" :key="index" >
			<view class="swiper-item" :class="['swiper-item-' + item.rank]" v-if="item.rank < 5">
				<view class="detail" @click="common.routerTo({path: '/pages/views/gameDetail/index', query: {game_id: item.game_id}})">
					<u-image :src="item.icon" width="100%" mode="widthFix"></u-image>
					<view class="game-name">
						{{item.game_name}}
					</view>
				</view>

				<view class="background">
					<u-image :src="item.icon" width="100%" height="100%" border-radius="30rpx"></u-image>
				</view>
			</view>
		</view>

	</view>
</template>

<script>
	export default {
		mounted() {

			setInterval(() => {
				this.handleChange('right');
			}, 2000)

		},
		// props: {
		// 	dataItem: {
		// 		type: Array,
		// 		default () {
		// 			return []
		// 		}
		// 	}
		// },
		data() {
			return {
				dataList: [],
				touchStartX: 0, // 触摸起点x
				touchStartY: 0, // 触屏起始点y  
				pageH5Data:{}
			}
		},
		created(){
			this.getH5GameData()
		},
		methods: {
			// 触摸开始
			touchStart(e) {
				this.touchStartX = e.touches[0].clientX;
				this.touchStartY = e.touches[0].clientY;
			},
			// 触摸结束
			touchEnd(e) {
				let deltaX = e.changedTouches[0].clientX - this.touchStartX;
				let deltaY = e.changedTouches[0].clientY - this.touchStartY;
				if (Math.abs(deltaX) > 50 && Math.abs(deltaX) > Math.abs(deltaY)) {
					if (deltaX >= 0) {
						this.handleChange('left')
					} else {
						this.handleChange('right')
					}
				}
			},
			// 切换
			handleChange(direction) {

				switch (direction) {
					// 左滑动
					case 'left':
						this.dataList.forEach((item, index, arr) => {
							if (item.rank == this.dataList.length - 1) {
								this.dataList[index].rank = 0;
							} else {
								this.dataList[index].rank = item.rank + 1;
							}
						});
						break;
					case 'right':
						this.dataList.forEach((item, index, arr) => {
							if (item.rank == 0) {
								this.dataList[index].rank = this.dataList.length - 1;
							} else {
								this.dataList[index].rank = item.rank - 1;
							}
						});
						break;
				}

				// 强制刷新数据
				this.$forceUpdate()
			},
			getH5GameData() {
				this.$api({
					url: "home/h5",
					method: "GET",
				}).then(res => {
					console.log(res.data.data.list)
					// this.newPageH5Data = this.getRandomArrayElements(this.pageH5Data.list[0].game_list, 6)
					this.newPageH5Data = this.getRandomArrayElements(res.data.data.list[0].game_list, 6)
					this.newPageH5Data.forEach((item, index)=>{
						item.rank = index;
						this.dataList.push(item);
					})
				})
			},
			getRandomArrayElements(arr, count) {
				var shuffled = arr.slice(0),
					i = arr.length,
					min = i - count,
					temp, index;
				while (i-- > min) {
					index = Math.floor((i + 1) * Math.random());
					temp = shuffled[index];
					shuffled[index] = shuffled[i];
					shuffled[i] = temp;
				}
				return shuffled.slice(min);
			},
		},
		// watch: {
		// 	dataItem: {
		// 		handler(val) {
		// 			val.forEach((item, index) => {
		// 				// if (index < 5) {
		// 				item.rank = index;
		// 				this.dataList.push(item);
		// 				// }
		// 			})
		// 			// console.log(this.dataList);
		// 		},
		// 		immediate: true
		// 	}
		// }
	}
</script>

<style lang="scss" scoped>
	.swiper {
		width: 100%;
		height: 300rpx;
		position: relative;

		.swiper-item {
			width: 230rpx;
			height: 300rpx;
			position: relative;
			transform-origin: 50% 100%;
			transition: all 0.5s;
			position: absolute;
			bottom: 0;

			.detail {
				width: 100%;
				height: 100%;
				border-radius: 50% !important;
				position: relative;
				z-index: 10;
				font-size: 24rpx;
				font-weight: 700;
				color: #fff;
				line-height: 50rpx;
				padding: 20rpx;

				.game-name {
					@include text-overflow(1);
					text-align: center;
				}
			}

			.background {
				position: absolute;
				top: 0;
				left: 0;
				right: 0;
				bottom: 0;
				z-index: 0;
				filter: brightness(50%);
				

			}
		}

		.swiper-item-0 {
			left: 0;
			z-index: 0;
			width: 184rpx;
			height: 240rpx;
		}

		.swiper-item-1 {
			left: 16%;
			z-index: 1;
			width: 207rpx;
			height: 270rpx;
		}

		.swiper-item-2 {
			left: 50%;
			z-index: 2;
			transform: translateX(-50%);
		}

		.swiper-item-3 {
			right: 16%;
			z-index: 1;
			width: 207rpx;
			height: 270rpx;
		}

		.swiper-item-4 {
			right: 0;
			z-index: 0;
			width: 184rpx;
			height: 240rpx;
		}
	}
	@media screen and (min-width: 600px) {
		.swiper{
			height: 350rpx;
		}
	    .swiper-item {
	        width: 230rpx !important;
			height: 310rpx !important;
	        
	    }
		.swiper-item-0 {
			height: 270rpx !important;
		}
		
		.swiper-item-1 {
			
			height: 290rpx !important;
		}
		
		.swiper-item-3 {
			
			height: 290rpx !important;
		}
		
		.swiper-item-4 {
		
			height: 270rpx !important;
		}
		
	}
</style>
