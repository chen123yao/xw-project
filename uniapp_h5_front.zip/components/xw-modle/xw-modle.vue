<template>
	<view class="modle">

		<view class="modleSelect">

			<u-popup v-model="IsShowPage" border-radius="30" height="40%" mode="bottom" @close="handleclose">
				<view class="modleSolid" @click="handleclose">
					<view class="">

					</view>
				</view>
				<view class="text">
					<text>游戏开服</text>
				</view>
				<xw-classification v-if="newCate" :cate="newCate" :type='1'></xw-classification>
			</u-popup>
		</view>
	</view>
</template>

<script>
	export default {
		props: ['isShow', 'cate'],
		data() {
			return {
				IsShowPage: false,
				newCate: []
			}
		},
		watch: {
			isShow(val) {
				this.IsShowPage = val;
			},
			cate(val) {
				this.newCate = val;
			},

		},

		methods: {
			handleclose() {
				this.IsShowPage = false
				this.$emit('close', this.IsShowPage)
			}
		}
	}
</script>

<style lang="scss" scoped>
	.modleSolid {
		width: 100%;
		display: flex;
		justify-content: center;

		view {
			width: 10%;
			height: 5px;
			background-color: #AFAFAF;
			margin: 15px 0;
			border-radius: 20px;
		}
	}

	.text {
		display: flex;
		justify-content: flex-start;

		text {
			font-size: 14px;
			font-weight: 600;
			padding: 0 10px 10px 22px;
		}
	}
</style>
