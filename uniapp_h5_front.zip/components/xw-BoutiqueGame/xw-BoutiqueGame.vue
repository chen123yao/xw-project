<template>
	<view class="BoutiqueGame">
		<view class="swiperGame">
              
			<swiper class="swiper" display-multiple-items='5' autoplay circular @change="changeIndicatorDots" interval='1500'>
				<swiper-item class="swiper-items" ref='swiperRef' :class=" 'icon'+index" v-for=" (item,index) in data" 
				 :name='item.game_name' :key='index' @click="common.routerTo({path: '/pages/views/gameDetail/index', query: {game_id: item.game_id}})">
					<view class="swiperI" :style="{backgroundImage: 'url(' + item.icon + ')', backgroundSize:'100% 100%', backgroundRepeat: 'no-repeat'}">

					</view>
					<view class="viewitem">
						<image :src="item.icon" mode="widthFix"></image>
						<text>{{item.game_name}}</text>

					</view>
				</swiper-item>

			</swiper>

		</view>
	</view>
</template>

<script>
	export default {
		name: 'BoutiqueGame',
		props: ['data'],
		data() {
			return {

			}
		},
		methods: {
			changeIndicatorDots(val) {
				// console.log(val.detail.current,'valvalvalval')
				this.$refs.swiperRef.forEach((item, index) => {	
			 (index+val.detail.current)<6?this.$refs.swiperRef[index+val.detail.current].$el.className= `swiper-items icon${index}`:
			 this.$refs.swiperRef[val.detail.current+index-6].$el.className= `swiper-items icon${index}`
				})

			}


		}

	}
</script>

<style lang="scss" scoped>
	.u-col {}

	.swiperGame {
		width: 90%;
		height: 160px;
		margin-bottom: 60rpx;



		.swiper {
			position: relative;
			height:100%;
			width: 180%;
			left: -7%;
		

			.swiper-items {
				position: absolute;
			     overflow: hidden;
				border-radius: 15%;
			    transition: ease-out 0.6s;

				.swiperI {
					position: absolute;
					filter: blur(5px);
					width: 100%;
					height: 100%;
					z-index: 0;
					overflow: hidden;

				}

				.viewitem {
					display: flex;
					flex-direction: column;
					justify-content: center;
					align-items: center;
					filter: blur(0);

					image {
						margin-top: 15rpx;
						width: 80%;

					}

					text {
						margin-top: 15rpx;
						font-size: 12rpx;
						text-align: center;
						white-space: nowrap;
						overflow: hidden;
						text-overflow: ellipsis;
						color: #fff;
					}
				}

			}
		}
	}

	.icon5 {
		top: 20px;
		right: 100px;
		z-index: -1;
	

	}

	.icon0 {
		top: 20px;
		left: 10%;
		z-index: 0;
	

	}

	.icon1 {
		top: 10px;
		right: 40%;
		z-index: 1;

	}

	.icon2 {
		right: 80%;
		z-index: 2;
		// width: 110% !important;

	}

	.icon3 {
		top: 10px;
		right: 120%;
		z-index: 1;

	}

	.icon4 {
		top: 20px;
		right: 160%;
		z-index: 0;
	}
.swiper-container-free-mode>.swiper-wrapper {
    -webkit-transition-timing-function: linear; /*之前是ease-out*/
    -moz-transition-timing-function: linear;
    -ms-transition-timing-function: linear;
    -o-transition-timing-function: linear;
    transition-timing-function: linear;
    margin: 0 auto;
}	
</style>
