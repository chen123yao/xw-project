<template>
	<view class="hotRings">

		<u-row gutter="16" v-if="list">
			<u-col span="4"  v-if="index" v-for=" index in list" :key='index.game_id'>
				<view class="hotRingstab">
					<image :src="index.icon" mode="widthFix" @click="common.routerTo({path: '/pages/views/gameDetail/index', query: {game_id: index.game_id}})"></image>
					<text class="hotRingstabText">{{index.game_name}}</text>
					<view class="">
						<image src="../../static/image/pingfen.png" mode="widthFix" style="width: 10px; margin-right: 5px;"></image>
						<text style="color: #ff8500;">{{index.star_cnt}}</text><text style="color: #a5a5a5;margin-left: 3px;" v-if="index.size!='0 B'">
							| {{index.size}}</text>
					</view>
					<view class="hotRingsBut">
						<xw-button :item="index"></xw-button>
					</view>
				</view>
			</u-col>


		</u-row>

	</view>
</template>

<script>
	export default {
		name: "hotRings",
		props: ['list'],
		data() {
			return {

			}

		}

	}
</script>

<style lang="scss" scoped>
	.hotRings {

		margin-bottom: 30rpx;

		image {
			width: 70px;
		}

		.hotRingstabText {
			width: 100px;
			text-overflow: ellipsis;
			white-space: nowrap;
			overflow: hidden;
			margin: 10px 0;
			font-weight: 600;
			text-align: center;

		}

		.hotRingstab {
			display: flex;
			flex-direction: column;
			justify-content: center;
			align-items: center;


			.hotRingsBut {
				margin-top: 15px;
				width: 50%;
			}

		}

		.u-col-4:nth-child(2) {
			order: -1
		}

		.u-col-4:nth-child(1) {
			margin-top: -10rpx;
			transform: scale(1.25, 1.05);
			-moz-transform-origin: 0 100%;
			-webkit-transform-origin: 0 100%;
			-o-transform-origin: 0 100%;
			transform-origin: 50% 130%;

		}
	}
</style>
