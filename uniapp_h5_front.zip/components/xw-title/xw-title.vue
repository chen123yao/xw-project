<!-- 首页小标题组件 -->
<template>
	<view class="myTitle">
		<u-row>
			<u-col span="0.5">
				
				<view class="titleLine">
				
				</view>
			</u-col>
			<u-col span="9">
				<view class="titleView">
					<slot>{{value}}</slot>
				</view>
				
				
			</u-col>
			<u-col span="2">
				<view class="more" @click="common.routerTo({name: router, params: topic})" v-if="router">
					更多<u-icon name="arrow-right" size="28"></u-icon>
				</view>
			</u-col>
		</u-row>
	</view>
</template>

<script>
	export default {
		name: "myTitle",
		props: {
			value: String,
			router: String,
			topic: {
				type: Object,
				default(){
					return {}
				}
			}
		},
		// created(){
		// 	console.log(this.topic);
		// }
	}
</script>

<style lang="scss" scoped>
	.myTitle {
		width: 100%;
		height: 60rpx;
		line-height: 60rpx;
		margin: 30rpx 0 20rpx;
        view{
			
		}
		
		.more {
			color: $xw-font-auxiliary-color;
			font-size: 24rpx;
		}
	}
</style>
