<!--
 * @Author: your name
 * @Date: 2021-01-23 15:15:57
 * @LastEditTime: 2021-03-11 10:54:14
 * @LastEditors: your name
 * @Description: In User Settings Edit
 * @FilePath: \uniapp_h5_front\components\xw-nodata\xw-nodata.vue
-->
<!-- 没有数据组件 -->
<template>
	<view class="nodata">
		<view class="loading" v-if="isLoading">
			<view class="desc">
				<image src="@/static/image/loading.gif" mode="widthFix"></image>
			</view>
		</view>
		<view class="desc" v-else>
			<image src="@/static/image/noData.png" mode="widthFix"></image>
			<view class="text">
				<slot>暂无数据</slot>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				loading: true
			}
		},
		computed: {
			isLoading(){
				return this.$store.state.isLoading
			}
		},
		created(){
			setTimeout(()=>{
				this.$store.commit('setIsLoading', false)
			}, 10000)
		},
	}
</script>

<style lang="scss" scoped>
	.nodata {
		width: 100%;
		height: 100%;
		min-height: 700rpx;
		text-align: center;
		position: relative;

		.loading {
			image {
				width: 100% !important;
			}
		}
		.desc {
			width: 100%;
			position: absolute;
			top: 50%;
			left: 50%;
			transform: translate(-50%, -50%);
			image {
				width: 60%;
			}

			.text {
				line-height: 50rpx;
				font-weight: $xw-font-weight-bold;
				font-size: 36rpx;
			}
		}
	}
</style>
