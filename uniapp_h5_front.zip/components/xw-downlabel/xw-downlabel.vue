<!-- 首页底部下载栏 -->
<template>
	<view class="downlabel" v-if="show">
		<u-row class="main">
			<u-col span="3">
				<u-image :src="userFormat.icon" width="120" height="120"></u-image>
			</u-col>
			<u-col span="6.5" class="text">
				<view class='h2'>{{userFormat.name}}</view>
				<view class="slogan">{{userFormat.slogan}}</view>
			</u-col>
			<u-col span="2.4">
				<xw-button @click="installNow" :item='{classify:8}'>立即安装</xw-button>
			</u-col>
		</u-row>

		<u-icon name="close" size="32" color="#fff" class="close" @click="handleClose"></u-icon>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				show: true
			}
		},
		methods: {
			// 立即下载
			installNow() {
				window.open(this.userFormat.down_app_url);
			},
			// 关闭按钮
			handleClose() {
				this.show = false;
			}
		}
	}
</script>

<style lang="scss" scoped>
	.downlabel {
		width: 100%;
		max-width: $max-width;
		height: 180rpx;
		padding: $xw-padding-sm;
		background: rgba(0, 0, 0, .7);
		position: fixed;
		bottom: 50px;
		z-index: 100;

		.main {
			width: 100%;
			height: 100%;

			.text {
				color: $xw-font-white-color;
				line-height: 60rpx;
			}
			
			.slogan {
				@include text-overflow(1);
			}
		}

		.close {
			position: absolute;
			right: 16rpx;
			top: 16rpx;
		}
	}
</style>
