<!-- 简单游戏展示组件 -->
<template>
  <view class="myConciseGame" v-if="data" @click="common.routerTo({path: '/pages/views/gameDetail/index', query: {game_id: data.game_id}})">

    <u-image width="120" height="120" :src="data.icon" mode="widthFix" border-radius="20" class="image"></u-image>
    <view class="gamename">{{data.gamename}}
      <u-badge bgColor="#FF174D" color="#fff" size="mini" :count="data.selling_point.split(',')[0]" v-if="badge" :offset="[-10,0]"></u-badge>
    </view>
    <view class="types" v-if="types">
      <text class="type" v-for="(v,i) in data.type" :key="i">{{v}}</text>
    </view>
  </view>
</template>

<script>
export default {
  name: "myConciseGame",
  props: {
    data: {
      type: Object,
      default: null,
    },
    types: Boolean,
    badge: Boolean,
  },
};
</script>

<style lang="scss" scoped>
.myConciseGame {
  width: 100%;
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  text-align: center;
  margin: 14rpx 0;
  position: relative;
  .image {
	  margin: 0 auto;
	  position: relative;
	  max-width: 140rpx;
  }

  .gamename {
   @include text-overflow(1);
   font-weight: 600;
   font-size: 24rpx;
  }

  .types {
    @include text-overflow(1);
    font-size: 24rpx;
    color: $xw-font-light-color;

    .type:after {
      content: "·";
      margin: 0 10rpx;
    }

    .type:last-child:after {
      content: "";
    }
  }
}

// @media screen and (min-width: 600px) {
// 	.image {
// 		margin-left: 38% !important;
// 		width: 160rpx !important;
// 		height: 160rpx !important;
// 	}

// 	.gamename {
// 		margin-left: 28% !important;
// 	}
// }
</style>
