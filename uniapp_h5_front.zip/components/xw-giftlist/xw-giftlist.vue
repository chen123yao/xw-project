<!-- 我的礼包 -->
<template>
	<view class="list" v-if="list.length">
		<u-row gutter="16" v-for="(item,index) in list" :key="index" class="item">
			<u-col span="2.6">
				<xw-image :src="item.icon"></xw-image>
			</u-col>
			<u-col span="7" style="overflow: hidden;">
				<view style="font-size: 36rpx;font-weight: 600;white-space: nowrap;width: 400rpx;text-overflow: ellipsis;overflow: hidden;">{{item.gift_name}}</view>
				<view class="code">礼包码：{{item.code}}</view>
				<view class="time">期限：{{item.end_time | dateFormat("yyyy-MM-dd")}}</view>
			</u-col>
			<u-col span="2.4">
				<xw-button @click="handleOpen(item)">复 制</xw-button>
			</u-col>
		</u-row>

		<u-modal v-model="copyShow" title="领取提示" confirm-text="复制" confirm-color="#ff8500" :mask-close-able="true" @confirm="handleCopy"
		 v-if="copyShow">
			<view class="slot-content">
				<view>兑换码：{{currentItem.code}}</view>
				<view>复制兑换码，去游戏中使用</view>
			</view>
		</u-modal>
	</view>
</template>

<script>
	export default {
		props: {
			list: {
				type: Array,
				default: []
			}
		},
		data() {
			return {
				copyShow: false,
				currentItem: null
			}
		},
		methods: {
			handleOpen(item) {
				this.copyShow = true;
				this.currentItem = item;
			},
			handleCopy() {
				this.common.copy(this.currentItem.code)
				this.copyShow = false;
			}
		}
	}
</script>

<style lang="scss" scoped>
	.list {
		padding: $xw-padding-md;
		font-size: $xw-font-size-sm;
		line-height: 1.7;
		color: $xw-font-base-color;
		
		.title,
		.code,
		.time {
			@include text-overflow(1);
		}

		.title {
			color: $xw-font-main-color;
		}

		.item {
			margin-bottom: $xw-margin-md;
		}

		.slot-content {
			text-align: center;
			font-size: $xw-font-size-md;
			margin: $xw-margin-base auto;
		}
	}
</style>
