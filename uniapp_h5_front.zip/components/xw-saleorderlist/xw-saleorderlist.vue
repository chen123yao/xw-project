<!-- 我买到的 -->
<template>
	<view class="list">
		<view v-if="list.length">
			<view class="item" v-for="(item,index) in list" :key="index">
				<view class="h3">订单号：{{item.order_id}}</view>
				<view class="content">
					<view>游戏名称：{{item.gamename}}</view>
					<view>小号ID：{{item.role_id}}</view>
					<view>区服：{{item.server_name}}</view>
					<view>支付金额：{{item.price}}元</view>
					<view>支付方式：{{item.payway}}</view>
					<view>支付时间：{{item.goods.create_time | dateFormat("yyyy-MM-dd hh:mm")}}</view>
					<view>状态：
						<text v-if="item.status == 1">待处理</text>
						<text v-else-if="item.status == 2">成功</text>
						<text v-else-if="item.status == 3">失败</text>
					</view>
					<view class="btn" v-if="item.status == 1">
						<xw-button @click="common.routerTo({path: '/pages/views/payMethods/index', query: {order_id: item.order_id}})">去支付</xw-button>
					</view>
				</view>
			</view>
		</view>

		<xw-nodata v-else>无订单信息</xw-nodata>
	</view>
</template>

<script>
	export default {
		props: {
			list: {
				type: Array,
				default: []
			}
		},
	}
</script>

<style lang="scss" scoped>
	.list {
		text-align: left;
		padding: 0 $xw-padding-base $xw-padding-base;

		.item {
			border-top: 20rpx solid $xw-border-primary-color;

			.h3 {
				padding: $xw-padding-md 0;
				border-bottom: 1px solid $xw-border-success-color;
			}

			.content {
				color: $xw-font-base-color;
				line-height: 60rpx;
				position: relative;
				
				.btn {
					width: 100rpx;
					position: absolute;
					bottom: 20rpx;
					right: 20rpx;
				}
			}
		}
	}
</style>
