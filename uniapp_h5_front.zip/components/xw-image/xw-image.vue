<!-- 图片组件 -->
<template>
	<view v-if="src">
		<u-image :src="src" mode="widthFix" :width="width" :height="height" :shape="shape" :lazy-load="false" :fade="true"
		 duration="150" class="image" border-radius="20rpx">
			<u-loading slot="loading"></u-loading>
			<view slot="error" style="font-size: 24rpx;">加载失败</view>
		</u-image>
	</view>
</template>

<script>
	export default {
		props: {
			src: {
				type: String,
				default: ""
			},
			shape: {
				type: String,
				default: "square"
			},
			width: {
				type: String,
				default: "100%"
			},
			height: {
				type: String,
				default: "100%"
			}
		}
	}
</script>

<style lang="scss" scoped>

</style>
