<template>
	<view class="gameVideoSwiper" v-if="pageData.length">
		<swiper class="swiper" vertical circular @change="changeGameVideo">
			<swiper-item class="swiper-item" v-for="(item, index) in pageData" :key="index">
				<!-- 视频部分 -->
				<video :src="item.mp4_url" loop :controls="false" show-fullscreen-btn enable-play-gesture
				 :enable-danmu="true" :enable-progress-gesture="false" class="video"></video>
				<!-- 游戏下载部分 -->
				<u-row class="gameDetail">
					<u-col :span="3" @click="common.routerTo({path: '/pages/views/gameDetail/index', query: {game_id: item.gamedetail.game_id}})">
						<u-image :src="item.gamedetail.icon" width="120" height="120"  border-radius="20"></u-image>
					</u-col>
					<u-col :span="6" class="detail" @click="common.routerTo({path: '/pages/views/gameDetail/index', query: {game_id: item.gamedetail.game_id}})">
						<h3 class="gamename">{{item.gamedetail.gamename}}</h3>
						<view class="types">
							<text class="type" v-for="(v,i) in item.gamedetail.type" :key="i">{{v}}</text>
							<text class="type">·</text>
							<text class="type">{{item.gamedetail.down_cnt}}</text>
						</view>
						<view class="tags" v-if="item.gamedetail.tags.length">
							<text :class="['tag','color'+index]" v-for="(v,i) in item.gamedetail.tags">{{v}}</text>
						</view>
						<view class="desc" :text="item.gamedetail.one_word" v-else>{{item.gamedetail.one_word}}</view>
					</u-col>
				</u-row>
				<!-- 侧边按钮组 -->
				<view class="btns">
					<view class="btn">
						<u-icon name="heart" color="#fff" size="60"></u-icon>
						<view>{{item.gamedetail.like_cnt}}</view>
					</view>
					<view class="btn">
						<u-icon name="chat" color="#fff" size="60" @click="getCommentData(commentParams)"></u-icon>
						<view>{{item.gamedetail.comment_cnt}}</view>
					</view>
					<view class="btn">
						<u-icon name="share-fill" color="#fff" size="60"></u-icon>
						<view>{{item.gamedetail.share_cnt}}</view>
					</view>
					<view class="btn">
						<view class="downlod">
							<u-icon name="arrow-downward" color="#fff" size="40"></u-icon>
						</view>
						<view class="fileSize">{{item.gamedetail.size}}</view>
					</view>
				</view>
				<!-- 评论区 -->
				<u-popup v-model="commentShow" mode="bottom" border-radius="20" height="70%">
					<view class="comment">
						<!-- 评论展示区 -->
						<view class="commentList">
							<scroll-view scroll-y="true" @scrolltolower="loadMore" lower-threshold="100" style="width:100%;">
								<xw-commentlist :list="commentData" @clickSupport="resetData"></xw-commentlist>
								<u-loadmore bg-color="#fff" :status="status" :icon-type="iconType" :load-text="loadText" @loadmore="loadMore"
								 v-if="commentData.length" />
							</scroll-view>
						</view>
						<!-- 评论输入区 -->
						<view class="commentInput">
							<u-row gutter="20" justify="between">
								<u-col span="10">
									<u-input v-model="rate.comment" :clearable="false" type="textarea" placeholder="请输入你想表达的内容..." @focus="common.isLogin"
									 width="100%" height="100%"></u-input>
								</u-col>
								<u-col span="2" text-align="center" @click="publicComment" :class="{'sendColor': rate.comment.length}">发送</u-col>
							</u-row>

						</view>
					</view>
				</u-popup>
			</swiper-item>
		</swiper>

		<u-toast ref="uToast" />
	</view>
</template>

<script>
	import {
		myLoading
	} from "@/common/js/mixin.js";

	export default {
		name: "myGameVideoSwiper",
		data() {
			return {
				pageData: [],
				currentIndex: 0,
				commentData: [],
				commentShow: false,
				status: "loadmore",
				// 评论
				commentParams: {
					page: 1,
					offset: 10,
					type_name: "game",
					object_id: 0
				},
				// 评分
				rate: {
					count: 5,
					value: 5,
					comment: ""
				},
			}
		},
		methods: {
			// 获取游戏数据
			getPageData() {
				this.$api({
					url: "home/slideMp4",
					method: "GET",
				}).then(res => {
					this.pageData.push(res.data.data);
					this.commentParams.object_id = this.pageData[this.currentIndex].gamedetail.game_id;
				})
			},
			// 切换游戏视频
			changeGameVideo(event) {
				this.currentIndex = event.detail.current;
				this.commentParams.object_id = this.pageData[this.currentIndex].gamedetail.game_id;

				if (this.pageData.length - this.currentIndex <= 2) {
					this.getPageData()
				}
			},
			// 获取评论数据
			getCommentData(params) {
				this.$api({
					url: "v8/comments/list",
					method: "GET",
					data: params
				}).then(res => {
					this.commentShow = true;
					this.commentData = this.commentData.concat(res.data.data.list);
					if (res.data.data.list.length < params.offset) {
						this.status = "nomore";
					}
				})
			},
			// 加载更多评论
			loadMore() {
				this.status = "loading"
				this.commentParams.page++;
				this.getCommentData(this.commentParams)
			},
			// 重置数据
			resetData() {
				this.commentParams['page'] = 1;
				this.commentData = [];
				this.getCommentData(this.commentParams)
			},
			// 提交评论
			publicComment() {
				if (!this.rate.comment) return;

				this.$api({
					url: "v8/comments/add",
					method: "GET",
					data: {
						object_id: this.commentParams.object_id,
						star_cnt: this.rate.value * 2,
						content: this.rate.comment,
						type_name: "game"
					}
				}).then(res => {
					this.$refs.uToast.show({
						title: '发表成功',
						type: 'success',
					})
					// 重置输入框
					this.rate.comment = "";
					this.resetData();
				})
			}
		},
		created() {
			this.getPageData()
			this.getPageData()
		},
		mixins: [myLoading]
	}
</script>

<style lang="scss" scoped>
	.gameVideoSwiper {
		width: 100%;
		height: 100%;

		.swiper {
			width: 100%;
			height: 100%;

			.swiper-item {
				display: flex;
				flex-direction: column;
				justify-content: center;
				position: relative;

				// 视频部分
				.video {
					width: 100%;
					height: 600rpx;
				}

				// 游戏详情部分
				.gameDetail {
					width: 100%;
					padding: 10rpx;
					box-sizing: border-box;
					position: absolute;
					bottom: 0;
					left: 0;

					.detail {
						overflow: hidden;
						display: flex;
						flex-direction: column;
						justify-content: space-around;
						align-items: flex-start !important;
						
						.gamename,
						.types,
						.tags,
						.desc{
							@include text-overflow(1);
						}

						.gamename {
							width: 100%;
							color: #fff;
						}

						.types {
							width: 100%;
							font-size: 24rpx;
							margin: 10rpx 0;
							color: $xw-font-light-color;

							.type {
								margin-right: 10rpx;
							}
						}

						.tags {
							width: 100%;
							font-size: 28rpx;

							.tag {
								margin-right: 10rpx;
							}

							.color0 {
								color: #74b9ff;
							}

							.color1 {
								color: #fab1a0;
							}

							.color2 {
								color: #a29bfe;
							}

							.color3 {
								color: #81ecec;
							}
						}
						
						.desc {
							@include color-gradient(right, red, blue);
						}
					}
				}

				// 按钮组部分
				.btns {
					width: 140rpx;
					position: absolute;
					right: 0;
					bottom: 0;
					z-index: 999;
					color: #fff;
					display: flex;
					flex-direction: column;
					justify-content: space-between;

					.btn {
						padding: 25rpx 0;

						.downlod {
							width: 70rpx;
							height: 70rpx;
							line-height: 70rpx;
							margin: 0 auto;
							background: #feca57;
							border-radius: 50%;
						}

						.fileSize {
							font-size: 24rpx;
						}
					}
				}

				// 评论
				.comment {
					width: 100%;
					height: 100%;
					display: flex;
					flex-direction: column;

					// 评论展示区
					.commentList {
						flex: 1;
						overflow-y: scroll;
						padding: $xw-padding-md;
						color: $xw-font-base-color;
						text-align: center;
					}

					// 评论输入区
					.commentInput {
						width: 100%;
						height: 80rpx;
						padding-top: 10rpx;
						overflow: hidden;
						border-top: 1px solid $xw-font-light-color;
						box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
						color: $xw-font-auxiliary-color;

						.sendColor {
							color: $xw-font-primary-color;
						}
					}
				}
			}
		}
	}
</style>
