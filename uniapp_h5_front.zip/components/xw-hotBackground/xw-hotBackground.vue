<template>
	<view class="hotBackground">
		<view class="Hotbackground" :class="type==1?'':'newBackground'" >
			
		</view>
	</view>
</template>

<script>
	export default {
		props:['type'],
		data(){
			return{
				
			}
			
		}
	}
	
</script>

<style lang="scss" scoped>
	.hotBackground{
		height:280rpx;
	.Hotbackground{
		height: 100%;
		background:url(../../static/image/Hotbackground.png) no-repeat center;
		background-position:0 0 ;
		background-size: 100%;
		margin-bottom: 10px;
	
	}
	.newBackground{	
		background:url(../../static/image/newBackground.png) no-repeat center;
		background-size: 100%;
		background-position:0 0 ;
	}
	}
	@media screen and (min-width:600px){
	 .hotBackground {
		height:330rpx !important;
	 }
	}
	
</style>
