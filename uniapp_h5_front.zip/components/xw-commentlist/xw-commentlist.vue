<template>
  <view class="commentlist">
    <view v-if="pageData.length">
      <u-row v-for="(item,index) in pageData" :key="index" class="item" align="top">
        <u-col span="2">
          <u-avatar :src="item.mem_avatar"></u-avatar>
        </u-col>
        <u-col span="8.2" class="clearfix">
          <view class="name h2">{{item.full_name}}
            <u-rate :count="5" v-model="item.star_cnt/2" active-color="#ff8500" :disabled="true" size="24" class="fr"></u-rate>
          </view>
          <view v-if="item.content.imglist">
            <image mode="widthFix" :src="v" v-for="(v,i) in item.content.imglist" :key="i"></image>
          </view>
          <view class="comment" v-if="item.content.desc">{{item.content.desc}}</view>
          <view class="comment" v-else>
            {{item.content}}
          </view>
          <view class="time fr">{{item.time_str}}</view>
        </u-col>
        <u-col span="1.7" text-align="center">
          <u-icon name="thumb-up" :color="item.is_like == 2 ? '#ff8500' : '#ccc'" size="50" @click="handleSupport(item, index)"></u-icon>
          <view>{{item.like_cnt}}</view>
        </u-col>
      </u-row>
    </view>

    <xw-nodata v-else>暂无评论</xw-nodata>
  </view>
</template>


<script>
import uImage from '../../uview-ui/components/u-image/u-image.vue';
export default {
  components: { uImage },
  props: {
    list: {
      type: Array,
      default: []
    }
  },
  data() {
    return {
      pageData: []
    }
  },
  methods: {
    // 点赞或取消
    handleSupport(item, index) {
      this.common.isLogin();

      let params = {
        game_id: this.$Route.query.game_id,
        comment_id: item.id,
      };
      if (item.is_like == 2) {
        params["type"] = 1
      } else {
        params["type"] = 2
      }
      this.$api({
        url: "comments/like",
        method: "GET",
        data: params
      }).then(res => {
        if (item.is_like == 2) {
          this.pageData[index].like_cnt--;
          this.pageData[index].is_like = 1;
        } else {
          this.pageData[index].like_cnt++;
          this.pageData[index].is_like = 2;
        }
      })
    },
  },
  onReachBottom() {
    console.log(11111111111111111)
  },
  watch: {
    list: {
      handler(val) {
        if (val.length) {
          this.pageData = val;
        }
      },
      immediate: true
    }
  }
}
</script>

<style lang="scss" scoped>
.commentlist {
  .item {
    margin: $xw-padding-md $xw-padding-sm;
    border-bottom: 1px solid $xw-border-primary-color;
    line-height: 40rpx;
    border-bottom: 1px solid $xw-bg-primary-color;

    .name {
      color: $xw-font-main-color;
      margin-bottom: 16rpx;
    }

    .comment {
      color: $xw-font-main-color;
      font-size: $xw-font-size-sm;
    }

    .time {
      line-height: 60rpx;
      font-size: $xw-font-size-sm;
    }
  }
}
</style>
