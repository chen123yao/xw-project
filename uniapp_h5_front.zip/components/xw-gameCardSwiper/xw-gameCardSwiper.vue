<template>
	<view class="gameCardSwiper" v-if="data">
		<swiper class="swiper" :circular="true">
			<swiper-item class="swiper-item" v-for="(item,index) in data.list" >
				<xw-gameCard :data="item"></xw-gameCard>
			</swiper-item>
		</swiper>
	</view>
</template>

<script>
	export default {
		name: "myGameCardSwiper",
		props: {
			data: {
				type: Object,
				default: null
			}
		}
	}
</script>


<style lang="scss" scoped>
	.gameCardSwiper {
		width: 100%;
		height: 100%;
		
		.swiper {
			width: 100%;
			height: 630rpx;
			
			.swiper-item {
				width: 94%!important;
			}
		}
	}
</style>