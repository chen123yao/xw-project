<template>
	<view class="gameLiVideo">
		<u-row>
			<u-col class="gameLi">
				<u-row :gutter="14">
					<u-col span="2.5" class="game-icon"
						@click="common.routerTo({path: '/pages/views/gameDetail/index', query: {game_id: data.game_id}})">
						<e-image :lazy-load="false" :src="data.icon" width="100%" mode="widthFix" border-radius="20"
							style="margin:0 auto;" class="gameIcon"></e-image>

						<view class="zhekou" v-if="data.rate<1">{{(data.rate*10).toFixed(1)}}</view>
					</u-col>
					<u-col span="7" class="gameDetail"
						@click="common.routerTo({path: '/pages/views/gameDetail/index', query: {game_id: data.game_id}})">
						<h4 class="title text1">{{data.gamename}}
							<!-- <text class="badge" v-if="data.rate && data.rate < 1">{{(data.rate*10).toFixed(1) + '�}}</text> -->
						</h4>
						<view class="types">
							<text class="type" v-for="(v,i) in data.type">{{v}}</text>
							<text class="dian" v-if="platform == 'android'">·</text>
							<text class="type" v-if="platform == 'android'">{{data.size}}</text>
						</view>
						<view class="tags">
							<view v-if="data.selling_point.length">
								<!-- <text class="tag" :style="{color: colors[i]}" v-for="(v,i) in data.selling_point.split(',')">{{v}}</text> -->
								<view class="tag" v-for="(v,i) in data.selling_point.split(',')" :key="i" v-if="v">
									<text :style="[{color: '#fff'},{backgroundColor: colors[i]}]"
										class="icon_text">{{v}}</text>
								</view>
							</view>
							<text v-else>
								{{data.one_word}}
							</text>
						</view>
					</u-col>
					<u-col span="2.5" class="score">
						<u-image :lazy-load="false" src="@/static/image/icon_score.png" width="24" mode="widthFix">
						</u-image>
						<text class="star_cnt">{{data.star_cnt.toFixed(1)}}</text>
					</u-col>
				</u-row>
			</u-col>
			<u-col class="gameVideo">
				<xw-iframeVideo :iframe_url="iframe_url" :hotImage="data.hot_image" :refId="refId"
					:imageShow="imageShow" :videoPlayShow="videoPlayShow" v-if="videoPlay" @iframeClick="iframeClick">
				</xw-iframeVideo>
			</u-col>
		</u-row>
	</view>
</template>


<script>
	import {
		tagTypes,
		colors
	} from "@/common/js/mixin.js";

	export default {
		name: "myGameLiVideo",
		mixins: [tagTypes, colors],
		props: {
			data: {
				type: Object,
				default: null
			},
			state: {
				type: String,
				default: ""
			},
			refId: String,
			videoPlay: Boolean,
			videoPlayShow: Boolean
		},
		data() {
			return {
				iframe_url: "",
				imageShow: true,
			}
		},
		methods: {
			iframeClick(game_id) {
				this.$emit('iframeClick', game_id);
			}
		},
		watch: {
			state: {
				handler(val) {
					if (val) {
						let muted = 1;
						if (this.platform == 'ios') {
							muted = 1;
						}
						this.iframe_url = "http://page.4000yx.com/active/gameVideo?video_url=" + encodeURIComponent(this
								.data.mp4_url) +
							"&muted=" + false + "&state=" + val + "&hot_image=" + encodeURIComponent(this.data.hot_image);
						if (val == "play") {
							this.imageShow = false;
						} else {
							this.imageShow = true;
						}
					}
				},
				immediate: true,
				deep: true
			}
		}
	}
</script>

<style lang="scss" scoped>
	.gameLiVideo {
		height: 250px;
		padding-bottom: 6rpx;
		border-bottom: 1px solid #eee;

		.gameLi {
			height: 66px;
			margin-top: 4px;

			.game-icon {
				position: relative;

				.zhekou {
					position: absolute;
					top: 0;
					left: 0;
					color: #fff;
					font-size: 20rpx;
					background: #e1251b;
					padding: 4rpx 10rpx;
					border-top-left-radius: 20rpx;
					border-bottom-right-radius: 20rpx;
				}
			}

			.title,
			.types,
			.tags {
				@include text-overflow(1);
			}

			.title {
				width: 100%;
				position: relative;

				.badge {
					background: url('../../static/image/zhekou.png') center no-repeat;
					-webkit-background-size: contain;
					background-size: contain;
					font-size: 24rpx;
					font-weight: 400;
					color: #fff;
					padding: 6rpx 10rpx 6rpx 15rpx;
					margin-left: 10rpx;
				}
			}

			.types {
				width: 99%;
				height: 40rpx;
				line-height: 40rpx;
				color: $xw-font-auxiliary-color;
				font-size: 20rpx;

				.type {
					margin-right: 10rpx;
				}

				.dian {
					margin: 0 6rpx;
				}
			}

			.tags {
				// width: 100%;
				display: flex;
				align-items: center;
				justify-content: space-between;
				overflow: hidden;
				text-wrap: none;
				// @include bbox-overflow;
				height: 34rpx;
				line-height: 34rpx;

				.tag {
					display: inline-block;
					font-size: 20rpx;

					.icon_text {
						margin: 0 10rpx 0 6rpx;
						padding: 0 4rpx;
						border-radius: 10rpx;
					}
				}


			}

			.score {
				display: flex;
				align-items: center;
				color: #ff8500;

				.star_cnt {
					margin-left: 10rpx;
				}
			}
		}

		.gameVideo {
			width: 90%;
			height: 200px;
			border-radius: 30rpx;
			margin: 10rpx auto;
			position: relative;
		}
	}
</style>
