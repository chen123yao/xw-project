<template>
	<view class="switch" @click="changeSwitch">
		<view id="game" :class="{left: true, active: active == 0}">手游</view>
		<view id="h5" :class="{right: true, active: active == 1}">H5</view>
	</view>
	<!-- <u-tabs :list="list" :is-scroll="false" bg-color= "#FF8500" inactive-color="#fff" active-color="#fff" :current="current" @change="changeSwitch" ></u-tabs> -->
	
</template>

<script>
	export default {
		name: "mySwitch",
		data(){
			return {
				active: 0,
				// list: [{
				// 					name: '手游'
				// 				}, {
				// 					name: 'H5'
				// 				}],
			}
		},
		methods: {
			changeSwitch(event){
				if(event.target.id == 'h5'){
					this.active = 1;
				}else {
					this.active = 0;
				}
				this.$emit("change", this.active);
			}
		}
	}
</script>

<style lang="scss" scoped>
	.switch {
		width: 240rpx;
		height: 60rpx;
		line-height: 60rpx;
		color: #000;
		background: #fff;
		border-radius: 40rpx;
		margin: 0 auto;
		display: flex;
		justify-content: space-around;
		align-items: center;
		
		.left {
			flex: 1;
		}
		
		.right {
			flex: 1;
		}
		
		.active {
			height: 100%;
			color: #fff;
			background: #eb4d4b;
			border-radius: 40rpx;
			// transition: 0.5s;
		}
	}
</style>
