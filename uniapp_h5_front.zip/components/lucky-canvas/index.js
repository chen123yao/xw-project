module.exports = require('./dist/lucky-canvas.cjs.min.js')
