<template>
	<view class="gameVerticalCard" :style="cardStyle" v-if="data" @click="common.routerTo({path: '/pages/views/gameDetail/index', query: {game_id: data.game_id}})">
		<view class="time">
			{{data.popularity_cnt}}在玩
		</view>
		<view class="game">
			<view class="gamename">{{data.gamename}}</view>
			<view class="types">
				<text class="type" v-for="(v,i) in data.type" :key="i">{{v}}</text>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: "myGameVerticalCard",
		props: {
			data: {
				type: Object,
				default: null
			}
		},
		data() {
			return {
				cardStyle: {
					background: "",
					backgroundSize: "100% 100%"
				}
			}
		},
		watch: {
			data: {
				handler(val) {
					if (val) {
						this.cardStyle.background = "url( " + val.home_img_style1 + ") no-repeat";
					}
				},
				immediate: true
			}
		}
	}
</script>

<style lang="scss" scoped>
	.gameVerticalCard {
		width: 100%;
		height: 400rpx;
		border-radius: 20rpx;
		box-shadow: 0px 40px 15px 0px rgba(0, 0, 0, 0.7) inset, 0px -40px 15px 0px rgba(0, 0, 0, 0.7) inset;
		color: #fff;
		display: flex;
		flex-direction: column;
		justify-content: space-between;

		.time {
			padding: 10rpx 20rpx;
			text-align: right;
		}

		.game {
			padding: 0 10rpx 10rpx;
			text-align: left;
			margin: 0 0 10rpx 10rpx;
			
			.types,
			.gamename {
				@include text-overflow(1);
				font-weight: 600;
			}

			.types {
				font-size: 24rpx;
				color: $xw-font-light-color;
				margin-top:10rpx;

				.type {
					
					font-weight: 300;
					font-size: 18rpx;
				}
			}
		}
	}
</style>
