<!-- 开服卡片组件 -->
<template>
	<view class="serviceLi" v-if="data" @click="common.routerTo({path: '/pages/views/gameDetail/index', query: {game_id: data.game_id}})">
		<view class="gameDetail">
			<image :src="data.icon" class="image"></image>
			<view class="gamename">{{data.gamename}}</view>
		</view>
		<view class="serviceDetail">
			<view class="ser_name">{{data.ser_name}}</view>
			<view class="time">{{data.start_time | dateFormat('hh:mm')}}</view>
		</view>
	</view>
</template>

<script>
	export default {
		props: {
			data: {
				type: Object,
				default: null
			}
		}
	}
</script>

<style lang="scss" scoped>
	.serviceLi {
		width: 100%;
		height: 70%;
		margin-top: 80rpx;
		box-shadow: 0 2px 4px rgba(0, 0, 0, .12), 0 0 6px rgba(0, 0, 0, .04);
		border-radius: 0rpx;
		border-bottom-right-radius: 40rpx;
		border-bottom-left-radius: 10rpx;
		
	
		display: flex;
		flex-direction: column;

		.gameDetail {
			position: relative;
			flex: 2;
			display: flex;
			flex-direction: column;
			justify-content: space-around;
			align-items: center;
			padding-top: 10rpx;

			.image {
				position: absolute;
				top: -45px;
				width: 140rpx;
				height: 140rpx;
				border-radius: 30%;

			}

			.gamename {
				@include text-overflow(1);
				font-size: 24rpx;
				margin-top: 40rpx;
				font-weight: 300;

			}
		}

		.serviceDetail {
			flex: 2;
			background: #FE7879;

			color: #fff;
			border-radius: 20rpx;
			border-bottom-right-radius: 40rpx;
			border-top-left-radius: 40rpx;
			border-top-right-radius: 10rpx;
			border-bottom-left-radius: 10rpx;
			display: flex;
			flex-direction: column;
			justify-content: space-around;
			align-items: center;
			padding: 10rpx 0;
			.ser_name{
				font-weight: 300;
			}

			.time {
				font-size: 24rpx;
			}
		}
		
	}
</style>
