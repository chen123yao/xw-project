<template>
	<view class="iframeVideo" @click="iframeClick(refId)">		
		<view class="box" v-if="imageShow">
			<image src="../../static/image/play.png" class="box-image"></image>
		</view>
		<image :src="hotImage" class="box-image1" v-if="imageShow"></image>
		
		<iframe :src="iframe_url" frameborder="0" class="video" :ref="refId" :id="refId" v-if="videoPlayShow"></iframe>
		
	</view>
</template>

<script>
	// iframe_url: http://page.hnyfqj.cn/active/gameVideo
	//             video_url: encodeURIComponent(this.data.mp4_url)      视频地址
	//             state: play || pause  播放还是暂停（默认为播放）
	//             hot_image: encodeURIComponent(this.data.hot_image)    封面图片
	//             muted: 0 || 1    是否静音（0为播放，1为静音，默认为1）
	export default {
		props: {
			iframe_url: String,
			refId: String,
			imageShow: Boolean,
			hotImage: String,
			videoPlayShow: Boolean
		},
		methods: {
			iframeClick(refId){
				let game_id = refId.substring(refId.length-4, refId.length);
				this.$emit('iframeClick', game_id)
			}
		}
	}
</script>

<style lang="scss" scoped>
	.iframeVideo {
		width: 100%;
		height: 164px;
		position: relative;
		background: #000;
		border-radius: 30rpx;
		
		.video {
			width: 100%;
			height: 164px;
			border-radius: 30rpx;
		}
		
		.box {
			position: absolute;
			top: 0;
			left: 0;
			right: 0;
			bottom: 0;
			z-index: 20;
			background: rgba(0, 0, 0, .8);
			display: flex;
			justify-content: center;
			align-items: center;
			border-radius: 30rpx;
		
			.box-image {
				width: 100rpx;
				height: 100rpx;
			}
		}
		
		.box-image1 {
			position: absolute;
			top: 0;
			left: 0;
			right: 0;
			bottom: 0;
			z-index: 18;
			border-radius: 30rpx;
		}
	}
</style>
