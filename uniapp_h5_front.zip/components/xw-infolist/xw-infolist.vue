<!-- 资讯列表组件 -->
<template>
	<view v-if="list">
		<u-row class="item" v-for="(item,index) in list.list" :key="index">
			<u-col span="5" class="image" :class="{'even': index%2==0}" @click.native="common.routerTo({ path: '/pages/views/infoDetail/index', query: { news_id: item.news_id}})">
				<u-image :src="item.img" width="100%" height="200rpx"></u-image>
			</u-col>
			<u-col span="7" class="content" @click.native="common.routerTo({ path: '/pages/views/infoDetail/index', query: { news_id: item.news_id}})">
				<view class="h2">{{item.title}}</view>
				<view class="desc">{{item.excerpt}}</view>
				<view class="time">
					<u-icon name="eye-fill" size="32" color="#ff8500"></u-icon>
					<text>{{item.post_hits}}</text>
					<text class="fr">{{item.start_time | dateFormat('yyyy-MM-dd hh:mm')}}</text>
				</view>
			</u-col>
		</u-row>
	</view>
</template>

<script>
	export default {
		name: "myInfolist",
		props: {
			list: {
				type: Object,
				default: []
			}
		},
	}
</script>

<style lang="scss" scoped>
	.item {
		margin: $xw-margin-base 0;
		background: #fff;

		.image {
			position: relative;
			mask: linear-gradient(to left, transparent, #fff);
		}

		.content {
			width: 100%;
			height: 200rpx;
			overflow: hidden;
			
			.h2,
			.desc,
			.time {
				@include text-overflow(1);
			}

			.h2 {
				line-height: 70rpx;
			}

			.desc {
				line-height: 60rpx;
			}

			.time {
				line-height: 70rpx;
				font-size: 24rpx;
				color: #888;
			}
		}

		// 偶数行
		.even {
			order: 2;
			mask: linear-gradient(to right, transparent, #fff);
		}
	}
</style>
