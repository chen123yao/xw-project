<template>
  <view class="gameLiSwiper" v-if="pageData.length">
    <swiper class="swiper" :autoplay="autoplay" :style="{height:swiperHeight}" interval="4000" circular indicator-dots indicator-color="#C0C4CC" next-margin='140rpx' indicator-active-color="#ff8500">
      <swiper-item class="swiper-item" v-for="(item,index) in pageData" :key="index">

        <xw-gameLi v-for="(v,i) in item" :key="i" :isshow="false" :data="v"></xw-gameLi>
      </swiper-item>
    </swiper>
  </view>
</template>

<script>
export default {
  name: "myGameLiSwiper",
  props: {
    data: {
      type: Object,
      default: null
    },
	swiperHeight:{
		type:String,
		default:'520rpx'
	},
    autoplay: Boolean
  },
  data() {
    return {
      pageData: []
    }
  },
  watch: {
    data: {
      handler(val) {
        if (val) {

          let arr = [],
            i = 0;
          val.game_list.forEach((item, index) => {

            if (index % 3 === 0) {
              i++;
              arr = [];
            }
            arr.push(item);
            this.pageData[i] = arr
          })
          this.pageData.shift()
        }
      },
      immediate: true
    }
  }
}
</script>

<style lang="scss" scoped>
.gameLiSwiper {
  width: 100%;
  height: 100%;

  .swiper {
    width: 100%;
    .swiper-item {
      width: 90% !important;
      margin-right: 20rpx;
    }
  }
}
</style>
