<!-- 订单列表 -->
<template>
	<view class="list" v-if="list.length">
		<view class="item" v-for="(item,index) in list" :key="index">
			<view class="h3">订单号：{{item.order_id}}</view>
			<view class="content">
				<slot name="gamename" :data="item"></slot>
				<view>消费金额：{{item.amount}}</view>
				<slot name="ptb" :data="item"></slot>
				<view>状态：
					<text v-if="item.status == 1">待处理</text>
					<text v-if="item.status == 2">成功</text>
					<text v-if="item.status == 3">失败</text>
				</view>
				<view>支付方式：{{item.payway}}</view>
				<view>支付时间：{{item.create_time | dateFormat("yyyy-MM-dd hh:mm")}}</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		props: {
			list: {
				type: Array,
				default: []
			}
		}
	}
</script>

<style lang="scss" scoped>
	.list {
		padding: $xw-padding-base;
		text-align: left;

		.item {

			.h3 {
				padding: $xw-padding-md 0;
				border-bottom: 1px solid $xw-border-success-color;
			}

			.content {
				color: $xw-font-base-color;
				line-height: 60rpx;
			}
		}
	}
</style>
