<template>
  <view class="myGameLi" :class='{borderBottom: borderBottom}' v-if="data">
    <u-row :gutter="14">
      <u-col span="1" class="rank" v-if="rankIndex">
        <!-- <u-image :src="'../../static/image/bw'+rankIndex+'.png'" width="100%" mode="widthFix" v-if="rankIndex<=3"></u-image> -->
        <text style="color:#D0D0D0;font-weight: 300;font-size: 16px;">{{rankIndex+3}}</text>
      </u-col>
      <u-col :span="download ? 2 : 3" @click="common.routerTo({path: '/pages/views/gameDetail/index', query: {game_id: data.game_id}})">
        <u-image :src="data.icon" width="120" height="120" border-radius="20" style="margin:0 auto;" :fade="false" :lazy-load="true"></u-image>
      </u-col>
      <u-col :span="download ? 7 : 9" :class="{gameDetail: true}" @click="common.routerTo({path: '/pages/views/gameDetail/index', query: {game_id: data.game_id}})">
        <view class="title text1">
          <text :style="{maxWidth:data.rate<1?'60%':''}">{{data.gamename}}</text>
          <text class="badge" v-if="badge && data.rate && data.rate < 1">{{(data.rate*10).toFixed(1) + '折'}}</text>
        </view>
        <view class="types">
          <text class="type" v-for="(v,i) in data.type" :key='i' v-if="i<2">{{v}}</text>
          <text class="dian" v-if="platform=='android'&&data.classify==3">|</text>
          <text class="type" v-if="platform=='android'&&data.classify==3">{{data.size}}</text>
          <text class="dian" v-if="data.popularity_cnt">|</text>
          <text class="type" v-if="data.popularity_cnt">{{data.popularity_cnt}}在玩</text>
          <!-- <text class="dian" v-if="data.start_time && data.start_time.length">|</text>
          <text v-if="data.start_time && data.start_time.length">{{getServerTime(data.start_time[0])}}</text> -->
        </view>
        <view class="tags">
          <view v-if="data.selling_point">
            <view class="tagsView" v-for="(v,i) in data.selling_point.split(',')" v-if="i<3" :key="i">
              <text :style="{backgroundColor: colors[i],color:'#fff'}" class="icon_text">{{v}}</text>
            </view>
          </view>
          <text v-else>
            {{data.one_word}}
          </text>
        </view>
      </u-col>
      <u-col span="2" v-if="download">
        <xw-button :item="data"></xw-button>
      </u-col>
    </u-row>
  </view>
</template>


<script>
import {
  tagTypes
} from "@/common/js/mixin.js";

export default {
  name: "myGameLi",
  mixins: [tagTypes],
  data() {
    return {
      colors: [
        "#FF9A30",
        "#F96B6B",
        "#5AC5FD",
        "#a29bfe",
        "#eb4d4b",
      ]
    }
  },
  props: {
    data: {
      type: Object,
      default: null
    },
    badge: {
      type: Boolean,
      default: true
    },
    download: Boolean,
    rankIndex: Number,
    borderBottom: {
      type: Boolean,
      default: true
    },
    isshow: {
      type: Boolean,
      default: true
    }
  },
  methods: {
    getServerTime(time) {
      time = this.common.dateFormat(time, 'yyyy-MM-dd hh:mm');

      let date = new Date();
      let year = date.getFullYear(),
        month = date.getMonth() + 1,
        day = date.getDate(),
        str = year + "-" + month + "-" + day
      // 如果是今天，则今天替换日期，否则直接返回日期
      if (str == time.substring(0, 10)) {
        return '今日' + time.substring(time.length - 5) + "开服"
      } else {
        return time
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.myGameLi {
  width: 100%;
  padding: 10rpx 0;
  box-sizing: border-box;
  &.borderBottom {
    // border-bottom:1px transparent solid;
    // border-image:linear-gradient(to left,yellow,pink) 1 10;
    padding: 20rpx 0 !important;
    border-bottom: 1px solid #eee;
  }

  .rank {
    text-align: center !important;
  }

  .gameDetail {
    height: inherit;
    display: flex;
    flex-direction: column;
    justify-content: space-around !important;
    align-items: flex-start !important;
    overflow: hidden;

    .title,
    .types,
    .tags {
      @include text-overflow(1);

      text {
        font-size: 20rpx;
      }
    }
    .types {
      height: 46rpx !important;
      margin-bottom: 4rpx;
    }
    .title {
      width: 100%;
      position: relative;
      @include uni-flex;
      justify-content: flex-start;

      .badge {
        background: url("../../static/image/zhekou.png") center no-repeat;
        -webkit-background-size: contain;
        background-size: 80%;
        padding: 6rpx 20rpx 6rpx 24rpx;
      }
    }

    .text1 > text:nth-child(1) {
      font-size: 28rpx;
      font-weight: 600;
      @include text-overflow(1);
    }

    .text1 > text:nth-child(2) {
      font-size: 22rpx;
      white-space: nowrap;
      color: #fff;
    }

    .types {
      width: 99%;
      height: 50rpx;
      line-height: 50rpx;
      color: $xw-font-auxiliary-color;
      font-size: 10rpx;

      .type {
        margin-right: 10rpx;
        font-weight: 300;
      }

      .dian {
        margin: 0 6rpx;
      }
    }

    .tags {
      @include color-gradient(right, #4834d4, #eb4d4b);
      width: 100%;
      height: 40rpx;
      // line-height: 40rpx;
      font-size: 28rpx;
      padding-bottom: 10rpx;

      .tagsView {
        display: inline;
        text-align: left;
        margin-right: 6px;
        .icon_text {
          margin: 0 2rpx;
          padding: 2rpx 4rpx;
          border-radius: 10rpx;
        }
      }

      .tag {
        margin-right: 10rpx;
      }
    }
  }
}
</style>
