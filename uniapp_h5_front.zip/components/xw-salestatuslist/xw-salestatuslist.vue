<!-- 出售游戏的状态 -->
<template>
	<view class="list">

		<view v-if="list.length">
			<u-row class="item" v-for="(item,index) in list" :key="index">
				<u-col span="4">
					<u-image :src="image(item)" width="100%" height="200rpx"></u-image>
				</u-col>
				<u-col span="8">
					<u-row class="content">
						<u-col class="h2" @click="common.routerTo({path: '/pages/views/commodityDetail/index', query: {goods_id: item.goods_id}})">{{item.title}}</u-col>
						<u-col class="desc text2" @click="common.routerTo({path: '/pages/views/commodityDetail/index', query: {goods_id: item.goods_id}})">{{item.description}}</u-col>
						<u-col class="price">
							<view class="fl">
								<u-tag :text="item.gamename" type="warning" size="mini" shape="circleRight" />{{item.server_name}}</view>
							<view class="fr">￥{{item.price | keepOne(2)}}</view>
						</u-col>
					</u-row>
				</u-col>
				<u-col class="btn">
					<view class="fl">
						<text v-if="item.status == 1">审核中</text>
						<text v-else-if="item.status == 2">已上架</text>
						<text v-else-if="item.status == 3">已下架</text>
						<text v-else-if="item.status == 4">已出售</text>
						<text v-else-if="item.status == 5">审核不通过</text>
						<text v-else-if="item.status == 6">锁定中</text>
					</view>
					<u-tag class="fr" text="下架" type="warning" shape="circle" @click="handleXiajia(item.goods_id)" v-if="item.status != 4" />
				</u-col>
			</u-row>

			<u-modal v-model="show" :content="content" :mask-close-able="true" confirm-color="#ff8500" :show-cancel-button="true"
			 @confirm="confirmOff"></u-modal>
		</view>

		<xw-nodata v-else>暂无出售记录</xw-nodata>
	</view>
</template>

<script>
	export default {
		props: {
			list: {
				type: Array,
				default: []
			}
		},
		data() {
			return {
				show: false,
				goods_id: 0,
				content: "是否确认下架该商品？"
			}
		},
		methods: {
			// 展示下架弹窗
			handleXiajia(goods_id){
				this.show = true;
				this.goods_id = goods_id;
			},
			// 确认下架
			confirmOff() {
				this.$api({
					url: "account/goods/cancel?goods_id=6",
					method: "GET",
					data: {
						goods_id: this.goods_id
					}
				}).then(res=>{
					this.$emit("updata");
				})
			},
			image(item) {
				return JSON.parse(item.image)[0].split(",")[0]
			}
		},
	}
</script>

<style lang="scss" scoped>
	.list {

		.item {
			padding: $xw-padding-base 0;
			border-top: 10px solid $xw-border-primary-color;

			.content {
				.h2 {
					line-height: 60rpx;
				}

				.desc {
					line-height: 40rpx;
					font-size: $xw-font-size-sm;
					color: $xw-font-base-color;
				}

				.price {
					line-height: 60rpx;
					font-size: $xw-font-size-sm;
					color: $xw-font-base-color;

					.fr {
						font-size: 32rpx;
						font-weight: $xw-font-weight-bold;
						color: $xw-font-success-color;
					}
				}
			}

			.btn {
				margin-top: $xw-margin-md;
				padding-top: $xw-padding-sm !important;
				border-top: 1px solid $xw-border-primary-color;

				.fl {
					color: $xw-font-primary-color;
				}
			}
		}
	}
</style>
