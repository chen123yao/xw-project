<template>
	<view class="myGameCard" >
		
  <swiper class="swiper"  circular autoplay next-margin='60rpx'>
	
	   <swiper-item v-for=" (item,value) in data.game_list" :key='value' >
	
	<view class="gameCard" v-if="data" @click="common.routerTo({path: '/pages/views/gameDetail/index', query: {game_id: item.game_id}})">
		<view class="gameImage">
			<u-image width="100%" :src="item.hot_image"
			 mode="widthFix" border-radius="20" style="margin:0 auto;" v-if="item.hot_image"></u-image>
			 <u-image width="120" height="120" :src="item.image"
			  mode="widthFix" border-radius="20" style="margin:0 auto;" v-else></u-image>
		</view>
		<view class="gameDetail">
			<view class="icon">
				<u-image :src="item.icon" width="120" height="120"
				 mode="widthFix" border-radius="20" class="icon"></u-image>
			</view>
			<view class="detail">
				<view class="title">
					{{item.game_name}}
					 
				</view>
				<view class="label">
			<text v-for="(v,i) in item.type" :key="i" style="font-size: 24rpx;">{{v}}</text><text style="font-size: 24rpx;">{{item.popularity_cnt}}在玩</text>
					<!-- {{item.one_word}} -->
				</view>
			</view>
			<!-- <view class="btn">
				<button class="button" @click="common.routerTo({path: '/pages/views/gameDetail/index', query: {game_id: item.game_id}})">下 载</button>
			</view> -->
		</view>
	</view>
	</swiper-item>
	
	</swiper>
	</view>
</template>

<script>
	export default {
		name: "myGameCard",
		props: {
			data: {
				type: Object,
				default(){
					return {
						height_home:'',
						hieghtS:'',
					}
				}
			}
		},
		// onShow() {
		// 	 uni.getSystemInfo({
		// 		 success:res=> {
		// 		 	this.height_home=res.windowHeight
		// 			let info = uni.createSelectorQuery().select('myGameCard')
		// 		   info.boundingClientRect(data=>{
		// 			   this.hieghtS = data.height
		// 		   }).exec()
		// 		 }
		// 	 })
		// }
	}
</script>

<style lang="scss" scoped>
	.myGameCard{
	  width: 100%;
	  height: 100%;
	}
	.swiper{
     width: 100%;
     padding: 20rpx 0;
     height: 550rpx;
	}
	.gameCard {
		border-radius: 20rpx;
		box-shadow: 0 2px 4px rgba(0, 0, 0, .12), 0 0 6px rgba(0, 0, 0, .04);
		display: flex;
		flex-direction: column;
		margin: 0 20rpx;
		
		.gameImage {
			flex: 1;		
		}

		.gameDetail {
			width: 100%;
			display: flex;
			justify-content: space-between;
			align-items: center;
			padding: 10rpx;

			.icon {
				flex: 1;
				margin-right: 10rpx;
			}

			.detail {
				flex: 3.2;
				text-align: left;
				overflow: hidden;

				.title,
				.label {
					@include text-overflow(1);
					max-width: 400rpx;
					line-height: 50rpx;
					font-weight: 300;
				}

				.title {
					color: $xw-font-black-color;
				}

				.label {
					@include color-gradient(left, #eb4d4b, #f0932b);
					text{
						margin:0 6rpx;
						font-size: 18rpx;
						color:#9A9CA1;
						
					}
				}
			}

			.btn {
				flex: 1;
				
				.button {
					font-size: 24rpx;
					background: #f9ca24;
					border: 1px solide #f9ca24;
					border-radius: 30rpx;
					color: #fff;
				}
			}
		}
	}
	@media screen and (max-width: 520px) {
	    .swiper {
	     height: 610rpx;
	    }
	}
</style>
