<template>
	<view class="timeOpen">
		<view class="timeOpenStar">


			<view class="timeButton">

				<swiper class="swiper" :circular="true">
					<swiper-item class="swiper-item" v-for="(index,value) in date" :key="value">
						<scroll-view scroll-y>
							<xw-button :item='item' @click='click'>{{index.time}}</xw-button>
						</scroll-view>
					</swiper-item>
				</swiper>

			</view>
			<view class="timeSelete">
				<image src="../../static/image/kaifu.png" mode="widthFix" style="width: 15px;margin: 0 12px;"></image><text>00:00</text>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: 'timeOpen',
		props: [],
		data() {
			return {

				type: 'openButton',
				item: {
					classify: 10
				},
				date: [{
						time: '00:00'
					},
					{
						time: '00:10'
					},
					{
						time: '00:20'
					},
					{
						time: '00:30'
					},
					{
						time: '00:40'
					},
					{
						time: '00:50'
					},
					{
						time: '01:00'
					},
				]


			}

		},
		methods: {
			click(val) {
				// console.log(val)
			}
		}

	}
</script>

<style lang="scss" scoped>
	.timeOpenStar {
		display: flex;
		flex-direction: column;
		justify-content: flex-start;
		height: 80px;

		.timeButton {
			height: 40px;
			width: 400px;
		}

		.swiper {
			height: 100%;
			width: 100%;

			.swiper-item {
				width: 20% !important;
				box-sizing: border-box;
				padding: 10rpx;
				overflow: none !important;
			}
		}

		.timeSelete {
			display: flex;
			justify-content: flex-start;
			padding: 5px 0;

			text {
				font-weight: 600;
			}

		}
	}
</style>
