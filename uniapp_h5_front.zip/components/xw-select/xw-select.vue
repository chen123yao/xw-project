<!-- 下拉选择框 -->
<template>
	<view class="select">
		<!-- 显示区域 -->
		<view class="selectInput" @click.stop="isShow = !isShow">
			<u-icon :name="isShow ? 'arrow-up' : 'arrow-down'" size="24" margin-left="20" :label="select.name" label-pos="left"
			 label-color="#fff" label-size="32"></u-icon>
		</view>
		<!-- options -->
		<transition name="slide">
			<view class="options" v-if="isShow">
				<view class="option" v-for="(item,index) in list" :key="index" @click.stop="selectOption(item)" :style="{color: select.id == item.id ? activeColor : inactiveColor}">
					<text class="label">{{item.name}} </text>
					<u-icon name="checkbox-mark" :color="activeColor" size="28" class="icon" v-if="select.id == item.id"></u-icon>
				</view>
			</view>
		</transition>
		<!-- 遮罩层 -->
		<view class="mask" v-if="isShow && closeOnClickMask" @click="isShow = false"></view>
	</view>
</template>

<script>
	export default {
		name: "mySelect",
		props: {
			list: {
				type: Array,
				default: [{
					id: 0,
					name: "请选择"
				}]
			},
			// option选中颜色
			activeColor: {
				type: String,
				default: "#ff8500"
			},
			// option未选中颜色
			inactiveColor: {
				type: String,
				default: "#606266"
			},
			// 点击区域外是否关闭 -- 默认为false
			closeOnClickMask: Boolean
		},
		data() {
			return {
				select: {
					id: this.list[0].id,
					name: this.list[0].name,
				},
				isShow: false
			}
		},
		methods: {
			selectOption(item) {
				this.select = item;
				this.isShow = false;
				
				this.$emit("changeTags", item.id);
			},
			closeOption() {
				this.isShow = false;
			}
		},
		created(){
			this.$emit("changeTags", this.select.id);
		}
	}
</script>

<style lang="scss" scoped>
	.select {
		width: 100%;
		height: 100%;

		// 输入框
		.selectInput {
			width: 100%;
			height: 100%;
		}

		// 选择框
		.options {
			width: 100vw;
			max-width: $max-width;
			color: $xw-font-base-color;
			background: #fff;
			border-bottom-left-radius: 20rpx;
			border-bottom-right-radius: 20rpx;
			box-shadow: 0 2px 4px rgba(0, 0, 0, .12), 0 0 6px rgba(0, 0, 0, .04);
			position: absolute;
			left: 0;
			top: 100%;
			z-index: 101;
			display: flex;
			flex-direction: column;

			.option {
				flex: 1;
				height: 80rpx;
				line-height: 80rpx;
				font-size: 28rpx;
				padding: 0 30rpx;
				text-align: left;
				border-bottom: 1px solid #f2f6fc;
				display: flex;
				justify-content: space-between;

				&:last-child {
					border-bottom: 0;
				}
			}
		}

		// 遮罩层
		.mask {
			width: 100vw;
			height: 100vh;
			position: fixed;
			top: 0;
			left: 0;
			overflow: hidden;
			background: transparent;
			z-index: 100;
		}
	}

	.slide-enter,
	.slide-leave-to {
		opacity: 0;
		transform: translateY(-20px);
	}

	.slide-enter-active,
	.slide-leave-active {
		transition: all 0.5s;
	}
</style>
