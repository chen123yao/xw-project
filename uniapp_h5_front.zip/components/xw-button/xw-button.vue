<!-- 按钮组件：按钮分类 -->
<template>
	<view>
		<!-- 1.安卓下载按钮 -->
		<view v-if="item && item.classify == 3">
			<u-button v-if="disabled" class="btn" size="medium" :plain="false">
				<slot>等待中</slot>
			</u-button>
			<u-button v-else class="btn" size="medium" :plain="false" @click.stop="androidDownload">
				<slot>下 载</slot>
			</u-button>
		</view>
		<!-- 2.IOS下载按钮 -->
		<view v-else-if="item && item.classify == 4">
			<u-button class="btn" size="medium" :plain="false" @click.stop="iosDownload">
				<slot>下 载</slot>
			</u-button>
		</view>
		<!-- 3.开玩按钮 -->
		<view v-else-if="item && item.classify == 5">
			<u-button class="btn" size="medium" :plain="false" @click.stop="h5Play">
				<slot>开 玩</slot>
			</u-button>
		</view>
		<!-- 开服表 -->
		<view v-else-if="item && item.classify ==10">
			<u-button shape="circle" class="openbtn" :type="type" :plain="false" @click='swiperBut'>
				<slot>{{value}}</slot>
			</u-button>
		</view>

		<!-- 分类but-->

		<view v-else-if="item && item.classify ==13">

			<u-button class="cationButton" size="medium" hover-class='none'
				:style="'backgroundColor'+':'+backColor[item.index]" type="success" :plain="false" @click='hadleSort'>
				<slot>{{value}}</slot>
			</u-button>
		</view>
		<!-- 立即安装 -->
		<view v-else-if="item && item.classify ==8">
			<button class="newBtn" size="mini" @click="handleClick">
				<slot>{{value}}</slot>
			</button>
		</view>
		<!-- 立即安装 -->
		<view v-else-if="item && item.classify ==14">
			<u-button class="btn" size="medium" :plain="false" @click="tourl">
				<slot>下 载</slot>
			</u-button>
		</view>
		<!-- 4.普通样式按钮 -->
		<view v-else>
			<button class="btn" size="mini" @click="handleClick">
				<slot>{{value}}</slot>
			</button>
		</view>
	</view>
</template>

<script>
	export default {
		props: {
			item: {
				type: Object,
				default: null
			},
			value: {
				type: String,
				default: ""
			},
			type: {
				type: String,
				default: ''
			},


		},
		computed: {
			link() {
				return location.host;
			},
		},
		data() {
			return {
				downloadTask: null,
				backColor: [
					'#FF5F5A', '#D088D4', '#7BC76F', '#F19B78', '#6F8EDE', '#FCBB23', '#EB7571', '#4CCEDB'
				],
				disabled: false,
				timeOutId: 0
			}

		},
		methods: {
			// 安卓下载
			androidDownload() {
				this.disabled = true;
				console.log('and_url:', this.item.down_url);
				let id = this.item.down_url.split("id=")[1];
				console.log('id:', id);
				if (id) {
					let sign = this.custom.downLoadUrl_sign();
					
					this.$api({
						url: "game/down_apk",
						method: "GET",
						data: {
							format: "json",
							id: id,
							sign: sign
						},
					}).then(res => {
						//
					}).catch((err) => {
						//
					});
					setTimeout(() => {
						this.getPreloadDownUrl(this.item.down_url)
					}, 500)
				} else {
					this.disabled = false;
					// window.open(data.and_url,'_blank')
					// window.open((data.and_url.indexOf('http:') != -1) ? (data.and_url.replace(/http/, "https")) : data.and_url);
					
					let url = (this.item.down_url.indexOf('http:') != -1) ? (this.item.down_url.replace(/http/, "https")) : this.item.down_url;
					console.log('openUrl:', url);
					window.open(url);
				}
					// android 下载鉴权
					// if (this.item.down_url.indexOf('?') != -1) {
					// 	let url = this.item.down_url.split('?');
					// 	url = url[0].slice(url[0].length - 8, url[0].length);
					// 	if (url == 'down_apk') {
					// 		console.log('url中有down_apk字段', this.item.down_url);
					// 		let down_url = this.item.down_url.replace(/down_apk/, "down_apk_new")
					// 		console.log('替换为apk_new:', down_url);
					// 		let sign = this.custom.downLoadUrl_sign();
					// 		console.log('生成签名sign:', sign);
					// 		down_url = down_url + '&sign=' + sign;
					// 		window.open(down_url)
					// 	} else {
					// 		window.open(this.item.down_url)
					// 	}					
					// } else {
					// 	window.open(this.item.down_url)
					// }
			},
			getPreloadDownUrl(downLoad_url) {
				let id = downLoad_url.split("id=")[1];
				let sign = this.custom.downLoadUrl_sign();
	
				console.log('getPreloadDownUrl', downLoad_url, id, sign);
				
				this.$api({
					url: "game/preload_down_apk",
					method: "GET",
					data: {
						format: "json",
						id: id,
						sign: sign
					}
				}).then((res) => {
					if (res.data.code == 200) {
						console.log('分包成功', res)
						window.location.href = res.data.data;
						this.disabled = false;
					} else {
						console.log('分包失败')
						this.timeOutId = setTimeout(() => {
							this.getPreloadDownUrl(downLoad_url)
						}, 3000)
					}
				}).catch((err) => {
					console.log('请求失败')
					this.timeOutId = setTimeout(() => {
						this.getPreloadDownUrl(downLoad_url)
					}, 3000)
				});
			},
			// IOS下载
			iosDownload() {
				window.open(this.item.down_url)
				/* app与 h5有差别 */
				// plus.runtime.openURL(this.item.down_url, (res) => {
				// console.log(res);
				// });
				return;
			},
			// h5开玩
			h5Play() {
				if (this.common.getStorage('mem-username') && this.common.getStorage('mem-password')) {
					this.game_url = this.item.down_url + "&token=" + this.loginInfo.user_token +
						"&link=uniapp_h5&indpt_mem_id=" + this.userInfo.mem_id;
					var newUrl = this.common.aesEncrypt(this.game_url, "aaa");
					let routeData = this.$router.resolve({
						path: "/pages/views/h5Play/index",
						query: {
							game_url: newUrl
						}
					})
					window.open(`http://${this.link}` + routeData.href, "_blank")
				} else {
					this.common.routerTo({
						path: "/pages/views/login/index",

					})
				}

			},
			//分类
			hadleSort() {
				this.common.routerTo({
					path: "/pages/info/index",
					query: {
						cates: this.item.id
					}
				})
				uni.$emit('cates', {
					cates: this.item.id
				})

			},
			swiperBut(val) {
				this.$emit("click", val)

			},
			// 普通按钮点击事件冒泡
			handleClick() {
				this.$emit("click")
			},
			tourl() {
				window.open(this.userFormat.down_app_url);
			}
		},
		onUnload() {
			// 移除监听事件  
			uni.$off('cates');
		},
		beforeDestroy() {
			if (this.timeOutId && this.timeOutId != 0) {
				clearTimeout(this.timeOutId)
			}
		}
	}
</script>

<style lang="scss" scoped>
	.btn {
		width: 100%;
		color: $xw-font-white-color;
		margin-left: -$xw-padding-sm;
		padding: $xw-padding-sm 0 !important;
		background: $xw-bg-btn-color;
		border-radius: 40rpx;

	}

	.openbtn {
		width: 60px;
		height: 30px;
		background: #EFEFEF;
		border: #EFEFEF !important;
	}

	.cationButton {
		padding: $xw-padding-sm 0 !important;
		width: 140rpx;
		margin: 10rpx 6%;

	}

	.newBtn {
		background: $xw-bg-btn-color !important;
		color: #fff;
		border-radius: 40rpx;
		border: none !important;
		margin-left: -50rpx;
		padding: 10rpx 20rpx;
	}

	@media screen and (min-width: 600px) {
		.newBtn {
			margin-left: -20rpx !important;
			padding: 10rpx 28rpx;

		}

		.cationButton {
			margin: 10rpx 54rpx !important;

		}

	}

	/*ipad*/
	@media screen and (min-width:768px) and (max-width: 1025px) {
		.cationButton {
			margin: 10rpx 17rpx !important;

		}
	}
</style>
