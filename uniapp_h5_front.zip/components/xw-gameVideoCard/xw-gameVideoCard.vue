<template>
	<view class="myGameVideoCard" v-if="data" @click="common.routerTo({path: '/pages/views/gameDetail/index', query: {game_id: data.gamedetail.game_id}})">
		<view class="gameVideo">
			<!-- <iframe :src="'http://page.hnyfqj.cn/active/gameVideo?video_url=' + encodeURIComponent(data.mp4_url) + '&state=play&muted=1&hot_image=' + encodeURIComponent(data.gamedetail.hot_image)" frameborder="0" class="video" :ref="'iframe_'+data.gamedetail.game_id" :id="'iframe_'+data.gamedetail.game_id"></iframe> -->
			<u-image :src="data.image" width="120" height="120" mode="widthFix" class="image" border-radius="20"></u-image>
		</view>
		<view class="gameDetail">
			<u-cell-group :border="false">
				<u-cell-item :center="true" :arrow="false">
					<u-image :src="data.icon" width="120" height="120"
					 mode="widthFix" slot="icon" border-radius="20" class="icon"></u-image>
					<h2 slot="title" class="title">
						{{data.game_name}}
					</h2>
					<view slot="label" class="label">
						<u-tag :text="v" mode="dark" size="mini" :type="tagTypes[i]" style="margin-right:10rpx;" v-for="(v,i) in data.type" :key="i"/>
						<u-tag :text="data.user_cnt + '人'" mode="dark" size="mini" type="primary" style="margin-right:10rpx;" />
					</view>
				</u-cell-item>
			</u-cell-group>
		</view>
	</view>
</template>

<script>
	import { tagTypes } from "@/common/js/mixin.js";
	
	export default {
		name: "myGameVideoCard",
		props: {
			data: {
				type: Object,
				default: null
			},
		},
		mixins: [tagTypes],
	}
</script>

<style lang="scss" scoped>
	.myGameVideoCard {
		width: 100%;
		border-radius: 20rpx;
		box-shadow: 0 2px 4px rgba(0, 0, 0, .12), 0 0 6px rgba(0, 0, 0, .04);
		display: flex;
		flex-direction: column;

		.gameVideo {
			flex: 1;
			display: flex;
			border-radius: 20rpx;
			
			.video {
				width: 100%;
				height: 164px;
				border-radius: 30rpx;
			}
			
			.image {
				width: 100%;
				min-height: 140rpx;
				border-radius:30rpx;
			}
		}

		.gameDetail {
			flex-basis: 120rpx;

			.icon {
				margin-right: 10rpx;
			}

			.title,
			.label {
				overflow: hidden;
				max-width: 500rpx;
				line-height: 50rpx;
				@include text-overflow(1);
			}

			.title {
				color: $xw-font-black-color;
			}

			.label {
				color: $xw-font-success-color;
			}
		}

	}
</style>
