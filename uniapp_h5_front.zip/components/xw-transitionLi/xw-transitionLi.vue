<!-- 开服卡片组件 -->
<template>
	<view class="serviceLi" v-if="data" @click="common.routerTo({path: '/pages/views/gameDetail/index', query: {game_id: data.game_id}})">
		<image :src="data.icon" class="image"></image>
		<h4 class="gamename">{{data.gamename}}</h4>
		<view class="price">￥200.00</view>
		
		<view class="tag">成交</view>
	</view>
</template>

<script>
	export default {
		props: {
			data: {
				type: Object,
				default: null
			}
		}
	}
</script>

<style lang="scss" scoped>
	.serviceLi {
		width: 100%;
		height: 100%;
		border-radius: 20rpx;
		background: #ecf0f1;
		display: flex;
		flex-direction: column;
		justify-content: space-around;
		align-items: center;
		position: relative;
		
		.tag {
			position: absolute;
			top: 0;
			right: 20rpx;
			z-index: 10;
			width: 80rpx;
			height: 80rpx;
			background: url(../../static/image/tagBg.png) no-repeat;
			-webkit-background-size: contain;
			background-size: contain;
			color: #fff;
			font-size: 24rpx;
		}
		
		.image {
			width: 160rpx;
			height: 160rpx;
		}

		.gamename {
			@include text-overflow(1);
		}
		
		.price {
			color: #ff8500;
			font-weight: 600;
		}
	}
</style>
