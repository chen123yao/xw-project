/*
* 这里存放交易页面路由
*/

const transaction = [
	{
		path: "/pages/transaction/index",
		name: "transaction",
		meta: {
			title: "交易",
			isLogin: false
		}
	},
	// 交易须知
	{
		path: "/pages/transaction/children/buyNumber/children/instruction/index",
		name: "instruction",
		meta: {
			title: "交易须知",
			isLogin: false
		}
	},
	// 选择游戏
	{
		path: "/pages/transaction/children/sellNumber/children/addGame/index",
		name: "addGame",
		meta: {
			title: "选择游戏",
			isLogin: true
		}
	}
]

export default transaction