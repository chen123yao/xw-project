/*
*  这里专门放路由表模块
*  这个index.js将引入同目录下其他js文件并读取，使所有路由整合为一个数组并export导出。 
*  根据不同的页面分类，我们可以在该目录下创建不同的js模块，本js会自动载入
*/
const files = require.context('.', false, /\.js$/)
const modules = []

files.keys().forEach(key => {
  if (key === './index.js') return
  const item = files(key).default
  modules.push(...item)
})

export default modules