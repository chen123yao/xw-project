/*
* 这里存放资讯页面路由
*/

const info = [
	{
		path: "/pages/info/index",
		name: "info",
		meta: {
			title: "游戏",
			isLogin: false
		}
	},
	{
		path: "/pages/info/children/selete/index",
		name: "selete",
		meta: {
			title: "精选",
			isLogin: false
		}
	}
]

export default info