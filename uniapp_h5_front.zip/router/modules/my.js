/*
 * 这里存放我的页面路由
 */

const my = [
	// 我的
	{
		path: "/pages/my/index",
		name: "my",
		meta: {
			title: "我的",
			isLogin: false
		}
	},

	/* 一级子页面 */

	// 设置
	{
		path: "/pages/my/children/mySetting/index",
		name: "mySetting",
		meta: {
			title: "设置",
			isLogin: false
		}
	},
	// 账户管理
	{
		path: "/pages/my/children/myAccount/index",
		name: "myAccount",
		meta: {
			title: "账户管理",
			isLogin: true
		}
	},
	// 我的钱包
	{
		path: "/pages/my/children/myWallet/index",
		name: "myWallet",
		meta: {
			title: "我的钱包",
			isLogin: true
		}
	},
	// 任务中心
	{
		path: "/pages/my/children/myTask/index",
		name: "myTask",
		meta: {
			title: "任务中心",
			isLogin: true
		}
	},
	// 我的积分
	{
		path: "/pages/my/children/myIntegral/index",
		name: "myIntegral",
		meta: {
			title: "我的积分",
			isLogin: true
		}
	},
	// 我的礼包
	{
		path: "/pages/my/children/myGift/index",
		name: "myGift",
		meta: {
			title: "我的礼包",
			isLogin: true
		}
	},
	// 消息中心
	{
		path: "/pages/my/children/myNews/index",
		name: "myNews",
		meta: {
			title: "消息中心",
			isLogin: true
		}
	},
	// 下载管理
	{
		path: "/pages/my/children/myDownload/index",
		name: "myDownload",
		meta: {
			title: "下载管理",
		}
	},
	// 我的游戏
	{
		path: "/pages/my/children/myGame/index",
		name: "myGame",
		meta: {
			title: "我的游戏",
			isLogin: true
		}
	},
	// 客服中心
	{
		path: "/pages/my/children/myService/index",
		name: "myService",
		meta: {
			title: "客服中心"
		}
	},

	/* 二级子页面 */

	// 修改手机号
	{
		path: "/pages/my/children/changeMobile/index",
		name: "changeMobile",
		meta: {
			title: "修改手机号",
			isLogin: true
		}
	},
	// 修改密码
	{
		path: "/pages/my/children/changePassword/index",
		name: "changePassword",
		meta: {
			title: "修改密码",
			isLogin: true
		}
	},
	// 实名认证
	{
		path: "/pages/my/children/changeRealname/index",
		name: "changeRealname",
		meta: {
			title: "实名认证",
			isLogin: true
		}
	},
	// 积分兑换详情
	{
		path: "/pages/my/children/exchangeDetail/index",
		name: "exchangeDetail",
		meta: {
			title: "积分兑换详情",
			isLogin: true
		}
	},
	// 兑换平台币
	{
		path: "/pages/my/children/exchangePlatform/index",
		name: "exchangePlatform",
		meta: {
			title: "兑换平台币",
			isLogin: true
		}
	},
	// 积分记录
	{
		path: "/pages/my/children/integralRecord/index",
		name: "integralRecord",
		meta: {
			title: "积分记录",
			isLogin: true
		}
	},
	// 消息列表
	{
		path: "/pages/my/children/newsList/index",
		name: "newsList",
		meta: {
			title: "消息列表",
			isLogin: true
		}
	},
	// 平台币记录
	{
		path: "/pages/my/children/platformRecord/index",
		name: "platformRecord",
		meta: {
			title: "平台币记录",
			isLogin: true
		}
	},
	// 充值
	{
		path: "/pages/my/children/rechange/index",
		name: "rechange",
		meta: {
			title: "充值",
			isLogin: true
		}
	},
	// 意见反馈
	{
		path: "/pages/my/children/submitFeedback/index",
		name: "submitFeedback",
		meta: {
			title: "意见反馈",
			isLogin: true
		}
	},
	// 活动详情
	{
		path: "/pages/my/children/activeDetail/index",
		name: "activeDetail",
		meta: {
			title: "活动详情",
			isLogin: true
		}
	},
	// 	幸运大转盘
	{
		path: "/pages/my/children/bigTurntable/index",
		name: "bigTurntable",
		meta: {
			title: "",
			isLogin: false
		}
	},
	{
		path : "/pages/my/children/myVip/index",
		name : "myVip",
			meta: {
				title: "",
				isLogin: true
			}
	}
]

export default my
