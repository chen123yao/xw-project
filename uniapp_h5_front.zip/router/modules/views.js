/*
 * 这里存放公用页面路由
 */

const view = [
  // 游戏详情
  {
    path: "/pages/views/gameDetail/index",
    name: "gameDetail",
    meta: {
      title: "游戏详情",
      isLogin: false
    }
  },
  // 礼包详情
  {
    path: "/pages/views/giftDetail/index",
    name: "giftDetail",
    meta: {
      title: "礼包详情",
      isLogin: true
    }
  },
  // 资讯列表
  {
    path: "/pages/views/information/index",
    name: "information",
    meta: {
      title: "资讯列表",
      isLogin: false
    }
  },
  // 资讯详情
  {
    path: "/pages/views/infoDetail/index",
    name: "infoDetail",
    meta: {
      title: "资讯详情",
      isLogin: false
    }
  },
  // 商品详情
  {
    path: "/pages/views/commodityDetail/index",
    name: "commodityDetail",
    meta: {
      title: "商品详情",
      isLogin: true
    }
  },
  // 找回密码
  {
    path: "/pages/views/forgetPwd/index",
    name: "forgetPwd",
    meta: {
      title: "找回密码",
      isLogin: false
    }
  },
  // 登录
  {
    path: "/pages/views/login/index",
    name: "login",
    meta: {
      title: "登录",
      isLogin: false
    }
  },
  // 注册
  {
    path: "/pages/views/register/index",
    name: "register",
    meta: {
      title: "注册",
      isLogin: false
    }
  },
  // 分享注册
  {
    path: "/pages/views/registerShare/index",
    name: "registerShare",
    meta: {
      title: "注册",
      isLogin: false
    }
  },
  // 搜索
  {
    path: "/pages/views/search/index",
    name: "search",
    meta: {
      title: "搜索游戏",
      isLogin: false
    }
  },
  // 支付方式
  {
    path: "/pages/views/payMethods/index",
    name: "payMethods",
    meta: {
      title: "支付方式",
      isLogin: true
    }
  },
  // h5游戏开玩
  {
    path: "/pages/views/h5Play/index",
    name: "h5Play",
    meta: {
      title: "h5游戏开玩",
      isLogin: false
    }
  },
  // 升级和热更页面
  {
    path: "/pages/views/updata/index",
    name: "updata",
    meta: {
      title: "弹窗",
      isLogin: false
    }
  },
  // 首次打开app引导页
  {
    path: "/pages/views/guidePage/index",
    name: "guidePage",
    meta: {
      title: "引导页",
      isLogin: false
    }
  },
  //注册
  {
    path: "/pages/views/share/index",
    name: "share",
    meta: {
      title: "分享注册",
      isLogin: false
    }
  },
]

export default view
