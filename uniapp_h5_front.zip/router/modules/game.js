/*
* 这里存放游戏精选页面路由
*/

const game = [
	// 游戏精选
	{
		path: "/pages/game/index",
		name: "game",
		aliasPath: "/",
		meta: {
			title: "精选",
			isLogin: false
		}
	},
	// 视频
	{
		path: "/pages/game/children/newVideo/index",
		name: "gameVideo",
		meta: {
			title: "游戏视频",
			isLogin: false
		}
	},
	// 新游推荐
	{
		path: "/pages/game/children/gameTopic/index",
		name: "gameTopic",
		meta: {
			title: "游戏专题",
			isLogin: false
		}
	},
]

export default game