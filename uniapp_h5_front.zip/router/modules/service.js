/*
* 这里存放开服页面路由
*/

const service = [
	{
		path: "/pages/service/index",
		name: "service",
		meta: {
			title: "开服",
			isLogin: false
		}
	}
]

export default service