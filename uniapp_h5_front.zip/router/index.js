/*
 * 这里引入并使用uni-simple-router模块
 */

import modules from './modules'
import Vue from 'vue'
import Router from '@/js_sdk/hhyang-uni-simple-router/index.js';
Vue.use(Router)

// 读取token
import Store from '@/store/store.js'

// 初始化
const router = new Router({
	APP: {
		holdTabbar: false //默认是true
	},
	encodeURI: false, //不编码
	routes: [
		...modules,
	] //路由表
});

// 全局路由前置守卫
router.beforeEach((to, from, next) => {
	let token = Store.state.loginInfo.user_token||'';
  console.log(token,'====token');
	// 对于没有登录但需要登录的页面
	if (to.meta && to.meta.isLogin) {
		if (token) {
			next()
		} else {
			next({
				name: "login",
				query: {
					redirect: from.name
				},
				NAVTYPE: 'push'
			})
		}
	} else {
		next()
	}
})

export default router;
