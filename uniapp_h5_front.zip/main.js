import Vue from 'vue'
import App from './App'
import 'progressive-image/dist/index.css'


Vue.config.productionTip = false

App.mpType = 'app'

// uView框架
import uView from "uview-ui";
Vue.use(uView);

// vuex
import store from './store/store.js';
Vue.prototype.$store = store;

// uni-simple-router
import router from './router'
import {
	RouterMount
} from '@/js_sdk/hhyang-uni-simple-router/index.js';

import Meta from 'vue-meta'
Vue.use(Meta)

import MetaInfo from 'vue-meta-info'
Vue.use(MetaInfo)

// http
import api from "@/api/api.js";
Vue.use(api);

// 全局过滤器
import filters from "@/common/js/filters.js";
for (let i in filters) {
	Vue.filter(i, filters[i]);
}

// 全局公用方法
import common from "@/common/js/common.js";
Vue.prototype.common = common;
// 全局定制方法
import custom from "@/common/js/custom.js";
Vue.prototype.custom = custom;

// 渐进式图片
 import progressive from 'progressive-image/dist/vue.js'; // 渐进式
 Vue.use(progressive, {
   	removePreview: true,
   	scale: true
 })

// 全局混入
import {
	myStore
} from "@/common/js/mixin.js";
Vue.mixin(myStore)

const app = new Vue({
	...App,
	store
})

// #ifdef H5
RouterMount(app, '#app');
// #endif

// #ifndef H5
app.$mount(); //为了兼容小程序及app端必须这样写才有效果
// #endif
