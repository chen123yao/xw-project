import {
	myRequest
} from '@/api/request.js';

import Store from "@/store/store.js";
import Common from "@/common/js/common.js"

// 这里存放异步数据请求的方法
export default {
	install(Vue, options) {
		Vue.prototype.$api = myRequest;

		// 获取用户个人信息
		Vue.prototype.getUserInfo = () => {
			myRequest({
				url: "user/detail",
				method: "GET",
			}).then(res => {
				let username = Common.getStorage('mem-username');
				if (res.data.code == 200) {
					// 当记录的用户登录账户与登录之后返回的账户不匹配时，就不允许登录成功
					if (username == res.data.data.mobile || username == res.data.data.username) {
						Store.commit('setUserInfo', res.data.data);
					} else {
						// uni.showToast({
						// 	icon: "none",
						// 	title: '登录过期，重新登录'
						// })
						// Store.commit("setLoginInfo", {})
					}
				} else {
					// uni.showToast({
					// 	icon: "none",
					// 	title: res.data.msg
					// })
					Store.commit("setLoginInfo", {})
					Store.commit('setInit', {});
					Store.commit('setUserInfo', {});
					setStorage('mem-username','')
					setStorage('mem-password','')
				}
			})
		}
	}
}
