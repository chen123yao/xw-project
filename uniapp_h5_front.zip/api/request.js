import Store from "@/store/store.js"

const BASE_URL = Store.state.httpAPI;
export const myRequest = (options) => {
	// 添加默认参数
	let params = {
		client_id: Store.state.client_id,
		app_id: Store.state.platform == 'android' ? 100 : 101, // 手机号 100  101   Store.state.game_id
		equipmentCode: Store.state.equipmentCode, // 手机设备码
		format: 'json',
		ts: Date.parse(new Date()),
		token: Store.state.loginInfo.user_token || Store.state.init.user_token || ''
	}
	options.data = typeof options.data == 'undefined' ? params : Object.assign(options.data, params);
	// 配置请求类型
	let header = options.method == 'GET' ? {
		'X-Requested-With': 'XMLHttpRequest',
		"Accept": "application/json",
		"Content-Type": "application/json; charset=UTF-8"
	} : {
		'X-Requested-With': 'XMLHttpRequest',
		'Content-Type': 'multipart/form-data;'
	}

	Store.commit('setIsLoading', true)

	return new Promise((resolve, reject) => {
		uni.request({
			url: BASE_URL + options.url,
			method: options.method || 'GET',
			data: options.data,
			timeout: 10000,
			dataType: 'json',
			header,
			success: (res) => {
				Store.commit('setIsLoading', false)
				if (res.data.code != 200&& res.data.code != 41103) {
					if (res.data.msg == '登录过期') {
						this.$store.commit('setInit', {});
						this.$store.commit('setLoginInfo', {});
						this.$store.commit('setUserInfo', {});
						this.common.setStorage('mem-username', '')
						this.common.setStorage('mem-password', '')
						uni.request({
							url: "user/logout",
							method: "GET",
						})

					}
					// return uni.showToast({
					// 	icon: "none",
					// 	title: res.data.msg
					// })
				}
				resolve(res)
			},
			fail: (err) => {
				// uni.showToast({
				// 	icon: "none",
				// 	title: '接口请求失败，请检查网络'
				// })
				reject(err)
			}
		})
	})
}
