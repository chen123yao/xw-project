<script>
	export default {
		methods: {
			// 页面初始化
			dataInit(client_id) {
				this.$api({
					url: "system/appinit",
					method: "GET",
					data: {
						client_id,
					},
				}).then((res) => {
					this.$store.commit("setInit", res.data.data);
				});
			},
			// 获取定制信息
			userFormat() {
				// let arr = location.host.split(".").slice(-2)
				// let domain = arr.join(".");
				// domain = 'zzchaoyi.cn';
				let domain = this.common.getDomainName()
				// domain = 'aierx.cn'
				console.log('doamin:', domain)

				let url = "system/h5_front_setup";
				this.$api({
					url,
					method: "GET",
					data: {
						link: domain,
					},
				}).then((res) => {
					// 存储client_id 和 front_setup
					let front_setup = res.data.data.front_setup;
					
					console.log('front_setup', front_setup)
					let client_id;
					if (!isNaN(location.host.split(".")[0])) {
						client_id = location.host.split(".")[0];
						front_setup.down_app_url = front_setup.down_app_url + client_id;
					} else {
						client_id = front_setup.channel_id;
						front_setup.down_app_url =
							front_setup.down_app_url + front_setup.channel_id;
					}
					// 版本 号
					this.$store.commit('setClientId', client_id == 0 ? 4231 : client_id)
					// this.$store.commit("setClientId", 4231);
					this.$store.commit("setUserFormat", front_setup);
					// 数据初始化
					this.dataInit(client_id);

					//判断平台
					this.$store.commit("setPlatform", uni.getSystemInfoSync().platform);
					//本机信息
					this.$store.commit("setSystemInfoSync", uni.getSystemInfoSync());
							
					this.$store.commit('setIsSafari', /Safari/.test(navigator.userAgent) && !/Chrome/.test(navigator.userAgent));
				});
			},
			// 自动登录
			autoLogin() {
				// this.$store.commit("setUserInfo", {});
				let username = this.common.getStorage("mem-username"),
					password = this.common.getStorage("mem-password");
				if (username && password) {
					this.$api({
						url: "user/login",
						method: "GET",
						data: {
							"mem-username": username,
							"mem-password": password,
							equipmentCode: this.equipmentCode,
						},
					}).then((res) => {
						if (res.data.code == 200) {
							// 将登录获取的数据记录下来
							this.$store.commit("setLoginInfo", res.data.data);
							// 获取用户信息
							this.getUserInfo();
						} else {
							this.common.setStorage("mem-username", "");
							this.common.setStorage("mem-password", "");
							this.$store.commit("setInit", {});
							this.$store.commit("setLoginInfo", {});
							this.$store.commit("setUserInfo", {});
						}
					});
				} else {
					// 清空本地存储的登录数据
					this.$store.commit("setInit", {});
					this.$store.commit("setLoginInfo", {});
					this.$store.commit("setUserInfo", {});
					this.common.setStorage("mem-username", "");
					this.common.setStorage("mem-password", "");
				}
			},
		},
		onLoad(option) {
			console.log(option, "optionoptionoption");
		},
		onLaunch: function() {
			// 获取用户定制信息
			this.userFormat();
			// 自动登录
			this.autoLogin();
		},
	};
</script>

<style>
	/* 解决头条小程序组件内引入字体不生效的问题 */
	/* #ifdef MP-TOUTIAO */
	@font-face {
		font-family: uniicons;
		src: url("/static/uni.ttf");
	}

	/* #endif */
</style>

<style lang="scss">
	/* #ifndef APP-PLUS-NVUE */
	@import "uview-ui/index.scss";
	@import "@/common/scss/common.scss";

	/* #endif */
	.titleView {
		font-size: 35rpx;
		font-weight: 600;
	}

	.titleLine {
		height: 50rpx;
		width: 8rpx;
		background-color: #ff8500;
	}
	
	.status_bar {
		width: 100%;
		background: linear-gradient(to bottom, #aaaaaa 0%,#eeeeee 100%);
		position: fixed;
		top: 0;
		z-index: 20;
	}
	
	.uni-tabbar-bottom {
		position: fixed;
		bottom: 0px !important;
		padding-bottom: 0 !important;
		margin-bottom: 0 !important;
		height: 80px;
		z-index: 55;
		
		.uni-tabbar {
			position: fixed;
			bottom: 0px !important;
			padding-bottom: 0 !important;
			margin-bottom: 0 !important;
			height: 80px;
			z-index: 55;
		}
	}
	
	.container {
		// margin-bottom: 5px;
	}
	
	uni-page-wrapper{
		height: 100% !important;
	}
	
	// u-image{
	// 	width: 120rpx !important;
	// }
</style>
