/*
* 这里存放公共数据状态
*/
// 版本环境
export default {
	// api请求头
	// httpAPI: "https://api.aierx.cn/",   // api.aierx.cn
	httpAPI: "https://api.sy12306.com/",   // sy12306.com
	platform: "",
	// 加载
	isLoading: true,
	// 首页顶部大图数组
	images: [],
	// 设备码
	equipmentCode: "",
	// client_id
	client_id: '',
	systemInfoSync: '',
	// game_id
	game_id: 100,
	// 初始化数据
	init: {},
	// 用户定制数据
	userFormat: {},
	// 登录数据
	loginInfo: {},
	// 用户信息
	userInfo: {},
	// 选择小号信息
	selectedGame: {
		game_id: "",
		gamename: ""
	},
	// 首页顶部大图信息
	pageRecommendData: null,

	// 记录下载的游戏状态 game_id  downStatus downStatusText
	gameProgressList: [],
	// 管理所有的下载任务
	downTasks: [],
	isSafari: '',
}