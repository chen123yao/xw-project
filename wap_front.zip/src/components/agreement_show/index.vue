<template>
    <div class="test">
        <div class="test-box" style="transform: translate(-50%, 0%);top:8%;height:80%">
            <div class="test_title"><span>{{agreement_id==1?'隐私政策':agreement_id==3?'第三方信息共享清单':'服务协议'}}</span></div>
            <div style="margin-top:40px;height:90%">
                <!-- <iframe :src="url" frameborder="0" style='width: 100%;position: relative;height:100%'></iframe> -->
                <v-agreement :type="agreement_id" :agent_id="agent_id" style='width: 100%;position: relative;height:100%;overflow-y: scroll;text-align: left;'></v-agreement>
            </div>
        </div>
    </div>
</template>

<script>
import agreement from "../agreement/agreement.vue"


export default {
  props: {
    agreement_id: [String, Number],
    agent_id: [String, Number],
  },
  components:{
    "v-agreement": agreement
  },
  data() {
    return {
      url: ''
    };
  },
  //滚动监听
  mounted() {
    this.url = "https://page.4000yx.com/active/agreement?agent_id=" + this.agent_id + "&type=" + this.agreement_id;
    console.log('agent_id:', this.agent_id, 'agreement_id:', this.agreement_id, 'url:', this.url)
  },
};
</script>

<style lang='less' scoped>
.agreement{
  width: 100%;
  height: 100%;
 /deep/p{
    font-size: 14px !important;
  }
  /deep/ul{
    font-size: 14px !important;
  }
}

.test {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.9);
  z-index: 999;
  .test-box {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 65%;
    height: 15%;
    background-color: #fff;
    border-radius: 0.350877rem;
    font-size: 0.280702rem;
    padding: 0.350877rem;
    text-align: center;
  }
}

.test_title {
  width: 100%;
  display: flex;
  justify-content: space-between;
}
</style>
