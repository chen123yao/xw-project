<template>
  <!-- 盒子下载单页面 -->
  <div class="download">
    <v-weixin></v-weixin>
    <div class="main" v-if="image_links.length">
      <div style="position: relative;" v-for="(item, index) in image_links" :key="index">
        <img :src="item" />
        <img :src="img" class="img" v-if="index==2">
      </div>
      <!-- <img :src="item" alt v-for="(item, index) in image_links" :key="index" /> -->
      <div class="down" @click="handleDown"></div>

      <p class="copyright">{{ this.copyright }}</p>
    </div>
  </div>
</template>


<script>
import weixin from "../gameAndDown/children/weixin";

import axios from "axios";

// 白金版
const images_pro = require.context(
  "@/assets/images_pro",
  false,
  /\.png/
);
export default {
  components: {
    "v-weixin": weixin
  },
  data() {
    return {
      type: 100, // and:100   ios:101
      copyright: "",
      down_url: "",

      image_links: [],
      img: ''
    };
  },
  methods: {
    handleDown() {
      location.href = this.down_url;
    }
  },
  created() {
    let flag = navigator.userAgent.match(
      /(phone|pad|pod|iPhone|iPod|ios|iPad|Android|Mobile|BlackBerry|IEMobile|MQQBrowser|JUC|Fennec|wOSBrowser|BrowserNG|WebOS|Symbian|Windows Phone)/i
    );
    if (flag && flag[0] == "iPhone") {
      this.type = 101;
    } else {
      this.type = 100;
    }
    console.log(this.$route);

  },
  mounted() {
    let imagesArr = images_pro.keys();
    imagesArr = images_pro.keys();
    imagesArr.forEach(fileName => {
      this.image_links.push(
        location.origin + "/" + images_pro(fileName)
      );
    });

    let link;
    let hostnameArr = location.hostname.split(".");
    hostnameArr.shift();
    link = hostnameArr.join(".");
    console.log(link);
    axios({
      url: `https://wap.${this.$common.domain()}/wap/down/proindex`,
      method: "get",
      params: {
        link: link,
        agent_id: 4231,
        format: "json"
      }
    }).then(res => {
      console.log(res, '======res');
      const resuleData = res.data.data;
      this.web_setup = resuleData.web_setup
      this.img = resuleData.er_code
      this.down_url = resuleData.down_url
    })


    this.copyright = "推广APP 致力于为您提供全方位的高品质游戏"

    // if (this.$route.query.id == 1) {
    //   imagesArr = images_jindian.keys();
    //   imagesArr.forEach(fileName => {
    //     this.image_links.push(
    //       location.origin + "/" + images_jindian(fileName)
    //     );
    //   });
    //   this.copyright = "玩手游经典版 致力于为您提供全方位的高品质游戏"
    //   this.down_url = "http://sp.hnyfqj.cn/uni_app_sp/001.apk"
    // } else if (this.$route.query.id == 2) {
    //   imagesArr = images_baijin.keys();
    //   imagesArr.forEach(fileName => {
    //     this.image_links.push(
    //       location.origin + "/" + images_baijin(fileName)
    //     );
    //   });
    //   this.copyright = "玩手游白金版 致力于为您提供全方位的高品质游戏"
    //   this.down_url = "http://sp.hnyfqj.cn/uni_app_sp/002.apk"
    // } else if (this.$route.query.id == 3) {
    //   imagesArr = images_rongyao.keys();
    //   imagesArr.forEach(fileName => {
    //     this.image_links.push(
    //       location.origin + "/" + images_rongyao(fileName)
    //     );
    //   });
    //   this.copyright = "玩手游荣耀版 致力于为您提供全方位的高品质游戏"
    //   this.down_url = "http://sp.hnyfqj.cn/uni_app_sp/003.apk"
    // } else if (this.$route.query.id == 4) {
    //   imagesArr = images_ruyi.keys();
    //   imagesArr.forEach(fileName => {
    //     this.image_links.push(
    //       location.origin + "/" + images_ruyi(fileName)
    //     );
    //   });
    //   this.copyright = "玩手游如意版 致力于为您提供全方位的高品质游戏"
    //   this.down_url = "http://sp.hnyfqj.cn/uni_app_sp/004.apk"
    // }
  },
};
</script>

<style scoped lang="less">
.download {
  margin: 0 auto;
  width: 100vw;
  height: 100%;
  max-width: 750px;
  line-height: 0;
  position: relative;

  .main {
    margin: 0 auto;
    width: 100vw;
    max-width: 750px;
    line-height: 0;
    position: relative;

    img {
      width: 100%;
    }

    .copyright {
      width: 100%;
      height: 10px;
      line-height: 10px;
      position: absolute;
      left: 0;
      bottom: 35px;
      font-size: 16px;
      font-weight: 700;
      color: #ffeae6;
      text-align: center;
    }

    .down {
      position: absolute;
      width: 100%;
      height: 100%;
      top: 0;
    }
  }
  .img {
    position: absolute;
    top: -50%;
    left: 50%;
    transform: translateX(-50%);
    width: 120px !important;
  }

  @media screen and (max-width: 500px) {
    .img {
      position: absolute;
      top: -65%;
      left: 50%;
      transform: translateX(-50%);
      width: 80px !important;
    }
    .main .copyright {
      bottom: 15px;
      font-size: 9px;
    }
  }
}
</style>
