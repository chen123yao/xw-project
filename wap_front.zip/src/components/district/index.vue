<template>
  <div class="district">
    <div class="district-box">
      <div class="d-title">{{gameName}}</div>
      <div class="d-list-title">
        <div>所有服务器</div>
        <!-- <div>选择服务器:
          <select name="全部" v-model="districtActive">
            <option value="0">请选择</option>
            <option value="v.id" v-for="(v,i) in select_data" :key="i">{{v.name}}</option>
          </select>
        </div> -->
      </div>
      <div class="d-list">
        <div v-for="(item,index) in page_data" :key="index" class="list-item" @click="toWebGame(item.servernumber,item.servername)">
          <div>{{item.servername}}</div>
          <div class="d-right">{{item.servertime}}</div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data(){
    return {
      // select_data:[
      //   {
      //     id:0,
      //     name:'全部'
      //   },
      //   {
      //     id:1,
      //     name:'正式服'
      //   }
      // ],
      // districtActive:'全部',
      page_data:{},
      game_id: "",
      client_id: "",
      agent_id: "",
      userToken:'',
      webGameUrl:'',
      gameName:'',
    }
  },
  created(){
    this.getPageData()
    // this.districtActive = this.select_data[0].id
  },
  watch: {
    $route: {
      handler(to, from) {
        this.game_id = to.query.game_id;
        this.client_id = to.query.client_id;
        this.userToken = to.query.userToken;
        this.webGameUrl = to.query.webGameUrl;
        this.webGameUrl = to.query.webGameUrl;
        this.gameName = to.query.gameName;
      },
      immediate: true,
    },
  },
  mounted(){},
  methods:{
    // 原生ajax请求：获取页面数据
    getPageData() {
      // let url = `https://api.${this.$common.domain()}/down/down/game?&client_id=${this.client_id}&format=json&game_id=${this.game_id}`;
      // let url = `https://api.${this.$common.domain()}/down/down/gamedetail?&client_id=${
      //   this.client_id
      // }&format=json&game_id=${this.game_id}`;
      let url = `https://api.sy12306.com/web_game/5144wan/server_lsit?format=json&abc_game_agent_id=${this.client_id}&app_id=${this.game_id}`
      let xhr = new XMLHttpRequest();
      xhr.open("GET", url, true);
      xhr.onreadystatechange = () => {
        // readyState == 4说明请求已完成
        if ((xhr.readyState == 4 && xhr.status == 200) || xhr.status == 304) {
          // 从服务器获得数据
          let res = JSON.parse(xhr.responseText);
          this.page_data = res.data;
          console.log(this.page_data);
        }
      };
      xhr.send();
    },
    toWebGame(id, name) {
      console.log(id, name, this.webGameUrl);
      window.open(
        `${this.webGameUrl}&client_id=${this.client_id}&token=${this.userToken}&is_pc_box=1&sid=${id}&server_name=${name}`,
        "_blank"
      );
    },
  },
}
</script>

<style scoped lang='less'>
.district {
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  background: url('~@/assets/districtBg.png') no-repeat center center;
  // background-size: cover;
  .district-box {
    width: 1026px;
    height: 568px;
    background: #12110F;
    border-radius: 8px;
    margin: 0 auto;
    font-family: Alibaba PuHuiTi;
    .d-title {
      padding-left: 123px;
      height: 65px;
      line-height: 65px;
      color: #c91203;
      font-size: 36px;
      font-family: Alibaba PuHuiTi;
      font-weight: 500;
      font-style: italic;
      background: url('~@/assets/district1.png') no-repeat center left;
    }
    .d-list-title {
      height: 21px;
      padding-left: 70px;
      margin-top: 50px;
      font-size: 22px;
      font-weight: 400;
      color: #F7F7F7;
    }
    .d-list {
      height: 320px;
      // width: 886px;
      margin-top: 50px;
      padding: 0 60px;
      display: flex;
      align-items: center;
      flex-wrap: wrap;
      overflow-y: scroll;
      box-sizing: border-box;
      &::-webkit-scrollbar {
        position: absolute;
        left: 10px;
        top: 0;
        margin-left: 20px;
        width: 5px; 
        height: 1px;
      }
      &::-webkit-scrollbar-thumb {
        border-radius: 10px;
        box-shadow: inset 0 0 5px rgba(211, 24, 3, 0.6);
        background: rgba(211, 24, 3, 0.6);
      }
      &::-webkit-scrollbar-track {
        border-radius: 10px;
        background: #ededed;
      }

      .list-item {
        width: 270px;
        height: 40px;
        padding: 12px;
        margin-right: 37px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        font-size: 14px;
        font-family: Alibaba PuHuiTi;
        font-weight: 400;
        color: #558BAF;
        box-sizing: border-box;
        &:nth-child(3n){
          margin-right: 0;
        }
        .d-right {
          color: #D31803;
        }
      }
    }
  }
}
</style>