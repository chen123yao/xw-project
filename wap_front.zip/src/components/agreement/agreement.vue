<template>
    <div class="agreement" v-if="agreement.length">
        <div v-html="agreement[0].content" v-if="type == 1" class="myhtml"></div>
        <div v-html="agreement[1].content" v-else-if="type == 2" class="myhtml"></div>
        <div v-html="agreement[2].content" v-else class="myhtml"></div>
    </div>
</template>
  
<script>
import axios from "axios";
export default {
    data() {
        return {
            agreement: []
        };
    },
    props: {
        type:{
            default: 1
        },
        agent_id: {
            default: 4231
        }
    },
    methods: {
        getagreement() {
            axios({
                url: `https://wap.sy12306.com/wap/down/agreement`,
                method: "get",
                params: {
                    agent_id: this.agent_id,
                    type: 1,
                    format: "json",
                },
            }).then(res => {
                if (res.data.code == 200) {
                    this.agreement = res.data.data
                }
            })
        },
    },
    created() {
        this.getagreement()
    }
};
</script>
  
<style lang='less' scoped>
.agreement {
    width: 100%;
    height: 100%;
    /deep/p , /deep/ul{
        font-size: 14px !important;
        margin: 14px 0;
        color: #000;
        line-height: 1.15;
        -webkit-text-size-adjust: 100%;
    }

}

.myhtml {
    width: 94%;
    margin: 0 auto;
}
</style>