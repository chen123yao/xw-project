<template>
    <v-agreement :type="type" :agent_id="agent_id"></v-agreement>
</template>

<script>
import agreement from "./agreement.vue"
export default {
  data() {
    return {
      type: 1,
      agent_id: 4231,
      agreement:[]
    };
  },
  components:{
    "v-agreement": agreement
  },
  watch: {
    $route: {
      handler(to, from) {
        console.log(to, from,'to, from')
        // muted参数为0时静音，为1时播放声音
        if (to.query) {
          this.type = to.query.type || 1;
          this.agent_id = to.query.agent_id || 4231;
        }
      },
      immediate: true,
    },
  },
};
</script>

<style lang='less' scoped>
.agreement{
  width: 100%;
  height: 100%;
 /deep/p{
    font-size: 14px !important;
  }
  /deep/ul{
    font-size: 14px !important;
  }
}
.myhtml{
    width: 94%;
    margin: 0 auto;
}
</style>