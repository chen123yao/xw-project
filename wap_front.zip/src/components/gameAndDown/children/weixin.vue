<template>
  <!-- 微信引导页 -->
  <div id="WeChartGuied" v-if="isWeiXin">
    <img :src="require('@/assets/wechart2.png')" alt />
  </div>
</template>

<script>
export default {
  computed: {
    isWeiXin() {
      let flag = navigator.userAgent.toLowerCase().match(/MicroMessenger/i) == "micromessenger" || ( /(iPhone|iPad|iPod|iOS)/i.test(navigator.userAgent) && /\sQQ/i.test(navigator.userAgent)) ||
      ( /(Android)/i.test(navigator.userAgent) && /MQQBrowser/i.test(navigator.userAgent) && /\sQQ/i.test((navigator.userAgent).split('MQQBrowser'))); //后两个判断是否为QQ内置浏览器打开
      return flag;
    }
  }
};
</script>

<style lang="less">
#WeChartGuied {
  width: 100vw;
  height: 100vh;
  position: fixed;
  top: 0;
  left: 0;
  background: rgba(0, 0, 0, 0.8);
  opacity: 0.8;
  z-index: 999999;
  color: #fff;
  overflow: hidden;
  img {
    width: 100%;
  }
}
</style>