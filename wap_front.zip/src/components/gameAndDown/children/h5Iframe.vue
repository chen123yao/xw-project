<!--  -->
<template>
  <div class="contentChild">
    <iframe :src="url" frameborder="0" width="100%" height="100%" id="iframe"></iframe>
  </div>
</template>

<script>
export default {
  data() {
    return {
      url: "",
      isPlay: false,
    };
  },
  computed: {
    agent_id() {
      return this.$store.state.abc_game_agent_id;
    },
    link() {
      return location.host;
    },
  },
  created() {
    if(this.$route.query.iframeTitle) {
      document.title = this.$route.query.iframeTitle
    }
  },
  mounted() {
    if (this.$route.query.url) {
      this.url = this.$route.query.url
      window.addEventListener("message", (e) => {
        setTimeout(() => {
          this.isPlay = true
        }, 100);
        if (this.isPlay) {
          console.log('e.data',e.data);
          let iframe = document.getElementById("iframe");
          iframe.src = this.url + "&token=" + e.data;
        }
      });
    } else {
      this.$router.push("/");
    }
  },
};
</script>
<style scoped lang='less'>
.contentChild {
  width: 100%;
  height: 100%;
  position: absolute;
  overflow: hidden;
  top: 0;
  left: 0;
  z-index: 1000;
  background: #fff;
}
</style>