<template>
  <!-- 盒子下载单页面 -->
  <div>
    <div class="download_bg" :style="{ 'background': 'url(' + require('@/assets/'+(web_setup.hezi_theme==7?'districtBg':'download_bg')+'.png') + ') no-repeat center center', 'background-size': 'cover'}">
    </div>
    <div class="download">
      <v-weixin></v-weixin>
      <div class="main" v-if="image_links.length">
        <div style="position: relative;" v-for="(item, index) in image_links" :key="index">
          <img :src="item" />
          <img :src="img" class="img" v-if="(!web_setup.hezi_theme||web_setup.hezi_theme==2||web_setup.hezi_theme==5)&&index==4 && web_setup.hezi_theme != 6 &&web_setup.hezi_theme != 7">
          <img :src="img" class="img riyao_img" v-if="index==0 && web_setup.hezi_theme == 7">
          <div class="xingyao" v-if="index==0 && web_setup.hezi_theme == 6">
            <h1>{{web_setup.name}}</h1>
            <div class="oneword">好游戏 一起玩</div>
            <img :src="img" class="img1">
            <span>(扫码安装到手机)</span>
            <img src="@/assets/ljaz.png" alt="" class="img2">
          </div>
          <div v-if="index == image_links.length-1 && (web_setup.hezi_theme == 6 || web_setup.hezi_theme == 7)" class="xingyao_copyright">
            <p :style="web_setup.hezi_theme == 7?'color:#000;font-weight:600':''">{{ copyright }}</p>
            <p :style="web_setup.hezi_theme == 7?'color:#000':''" class="copyright_p2">{{ web_setup.footer_wechatCode_txt }}</p>
          </div>
        </div>
        <div class="down" @click="handleDown"></div>
        <p class="copyright" v-if="web_setup.hezi_theme != 6 && web_setup.hezi_theme != 7">{{ copyright }}</p>
        <a :href="admin_friendship_url" style="opacity:0;position:absolute;top:0;left:0;">{{admin_friendship_title}}</a>
      </div>
    </div>
  </div>
</template>


<script>
import weixin from "./weixin";

import axios from "axios";

// 白金版
const images_baijin = require.context(
  "@/assets/images_baijin",
  false,
  /\.png/
);
// 荣耀版
const images_rongyao = require.context(
  "@/assets/images_rongyao",
  false,
  /\.png/
);
// 如意版
const images_ruyi = require.context(
  "@/assets/images_ruyi",
  false,
  /\.png/
);
// 精英版
const images_jingying = require.context(
  "@/assets/images_jingying",
  false,
  /\.png/
);
// 星耀版
const images_xingyao = require.context(
  "@/assets/images_xingyao",
  false,
  /\.png/
);
// 日耀版
const images_riyao = require.context(
  "@/assets/images_riyao",
  false,
  /\.png/
);

export default {
  props: {
    agentId: {
      type: [Number, String],
      default: 0
    }
  },
  components: {
    "v-weixin": weixin
  },
  data() {
    return {
      type: 100, // and:100   ios:101
      copyright: "",
      down_url: "",
      ios_down_url: "",
      isiOS: false,
      image_links: [],
      web_setup: {},
      admin_friendship_url:null,
      admin_friendship_title:''
    };
  },
  methods: {
    handleDown() {
      if(this.isiOS && this.ios_down_url != "" && !isRealGameBox){
        console.log(isRealGameBox,'isRealGameBox');
        window.location.href = this.ios_down_url
        setTimeout(() => {
          window.location.href = "https://static.sy12306.com/upload/mobileconfig/embedded.mobileprovision"
        }, 4000);
        return
      } 
      if (this.down_url != "") {
        if (this.down_url.indexOf('?') != -1) {
          let url = this.down_url.split('?');
          url = url[0].slice(url[0].length - 8,url[0].length);
          console.log('url:', url);
          if (url == 'down_apk') {
            console.log('url中有down_apk字段', this.down_url);
            let down_url = this.down_url.replace(/down_apk/, "down_apk_new")
            console.log('替换为apk_new:', down_url);
            let sign = this.$common.downLoadUrl_sign();
            console.log('生成签名sign:', sign);
            down_url = down_url + '&sign=' + sign;
            console.log('生成url_new:', down_url);
            window.open(down_url);
          } else {
            window.open(this.down_url);
          }
        } else {
          window.open(this.down_url);
        }
      }
    }
  },
  created() {
    let u = navigator.userAgent;
    this.isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端
    let flag = u.match(
      /(phone|pad|pod|iPhone|iPod|ios|iPad|Android|Mobile|BlackBerry|IEMobile|MQQBrowser|JUC|Fennec|wOSBrowser|BrowserNG|WebOS|Symbian|Windows Phone)/i
    );
    if (flag && flag[0] == "iPhone") {
      this.type = 101;
    } else {
      this.type = 100;
    }
    document.title = '盒子下载';
  },
  mounted() {
    let link;
    let hostnameArr = location.hostname.split(".");
    hostnameArr.shift();
    link = hostnameArr.join(".");
    console.log(link);
    console.log(this.agentId);

    axios({
      url: `${this.$common.httpmin()}//wap.${this.$common.domain()}/wap/down/index`,
      method: "get",
      params: {
        link: link,
        agent_id: this.agentId,
        format: "json"
      }
    }).then(res => {
      console.log(res,'ssssssssssssss11111')
      const resuleData = res.data.data;
      this.web_setup = resuleData.web_setup
      if (resuleData) {
        this.down_url = resuleData.down_url;
        this.ios_down_url = resuleData.ios_down_url
        this.copyright = resuleData.web_setup.wap_copyright;
        this.admin_friendship_url = resuleData.admin_friendship_url
        this.admin_friendship_title = res.data.admin_friendship_title
        console.log(this.admin_friendship_url,'admin_friendship_url');
        let link = document.querySelector("link[rel*='icon']") || document.createElement('link');
        link.type = 'image/x-icon';
        link.rel = 'icon';
        link.href = resuleData.web_setup.icon;
        document.getElementsByTagName('head')[0].appendChild(link);
        let imagesArr;

        switch (Number(resuleData.web_setup.hezi_theme)) {
          // 白金版本  
          case 2:
            imagesArr = images_baijin.keys();
            imagesArr.forEach(fileName => {
              this.image_links.push(
                location.origin + "/" + images_baijin(fileName)
              );
            });
            break;
          // 荣耀版本  
          case 3:
            imagesArr = images_rongyao.keys();
            imagesArr.forEach(fileName => {
              this.image_links.push(
                location.origin + "/" + images_rongyao(fileName)
              );
            });
            break;
          // 如意版本
          case 4:
            imagesArr = images_ruyi.keys();
            imagesArr.forEach(fileName => {
              this.image_links.push(
                location.origin + "/" + images_ruyi(fileName)
              );
            });
            break;
              // 精英版
          case 5:
            imagesArr = images_jingying.keys();
            imagesArr.forEach(fileName => {
              this.image_links.push(
                location.origin + "/" + images_jingying(fileName)
              );
            });
            break;
          // 星耀版
          case 6:
            imagesArr = images_xingyao.keys();
            imagesArr.forEach(fileName => {
              this.image_links.push(
                location.origin + "/" + images_xingyao(fileName)
              );
            });
            break;
          // 日耀版
          case 7:
            imagesArr = images_riyao.keys();
            imagesArr.forEach(fileName => {
              this.image_links.push(
                location.origin + "/" + images_riyao(fileName)
              );
            });
            break;
          // 默认：白金版  
          default:
            imagesArr = images_baijin.keys();
            console.log(imagesArr);
            imagesArr.forEach(fileName => {
              this.image_links.push(
                location.origin + "/" + images_baijin(fileName)
              );
            });
            console.log(imagesArr,this.image_links,'2222');
            break;
        }
        console.log(resuleData);
        this.img = resuleData.er_code
      }
    });
  },
};
</script>

<style scoped lang="less">
.download_bg {
  flex: 1;
  position: fixed;
  width: 100%;
  height: 100%;
  img {
    display: block;
    position: absolute;
    left: 0;
  }
}

.download {
  margin: 0 auto;
  width: 100vw;
  height: 100%;
  max-width: 750px;
  line-height: 0;
  position: relative;

  .main {
    margin: 0 auto;
    width: 100vw;
    max-width: 750px;
    line-height: 0;
    position: relative;

    img {
      width: 100%;
    }

    .copyright {
      width: 100%;
      height: 10px;
      line-height: 10px;
      position: absolute;
      left: 0;
      bottom: 35px;
      font-size: 16px;
      font-weight: 700;
      color: #ffeae6;
      text-align: center;
    }

    .down {
      position: absolute;
      width: 100%;
      height: 100%;
      top: 0;
    }
  }
  .img {
    position: absolute;
    top: -50%;
    left: 50%;
    transform: translateX(-50%);
    width: 120px!important;
  }
  .riyao_img {
    top: auto;
    bottom: 16.7%;
    width: 37%!important;
  }

  .xingyao {
    position: absolute;
    left: 0;
    bottom: 10%;
    width: 45%;
    padding: 0 0.2rem;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    font-size: 0.24rem!important;
    color: #fff;
    h1 {
      font-size: 0.4rem!important;
    }
    .oneword {
      margin: 0.3rem auto;
    }
    .img1 {
      width: 1.8rem!important;
    }
    span {
      line-height: 0.5rem;
      font-size: 0.2rem!important;
    }
    .img2 {
      display: block;
      margin: 0 auto;
      max-width: 80%;
    }
  }
  .xingyao_copyright {
    position: absolute;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    font-size: 0.24rem;
    // font-weight: 700;
    color: #ffeae6;
    text-align: center;
    .copyright_p2 {
      font-size: 0.2rem;
    }
  }

  @media screen and (max-width: 500px) {
    .img {
      position: absolute;
      top: -65%;
      left: 50%;
      transform: translateX(-50%);
      width: 80px !important;
    }
    .riyao_img {
      top: auto;
      bottom: 16.7%;
      width: 37%!important;
    }
    .main .copyright {
      bottom: 15px;
      font-size: 9px;
    }
    .xingyao {
      width: 40%;
      bottom: 8%;
    }
  }
}
</style>
