<!--
 * @Author: your name
 * @Date: 2021-01-26 09:57:22
 * @LastEditTime: 2021-04-09 10:17:16
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \wap_front\src\components\gameAndDown\index.vue
-->
<template>
  <div class="gameAndDown">
    <!-- 游戏详情单页面 -->
    <v-agreement
      v-if="agreement_id && agent_id"
      :agreement_id="agreement_id"
      :agent_id="agent_id"
    ></v-agreement>
    <v-gameDetail
      v-else-if="game_id"
      :client_id="client_id"
      :game_id="game_id"
      :flag="flag"
    ></v-gameDetail>
    <!-- 盒子下载单页面 -->
    <v-download :agentId="agent_id" v-else />
  </div>
</template>

<script>
import agreement from "../agreement_show/index.vue";
import download from "./children/download.vue";
import gameDetail from "./children/gameDetail";

export default {
  data() {
    return {
      game_id: "",
      client_id: "",
      agent_id: "",
      agreement_id: "",
      flag: "",
    };
  },
  components: {
    "v-download": download,
    "v-gameDetail": gameDetail,
    "v-agreement": agreement,
  },
  watch: {
    $route: {
      handler(to, from) {
        this.game_id = to.query.game_id;
        this.client_id = to.query.client_id;
        this.agent_id = to.query.agent_id;
        this.flag = to.query.flag;
        console.log(this.flag);
        this.agreement_id = to.query.agreement_id || 0;
        console.log(this.agent_id, "agreement_id:", this.agreement_id);
        // this.game_id = 11826;
        // this.client_id = 99913;
        // this.agent_id = 4231;
        // this.agreement_id = 1;
        // this.flag = 1235;
      },
      immediate: true,
    },
  },
};
</script>
<style scoped lang='less'>
.gameAndDown {
  width: 100%;
  height: 100%;
}
</style>
