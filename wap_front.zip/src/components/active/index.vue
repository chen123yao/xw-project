<!-- 用于统一的路由分发 -->
<template>
  <div class="active">
      <router-view></router-view>
  </div>
</template>

<script>
export default {
  data() {
    return {};
  }
};
</script>
<style scoped lang='less'>
.active {
    width: 100%;
    height: 100%;
}
</style>