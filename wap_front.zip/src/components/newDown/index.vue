<template>
  <!-- 盒子下载单页面 -->
  <div class="download">
    <!-- <v-weixin></v-weixin> -->
    <div class="main" v-if="image_links.length">

      <img :src="item" alt v-for="(item, index) in image_links" :key="index" />
      <div class="down" @click="handleDown"></div>

      <p class="copyright">{{ this.copyright }}</p>
    </div>
  </div>
</template>


<script>
// import weixin from "./weixin";

import axios from "axios";

// 白金版
const images_baijin = require.context(
  "@/assets/images_baijin",
  false,
  /\.png/
);
// 荣耀版
const images_rongyao = require.context(
  "@/assets/images_rongyao",
  false,
  /\.png/
);
// 如意版
const images_ruyi = require.context(
  "@/assets/images_ruyi",
  false,
  /\.png/
);
// 经典版
const images_jindian = require.context(
  "@/assets/images_jindian",
  false,
  /\.png/
);
export default {
  props: {
    agentId: {
      type: [Number, String],
      default: 0
    }
  },
  // components: {
  //   "v-weixin": weixin
  // },
  data() {
    return {
      type: 100, // and:100   ios:101
      copyright: "",
      down_url: "",

      image_links: []
    };
  },
  methods: {
    handleDown() {
      location.href = this.down_url;
    }
  },
  created() {
    let flag = navigator.userAgent.match(
      /(phone|pad|pod|iPhone|iPod|ios|iPad|Android|Mobile|BlackBerry|IEMobile|MQQBrowser|JUC|Fennec|wOSBrowser|BrowserNG|WebOS|Symbian|Windows Phone)/i
    );
    if (flag && flag[0] == "iPhone") {
      this.type = 101;
    } else {
      this.type = 100;
    }
    console.log(this.$route);

  },
  mounted() {
    let imagesArr;
    if (this.$route.query.id == 1) {
      imagesArr = images_jindian.keys();
      imagesArr.forEach(fileName => {
        this.image_links.push(
          location.origin + "/" + images_jindian(fileName)
        );
      });
      this.copyright = "玩手游经典版 致力于为您提供全方位的高品质游戏"
      this.down_url = "http://sp.hnyfqj.cn/uni_app_sp/001.apk"
    } else if (this.$route.query.id == 2) {
      imagesArr = images_baijin.keys();
      imagesArr.forEach(fileName => {
        this.image_links.push(
          location.origin + "/" + images_baijin(fileName)
        );
      });
      this.copyright = "玩手游白金版 致力于为您提供全方位的高品质游戏"
      this.down_url = "http://sp.hnyfqj.cn/uni_app_sp/002.apk"
    } else if (this.$route.query.id == 3) {
      imagesArr = images_rongyao.keys();
      imagesArr.forEach(fileName => {
        this.image_links.push(
          location.origin + "/" + images_rongyao(fileName)
        );
      });
      this.copyright = "玩手游荣耀版 致力于为您提供全方位的高品质游戏"
      this.down_url = "http://sp.hnyfqj.cn/uni_app_sp/003.apk"
    } else if (this.$route.query.id == 4) {
      imagesArr = images_ruyi.keys();
      imagesArr.forEach(fileName => {
        this.image_links.push(
          location.origin + "/" + images_ruyi(fileName)
        );
      });
      this.copyright = "玩手游如意版 致力于为您提供全方位的高品质游戏"
      this.down_url = "http://sp.hnyfqj.cn/uni_app_sp/004.apk"
    }
  },
};
</script>

<style scoped lang="less">
.download {
  margin: 0 auto;
  width: 100vw;
  height: 100%;
  max-width: 750px;
  line-height: 0;
  position: relative;

  .main {
    margin: 0 auto;
    width: 100vw;
    max-width: 750px;
    line-height: 0;
    position: relative;

    img {
      width: 100%;
    }

    .copyright {
      width: 100%;
      height: 10px;
      line-height: 10px;
      position: absolute;
      left: 0;
      bottom: 35px;
      font-size: 16px;
      font-weight: 700;
      color: #ffeae6;
      text-align: center;
    }

    .down {
      position: absolute;
      width: 100%;
      height: 500px;
      top: 0;
    }
  }

  @media screen and (max-width: 500px) {
    .main .copyright {
      bottom: 15px;
      font-size: 9px;
    }
  }
}
</style>
