<!-- 视频播放，配合app做组件 -->
<template>
  <div class="gameVideo">
    <video
      x5-video-player-fullscreen="true"
      x5-playsinline
      playsinline
      webkit-playsinline
      loop
      autoplay
      :muted="muted == 1"
      preload="metadata"
      class="gameVideo"
      id="gameVideo"
      ref="gameVideo"
      :poster="hot_image"
    >
      <source :src="video_url" type="video/mp4" />
    </video>

    <div class="box"></div>
  </div>
</template>

<script src="./jweixin.js"></script>

<script>
// iframe_url: http://page.hnyfqj.cn/active/gameVideo
//             video_url: encodeURIComponent(this.data.mp4_url)      视频地址
//             state: play || pause  播放还是暂停（默认为播放）
//             hot_image: encodeURIComponent(this.data.hot_image)    封面图片
//             muted: 0 || 1    是否静音（0为播放，1为静音，默认为1）

export default {
  data() {
    return {
      video_url: "",
      hot_image: "",
      state: "play",
      muted: 1
    };
  },
  methods: {
    videoPlay() {
      let videoCxt = this.$refs["gameVideo"];
      videoCxt.play();
      document.addEventListener(
        "WeixinJSBridgeReady",
        function() {
          console.log(2222);
          videoCxt.play();
        },
        false
      );
    },
    videoPause() {
      let videoCxt = document.getElementById("gameVideo");
      videoCxt.pause();
    }
  },
  watch: {
    $route: {
      handler(to, from) {
        // muted参数为0时静音，为1时播放声音
        if (to.query.video_url) {
          this.video_url = 'https://4000yx.oss-cn-hangzhou.aliyuncs.com/game_res/g_6335/%E4%BB%99%E7%81%B5%E7%89%A9%E8%AF%AD%EF%BC%88%E6%B8%B8%E6%88%8F%EF%BC%89.mp4'
          // this.hot_image = decodeURIComponent(to.query.hot_image);
          // this.state = to.query.state || "play";
          // this.muted = to.query.muted || 1;
        }

        if (this.state == "play") {
          this.$nextTick(function() {
            this.videoPlay();
          });
        } else if (this.state == "pause") {
          this.$nextTick(function() {
            this.videoPause();
          });
        }
      },
      immediate: true
    }
  }
};
</script>
<style scoped lang='less'>
.gameVideo {
  width: 100%;
  height: 100%;
  background: #000;
  // border-radius: 10px;
  overflow: hidden;

  .box {
    width: 100%;
    height: 100%;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    z-index: 100;
    overflow: hidden;
  }
}
</style>