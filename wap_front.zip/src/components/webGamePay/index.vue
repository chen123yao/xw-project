<template>
  <div class="topup" v-loading="loading" :element-loading-text="loadingtext">
    <div class="topup-title">{{game_name}}-充值中心</div>
    <div class="main">
      <div class="left-table">
        <div class="table-item" :class="{'active':activePayWay=='wx'}" @click="activePayWay='wx'">微信</div>
        <div class="table-item" :class="{'active':activePayWay=='zfb'}" @click="activePayWay='zfb'">支付宝</div>
      </div>
      <div class="right-content">
        <h1 v-if="activePayWay == 'wx'">微信支付</h1>
        <h1 v-if="activePayWay == 'zfb'">支付宝支付</h1>
        <div class="user-name">
          <div class="user-name-right">充值账号:</div>
          {{user_name}}
        </div>
        <div class="item" style="margin-bottom:20px;">
          <div class="item-left">选择游戏区服</div>
          <div class="item-right" style="align-items:center;height:40px;">
            <select v-model="sid">
              <option :value="v.server_id" v-for="(v,i) in serveList" :key="i">{{v.server_name}}</option>
            </select>
            <div style="margin-left:20px;">游戏角色名：<span style="color:#d31803">{{role_name}}</span></div>
          </div>
        </div>
        <div class="item">
          <div class="item-left">充值金额:</div>
          <div class="item-right">
            <div class="amount" :class="{'active':payAmount == v.money}" v-for="(v,i) in amountList" :key="i" @click="changeAmount(v.money)">{{v.name}}</div>
            <div style="width:100%">
              其他金额:&nbsp;&nbsp;<input type="text" @change="payAmount=otherAmount" style="margin-left:10px;padding:0 5px;" v-model.trim.number="otherAmount" placeholder="建议为整数">&nbsp;元
            </div>
          </div>
        </div>
        <div class="item">
          <div class="item-left">付款金额:</div>
          <div class="item-right"><span style="color:#d31803">{{payAmount}}</span>元</div>
        </div>
        <div class="item">
          <div class="item-left">充值获得:</div>
          <div class="item-right">
            <div style="margin-right:10px;">
              <span style="color:#d31803">{{payAmount*recharge}}</span>{{product_name}}
            </div>
            (充值比例:1:{{recharge}})
          </div>
        </div>
        <div class="topup-btn" @click="payGo">
          立即充值
        </div>
      </div>
    </div>
    <!-- 微信充值弹窗 -->
    <transition name="el-zoom-in-top">
      <div v-show="wxBox" class="weixinBox">
        <div class="wxFlexd d-flex">
          <i class="el-icon-circle-close iconPosit" @click="weixinBoxClose"></i>
          <div class="payorder-info">
            <h2>订单提交成功，请尽快付款！</h2>
            <p>订单号：{{order_id}}</p>
            <p>商品名称：{{product_desc}}</p>
            <p>商品描述：{{product_name}}</p>
            <p>交易金额：{{real_amount}}元</p>
          </div>
          <div class="payorder-qrcode">
            <div class="payorder-card">
              <h2 style="font-size:16px;line-height:18px"><span>{{real_amount}}</span>元</h2>
              <div class="payorder-card-img">
                <img class="wxpay-qrcode" :src="$common.erweimaCode(wxUrl)" v-if="wxUrl">
              </div>
              <div class="payorder-card-footer d-flex align-center justify-center">
                <img src="@/assets/topUpCenter/saoyisao.png" alt="">
                <div>
                  <p>请使用微信扫一扫</p>
                  <p>扫描二维码付款</p>
                </div>
              </div>
            </div>
            <div class="payorder-prompt">
              *使用微信付款成功后，将自动跳到结果页
            </div>
          </div>
          <div class="payorder-tips">
            <img src="@/assets/topUpCenter/picture.png" alt="">
          </div>
        </div>
      </div>
    </transition>

    <!-- 微信充值弹窗 -->
    <transition name="el-zoom-in-top">
      <div v-show="topUpAffirm" class="affirm">
        <div class="affirmFlexd">
          <div class="affirmImg"><img src="@/assets/topUpCenter/tishiOk.png" alt=""></div>
          <h2>提示</h2>
          <p>恭喜！ 充值成功</p>
          <div class="affirmBtn" @click="affirmBtn">OK</div>
        </div>
      </div>
    </transition>
  </div>
</template>

<script>
// import axios from "axios";
export default {
  data(){
    return {
      reqNumber:1,
      loading:false,
      loadingtext:'查询角色中',
      game_name:'',
      activePayWay:'wx',
      serveList:[], //区服列表
      user_name:'', //用户名字
      // role_id:'', //角色id
      role_level:'', //角色等级
      server_name:'',//服务器名字
      app_id:'', //游戏id
      uid: "", //游戏里传来的值
      gid: "", //游戏里传来的值
      sid:'', //区服id
      recharge:'10', //充值比例
      payAmount: 10, //支付金额
      otherAmount:'', //输入框金额
      amountList: [
        { money: 10, name: '10元' },
        { money: 20, name: '20元' },
        { money: 50, name: '50元' },
        { money: 100, name: '100元' },
        { money: 200, name: '200元' },
        { money: 500, name: '500元' },
        { money: 1000, name: '1000元' },
        { money: 2000, name: '2000元' },
        { money: 5000, name: '5000元' },
        { money: 10000, name: '10000元' }
      ], 
      wxBox: false, //微信支付
      order_id: '', //订单id
      product_desc: '', //商品描述
      product_name: '', //商品名称
      real_amount: 0, //真实金额
      wxUrl: '', //微信URL
      wxInterval: null, //定时器
      topUpAffirm: false 
    }
  },
  created(){
    this.getPageData()
    // this.getRoleQuery()
    this.getRecharge()
  },
  watch: {
    $route: {
      handler(to, from) {
        this.uid = to.query.uid;
        this.gid = to.query.gid;
        this.sid = to.query.sid;
      },
      immediate: true,
    },
    otherAmount(val){
      if(val>100000){
        val = 100000;
        this.otherAmount = 100000;
      }
      if(val !='') this.otherAmount = val;
    }
  },
  computed:{
    role_name(){ //角色名
      let name = ''
      this.serveList.map((val,index)=>{
        if(val.server_id == this.sid) {
          name =  val.role_name
          this.server_name = val.server_name
          // this.role_id = val.role_id
        }
      })
      return name
    }
  },
  mounted(){
    // console.log(this.$route.query);
  },
  methods:{
    // 原生ajax请求：获取页面数据
    getPageData() {
      this.reqNumber++
      // this.$axios({
      //   method: "get",
      //   url: `https://api.sy12306.com/web_game/5144wan/role_info?format=json`,
      //   params:{
      //     ...this.$route.query
      //   }
      // })
      //   .then(res => {
      //     if(res.data.code == 200) {
      //       if(res.data.data.list[0].role_name == '') {
      //         if(this.reqNumber <= 5) this.getRoleQuery()
      //       }
      //       this.game_name = res.data.data.game_name
      //       this.serveList = res.data.data.list;
      //       // this.role_id = res.data.data.list[0].role_id
      //       this.server_name = res.data.data.list[0].server_name
      //       this.app_id = res.data.data.app_id;
      //       this.user_name = res.data.data.mem_nickname;
      //       console.log(this.serveList,this.sid);
      //     }
      //   })
      //   .catch(err => {
      //     console.log(err);
      //   });
      let url = `https://api.sy12306.com/web_game/5144wan/role_info?format=json&uid=${this.uid}&gid=${this.gid}&sid=${this.sid}`
      // let url = `https://api.sy12306.com/web_game/5144wan/role_info?format=json&uid=217679&gid=9142&sid=`
      let xhr = new XMLHttpRequest();
      xhr.open("GET", url, true);
      xhr.onreadystatechange = () => {
        // readyState == 4说明请求已完成
        if ((xhr.readyState == 4 && xhr.status == 200) || xhr.status == 304) {
          // 从服务器获得数据
          let res = JSON.parse(xhr.responseText);
          if(res.data.list[0].role_name == '') {
            if(this.reqNumber <= 5) this.getRoleQuery()
          }
          this.game_name = res.data.game_name
          this.serveList = res.data.list;
          // this.role_id = res.data.list[0].role_id
          this.server_name = res.data.list[0].server_name
          this.app_id = res.data.app_id;
          this.user_name = res.data.mem_nickname;
          console.log(this.serveList,this.sid);
        }
      };
      xhr.send();
    },
    // 获取充值比例
    getRecharge() {
      let url = `https://api.sy12306.com/game/recharge_list?format=json&gid=${this.gid}`
      // let url = `https://api.sy12306.com/game/recharge_list?format=json&app_id=9142`
      let xhr = new XMLHttpRequest();
      xhr.open("GET", url, true);
      xhr.onreadystatechange = () => {
        // readyState == 4说明请求已完成
        if ((xhr.readyState == 4 && xhr.status == 200) || xhr.status == 304) {
          // 从服务器获得数据
          console.log(res);
          let res = JSON.parse(xhr.responseText);
          if(res.data === null) {
            this.recharge = '10'
            return
          }
          this.recharge = res.data.ratio;
          this.product_name = res.data.product_name
        }
      };
      xhr.send();
    },
    //角色查询接口
    getRoleQuery() {
      if(!this.sid || this.sid==''){
      this.loading = true
      this.loadingtext = '未查询到角色，请联系游戏厂商'
      return
      }
      this.loading = true
      let url = `https://api.sy12306.com/web_game/5144wan/role_query?format=json&mg_mem_id=${this.uid}&cp_app_id=${this.gid}&sid=${this.sid}`
      let xhr = new XMLHttpRequest();
      xhr.open("GET", url, true);
      xhr.onreadystatechange = () => {
        // readyState == 4说明请求已完成
        if ((xhr.readyState == 4 && xhr.status == 200) || xhr.status == 304) {
          // 从服务器获得数据
          this.loading = false;
          this.getPageData()
        }
      };
      xhr.send();
    },
    changeAmount(val){
      this.payAmount = val;
    },
    weixinTopUp(ptb_cnt, payway) {
      return this.$axios({
        method: "get",
        // url: `/secondApi/wap/pay/web_post?format=json&app_id=${this.app_id}&mg_mem_id_sdk=${this.uid}&payway=${payway}&order-product_desc=${this.payAmount}&order-product_name=${this.payAmount}&order-product_price=${this.payAmount}&role-role_id=${this.role_id}&role-role_name=${this.role_name}&role-server_id=${this.sid}&role-server_name=${this.server_name}`,
        url: `https://api.sy12306.com/wap/web_pay/post?format=json&app_id=${this.app_id}&mg_mem_id_sdk=${this.uid}&payway=${payway}&order-product_desc=玩家充值${ptb_cnt}${this.product_name}&order-product_name=${this.product_name}&order-product_price=${ptb_cnt}&role-role_name=${this.role_name}&role-server_id=${this.sid}&role-server_name=${this.server_name}`,
      })
        .then(res => {
          return res.data;
        })
        .catch(err => {
          console.log(err);
        });
    },
    payGo() {
      //js 判断输入的值 是否为整数
      var ex = /^\d+$/;
      if (!ex.test(this.payAmount)) {
        this.$message({
          type: "error",
          message: '订单金额只能为整数',
          duration: 1500
        });
        return false;
      }; 
      //  请求接口成功 如果是微信就展示微信弹窗
      if (this.activePayWay == 'wx') {
        this.weixinTopUp(this.payAmount, 'wxpay').then(res => {
          if (res.code == 200) {
            this.wxBox = true;
            let retusto = res.data;
            this.order_id = retusto.order_id;
            this.product_desc = retusto.product_desc;
            this.product_name = retusto.product_name;
            this.real_amount = retusto.real_amount;
            this.wxUrl = retusto.token;
            let this_ = this;
            this.wxInterval = setInterval(function () {
              this_.wxChrck();
            }, 10000)

            console.log(res);
          } else {
            this.$message({
              type: "error",
              message: res.msg,
              duration: 1500
            });
          }
        });
      } else {
        this.weixinTopUp(this.payAmount, 'alipay').then(res => {
          if (res.code == 200) {
            let formHtml = res.data.token;
            let parser = new DOMParser();
            let doc = parser.parseFromString(formHtml, "text/html");
            // console.log(doc.getElementById('alipaysubmit').innerHTML) // 得到所有的子内容
            let aliurl = doc.getElementById('alipaysubmit').getAttribute("action");
            let divFormInput = doc.getElementsByTagName('input');
            let parameter = '';
            for (let i = 0; i < divFormInput.length; i++) { // 第一个参数不用加上去 
              if (i != 0) {
                parameter += '&' + divFormInput[i].getAttribute("name") + '=' + divFormInput[i].getAttribute("value");
              }
            }
            // window.open(aliurl + parameter);
            window.location.href = aliurl + parameter; // 本窗口打开
            // window.open(`${aliurl}${parameter}`,'_blank'); // 新窗口打开
          } else {
            this.$message({
              type: "error",
              message: res.msg,
              duration: 1500
            });
          }
        });
      }

    },
    weixinCheck(order_id) {
      return this.$axios({
        method: "get",
        url: "https://api.sy12306.com/wap/web_pay/check?order_id=" + order_id + "&format=json&t=" + new Date().getTime(),
      })
        .then(res => {
          return res.data;
        })
        .catch(err => {
          console.log(err);
        });
    },
    wxChrck() {
      this.weixinCheck(this.order_id).then(res => {
        if (res.code == 200) {
          let status = res.data.status;
          if (status == 2) { // 充值成功
            clearInterval(this.wxInterval);
            this.wxInterval = null;
            this.wxBox = false;
            this.topUpAffirm = true;
          }
        } else {
          this.$message({
            type: "error",
            message: res.msg,
            duration: 1500
          });
          clearInterval(this.wxInterval);
          this.wxInterval = null;
        }
      });
    },
    weixinBoxClose() {
      clearInterval(this.wxInterval);
      this.wxInterval = null;
      this.wxBox = false;
    },
    affirmBtn() {
      this.topUpAffirm = false;
      this.$route.query.urlPay = "";
    }
  },
}
</script>

<style scoped lang='less'>
.topup {
  width: 100%;
  height: 100%;
  font-size: 22px;
  background: #f8f8f8;
  .topup-title {
    text-align: center;
    line-height: 75px;
    background-color: #fff;
  }
  .main {
    display: flex;
    // width: 80%;
    height: 100%;
    margin: 20px auto;
    background-color: #fff;
    border: 1px solid #efefef;
    .left-table {
      width: 20%;
      padding-top: 20px;
      text-align: center;
      font-size: 18px;
      border-right: 1px solid #efefef;
      .table-item {
        position: relative;
        line-height: 60px;
        cursor: pointer;
        &.active {
          color: #d31803;
          background-color: #f8f8f8;
          &::before {
            content: "";
            position: absolute;
            left: 0;
            top: 0;
            display: block;
            width: 4px;
            height: 100%;
            background-color: #d31803;
            border-right: 4px;
          }
        }
      }
    }
    .right-content {
      flex: 1;
      padding: 20px 40px;
      h1 {
        margin: 10px 0;
        font-size: 30px;
        color: #d31803;  
      }
      .user-name {
        width: 100%;
        line-height: 60px;
        display: flex;
        margin-bottom: 20px;
        border-bottom: 1px dashed #999;
        .user-name-right {
          width: 150px;
          margin-right: 20px;
          text-align: right;
        }
      }
      .item {
        width: 766px;
        font-size: 16px;
        display: flex;
        align-items: flex-start;
        line-height: 40px;
        .item-left {
          width: 150px;
          margin-right: 20px;
          text-align: right;
        }
        .item-right {
          flex: 1;
          display: flex;
          align-items: flex-start;
          flex-wrap: wrap;
          .amount {
            width: 100px;
            margin: 0 20px 20px 0;
            line-height: 40px;
            text-align: center;
            border: 1px solid #eee;
            cursor: pointer;
            border-radius: 5px;
            &.active {
              border-color: #d31803;
              color: #d31803;
            }
          }
        }
      }
      .topup-btn {
        width: 150px;
        height: 60px;
        margin-top: 30px;
        margin-left: 170px;
        line-height: 60px;
        text-align: center;
        color: #fff;
        border-radius: 10px;
        background-color: #d31803;
      }
    }
  }
  .weixinBox {
    position: fixed;
    width: 100%;
    height: 100%;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.2);
    z-index: 10;
    .wxFlexd {
      width: 975px;
      height: 556px;
      background: #ffffff;
      border-radius: 12px;
      // overflow: hidden;
      position: absolute;
      left: calc(50% - 975px / 2);
      top: calc(50% - 556px / 2);
      box-sizing: border-box;
      padding: 20px 20px 0 73px;

      .iconPosit {
        position: absolute;
        right: -50px;
        top: -36px;
        font-size: 36px;
        color: #fff;
      }

      .payorder-info {
        width: 281px;
        padding-top: 100px;
        h2 {
          line-height: 21px;
          margin-bottom: 10px;
          color: #333333;
          font-size: 16px;
          font-weight: 400;
        }

        p {
          margin-bottom: 10px;
          color: #999999;
          font-size: 12px;
        }
      }

      .payorder-qrcode {
        width: 284px;
        padding-top: 30px;
        box-sizing: border-box;

        .payorder-card {
          padding-bottom: 44px;
          width: 100%;
          box-shadow: 0px 2px 5px 0px rgba(0, 0, 0, 0.2);
          border-radius: 5px;

          h2 {
            padding-top: 11px;
            padding-bottom: 11px;
            text-align: center;
            box-shadow: inset 0px -2px 2px -2px #e6e6e6;
            color: #999999;
            font-weight: 400;

            span {
              color: #ff8500;
              font-size: 20px;
            }
          }

          .payorder-card-img {
            padding: 20px;
            box-sizing: border-box;

            img {
              display: block;
              width: 244px;
              height: 244px;
            }
          }

          .payorder-card-footer {
            box-sizing: border-box;
            padding: 0 0 0 42px;

            img {
              width: 42px;
              float: left;
              margin: 4px 14px 0 0;
            }

            div {
              width: calc(100% - 60px);
              float: left;

              p {
                margin: 0;
                font-size: 18px;
                line-height: 24px;
                color: #000000;
              }
            }
          }
        }

        .payorder-prompt {
          width: 100%;
          text-align: center;
          font-size: 14px;
          color: #999999;
          margin-top: 20px;
        }
      }

      .payorder-tips {
        margin-left: 25px;
      }
    }
  }
  .affirm {
    position: fixed;
    width: 100%;
    height: 100%;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.2);
    z-index: 11;

    .affirmFlexd {
      width: 477px;
      height: 305px;
      background: #ffffff;
      border-radius: 8px;
      // overflow: hidden;
      position: absolute;
      left: calc(50% - 476px / 2);
      top: calc(50% - 460px / 2);
      box-sizing: border-box;
      padding: 20px 80px 0 80px;
      text-align: center;

      .affirmImg {
        width: 90px;
        height: 90px;
        margin: 20px auto;

        img {
          width: 100%;
          height: 100%;
        }
      }

      h2 {
        color: #575757;
        font-size: 32px;
      }

      p {
        height: 60px;
        line-height: 60px;
        color: #bbbbbb;
        font-size: 16px;
      }

      .affirmBtn {
        width: 90px;
        height: 40px;
        line-height: 38px;
        margin: 6px auto;
        background: #ffb462;
        color: #fff;
        font-size: 16px;
        border-radius: 4px;
      }
    }
  }
  .d-flex {
    display: flex;
  }
  .align-center {
    align-items: center;
  }
  .justify-center {
    justify-content: center;
  }
}
input {
  &::-webkit-input-placeholder { /* WebKit, Blink, Edge */
    font-size: 14px;
  }
  &:-moz-placeholder { /* Mozilla Firefox 4 to 18 */
    font-size: 14px;
  }
  &::-moz-placeholder { /* Mozilla Firefox 19+ */
    font-size: 14px;
  }
  &:-ms-input-placeholder { /* Internet Explorer 10-11 */
    font-size: 14px;
  }
}
</style>
<style>
.el-message__icon {
    font-size: 16px!important;
  }
</style>