<template>
  <!-- 游戏推广页 -->
  <div class="gameDetail_box">
    <!-- 左侧背景图 -->
    <div
      v-if="is_this_bg_id(['仙侠'])"
      class="recommend_image"
      :style="{
        background:
          'url(' +
          require('@/assets/images_gameAndDown/chuanqi_L.png') +
          ') no-repeat center center',
        'background-size': 'cover',
      }"
    ></div>
    <div
      v-else-if="is_this_bg_id(['回合', '放置'])"
      class="recommend_image"
      :style="{
        background:
          'url(' +
          require('@/assets/images_gameAndDown/west_L' + picNumber + '.png') +
          ') no-repeat center center',
        'background-size': 'cover',
      }"
    ></div>
    <div
      v-else-if="is_this_bg_id(['卡牌', '回合', '放置'])"
      class="recommend_image"
      :style="{
        background:
          'url(' +
          require('@/assets/images_gameAndDown/east_L' + picNumber + '.png') +
          ') no-repeat center center',
        'background-size': 'cover',
      }"
    ></div>
    <div
      v-else
      class="recommend_image"
      :style="{
        background:
          'url(' +
          require('@/assets/images_gameAndDown/leftTop1.png') +
          ') no-repeat center center',
        'background-size': 'cover',
      }"
    ></div>
    <div v-if="error_show"  class="error"></div>
    <!-- 主体内容 -->
    <div
      v-else
      class="gameDetail"
      :style="page_data.game_list_count < 5 && !isPC ? 'height:100%' : ''"
    >
      <div
        class="game_views"
        @click="openGameDetil(page_data.game_id, front_setup.channel_id)"
      >
        <img
          style="width: 100%"
          :alt="page_data.game_name"
          :src="page_data.image"
        />
        <!-- :src="page_data.image" src="@/assets/images_gameAndDown/cs.jpg"-->
      </div>
      <div class="main">
        <div class="game_views">
          <ul class="game_box_ul">
            <li
              class="game_box_li"
              v-for="(item, index) in page_data.game_list"
              :key="index"
              @click="openGameDetil(item.game_id, front_setup.channel_id)"
            >
              <div class="game_icon">
                <img :src="item.icon" :alt="item.game_name" />
                <!-- 角标 -->
                <!-- <div class="mark" v-if="item.rate < 1 ">{{item.rate * 10}}</div> -->
                <div class="mark" v-if="item.rate < 1">
                  <span>{{ item.rate * 10 }}折</span>
                </div>
              </div>
              <div class="game_desc">
                <div class="game_name">
                  <div v-if="item.double_side">
                    <img class="type_icon" src="@/assets/iosIcon.png" />
                    <img class="type_icon" src="@/assets/androidIcon.png" />
                  </div>
                  <div v-else>
                    <img
                      class="type_icon"
                      v-if="item.classify == 3"
                      src="@/assets/androidIcon.png"
                    />
                    <img
                      class="type_icon"
                      v-else-if="item.classify == 4"
                      src="@/assets/iosIcon.png"
                    />
                    <img
                      class="type_icon"
                      v-else-if="item.classify == 5"
                      src="@/assets/h5Icon.png"
                    />
                  </div>
                  {{ item.game_name }}
                </div>
                <p class="game_tag" v-if="!isPC">
                  <span
                    :class="tag_style[Math.floor(Math.random() * 5)]"
                    v-for="(point, index) in item.selling_point
                      .split(',')
                      .slice(0, 2)"
                    :key="index"
                    >{{ point }}</span
                  >
                </p>
                <p class="game_tag" v-else>
                  <span
                    :class="tag_style[Math.floor(Math.random() * 4)]"
                    v-for="(point, index) in item.selling_point.split(',')"
                    :key="index"
                    >{{ point }}</span
                  >
                </p>
                <p class="game_gtype" v-if="!isPC">
                  <span
                    v-for="(type, index) in item.type.slice(0, 2)"
                    :key="index"
                    >{{ type }}</span
                  >
                  <span class="popularity_cnt"
                    >| 已有<span>{{ item.user_cnt }}</span
                    >人在玩</span
                  >
                </p>
                <p class="game_gtype" v-else>
                  <span v-for="(type, index) in item.type" :key="index">{{
                    type
                  }}</span>
                  <span class="popularity_cnt"
                    >| 已有<span>{{ item.user_cnt }}</span
                    >人在玩</span
                  >
                </p>
              </div>
              <div class="game_discount">
                <p>下载</p>
              </div>
            </li>
          </ul>
        </div>
      </div>
      <!-- 底部 -->
      <div class="company-footer">
        <div class="wechat">
          <img
            :src="front_setup.footer_wechatCode"
            style="width: 0.9rem; vertical-align: middle; border-radius: 0.1rem"
          />
          <span class="company-footer-text">客服中心 QQ交谈</span>
        </div>
        <div class="company-footer-text-box">
          <div class="company-footer-text">
            {{ front_setup.fullName }}
          </div>
          <div class="company-footer-text">
            网站备案号：<a
              :href="front_setup.footer_ICP_url"
              style="color: #c1c1c1"
              target="_blank"
              >{{ front_setup.footer_ICP_txt }}</a
            >
          </div>
          <div class="company-footer-text">
            客服电话：{{ front_setup.footer_mobile }}
            <span style="padding-left: 0.1rem"
              >客服QQ：{{ front_setup.QQ_business }}</span
            >
          </div>
          <div class="company-footer-text">
            《<span class="ageem_text" @click="handleAment(1)">隐私策略</span>》
            &nbsp; 《<span class="ageem_text" @click="handleAment(2)"
              >服务协议</span
            >》 &nbsp; 《<span class="ageem_text" @click="handleAment(3)"
              >应用权限</span
            >》
          </div>
          <a
            :href="admin_friendship_url"
            style="opacity: 0; position: absolute; bottom: 0; left: 0"
            >{{ admin_friendship_title }}</a
          >
        </div>
      </div>

      <!-- 遮罩 -->
      <div class="test" v-show="ismusk">
        <div class="test-box">
          是否前往下载游戏?
          <div class="test-btn">
            <div @click="ismusk = false">取消</div>
            <!-- 移动端、安卓 -->
            <a
              :href="page_data.and_url"
              class="game_btn"
              v-if="!isPC && !isIos && page_data.classify != 5"
              >确认</a
            >
            <!-- 移动端、IOS -->
            <a
              :href="page_data.ios_url"
              class="game_btn"
              v-else-if="
                !isPC && isIos && page_data.classify != 5 && page_data.ios_url
              "
              >确认</a
            >
            <a
              href="javascript:void(0);"
              class="game_btn"
              v-else-if="
                !isPC && isIos && page_data.classify != 5 && !page_data.ios_url
              "
              >确认</a
            >
          </div>
        </div>
      </div>

      <!-- 遮罩1 -->
      <div class="test" v-show="ishow">
        <div
          class="test-box"
          style="transform: translate(-50%, 0%); top: 8%; height: 80%"
        >
          <div class="test_title">
            <span>{{
              content_type == 1
                ? "隐私策略"
                : content_type == 3
                ? "应用权限"
                : "服务协议"
            }}</span
            ><i @click="ishow = false">X</i>
          </div>
          <div
            style="margin-top: 40px; height: 90%;overflow-y: scroll;text-align: left;"
          >
            <v-agreement
              :type="content_type"
              :agent_id="client_id"
            ></v-agreement>
          </div>
        </div>
      </div>
    </div>
    <!-- 右侧背景图 -->
    <div
      v-if="is_this_bg_id(['仙侠'])"
      class="recommend_image"
      :style="{
        background:
          'url(' +
          require('@/assets/images_gameAndDown/chuanqi_R.png') +
          ') no-repeat center center',
        'background-size': 'cover',
      }"
    ></div>
    <div
      v-else-if="is_this_bg_id(['回合', '策略', '养成', '冒险'])"
      class="recommend_image"
      :style="{
        background:
          'url(' +
          require('@/assets/images_gameAndDown/west_L' + picNumber + '.png') +
          ') no-repeat center center',
        'background-size': 'cover',
      }"
    ></div>
    <div
      v-else-if="is_this_bg_id(['国战', '传奇'])"
      class="recommend_image"
      :style="{
        background:
          'url(' +
          require('@/assets/images_gameAndDown/east_R' + picNumber + '.png') +
          ') no-repeat center center',
        'background-size': 'cover',
      }"
    ></div>
    <div
      v-else
      class="recommend_image"
      :style="{
        background:
          'url(' +
          require('@/assets/images_gameAndDown/leftTop2.png') +
          ') no-repeat center center',
        'background-size': 'cover',
      }"
    ></div>
  </div>
</template>

<script>
import weixin from "@/components/gameAndDown/children/weixin.vue";
import axios from "axios";
import agreement from "@/components/agreement/agreement.vue";

export default {
  components: {
    "v-weixin": weixin,
    "v-agreement": agreement,
  },
  data() {
    return {
      page_data: null,
      url: "",
      ishow: false,
      AmentType: 0,
      isPlay: false,
      downIshow: false,
      isPC: false,
      isIos: false,
      fuliData: null,
      fanliData: null,
      ismusk: false,
      gift: null,
      downbtn: true,
      page_comment: null,
      content_type: "",
      bg_type: "",
      admin_friendship_url: null,
      admin_friendship_title: "",
      disabled: false,
      timeOutId: 0,
      client_id: "",
      iframeTitle: "",
      topic_code: "",
      front_setup: {},
      tag_style: [
        "tag_blue",
        "tag_green",
        "tag_orange",
        "tag_cyan",
        "tag_yellow",
      ],
      error_show: false,
    };
  },
  //滚动监听
  mounted() {
    window.addEventListener("scroll", this.handleScroll, true); // 监听滚动事件，然后用handleScroll这个方法进行相应的处理
  },
  destroyed() {
    window.removeEventListener("scroll", this.handleScroll, true);
  },
  computed: {
    type() {
      // console.log(
      //   this.page_data.detaildata.data.selling_point,
      //   "this.page_data"
      // );
      if (typeof this.page_data.detaildata.data.selling_point == "string") {
        return this.page_data.detaildata.data.selling_point.split(",");
      } else {
        return this.page_data.detaildata.data.selling_point;
      }
    },
    erweimaUrl() {
      return window.location.href;
    },
    picNumber() {
      return Math.round(Math.random());
    },
  },
  methods: {
    is_this_bg_id(items) {
      let a = false;
      items.forEach((item, index) => {
        if (this.bg_type[0] == item) {
          a = true;
        }
      });
      return a;
    },
    handleAment(type) {
      (this.ishow = true), (this.content_type = type);
      this.url =
        "https://page.4000yx.com/active/agreement?agent_id=4231" +
        "&type=" +
        type;
    },
    //滚动事件
    handleScroll(e) {
      if (e.target.scrollTop > 250) {
        this.downIshow = true;
      } else {
        this.downIshow = false;
      }
    },
    downwaring() {
      this.ismusk = true;
    },
    // 获取页面数据
    getPageData() {
      // let url = `https://api.${this.$common.domain()}/down/down/game?&client_id=${this.client_id}&format=json&game_id=${this.game_id}`;
      let hostArray = window.location.host.split(".");
      hostArray.shift();
      let domian = hostArray.join(".") || "etuw.cn";
      console.log(domian);
      // let url = `secondApi/game/custom_category?format=json&device_type=page&topic_code=${this.topic_code}&link=${domian}&client_id=${this.client_id}`;
      let url = `https://api.${this.$common.domain()}/game/custom_category?format=json&device_type=page&topic_code=${this.topic_code}&link=${domian}&client_id=${this.client_id}`;
      axios({
        url: url,
        method: "get",
      }).then((res) => {
        if (res.data.code == 200) {
          // 从服务器获得数据
          this.page_data = res.data.data.list[0];
          // console.log(this.page_data);
          this.iframeTitle = document.title = `${this.page_data.topic_name}-${this.page_data.description}`;
          let meta_kws =
            document.querySelector("meta[name*='keywords']") ||
            document.createElement("meta");
          meta_kws.name = "keywords";
          meta_kws.content = `${this.page_data.game_name},${this.page_data.game_name}下载,游戏攻略,游戏礼包,激活码,${this.page_data.topic_name}`;
          document.getElementsByTagName("head")[0].appendChild(meta_kws);
          let meta_desc =
            document.querySelector("meta[name*='description']") ||
            document.createElement("meta");
          meta_desc.name = "description";
          meta_desc.content = `${this.page_data.topic_name}版${this.page_data.game_name}为您提供${this.page_data.game_name}安卓版和iOS苹果版以及H5版最新免费下载,最全的${this.page_data.game_name}游戏攻略,最多的${this.page_data.game_name}游戏福利,玩家在${this.page_data.game_name}不仅享有满减优惠券,首充折扣等福利,同时也享有充值返利福利,礼包激活码等,欢迎来${this.page_data.topic_name}下载${this.page_data.game_name}。`;
          document.getElementsByTagName("head")[0].appendChild(meta_desc);
          let link =
            document.querySelector("link[rel*='icon']") ||
            document.createElement("link");
          console.log("icon", link);
          link.type = "image/x-icon";
          link.rel = "icon";
          link.href = this.front_setup.icon;
          document.getElementsByTagName("head")[0].appendChild(link);
          this.bg_type = res.data.list[0].type;
          this.$nextTick(() => {
            $("#dg-container").carrousel({
              current: 0,
              autoplay: true,
              interval: 3000,
            });
          });
        } else {
          this.error_show = true;
        }
      });
    },
    // h5游戏如有flag修改client_id
    handleClientId() {
      axios({
        url: `${this.$common.httpmin()}//api.${this.$common.domain()}/down/down/getPromotion`,
        method: "get",
        params: {
          client_id: this.client_id,
          format: "json",
          flag: this.flag,
        },
      }).then((res) => {
        this.h5_client_id = res.data.data.agent_id;
        console.log(this.h5_client_id);
      });
    },
    // 判断当前是手机端还是PC端
    judgeEquipment() {
      if (
        /Android|webOS|iPhone|iPod|ipad|BlackBerry/i.test(navigator.userAgent)
      ) {
        console.log("当前处于移动端");
        this.isPC = false;
      } else {
        console.log("当前处于PC");
        this.isPC = true;
      }
    },
    // 判断当前设备为IOS还是android
    judgeIos() {
      let flag = navigator.userAgent.match(
        /(phone|pad|pod|iPhone|iPod|ios|iPad|Android|Mobile|BlackBerry|IEMobile|MQQBrowser|JUC|Fennec|wOSBrowser|BrowserNG|WebOS|Symbian|Windows Phone)/i
      );
      if (flag && (flag[0] == "iPhone" || flag[0] == "iPad")) {
        console.log("当前处于IOS系统");
        this.isIos = true;
      } else {
        this.isIos = false;
      }
    },
    //弹出菜单时body溢出隐藏,关闭菜单时恢复
    toHidden() {
      if (this.ishow | this.ismusk) {
        $("body").css({ overflow: "hidden" });
      } else {
        $("body").css({ overflow: "visible" });
      }
    },
    // 下载处理(鉴权)
    handleDownLoad(downLoad_url) {
      this.disabled = true;
      console.log("and_url:", downLoad_url);
      let id = downLoad_url.split("&id=")[1] || downLoad_url.split("?id=")[1];
      console.log("id:", id);
      if (id) {
        let sign = this.$common.downLoadUrl_sign();
        axios({
          url: `${this.$common.httpmin()}//api.${this.$common.domain()}/game/down_apk`,
          method: "get",
          params: {
            format: "json",
            id: id,
            sign: sign,
            client_id: this.client_id,
            game_id: this.game_id,
          },
        })
          .then((res) => {
            this.front_setup = res.data.front_setup;
          })
          .catch((err) => {
            //
          });
        console.log("??");
        this.getPreloadDownUrl(downLoad_url);
      } else {
        this.disabled = false;

        let url = downLoad_url;
        console.log("openUrl:", url);
        window.open(url);
      }
    },
    getPreloadDownUrl(downLoad_url) {
      let id = downLoad_url.split("id=")[1];
      let sign = this.$common.downLoadUrl_sign();

      console.log("getPreloadDownUrl", downLoad_url, id, sign);

      axios({
        url: `${this.$common.httpmin()}//api.${this.$common.domain()}/game/preload_down_apk`,
        method: "get",
        params: {
          format: "json",
          id: id,
          sign: sign,
          client_id: this.client_id,
          game_id: this.game_id,
        },
      })
        .then((res) => {
          if (res.data.code == 200) {
            console.log("分包成功", res);
            window.location.href = res.data.data;
            this.disabled = false;
          } else {
            console.log("分包失败");
            this.timeOutId = setTimeout(() => {
              this.getPreloadDownUrl(downLoad_url);
            }, 3000);
          }
        })
        .catch((err) => {
          console.log("请求失败");
          this.timeOutId = setTimeout(() => {
            this.getPreloadDownUrl(downLoad_url);
          }, 3000);
        });
    },
    toIframe() {
      let link = location.host;
      let routeData = this.$router.resolve({
        path: "/active/h5Iframe",
        query: { url: this.play_url, iframeTitle: this.iframeTitle },
      });
      window.open(`http://${link}` + routeData.href, "_blank");
    },
    // 跳转游戏详情页
    openGameDetil(game_id, agent_id) {
      // 拼接链接 进行跳转
      let hostArray = window.location.host.split(".");
      hostArray.shift();
      let domian = hostArray.join(".") || "etuw.cn";
      let aurl = `http://page.${domian}/active/gameAndDown?game_id=${game_id}&client_id=${agent_id}`;
      console.log(aurl);
      window.open(aurl, "_blank");
    },
    // 获取站点信息
    getBoxFrontSetup() {
      axios({
        url: `${this.$common.httpmin()}//api.${this.$common.domain()}/system/box_front_setup?format=json&client_id=${
          this.client_id
        }`,
        method: "get",
      }).then((res) => {
        this.front_setup = res.data.data.front_setup;
      });
    },
  },
  created() {
    this.getPageData();
    this.judgeEquipment();
    this.judgeIos();
    this.getBoxFrontSetup();
  },
  watch: {
    //监视弹出窗口是否关闭执行的回调
    ishow: {
      handler(val) {
        this.toHidden();
      },
    },
    $route: {
      handler(to, from) {
        // console.log(to);
        this.topic_code = to.params.topic_code;
        this.client_id = to.params.client_id;
      },
      immediate: true,
    },
  },
  beforeDestroy() {
    if (this.timeOutId && this.timeOutId != 0) {
      clearTimeout(this.timeOutId);
    }
  },
};
</script>
<style lang="less">
html {
  font-size: 100px;
}
body {
  overflow-x: hidden !important;
}
</style>
<style scoped lang="less">
.error {
  width: 100%;
  height: 100vh;
  background: #f6f7fb url("../../assets/404.png") center no-repeat;
  background-size: 60% 50%;
}
.ageem_text {
  text-decoration: underline;
}
.test_title {
  width: 100%;
  display: flex;
  justify-content: space-between;
}
.gameDetail_box {
  display: flex;
  background: #2b5959;
  // overflow: hidden;
  box-sizing: border-box;
  width: 100%;
  .recommend_image {
    flex: 1;
    position: fixed;
    width: calc((100vw - 7.63rem) / 2);
    height: 10.8rem;
    img {
      display: block;
      position: absolute;
      left: 0;
    }
  }
  .recommend_image:nth-last-child(1) {
    right: 0;
    img {
      display: block;
      position: absolute;
      right: 0;
    }
  }
}
.gameDetail {
  width: 100%;
  // height: 100%;
  max-width: 7.63rem;
  // margin: 0 auto;
  position: absolute;
  left: calc((100vw - 7.63rem) / 2);
  // transform: translateX(-50%);
  // overflow-y: scroll;
  // line-height: 1;
  z-index: 666;
  opacity: 1;
  background-color: #f6f3fc;
  .downLoad {
    width: 1.28rem;
    border: 0 none;
    outline: none;
    height: 0.46rem;
    text-decoration: none;
    line-height: 0.46rem;

    img {
      display: block;
      width: 100%;
      height: 100%;
    }
  }

  .game_views {
    overflow: hidden;
    position: relative;
    z-index: 10;
    font-size: 16px;
    display: block;
    border-bottom-right-radius: 150px 70px;
    li {
      list-style: none;
    }
    // margin-bottom: 0.2rem;
    img {
      display: block;
    }
    .game_box_ul {
      width: 90%;
      margin: 0 auto;
      padding: 0;
      .game_box_li:hover {
        background-color: #edf6ff;
        .game_discount p {
          color: #fff;
          background-color: #ec5429;
        }
      }

      .game_box_li {
        display: flex;
        align-items: center;
        margin: 20px 0;
        overflow: hidden;
        .game_icon {
          position: relative;
          width: 22%;
          img {
            width: 100%;
          }
          .mark {
            width: 84%;
            height: 84%;
            position: absolute;
            bottom: 0;
            left: 24px;
            text-shadow: 2px 0px #aa931e;
            color: #b20208;
            background: url("../../assets/mark.png") no-repeat;
            background-size: 100% 100%;
            span {
              font-size: 24px;
              font-weight: 600;
              position: absolute;
              bottom: 16px;
              right: 12px;
              transform: rotate(314deg);
            }
          }
        }
        .game_desc {
          flex: 1;
          margin: 0 0 0 3%;
          overflow: hidden;
          .game_name {
            width: 90%;
            font-weight: 700;
            font-size: 18px;
            margin: 5% 0;
            white-space: nowrap;
            text-overflow: ellipsis;
            overflow: hidden;
            div {
              display: inline-block;
              img {
                display: inline-block;
                vertical-align: middle;
              }
            }
          }
          .game_tag span {
            display: inline-block;
            padding: 2px 6px;
            border-radius: 20px;
            margin: 5px 2px;
          }
          .game_tag span:nth-child(1) {
            margin-left: 0;
          }
          // 样式一
          .tag_green {
            color: #feaf36;
            background-color: #fef7ec;
          }
          .tag_orange {
            color: #28d58b;
            background-color: #e9fbf3;
          }
          .tag_blue {
            color: #2f58f2;
            background-color: #eaeefd;
          }
          .tag_cyan {
            color: #fd6f50;
            background-color: #fff0ec;
          }
          .tag_yellow {
            color: #3da3ee;
            background-color: #edf6ff;
          }
          .game_gtype span {
            color: #d08877;
            margin: 0 4px;
          }
          .game_gtype .popularity_cnt {
            color: #636165;
            width: 60%;
            display: inline-block;
            vertical-align: middle;
            white-space: nowrap;
            text-overflow: ellipsis;
            overflow: hidden;
            span {
              color: red;
            }
          }
        }
        .game_discount {
          margin-right: 10px;
          cursor: pointer;
          p {
            padding: 10px 20px;
            border: 2px solid #e8e5ea;
            border-radius: 20px;
            color: #ec5429;
            font-weight: 700;
          }
        }
      }
      .game_box_li:first-child {
        margin-top: 0;
      }
      .game_box_li:last-child {
        margin-bottom: 0;
      }
    }

    .game_views-outer {
      width: 100%;
      margin: 0 auto;
      overflow-x: auto;
      padding-left: 0;
      display: flex;
      justify-content: space-between;

      .game_views-inner {
        flex: 1;
        margin-right: 0.1rem;
        list-style: none;

        img {
          display: block;
          height: 3.6rem;
          margin: 0 auto;
        }
      }
    }
  }
  // .main::after {
  //   content: "";
  //   display: block;
  //   width: 60px;
  //   background-color: red;
  //   height: 60px;
  //   position: absolute;
  //   right: 0;
  //   top: -20%;
  //   border-radius: 60px 0 0 0;
  //   transform: rotate(180deg);
  // }
  .main {
    min-height: 56%;
    padding-bottom: 0.4rem;
    padding-top: 0.2rem;
    position: relative;
    z-index: 20;
    top: -28px;
    border-radius: 30px 30px 0 0;
    background-color: #f6f3fc;
    .game_type {
      display: flex;
      font-size: 0.22rem;
      line-height: 0.44rem;
      height: 0.44rem;
      margin-bottom: 0.2rem;
      color: #fff;
      span {
        flex: 1;
        text-align: center;

        &:nth-child(1) {
          background: rgb(159, 76, 211);
        }

        &:nth-child(2) {
          background: rgb(243, 107, 72);
        }

        &:nth-child(3) {
          background: rgb(72, 177, 243);
        }
      }
    }

    .game_intro {
      .game_intro-title {
        // background-color: rgb(226, 226, 226);
        // border-radius: 0 0.25rem 0.25rem 0;
        // display: inline-block;
        // font-size: 0.27rem;
        // height: 0.5rem;
        // line-height: 0.5rem;
        // padding: 0 0.42rem;
        // color: #484848;
        text-align: left;
        padding-left: 0.140351rem;
        margin-left: 0.140351rem;
        margin-bottom: 0.192982rem;
        border-left: 0.087719rem solid #ff8500;
        font-weight: 700;
        font-size: 0.280702rem;
      }

      .game_intro-detail {
        color: #7b7b7b;
        font-size: 0.22rem;
        line-height: 0.36rem;
        padding: 0.3rem;
        padding-top: 0;
        padding-bottom: 0.1rem;
        /deep/p {
          margin: 0;
        }
      }

      .game_gift {
        padding: 0 0.175439rem;
        .game_gift_item {
          display: flex;
          align-items: center;
          width: 100%;
          margin-top: 0.070175rem;
          vertical-align: middle;
          img {
            width: 1rem;
            height: 1rem;
          }
          .game_gift_content {
            font-size: 0.280702rem;
            width: 60%;
            height: 0.8rem;
            margin: 0 0.175439rem;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            div:nth-child(1) {
              font-weight: 700;
              font-size: 0.280702rem;
              color: #606266;
            }
            div:nth-child(2) {
              font-size: 13px;
              color: #606266;
              overflow: hidden;
              white-space: nowrap;
              text-overflow: ellipsis;
              width: 90%;
            }
          }

          .git_gift_btn {
            width: 15%;
            height: 0.438596rem;
            line-height: 0.438596rem;
            font-size: 0.210526rem;
            text-align: center;
            background-color: #fdf6ec;
            color: #e17055;
            border: 1px solid #fcbd71;
            border-radius: 0.087719rem;
          }
        }
      }
    }
  }

  iframe {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    width: 100%;
    height: 100%;
    background: #fff;
    z-index: 999;
  }
  .company-footer {
    background-color: rgb(51, 51, 51, 0.9);
    // height: 1.96rem;
    box-sizing: border-box;
    padding: 0.4rem 0.2rem;
    display: flex;
    align-items: flex-start;
    justify-content: center;
    .company-footer-text {
      color: #fff;
      font-size: 0.12rem;
      padding-top: 0.2rem;
      color: #c1c1c1;
    }
    .company-footer-text:nth-child(1) {
      font-size: 0.16rem;
      padding-top: 0;
    }
    .wechat {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      margin-right: 0.3rem;
      .company-footer-text {
        color: #fff;
        font-size: 0.12rem;
        padding-top: 0.14rem;
        white-space: nowrap;
      }
    }
  }
  .footer {
    // background-color: rgb(255, 251, 216);
    background: rgba(0, 0, 0, 0.7);
    bottom: 0;
    height: 1.5rem;
    left: 0;
    position: absolute;
    width: 100%;

    .game_btn {
      background-color: rgb(243, 107, 72);
      color: #ffffff;
      display: block;
      font-size: 0.3rem;
      height: 0.76rem;
      line-height: 0.76rem;
      margin: 0.3rem auto 0;
      width: 40%;
      border: 0 none;
      outline: none;
      text-align: center;
      text-decoration: none;
      border-radius: 0.48rem;

      &:hover {
        cursor: pointer;
      }
    }

    .game_pc {
      position: relative;

      ul.erweima {
        opacity: 0;
        padding: 0;
        margin: 0;
        list-style: none;
        background: #fff;
        position: absolute;
        top: -238px;
        left: 50%;
        transform: translateX(-50%);
        display: flex;

        li {
          flex: 1;
          padding: 20px;

          p {
            font-size: 0.22rem;
            text-align: center;
          }

          img {
            width: 180px;
            height: 180px;
          }
        }
      }

      .game_btn:hover {
        & + ul.erweima {
          opacity: 1;
        }
      }
    }
  }
}

.test {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.9);
  z-index: 999;
  .test-box {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 65%;
    height: 15%;
    background-color: #fff;
    border-radius: 0.350877rem;
    font-size: 0.280702rem;
    padding: 0.350877rem;
    text-align: center;
  }

  .test-btn {
    position: absolute;
    bottom: 10%;
    left: 0;
    width: 100%;
    display: flex;
    justify-content: center;
    div {
      width: 50%;
      text-align: center;
    }
    a {
      width: 50%;
      text-align: center;
      display: block;
      text-decoration: none;
      color: #000;
    }
  }
}

.main .Pic {
  width: 5.5rem;
  margin: auto;
  padding-top: 0.5rem;
  box-sizing: border-box;
  font-size: 0;
}
.main .Title {
  width: 5.5rem;
  margin: auto;
  padding: 0.3rem 0;
  box-sizing: border-box;
  font-size: 0;
}

@media screen and (max-width: 750px) {
  .error {
    background-size: 40%;
  }
  .gameDetail {
    left: 0;
    .game_views {
      border-bottom-right-radius: 90px 50px;
    }
    .company-footer .wechat {
      margin-right: 0.1rem;
    }
  }
  .gameDetail .game_views .game_box_ul .game_box_li .game_discount p {
    padding: 6px 14px;
  }
  .gameDetail .company-footer .wechat .company-footer-text {
    transform: scale(0.8);
  }
  .gameDetail .main {
    padding-top: 0;
    top: -16px;
  }

  .gameDetail .game_views .game_box_ul {
    width: 94%;
    .game_box_li {
      background-color: transparent;
      border-radius: 20px;
      .game_icon .mark {
        width: 70%;
        height: 70%;
        bottom: 0;
        left: 26px;
        span {
          font-size: 15px;
          bottom: 6px;
          right: 3px;
        }
      }
    }
    .game_box_li:first-child {
      margin-top: 0.4rem;
    }
    .game_box_li .game_desc .game_tag {
      margin: 0;
      span {
        font-size: 13px;
      }
    }
    .game_box_li .game_icon {
      width: 24%;
    }
    .game_box_li .game_desc .game_gtype {
      margin: 4px 0;
      font-size: 12px;
      span {
        margin: 0 2px;
      }
    }
    .game_box_li .game_desc .game_name {
      margin: 6px 2px;
    }
  }
}
</style>
