<!-- 支付成功单页面 -->
<template>
  <div class="payResult">
    <!-- 提示图片 -->
    <div class="images">
      <img src="../../assets/paySuccess.png" alt width="60%" v-if="isSuccess" />
      <img src="../../assets/payError.png" alt width="60%" v-else />
    </div>
    <div>
      <p v-if="isSuccess">您已成功支付</p>
      <div v-else>
        <img src="../../assets/payErrorIcon.png" alt width="60%" />
        <p>支付失败</p>
      </div>
    </div>
    <div>
      <img src="../../assets/paySuccessIcon.png" alt width="60%" v-if="isSuccess" />
    </div>
    <h2 v-if="isSuccess">
      <span>￥</span>
      {{ amount }}
    </h2>
  </div>
</template>

<script>
export default {
  data() {
    return {
      isSuccess: false,
      amount: ""
    };
  },
  watch: {
    $route: {
      handler(to, from) {
        if(to.query.amount){
          this.isSuccess = true;
          this.amount = to.query.amount;
        }
      },
      immediate: true
    }
  }
};
</script>
<style scoped lang='less'>
.payResult {
  width: 100%;
  height: 100%;
  overflow-y: scroll;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: center;
  font-size: 0.3rem;

  img {
    display: block;
    margin: 0.3rem auto 0.2rem;
  }
}
</style>