<template>
  <!-- 盒子下载单页面 -->
  <div class="download">
    <img src="https://cdn.jsdelivr.net/gh/2015214547/myImages/img/20201214104907.png" width="100%" height="100%" />
    <div class="down" @click="handleDown"></div>

    <p class="copyright">{{ this.copyright }}</p>
  </div>
</template>

<script>
import axios from "axios";
const imgs = require.context("@/assets/images_baijin", false, /\.png/);
let imgArr = imgs.keys();
let imgsArr = [];
imgArr.forEach(fileName => {
  imgsArr.push(location.origin + "/" + imgs(fileName));
});

export default {
  props: {
    agentId: {
      type: [Number, String],
      default: 0
    }
  },
  data() {
    return {
      type: 100, // and:100   ios:101
      copyright: "",
      down_url: ""
    };
  },
  computed: {
    imgs() {
      return imgsArr;
    }
  },
  created() {
    let flag = navigator.userAgent.match(
      /(phone|pad|pod|iPhone|iPod|ios|iPad|Android|Mobile|BlackBerry|IEMobile|MQQBrowser|JUC|Fennec|wOSBrowser|BrowserNG|WebOS|Symbian|Windows Phone)/i
    );
    if (flag && flag[0] == "iPhone") {
      this.type = 101;
    } else {
      this.type = 100;
    }
  },
  mounted() {
    let link;
    let hostnameArr = location.hostname.split(".");
    hostnameArr.shift();
    link = hostnameArr.join(".");
    // console.log(link);
    // console.log(this.agentId);

    axios({
      url: `http://wap.${this.$common.domain()}/wap/down/index`,
      method: "get",
      params: {
        link: link,
        agent_id: this.agentId,
        format: "json"
      }
    }).then(res => {
      const resuleData = res.data.data;
      if (resuleData) {
        this.down_url = resuleData.down_url;
        this.copyright = resuleData.web_setup.wap_copyright;
      }
    });
  },
  methods: {
    handleDown() {
      if (this.down_url != "") location.href = this.down_url;
    }
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="less">
.download {
  margin: 0 auto;
  width: 100vw;
  height: 100%;
  max-width: 750px;
  line-height: 0;
  position: relative;
  overflow-y: scroll;

    img {
      width: 100%;
      
    }

    .copyright {
      width: 100%;
      height: 10px;
      line-height: 10px;
      position: absolute;
      left: 0;
      bottom: 35px;
      font-size: 16px;
      font-weight: 700;
      color: rgba(0,0,0,.5);
      text-align: center;
    }

    .down {
      position: absolute;
      width: 100%;
      height: 500px;
      top: 0;
    }

  @media screen and (max-width: 500px) {
    .hello .copyright {
      bottom: 15px;
      font-size: 9px;
    }
  }
}
</style>
