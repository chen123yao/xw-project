import md5 from 'js-md5';

export default {
    domain() {
        return "sy12306.com"
        // return "aierx.cn"
    },
    httpmin() { 
        return 'https:'
    },
    // 页面缩放处理方法
    changeResize() {
        let html = document.getElementsByTagName("html")[0];
        if (/Android|webOS|iPhone|iPod|BlackBerry/i.test(navigator.userAgent)) {
            html.style.fontSize = "57px";
        } else {
            html.style.fontSize = "100px";
        }
    },
    // 判断当前是手机端还是PC端
    judgeEquipment() {
        if (/Android|webOS|iPhone|iPod|BlackBerry/i.test(navigator.userAgent)) {
            console.log("当前处于移动端");
            this.isPC = false;
        } else {
            console.log("当前处于PC");
            this.isPC = true;
        }
    },
    // 判断当前设备为IOS还是android
    judgeIos() {
        let flag = navigator.userAgent.match(
            /(phone|pad|pod|iPhone|iPod|ios|iPad|Android|Mobile|BlackBerry|IEMobile|MQQBrowser|JUC|Fennec|wOSBrowser|BrowserNG|WebOS|Symbian|Windows Phone)/i
        );
        if (flag && flag[0] == "iPhone") {
            console.log("当前处于IOS系统");
            this.isIos = true;
        } else {
            this.isIos = false;
        }
    },
    // 随机字符串
    randomString(len) {
      len = len || 32;
      let $chars = 'ABCDEFGHJKMNPQRSTWXYZabcdefhijkmnprstwxyz2345678';    /****默认去掉了容易混淆的字符oOLl,9gq,Vv,Uu,I1****/
      let maxPos = $chars.length;
      let pwd = '';
      for (let i = 0; i < len; i++) {
        pwd += $chars.charAt(Math.floor(Math.random() * maxPos));
      }
      return pwd;
    },

    // 生成下载鉴权sign
    downLoadUrl_sign() {
      let key = 'QyWbpzcfbJgtppSA';
      let code = this.randomString(5);
      let timestamp = Date.parse(new Date()) / 1000;
      let sign_key = String(timestamp.toString() + key + code);
      let sign1 = md5(code + timestamp + sign_key);
      let sign = code + '-' + timestamp + '-' + sign1;
      return sign;
    },

    // 二维码生成
    erweimaCode: (url, iconUrl) => {
    console.log(url, iconUrl);
    return `http://www.yuehuajuheng.com/game/getImageUrl?msg_str=${encodeURIComponent(url)}&icon_url=${encodeURIComponent(iconUrl)}`   
    // return `http://yuehuajuheng.com/game/getImageUrl?msg_str=${encodeURIComponent(url)}&icon_url=${encodeURIComponent(iconUrl)}`   
    }
}