import Vue from "vue";
import VueRouter from "vue-router";

Vue.use(VueRouter);

const router = new VueRouter({
  mode: 'history', // 去掉#
  // base: "/wap",
  routes: [{
    path: "/",
    redirect: "/active/gameAndDown"
  },
  {
    path: "/active",
    name: "active",
    meta: {
      title: "统一路由分发"
    },
    component: () => import("@/components/active/index.vue"),
    children: [{
      path: "gameAndDown",
      name: "gameAndDown",
      meta: {
        title: ''
      },
      component: () => import("@/components/gameAndDown/index.vue"),
    },
    {
      path: "agreement",
      name: "agreement",
      meta: {
        title: '协议'
      },
      component: () => import("@/components/agreement/index.vue"),
    },
    {
      path: "newDown",
      name: "newDown",
      meta: {
        title: '盒子下载'
      },
      component: () => import("@/components/newDown/index.vue"),
    },

    {
      path: "proDown",
      name: "proDown",
      meta: {
        title: '推广app下载'
      },
      component: () => import("@/components/proDown/index.vue"),
    }, {
      path: "payResult",
      name: "payResult",
      meta: {
        title: "支付结果"
      },
      component: () => import("@/components/payResult/index.vue")
    }, {
      path: "gameVideo",
      name: "gameVideo",
      meta: {
        title: "视频播放"
      },
      component: () => import("@/components/gameVideo/index.vue")
    }, {
      path: "xiaochengxu",
      name: "xiaochengxu",
      meta: {
        title: "小程序下载页面"
      },
      component: () => import("@/components/xiaochengxu/index.vue")
    },{
      path: "webGamePay",
      name: "webGamePay",
      meta: {
        title: "充值中心"
      },
      component: () => import("@/components/webGamePay/index.vue")
    },{
      path: "district",
      name: "district",
      meta: {
        title: "区服列表"
      },
      component: () => import("@/components/district/index.vue")
    }, {
      path: "topic/:topic_code/:client_id",
      name: "topic",
      meta: {
        title: "专题推广"
      },
      component: () => import("@/components/gameDetailList/index.vue")
    }, {
      path: "h5Iframe",
      name: "h5Iframe",
      component: () => import("@/components/gameAndDown/children/h5Iframe.vue")
    }]
  }
  ]
})

export default router