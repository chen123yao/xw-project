<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: "App",

  created() {
    this.$common.changeResize();
    window.onresize = this.$common.changeResize;
  }
};
</script>

<style lang="less">
@import url("common/css/normalize.css");
#app {
  width: 100vw;
  height: 100vh;
  overflow-x: hidden;
}
</style>
