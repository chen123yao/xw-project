let baseURL = process.env.NODE_ENV === 'development' ? '/api/' : '/';

if (process.env.NODE_ENV === "development") {
  console.log("当前为开发环境");
} else {
  console.log("当前为生产环境");
}

export default {
  baseURL,
  timeout: 10000,
};
