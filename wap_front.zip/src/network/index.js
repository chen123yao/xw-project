import { request } from "./request";

export const getUserInfo = (link) => {
  return request({
    url: `/home/tg_front_setup?format=json&link=t9j5.cn`,
    method: "post",
  });
};
