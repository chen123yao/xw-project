import axios from 'axios';
import urlConfig from './config';
axios.defaults.withCredentials = true;

export const request = config => {
  // 1. *************--------- 创建axios实例 ---------*************
  const axiosRequire = axios.create(urlConfig);

  // 2. *************--------- axios请求拦截器 ---------*************
  axiosRequire.interceptors.request.use(
    config => {
      return config;
    },
    error => {
      // 2.3 对请求错误做些什么
      return Promise.reject(error);
    }
  );

  // 3. *************--------- axios响应拦截器 ---------*************
  axiosRequire.interceptors.response.use(
    // 3.1 请求成功
    response => {
      if (response.status === 200) {
        return Promise.resolve(response);
      } else {
        return Promise.reject(response);
      }
    },
    error => {
      // 判断请求异常信息中是否含有超时timeout字符串
      if (error.message.includes('timeout')) {
        return Promise.reject(error); // reject这个错误信息
      }
      return Promise.reject(error);
    }
  );
  return axiosRequire(config);
};

// function getAxiosInstance(developmentURL, productRequestURL) {
//   console.log('正式接口');
//   const instance = axios.create({
//     baseURL: process.env.NODE_ENV == "development" ? developmentURL : productRequestURL,
//     timeout: 10000,
//     "Content-Type": "application/json;charset=UTF-8",
//     withCredentials: true
//   })
//   instance.interceptors.request.use((config) => {
//     return config;
//   }, function (error) {
//     return Promise.reject(error);
//   });
//   instance.interceptors.response.use(function (response) {
//     return response.data;
//   }, function (error) {
//     return Promise.reject(error);
//   });
//   return instance
// }


// const wapInstance = getAxiosInstance('/api/', 'http://wap.sy12306.com/')

// // const apiInstance = getAxiosInstance('secondApi/', 'http://api.sy12306.com/')
// const apiInstance = getAxiosInstance('/secondApi/', 'http://api.zzchaoyi.cn/')


// export {
//   wapInstance,
//   apiInstance
// }

// 同时请求 端口号 sy12306 zzchaoyi
