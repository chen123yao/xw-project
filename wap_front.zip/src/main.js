import Vue from "vue";
import App from "./App.vue";
import axios from "axios";
Vue.prototype.$axios=axios;
// import {apiInstance} from './network/request';
// Vue.prototype.$apiInstance=apiInstance;

import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css';

Vue.use(ElementUI)


Vue.config.productionTip = false;

import VueJsonp from 'vue-jsonp'
Vue.use(VueJsonp);

import router from "./router";


import common from "@/common/js/common.js";
Vue.prototype.$common = common;

let link = document.querySelector("link[rel*='icon']") || document.createElement('link');
link.type = 'image/x-icon';
link.rel = 'icon';
link.href = '';
document.getElementsByTagName('head')[0].appendChild(link);

router.beforeEach((to, from, next) => {
  /* 路由发生变化修改页面title */
  if (to.meta.title) {
    document.title = to.meta.title
  }
  if (to.meta.content) {
    const head = document.getElementsByTagName('head')
    const meta = document.createElement('meta')
    document
      .querySelector('meta[name="keywords"]')
      .setAttribute('content', to.meta.content.keywords)
    document
      .querySelector('meta[name="description"]')
      .setAttribute('content', to.meta.content.description)
    meta.content = to.meta.content
    head[0].appendChild(meta)
  }
  next()
})

new Vue({
  router,
  render: (h) => h(App),
}).$mount("#app");