const express = require('express');

module.exports = {
  runtimeCompiler: false,
  publicPath: process.env.NODE_ENV === "prodution" ? "/" : "/",
  outputDir: "./dist",
  assetsDir: "static",
  devServer: {
    // port: 6000, // 端口
    open: true, // 自动开启浏览器
    clientLogLevel: "none",
    proxy: {
      "/api": {
        target: "http://wap.sy12306.com",
        // target: "http://wap.aierx.cn",
        changeOrigin: true, // 允许跨域
        // logLevel:'debug',  //是否开启真实请求代理地址
        pathRewrite: {
          "^/api": "/",
        },
      },
      "/secondApi/": {
        target: "http://api.sy12306.com/",
        // target: "https://api.aierx.cn/",
        changeOrigin: true, // 允许跨域
        logLevel: 'debug',
        pathRewrite: {
          "^/secondApi/": "",
        },
      },
    },
  },
  productionSourceMap: false,
  // 自定义webpack配置
  chainWebpack: (config) => {
    // 配置引用路径别名
    config.resolve.alias
      .set("@", resolve("src"))
      .set("assets", resolve("src/assets"))
      .set("common", resolve("src/common"))
      .set("components", resolve("src/components"))
      .set("network", resolve("src/network"))
      .set("views", resolve("src/views"));
  },
};

// 引入路径
const path = require("path");
const resolve = (dir) => {
  return path.join(__dirname, dir);
};