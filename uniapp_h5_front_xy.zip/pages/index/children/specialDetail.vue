<template>
	<!-- cc 游戏专题详情页面 -->
	<view class="container special">
		<!-- cc 游戏专题详情页面顶部标题 -->
		<view class="special-topTitle">
			<view class="special-topTitle-box">
				<image class="special-topTitle-box-left" src="@/static/images/left.png" mode="heightFix" @click="back" />
				<text class="special-topTitle-box-text">{{ specialName }}</text>
			</view>
		</view>
		
		<u-empty v-if="!isLoading && !specialCount" text="专题为空" :width="400" :height="400" :textSize="32" :marginTop="560" mode="data" icon="http://cdn.uviewui.com/uview/empty/data.png"></u-empty>
			
		<!-- cc 是否请求数据中 显示loading界面 -->
		<u-loading-page class="special-loading" :loading="isLoading && !specialCount" icon-size="72" font-size="30" loading-mode="spinner"></u-loading-page>
		
		<!-- cc 游戏专题详情页面内容显示区域 -->
		<view v-if="specialCount" class="special-content">
			
			<!-- cc 轮播图 -->
			<u-swiper class="special-content-swiper" :list="swiperList" indicator indicatorMode="dot" circular height="384rpx"
				radius="20rpx" bgColor="transparent" @click="swiperClick">
			</u-swiper>
			
			<!-- cc 专题游戏 -->
			<view class="special-content-item"  v-for="(value, index) in specialData" :key="index">
				<vue-gameItem :itemData='value' :itemWidth="686" :tagType="2" :itemBMargin="32" :iconWidth="144" :hasPadding="false" :isShowMaxWidth="true"></vue-gameItem>
				
				<view class="special-content-item-line"></view>
			</view>
			
			<u-loadmore v-if="specialData.length" bg-color="transparent" height="30" marginTop="0" fontSize="24" marginBottom="64" :status="loadingStatus" loadingIcon="spinner" />
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				// cc 专题详情页面名称
				specialName: '',
				// cc 专题详情页面ID
				specialId: 0,
				// cc 专题详情页面请求数据
				specialData: [],
				// cc 轮播图list数据
				swiperList: [],
				// cc 专题详情页面数据请求参数
				specialParams: {
					page: 1,
					offset: 10,
					topic_id: 0
				},
				// cc 专题详情页面数据数量 默认0
				specialCount: 0,
				// cc 是否加载中 默认false
				isLoading: false,
				// cc loadmore状态
				loadingStatus: 'loading'
			}
		},
		onLoad(option){
			this.specialName = option.specialName
			this.specialParams.topic_id = option.specialId
			
			console.log('specialOnloadOption-name:', this.specialName, '-id:', this.specialId);
			
			// cc 获取专题数据
			this.getSpeciaData()
		},
		onReachBottom() {
			this.loadMoreSpecialData()
		},
		methods: {
			// cc 返回上一级页面
			back() {
				uni.navigateBack({
					delta: 1
				});
			},
			// cc swiper 轮播图点击之后的响应事件 根据当时的轮播图跳转对应的游戏详情
			swiperClick(index) {
				uni.navigateTo({
					url: `/pages/view/gameDetail/gameDetail?gameId=${ this.specialData[index].game_id }`
				})
			},
			// cc 动态加载专题详情数据响应事件
			loadMoreSpecialData() {
				console.log('loadMoreSpecialData');
				if (Object.keys(this.specialData).length < this.specialCount && !this.isLoading) {
					this.specialParams.page++
					this.isLoading = true
					this.loadingStatus = 'loading'
					this.getSpeciaData()
				} else {
					this.loadingStatus = 'nomore'
					this.isLoading = false
				}
			},
			// cc 获取专题详情页面数据
			getSpeciaData() {
				this.isLoading = true
				this.$api.get('/game/special/games', {
					...this.specialParams,
					client_id: this.$store.state.client_id
				}).then(res => {
					if (res.data.code == 200) {
						console.log('log', res);
						if (!res.data.data) {
							this.isLoading = false
							this.loadingStatus = 'nomore'
							return
						}
						this.specialCount = res.data.data.count
						this.specialData = this.specialData.concat(res.data.data.list)
						this.getSwiperListData(this.specialData.slice(0, 5));
						this.isLoading = false
						console.log('specialData', res.data.data, this.specialData);
						
						if (this.specialData.length >= this.specialCount) {
							this.loadingStatus = 'nomore'
						}
					}
				})
			},
			// cc 从后端拿到的数据中去手动处理swiper的list数据
			getSwiperListData(list) {
				console.log('getSwiperListData-list:', typeof list, list);
				this.swiperList = []
				for(let index in list) {
					console.log('getSwiperListData-item:', list[index]);
					this.swiperList.push(list[index].hot_image)
				}
				console.log('getSwiperListData-swiperList:', typeof this.swiperList, this.swiperList);
			}
		}
	}
</script>

<style lang="scss" scoped>
	.container { 
		background-color: #FFFFFF;
		width: 750rpx;
		height: 100vh;
		padding-bottom: 24rpx;
	}
	
	.special {
		
		&-loading {
			width: 750rpx;
			top: 176rpx !important;
		}
		
		&-topTitle {
			position: fixed;
			// background-color: #FFFFFF;
			background: linear-gradient(to bottom, #CCCCCC, #FFFFFF env(safe-area-inset-top));
			z-index: 999;
			top: 0;
			width: 750rpx;
			height: 176rpx;
			padding-left: 34rpx;
			padding-bottom: 16rpx;
			box-sizing: border-box;
			display: flex;
			flex-direction: column;
			justify-content: flex-end;
			box-shadow: 0rpx 0rpx 12rpx rgba(0, 0, 0, 0.16);
			
			&-box {
				box-sizing: border-box;
				display: flex;
				flex-direction: row;
				align-items: center;
				
				&-left {
					// width: 22rpx;
					height: 34rpx;
				}
				
				&-text {
					margin-left: 48rpx;
					font-size: 40rpx;
					line-height: 56rpx;
					font-family: PingFang SC;
					font-weight: 600;
					color: #1C1C1C;
				}
			}
		}
		
		&-content {
			width: 750rpx;
			padding: 224rpx 32rpx 0;
			box-sizing: border-box;
			color: #1C1C1C;
			font-family: PingFang SC;
			background-color: #FFFFFF;
			
			// cc 轮播图
			&-swiper{
				height: 400rpx;
				margin-bottom: 48rpx;
			}
			
			&-item {
				margin-bottom: 64rpx;
				position: relative;
				
				&-line {
					height: 2rpx;
					background-color: #EFEFEF;
					width: 550rpx;
					position: absolute;
					right: -32rpx;
				}
			}
		}
	}
</style>