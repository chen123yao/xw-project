<template>
	<view class="recommend_layout">
		<!-- cc 背景图片 固定定位 -->
		<view class="recommend-bg">
			<image v-if="bannerList[currentImgIndex]" class="recommend-bg-img" :src="bannerList[currentImgIndex].image" mode="scaleToFill" />
			<view :style="{width: '750rpx', height: $store.state.myHeight + 'rpx', position: 'absolute', top: '0', left: '0', backgroundColor: 'rgba(0, 0, 0, .3)' }"></view>
			<view v-if="showShade" :style="{width: '750rpx', height: $store.state.myHeight + 'rpx', position: 'absolute', top: '0', left: '0', backgroundColor: '#F6F3FC' }"></view>
		</view>
		
		<!-- cc 内容区的list -->
		<scroll-view class="recommend-scroll" :scroll-y="true" :scroll-with-animation="true" :refresher-enabled="false" 
			@scrolltolower="scrollToLower" @scroll="recommendScroll" @refresherpulling="scrollRefresh">
			
			<!-- cc 顶部标题导航栏站位元素 -->
			<view :style="{ width: '750rpx', height: $store.state.statusBarHeight + 160 + 'rpx' }"></view>
			<!-- cc 轮播图 -->
			<u-swiper class="recommend-scroll-swiper" :list="swiperList" indicator indicatorMode="dot" circular height="400rpx"
				radius="20rpx" bgColor="transparent" @change="swiperChange" @click="swiperClick">
			</u-swiper>
			
			<!-- cc 金刚区 -->
			<view class="recommend-scroll-jinGang" :style="{ backgroundImage: coupons.count ? 'linear-gradient(to bottom, #FFFFFF, #FCFBFE)' : 'linear-gradient(to bottom, #FFFFFF, #F6F3FC)' }">
				<view class="jinGang-box">
					<view class="jinGang-box-item" v-for="(item, index) in mergeList" :key='index' @click="handleRouter(item.router, item.type)">
						<image class="jinGang-box-item-icon" :src="item.url" mode="scaleToFill"></image>
						<text class="jinGang-box-item-text">{{ item.name || item.topic_name }}</text>
					</view>
				</view>
			</view>
			
			<!-- cc 新用户福利 优惠券 -->
			<view v-if="coupons.count" class="recommend-scroll-coupons">
				<view class="coupons-box">
					<!-- cc 优惠券标题和优惠券总额 -->
					<view class="couponsTitle_layout">
						<image class="couponsTitle_layout-title" src="@/static/images/index/coupons_title.png"></image>
						<text class="couponsTitle_layout-total">领取价值{{ couponsTotal }}元新手礼包</text>
					</view>
					<!-- cc 优惠券一键领取按钮 -->
					<view class="couponsBtn" @click="receiveCoupons"></view>
					<!-- cc 优惠券列表 -->
					<scroll-view class="coupons_layout" scroll-x="true">
						<view class="coupons-item" v-for="(value, index) in coupons.list" :key="index">
							<view class="coupons-item-box">
								<text class="coupons-item-box-topTag" :style="{left: Number(value.coupons_amount).toFixed(0) >= 10 ? '6rpx' : '18rpx'}">￥</text>
								<text class="coupons-item-box-topCoupons">{{ Number(value.coupons_amount).toFixed(0) }}</text>
								<text class="coupons-item-box-bottom">满{{ Number(value.order_amount_min).toFixed(0) }}元使用</text>
							</view>
						</view>
					</scroll-view>
				</view>
			</view>
			
			<!-- cc 爆款推荐 -->
			<view v-if="hotRecommend.game_list_count" class="recommend-item-bg recommend-scroll-hotRecommend">
				<!-- cc 爆款推荐外部弹性盒子 -->
				<view class="recommend-scroll-hotRecommend-box">
					<!-- cc 顶部标题组件 -->
					<itemTop class="item-top" top_title="爆款推荐" top_img="../../static/images/index/hot.png" :img_height="32" 
						:right_url="`/pages/index/children/specialDetail?specialName=${ hotRecommend.topic_name }&specialId=${ hotRecommend.topic_id }`"></itemTop>
					<!-- cc 爆款推荐列表 -->
					<scroll-view class="hotRecommend_scroll" scroll-x="true">
						<view v-if="index < 6" class="hotRecommend-item" v-for="(value, index) in hotRecommend.game_list" :key="index" :style="{ 'backgroundImage': 'url(' + value.home_img_style1 + ')' }"
							@click="handleRouter(`/pages/view/gameDetail/gameDetail?gameId=${ value.game_id }`)" >
							<!-- cc 游戏名称与icon -->
							<view class="hotRecommend-item-title">
								<image class="hotRecommend-item-title-icon" :src="value.new_icon || value.icon" mode="scaleToFill"></image>
								<text class="hotRecommend-item-title-text">{{ value.game_name }}</text>
							</view>
						</view>
					</scroll-view>
				</view>
			</view>
			
			<!-- cc 新游首发 -->
			<view class="recommend-item-bg recommend-scroll-firstPublish">
				<!-- cc 新游首发外部弹性盒子 -->
				<view class="recommend-scroll-firstPublish-box">
					<!-- cc 顶部标题组件 -->
					<itemTop class="item-top" top_title="新游首发" top_img="../../static/images/index/new.png" :img_height="36" :img_top="-2" right_url="/pages/my/serverList/serverList"></itemTop>
					<!-- cc 新游图片轮播 -->
					<view class="firstPublish-layout">
						<view class="firstPublish-layout-box" @click="handleRouter('/pages/my/serverList/serverList')">
							<!-- <image class="firstPublish-layout-item" src="@/static/images/index/xinpin.png" mode="scaleToFill"></image> -->
							<image class="firstPublish-layout-item" :src="value.url" v-for="(value, index) in firstPublish" :key="index" mode="scaleToFill"></image>
						</view>
					</view>
				</view>
			</view>
	
			<!-- cc 试玩赚金 -->
			<view v-if="gameDemos.length" class="recommend-item-bg recommend-scroll-gameDemos">
				<!-- cc 试玩赚金外部弹性盒子 -->
				<view class="recommend-scroll-gameDemos-box">
					<!-- cc 顶部标题组件 -->
					<itemTop class="item-top" top_title="试玩赚金" top_img="../../static/images/index/tuijian.png" :img_height="28" right_url="/pages/getMoney/index" :isSpecial="true"></itemTop>
					<!-- cc 试玩游戏 -->
					<scroll-view class="gameDemos_scroll" scroll-x="true">
						<view class="gameDemos_scroll-box" v-for="(value, index) in gameDemos.length/2" :key='index'>
							<vue-gameIcon :iconTitleStyle="{ fontSize: '24rpx', color: '#666666', fontWeight: '400', marginTop: '12rpx', height: '68rpx' }" :iconData='gameDemos[index*2].game'></vue-gameIcon>
							<vue-gameIcon :iconTitleStyle="{ fontSize: '24rpx', color: '#666666', fontWeight: '400', marginTop: '12rpx', height: '68rpx' }" :iconData='gameDemos[index*2+1].game'></vue-gameIcon>
						</view>
					</scroll-view>
				</view>
			</view>
			
			<!-- cc 热门榜 -->
			<view v-if="hotRank.game_list_count" class="recommend-item-bg recommend-scroll-hotRank">
				<!-- cc 热门榜外部弹性盒子 -->
				<view class="recommend-scroll-hotRank-box">
					<!-- cc 顶部标题组件 -->
					<itemTop class="item-top" top_title="热门榜" top_img="../../static/images/index/hotRank.png" :img_height="32" :img_top="-2" right_url="/pages/my/rankList/rankList"></itemTop>
					<!-- cc 热门榜前三 -->
					<vue-gameItem v-if="index < 3 && gameColorArray[index]" :itemData='value' :contentTagsColor="[gameColorArray[(index) * 2],gameColorArray[(index) * 2 + 1]]" :itemWidth="686" :tagType="4" 
						:itemRankIndex="index" :itemBMargin="32" :iconWidth="120" v-for="(value, index) in hotRank.game_list" :key="index"></vue-gameItem>
				</view>
			</view>
			
			<!-- cc 网易专题 -->
			<view v-if="wangyi && wangyi.game_list_count" class="recommend-item-bg recommend-scroll-special">
				<!-- cc 网易专题外部弹性盒子 -->
				<view class="recommend-scroll-special-box">
					<!-- cc 顶部标题组件 -->
					<itemTop class="item-top" top_title="网易专题" top_img="../../static/images/index/zhuanti1.png" :img_height="32" 
						:right_url="`/pages/index/children/specialDetail?specialName=${ wangyi.topic_name }&specialId=${ wangyi.topic_id }`"></itemTop>
					<!-- cc 游戏专题展示 -->
					<itemSpecial :specialData="wangyi"></itemSpecial>
					<!-- cc 部分专题游戏展示 -->
					<scroll-view class="special_scroll" scroll-x="true">
						<view v-if="index < 6" class="special_scroll-item" v-for="(value, index) in wangyi.game_list" :key="index">
							<vue-gameIcon :iconTitleStyle="{ fontSize: '24rpx', color: '#666666', fontWeight: '400', marginTop: '4rpx', height: '68rpx' }"
								:iconData='value'></vue-gameIcon>
						</view>
					</scroll-view>
				</view>
			</view>
			
			<!-- cc 腾讯专题 -->
			<view v-if="tencent && tencent.game_list_count" class="recommend-item-bg recommend-scroll-special">
				<!-- cc 腾讯专题外部弹性盒子 -->
				<view class="recommend-scroll-special-box">
					<!-- cc 顶部标题组件 -->
					<itemTop class="item-top" top_title="腾讯专题" top_img="../../static/images/index/zhuanti2.png" :img_height="32"
						:right_url="`/pages/index/children/specialDetail?specialName=${ tencent.topic_name }&specialId=${ tencent.topic_id }`"></itemTop>
					<!-- cc 游戏专题展示 -->
					<itemSpecial :specialData="tencent"></itemSpecial>
					<!-- cc 部分专题游戏展示 -->
					<scroll-view class="special_scroll" scroll-x="true">
						<view v-if="index < 6" class="special_scroll-item" v-for="(value, index) in tencent.game_list" :key="index">
							<vue-gameIcon :iconTitleStyle="{ fontSize: '24rpx', color: '#666666', fontWeight: '400', marginTop: '4rpx', height: '68rpx' }"
								:iconData='value'></vue-gameIcon>
						</view>
					</scroll-view>
				</view>
			</view>
			
			<!-- cc 画质精选 -->
			<view v-if="choicenessGame || choicenessGame.game_list_count" class="recommend-item-bg recommend-scroll-choicenessGame">
				<!-- cc 画质精选外部弹性盒子 -->
				<view class="recommend-scroll-choicenessGame-box">
					<!-- cc 顶部标题组件 -->
					<itemTop class="item-top" top_title="画质精选" top_img="../../static/images/index/choiceness.png" :img_height="32"
						:right_url="`/pages/index/children/specialDetail?specialName=${ choicenessGame.topic_name }&specialId=${ choicenessGame.topic_id }`"></itemTop>
					<!-- cc 爆款推荐列表 -->
					<scroll-view class="choicenessGame_scroll" scroll-x="true">
						<view v-if="index < 6" class="choicenessGame-item" v-for="(value, index) in choicenessGame.game_list" :key="index" :style="{ 'backgroundImage': 'url(' + value.home_img_style1 + ')' }"
							@click="handleRouter(`/pages/view/gameDetail/gameDetail?gameId=${ value.game_id }`)" >
							<!-- cc 游戏名称与icon -->
							<view class="choicenessGame-item-title">
								<text class="choicenessGame-item-title-text">{{ value.game_name }}</text>
								<view class="choicenessGame-item-title-btn">{{ value.classify == 5 ? '开玩' : '下载' }}</view>
							</view>
						</view>
					</scroll-view>
				</view>
			</view>
			
			<!-- cc 经典传奇 -->
			<view v-if="classicsGame || classicsGame.game_list_count" class="recommend-item-bg recommend-scroll-classicsGame">
				<!-- cc 经典传奇外部弹性盒子 -->
				<view class="recommend-scroll-classicsGame-box">
					<!-- cc 顶部标题组件 -->
					<itemTop class="item-top" top_title="经典传奇" top_img="../../static/images/index/classicsGame.png" :img_height="32"
						:right_url="`/pages/index/children/specialDetail?specialName=${ classicsGame.topic_name }&specialId=${ classicsGame.topic_id }`"></itemTop>
					<!-- cc 游戏专题展示 -->
					<itemSpecial class="classicsGame-special" :specialData="classicsGame" :specialType="2"></itemSpecial>
					<!-- cc 专题前三游戏 打分布局 -->
					<vue-gameItem v-if="index < 3 && gameColorArray[index + 6]" :itemData='value' :contentTagsColor="[gameColorArray[(index) * 2 + 6],gameColorArray[(index) * 2 + 1 + 6]]" :itemWidth="686" :tagType="5"
						:itemRankIndex="index" :itemBMargin="32" :iconWidth="120" v-for="(value, index) in classicsGame.game_list" :key="index"></vue-gameItem>
				</view>
			</view>
			
			<!-- cc H5精选 -->
			<view v-if="choicenessH5 || choicenessH5.game_list_count" class="recommend-item-bg recommend-scroll-choicenessH5">
				<!-- cc H5精选外部弹性盒子 -->
				<view class="recommend-scroll-choicenessH5-box">
					<!-- cc 顶部标题组件 -->
					<itemTop class="item-top" top_title="H5精选" top_img="../../static/images/index/choicenessH5.png" :img_height="32"
						:right_url="`/pages/index/children/specialDetail?specialName=${ choicenessH5.topic_name }&specialId=${ choicenessH5.topic_id }`"></itemTop>
					<!-- cc 游戏专题展示 -->
					<itemSpecial class="choicenessH5-special" :specialData="choicenessH5" :specialType="2"></itemSpecial>
					<!-- cc 专题前三游戏 打分布局 -->
					<vue-gameItem v-if="index < 3 && gameColorArray[index + 12]" :itemData='value' :contentTagsColor="[gameColorArray[(index) * 2 + 12],gameColorArray[(index) * 2 + 1 + 12]]" :itemWidth="686" :tagType="5" 
						:itemRankIndex="index" :itemBMargin="32" :iconWidth="120" v-for="(value, index) in choicenessH5.game_list" :key="index"></vue-gameItem>
				</view>
			</view>
			
			<!-- cc 热门分类 -->
			<view v-if="tagsList.length" class="recommend-item-bg recommend-scroll-classify">
				<!-- cc 热门分类外部弹性盒子 -->
				<view class="recommend-scroll-classify-box">
					<!-- cc 顶部标题组件 -->
					<itemTop class="item-top" top_title="热门分类" :isMore="false" top_img="../../static/images/index/classify.png" :img_height="32" ></itemTop>
					<!-- cc 热门分类列表 -->
					<view class="classify-box">
						<view class="classify-box-item" v-for="(value, index) in tagsList" :key="'tagsList' + index" @click="handleToGameList('tags', value.id, value.name)">
							<view class="classify-box-item-content">{{ value.name }}</view>
						</view>
						<view class="classify-box-item" @click="handleToGameList('h5', 1, 'H5')">
							<view class="classify-box-item-content">H5</view>
						</view>
						<view v-if="cateList.length && index < (showAllCate ? 15 : 3)" class="classify-box-item" v-for="(value, index) in cateList" :key="'cateList' + index" @click="handleToGameList('cate', value.id, value.name)">
							<view class="classify-box-item-content">{{ value.name }}</view>
						</view>
						<view class="classify-box-item" @click="showAllCate = !showAllCate">
							<view class="classify-box-item-content">{{ showAllCate ? '收起' : '展开' }}
								<u-icon v-if="!showAllCate" name="arrow-down" size="30rpx" color="#666666" style="margin-left: 10rpx; display: inline-block;"></u-icon>
								<u-icon v-else name="arrow-up" size="30rpx" color="#666666" style="margin-left: 10rpx; display: inline-block;"></u-icon>
							</view>
						</view>
					</view>
				</view>
			</view>
			
			<!-- cc 没有更多了 -->
			<view class="recommend-item-bg recommend-scroll-noMore">已经到底了！</view>
		</scroll-view>
	</view>
</template>

<script>
	import itemTop from '../components/index-item-top.vue'
	import itemSpecial from '../components/index-item-special.vue'
	
	export default {
		components: {
			itemTop,
			itemSpecial
		},
		props:{
			// cc 是否利用遮罩盖住后面的高斯模糊背景 防止底部滚动之后显示出奇怪的背景颜色
			showShade: {
				type: Boolean,
				default: false // 默认不遮盖  一旦滚动到一定的距离之后再动态遮盖
			}
		},
		data() {
			return {
				// cc 轮播图list数据
				bannerList: [],
				swiperList: [],
				// cc 当前显示的图片下标
				currentImgIndex: 0,
				// cc 金刚区 功能list
				mergeList: [
					{
						url: '../../static/images/index/index-icon/qmtg.png',
						name: '全民推广',
						router: '/pages/my/children/share/index',
						type: 1
					},
					{
						url: '../../static/images/index/index-icon/lqzx.png',
						name: '领券中心',
						router: '/pages/my/children/couponsCore/index',
						type: 1
					},
					{
						url: '../../static/images/index/index-icon/swzj.png',
						name: '试玩赚金',
						router: '/pages/getMoney/index',
						type: 3,
					},
					{
						url: '../../static/images/index/index-icon/jfsc.png',
						name: '积分商城',
						router: '/pages/my/children/pointMall/index',
						type: 1
					},
					{
						url: '../../static/images/index/index-icon/xyzp.png',
						name: '幸运转盘',
						router: '/pages/getMoney/index',
						type: 4
					},
					{
						url: '../../static/images/index/index-icon/xhjy.png',
						name: '小号置换',
						router: '/pages/transaction/index',
						type: 0,
					},
					{
						url: '../../static/images/index/index-icon/czfl.png',
						name: '充值返利',
						router: '/pages/customerService/children/rechargeRebate/index',
						type: 1
					}
				],
				// cc 优惠券数据
				coupons:[],
				// cc 优惠券优惠总额
				couponsTotal: 0,
				// cc 爆款推荐数据
				hotRecommend: [],
				// cc 新游首发数据
				firstPublish: [
					{url: '../../static/images/index/xinpin1.png'},
					{url: '../../static/images/index/xinpin2.png'},
					{url: '../../static/images/index/xinpin3.png'},
					{url: '../../static/images/index/xinpin1.png'}
				],
				// cc 试玩赚金
				gameDemos: [],
				// cc 热门榜
				hotRank: [],
				// cc 网易专题
				wangyi: {},
				// cc 腾讯专题
				tencent: {},
				// cc 画质精选
				choicenessGame: [],
				// cc 经典传奇
				classicsGame: {},
				// cc H5精选
				choicenessH5: {},
				// cc 热门分类
				tagsList: [],
				cateList: [],
				showAllCate: false,
				
				// cc 新开服游戏列表、游戏列表 item tags color
				gameColorArray: [],
			}
		},
		// 组件挂载到实例生命周期函数
		mounted() {
			console.log('recommend-mounted')
			
			setTimeout(() => {
				// cc 获取轮播图数据
				this.getBannerListData()
				// cc 获取金刚区部分动态数据
				this.getFuliCategory()
				// cc 获取新人福利 优惠券数据
				this.getCouponsData()
				// cc 获取更多专题数据
				this.getExtendSpecialData()
				// cc 获取试玩赚金数据
				this.gameDemosData()
				// cc 获取热门榜数据
				this.hotRankData()
				// cc 热门分类数据
				this.categorynewData()
			}, 300)
			
			// cc 给页面中显示的gameItem tags color 随机
			if (true) {
				// console.log('gameColorArrayLength: ', res.data.data.list.length);
				let gameColorIndexArray = [ ...this.$common.getRandomColorIndexArray([], 18) ]
				// console.log('gameColorIndexArray: ', this.gameColorIndexArray);
				this.gameColorArray = { ...this.$common.getRandomColorArray(gameColorIndexArray) }
				// console.log('gameColorArray: ', this.gameColorArray);
			}
			// // cc 获取轮播图数据
			// this.getBannerListData()
			// // cc 获取金刚区部分动态数据
			// this.getFuliCategory()
			// // cc 获取新人福利 优惠券数据
			// this.getCouponsData()
			// // cc 获取更多专题数据
			// this.getExtendSpecialData()
			// // cc 获取试玩赚金数据
			// this.gameDemosData()
			// // cc 获取热门榜数据
			// this.hotRankData()
			// // cc 热门分类数据
			// this.categorynewData()
		},
		methods: {
			scrollToLower() {
				
			},
			recommendScroll(event) {
				console.log('scrollEvent:', event);
			},
			// cc 获取轮播图数据方法
			getBannerListData() {
				this.$api.get('game/special_banner', {
					client_id: this.$store.state.client_id
				}).then(res => {
					console.log('bannerData:', res)
					this.bannerList = res.data.data.list
					this.getSwiperListData(this.bannerList);
				})
			},
			// cc 从后端拿到的数据中去手动处理swiper的list数据
			getSwiperListData(list) {
				console.log('getSwiperListData-list:', typeof list, list);
				for(let index in list) {
					console.log('getSwiperListData-item:', list[index]);
					this.swiperList.push(list[index].image)
				}
				console.log('getSwiperListData-swiperList:', typeof this.swiperList, this.swiperList);
			},
			// cc swiper 轮播图切换之后的响应事件 根据当前的轮播图切换对应的背景图片
			swiperChange(e) {
				this.currentImgIndex = e.current
			},
			// cc swiper 轮播图点击之后的响应事件 根据当时的轮播图跳转对应的游戏详情
			swiperClick(index) {
				this.handleRouter(`/pages/view/gameDetail/gameDetail?gameId=${ this.bannerList[index].ext.app_id }`)
			},
			// cc 金刚区部分数据从后端获取
			getFuliCategory() {
				this.$api.get('game/extend_category', {
					client_id: this.$store.state.client_id,
					extend_type: 3
				}).then(res => {
					let arrList = res.data.data.list 
					arrList.map((item,index)=>{
						item.url = `../../static/images/index/index-icon/jgqzti${ index + 1 }.png`
						item.router = `/pages/index/children/specialDetail?specialName=${ item.topic_name }&specialId=${ item.topic_id }`
						// console.log(item.topic_name,'item.url')
					})
					this.mergeList.push(...arrList)
				})
			},
			// cc 获取通用券数据
			getCouponsData() {
				console.log('getCouponsData:', this.$store.state.client_id);
				this.$api.get('coupons/list', {
					client_id: this.$store.state.client_id,
					type:1,
				}).then(res=>{
					this.coupons = res.data.data
					console.log('getCouponsData-coupons:', this.coupons);
					res.data.data.list.map((item,index)=>{
						this.couponsTotal += Number(item.coupons_amount)
					})
				})
			},
			// cc 获取更多专题数据
			getExtendSpecialData() {
				this.$api.get('game/extend_category', {
					client_id: this.$store.state.client_id,
					extend_type: 1
				}).then(res => {
					// this.
					this.hotRecommend = res.data.data.list[3]
					this.wangyi = res.data.data.list[4]
					this.tencent = res.data.data.list[5]
					this.choicenessGame = res.data.data.list[1]
					this.classicsGame = res.data.data.list[0]
					this.choicenessH5 = res.data.data.list[2]
					
					console.log('hotRecommendData:', this.hotRecommend);
					console.log('wangyiData:', this.wangyi);
					console.log('classicsGameData:', this.classicsGame);
				})
			},
			// cc 获取试玩赚金数据
			gameDemosData() {
				this.$api.get('/task/listgame', {
					client_id: this.$store.state.client_id,
					page: 1,
					offset: 10
				}).then(res => {
					if(res.data.data.list.length){
						this.gameDemos = this.gameDemos.concat(res.data.data.list)
						if(this.gameDemos.length % 2 == 1) {
							this.gameDemos.push([])
						}
					}
					console.log('gameDemos:', this.gameDemos)
				})
			},
			// cc 获取热门榜数据
			hotRankData() {
				this.$api.get('game/rank_category', {
					client_id:this.$store.state.client_id,
					page:1,
					offset:3
				}).then(res => {
					if(res.data.code==200){
						// this.getRandomColor(3)
						this.hotRank = res.data.data.list[0]
						console.log('hotRank:', this.hotRank);
					}
				})
			},
			// cc 获取热门分类数据
			categorynewData() {
				this.$api.get('/game/getcategorynew', {
					client_id: this.$store.state.client_id,
				}).then(res => {
					this.cateList = res.data.data.cate;
					this.tagsList = res.data.data.tags;
				})
			},
			// cc 点击跳转路由页面
			handleRouter(url, type) {
				console.log('handleRouter', url);
				if (type == 1) {
					if (this.$common.isLogin()) {
						uni.navigateTo({
							url
						})
					}
				} else if (type==3||type==4||type==5){
					if(this.$common.isLogin()){
						if(type==3){
							uni.setStorage({
								key: 'active',
								data: 1
							})
						}else if(type==4){
							uni.setStorage({
								key: 'active',
								data: 2
							})
						}else if(type==5){
							uni.setStorage({
								key: 'active',
								data: 0
							})
						}
						uni.switchTab({
							url
						})
					}
				}else{
					uni.navigateTo({
						url
					})
				}
			},
			// cc 领取通用券
			receiveCoupons(){
				if(this.$common.isLogin()){					
					this.$api.get('user/coupons/add_general', {
						client_id: this.$store.state.client_id,
					}).then(res=>{
						if (res.data.code == 200) {
							uni.showToast({
								icon: "none",
								title: '领取成功'
							})
							this.coupons.count = 0
						} else {
							uni.showToast({
								icon: "none",
								title: res.data.msg
							})
						}
					})
				} else {
					uni.navigateTo({
						url
					})
				}
			},
			// cc 游戏类型路由跳转
			handleToGameList(type, id, name) {
				uni.setStorage({
					key:'gameHall',
					data: `${type}-${id}-${name}`,
					success: function () {
						console.log('success', `${type}-${id}-${name}`);
					}
				})
				uni.switchTab({
					url: '/pages/gameList/index'
				})
			},
		}
	}
</script>

<style lang="scss" scoped>
	::v-deep .uni-swiper-slides,
	::v-deep .uni-swiper-slide-frame {
		border-radius: 20rpx;
	}
	
	.recommend_layout {
		width: 100%;
		height: 100%;
		
		.recommend-bg {
			position: fixed;
			top: 0;
			width: 100%;
			height: 100%;
			
			&-img {
				width: 100%;
				height: 100%;
				transform: scale(1.2);
				filter: blur(20rpx);
			}
		}
		
		.recommend-scroll {
			width: 100%;
			height: 100%;
			box-sizing: border-box;
			
			// cc 轮播图
			&-swiper{
				height: 400rpx;
				margin-bottom: 32rpx;
				padding: 0 32rpx;
			}
			
			// cc 金刚区
			&-jinGang {
				background-color: #fff;
				width: 100%;
				// height: 344rpx;
				box-sizing: border-box;
				padding: 32rpx 32rpx 40rpx;
				border-top-left-radius: 40rpx;
				border-top-right-radius: 40rpx; 
				
				.jinGang-box {
					display: flex;
					flex-wrap: wrap;
					flex-direction: row;
					align-content: flex-start;
					
					&-item {
						width: 20%;
						display: flex;
						flex-direction: column;
						align-items: center;
						margin-bottom: 32rpx;
						
						&:nth-child(n + 5) {
							margin-bottom: 0rpx;
						}
						
						&-icon {
							width: 60rpx;
							height: 60rpx;
							margin-bottom: 12rpx;
						}
						
						&-text {
							color: #1C1C1C;
							font-size: 28rpx;
							font-weight: 300;
						}
					}
				}
			}
			
			// cc 新用户福利 优惠券
			&-coupons {
				width: 750rpx;
				height: 356rpx;
				padding: 32rpx;
				padding-top: 0;
				position: relative;
				box-sizing: border-box;
				background-image: linear-gradient(to bottom, #FCFBFE, #F6F3FC);
				
				.coupons-box {
					width: 686rpx;
					height: 324rpx;
					background-repeat: no-repeat;
					background-origin: content-box;
					background-size: 686rpx, 324rpx, contain;
					background-image: url('../../../static/images/index/coupons_bg.png');
					
					.couponsTitle_layout {
						display: flex;
						position: absolute;
						align-items: center;
						flex-direction: column;
						width: 686rpx;
						top: 20rpx;
						
						&-title {
							width: 220rpx;
							height: 46rpx;
						}
						
						&-total {
							font-size: 22rpx;
							color: #FDE443;
							line-height: 32rpx;
							margin-top: 4rpx;
						}
					}
					
					.couponsBtn {
						width: 128rpx;
						height: 48rpx;
						right: 52rpx;
						top: 34rpx;
						position: absolute;
						background-repeat: no-repeat;
						background-size: 128rpx, 48rpx, contain;
						background-image: url('../../../static/images/index/coupons_btn.png');
					}
					
					.coupons_layout {
						bottom: 28rpx;
						position: absolute;
						white-space: nowrap;
						padding: 0 20rpx;
						width: 646rpx;
						overflow: hidden;
						
						::-webkit-scrollbar {
							display: none;
						}
						
						.coupons-item {
							width: 128rpx;
							height: 176rpx;
							padding-bottom: 24rpx;
							display: inline-block;
							background-repeat: no-repeat;
							background-size: 128rpx, 176rpx, contain;
							background-image: url('../../../static/images/index/coupons-item_bg.png');
							margin-right: 20rpx;
							
							&:last-child {
								margin-right: 0rpx;
							}
							
							&-box {
								position: relative;
								padding-top: 34rpx;
								height: 118rpx;
								display: flex;
								flex-direction: column;
								align-items: center;
								justify-content: space-between;
								
								&-topTag {
									position: absolute;
									color: #cc2328;
									line-height: 38rpx;
									font-size: 28rpx;
									top: 38rpx;
									font-weight: 700;
									font-family: Arial;
								}
								
								&-topCoupons {
									font-size: 64rpx;
									// width: 64px;
									text-align: center; 
									line-height: 36px; 
									font-weight: 700;
									color: #cc2328;
									font-family: Arial;
								}
								
								&-bottom {
									text-align: center; 
									font-size: 24rpx; 
									transform: scale(0.66);
									display: inline-block;
									line-height: 22rpx;
									color: #cc2328;
									font-family: PingFang SC;
								}
							}
							
						}
					}
				}
			}
			
			// cc 公共布局 底部背景+左右内边距
			.recommend-item-bg {
				background-color: #F6F3FC;
				padding: 28rpx 32rpx 0;
				box-sizing: border-box;
				display: flex;
				position: relative;
				flex-direction: column;
				justify-content: space-between;
			}
			
			// cc 专题顶部标题组件的样式
			.item-top {
				margin-bottom: 24rpx;
			}
			
			// cc 爆款推荐
			&-hotRecommend {
				width: 750rpx;
				padding-top: 0 !important;
				
				&-box {
					width: 686rpx;
					display: inline-block;
					border-radius: 20rpx;
					padding-top: 28rpx;
					background-repeat: no-repeat;
					// background-size: 686rpx, 552rpx, contain;
					background-image: linear-gradient(to bottom, #FEF0DD 0%, #FFFFFF 100%);
					
					.hotRecommend_scroll {
						white-space: nowrap;
						padding: 0 32rpx;
						width: 686rpx;
						height: 424rpx;
						box-sizing: border-box;
						margin-bottom: 32rpx;
						overflow: hidden;
						border-radius: 16rpx;
						
						::-webkit-scrollbar {
							display: none;
						}
						
						.hotRecommend-item {
							width: 248rpx;
							height: 424rpx;
							border-radius: 16rpx;
							overflow: hidden;
							margin-right: 24rpx;
							display: inline-block;
							background-size: 100% 100%;
							position: relative;
							
							&:last-child {
								margin-right: 0rpx;
							}
							
							&-title {
								height: 58rpx;
								display: flex;
								flex-direction: row;
								justify-content: flex-start;
								align-items: center;
								position: absolute;
								left: 0;
								bottom: 0;
								padding: 10rpx;
								width: 248rpx;
								box-sizing: border-box;
								background-image: linear-gradient(to bottom, rgba(0, 0, 0, 0), rgba(0, 0, 0, .5));
								border-radius: 16rpx;
								
								&-icon {
									width: 48rpx;
									height: 48rpx;
									border-radius: 20rpx;
									margin-right: 6rpx;
								}
								
								&-text {
									color: #fff;
									white-space: nowrap;
									overflow: hidden;
									text-overflow: ellipsis;
									font-weight: 500;
									flex: 1;
									font-size: 24rpx;
								}
							}
						}
					}
				}
			}
			
			// cc 新游首发
			&-firstPublish {
				width: 750rpx;
				
				&-box {
					width: 686rpx;
					padding-top: 28rpx;
					display: inline-block;
					border-radius: 20rpx;
					background-color: #FFFFFF;
					
					@keyframes firstPunlishScroll {
						0%{
							left: 0rpx;
						}
						
						100% {
							left: -1932rpx;
						}
					}
					
					.firstPublish-layout {
						width: 622rpx;
						height: 584rpx;
						margin-left: 32rpx;
						padding-bottom: 32rpx;
						box-sizing: border-box;
						overflow: hidden;
						
						&-box {
							animation: firstPunlishScroll 30s infinite linear;
							position: relative;
							width: 2576rpx;
							height: 552rpx;
							display: flex;
							flex-direction: row;
						}
						
						&-item {
							width: 622rpx;
							height: 552rpx;
							margin-right: 22rpx;
						}
					}
				}
			}
			
			// cc 试玩赚金
			&-gameDemos {
				width: 750rpx;
				
				&-box {
					width: 686rpx;
					padding-top: 28rpx;
					display: inline-block;
					border-radius: 20rpx;
					background-color: #FFFFFF;
					
					.gameDemos_scroll {
						width: 622rpx;
						height: 432rpx;
						margin-left: 32rpx;
						margin-bottom: 32rpx;
						white-space: nowrap;
						
						::-webkit-scrollbar {
							display: none;
						}
						
						&-box {
							display: inline-block;
							flex-direction: column;
							width: 120rpx;
							margin-right: 24rpx;
							
							&:last-child {
								margin-right: 0rpx;
							}
						}
					}
				}
			}
			
			// cc 热门榜
			&-hotRank {
				width: 750rpx;
				
				&-box {
					width: 686rpx;
					padding-top: 28rpx;
					display: inline-block;
					border-radius: 20rpx;
					background-color: #FFFFFF;
				}
			}
			
			// cc 网易/腾讯专题
			&-special {
				width: 750rpx;
				
				&-box {
					width: 686rpx;
					display: inline-block;
					border-radius: 20rpx;
					padding-top: 28rpx;
					background-color: #FFFFFF;
					
					.special_scroll {
						width: 622rpx;
						height: 192rpx;
						margin: 24rpx 0 32rpx 32rpx;
						white-space: nowrap;
						overflow: hidden;
						
						::-webkit-scrollbar {
							display: none;
						}
						
						&-item {
							display: inline-block;
							width: 120rpx;
							margin-right: 24rpx;
							
							&:last-child {
								margin-right: 0rpx;
							}
						}
					}
				}
				
				&::before {
					content: '';
					width: 686rpx;
					position: absolute;
					display: inline-block;
					border-radius: 20rpx;
					transform: translateY(-28rpx);
					background-color: #FFFFFF;
				}
				
				
			}
			
			// cc 画质精选
			&-choicenessGame {
				width: 750rpx;
				
				&-box {
					width: 686rpx;
					padding-top: 28rpx;
					display: inline-block;
					border-radius: 20rpx;
					background-color: #FFFFFF;
					
					.choicenessGame_scroll {
						white-space: nowrap;
						padding: 0 32rpx;
						width: 686rpx;
						height: 424rpx;
						box-sizing: border-box;
						margin-bottom: 32rpx;
						overflow: hidden;
						border-radius: 16rpx;
						
						::-webkit-scrollbar {
							display: none;
						}
						
						.choicenessGame-item {
							width: 248rpx;
							height: 424rpx;
							border-radius: 16rpx;
							overflow: hidden;
							margin-right: 24rpx;
							display: inline-block;
							background-size: 100% 100%;
							position: relative;
							box-sizing: border-box;
							
							&:last-child {
								margin-right: 0rpx;
							}
							
							&-title {
								height: 182rpx;
								display: flex;
								flex-direction: column;
								justify-content: space-between;
								align-items: center;
								position: absolute;
								left: 0;
								bottom: 0;
								padding: 20rpx;
								padding-top: 60rpx;
								width: 248rpx;
								box-sizing: border-box;
								background-image: linear-gradient(to bottom, rgba(0, 0, 0, 0), rgba(0, 0, 0, .8));
								border-radius: 16rpx;
								
								&-text {
									color: #fff;
									white-space: nowrap;
									overflow: hidden;
									text-overflow: ellipsis;
									font-weight: 500;
									flex: 1;
									font-size: 24rpx;
								}
								
								&-btn {
									background-color: rgba(255, 255, 255, .3);
									border-radius: 24rpx;
									width: 104rpx;
									height: 48rpx;
									text-align: center;
									color: #FF5927;
									font-family: PingFang SC;
									line-height: 48rpx;
								}
							}
						}
					}
				}
			}
			
			// cc 经典传奇 H5精选
			&-classicsGame,
			&-choicenessH5 {
				width: 750rpx;
				justify-content: flex-start !important;
				
				&-box{
					width: 686rpx;
					display: flex;
					padding-top: 28rpx;
					flex-direction: column;
					border-radius: 20rpx;
					background-color: #FFFFFF;
					
					.classicsGame-special,
					.choicenessH5-special {
						margin-bottom: 32rpx;
					}
				}
			}
			
			// cc 热门分类
			&-classify {
				width: 750rpx;
				justify-content: flex-start !important;
				padding-bottom: 40rpx !important;
				
				&-box{
					width: 686rpx;
					display: flex;
					// height: 256rpx;
					padding-top: 28rpx;
					flex-direction: column;
					border-radius: 20rpx;
					background: linear-gradient(to bottom, #FEF0DD, rgba(255, 255, 255, 1));
					
					.classify-box {
						display: flex;
						flex-direction: row;
						flex-wrap: wrap;
						justify-content: flex-start;
						width: 100%;
						
						&-item {
							margin-bottom: 32rpx;
							width: 25%;
							height: 48rpx;
							display: flex;
							justify-content: center;
							align-items: center;
							
							&-content {
								margin: 0 auto;
								line-height: 48rpx;
								text-align: center;
								background-color: #FCF3F3;
								border-radius: 24rpx;
								color: #666666;
								font-size: 28rpx;
								// display: inline-block;
								width: 132rpx;
							}
						}
					}
				}
			}
			
			// cc 没有更多了
			&-noMore {
				width: 750rpx;
				text-align: center;
				line-height: 32rpx;
				padding: 0 !important;
				padding-bottom: 40rpx !important;
				color: #CCCCCC;
				font-size: 24rpx;
				font-family: PingFang SC;
			}
		}
	}
</style>