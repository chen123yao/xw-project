<template>
	<view class="hotGame_layout">
		<!-- cc 背景图片 固定定位 -->
		<view class="hotGame-bg">
			<image v-if="hotGameData[0]" class="hotGame-bg-img" :src="hotGameData[0].hot_image" mode="scaleToFill" />
			<view :style="{width: '750rpx', height: $store.state.myHeight + 'rpx', position: 'absolute', top: '0', left: '0', backgroundColor: 'rgba(0, 0, 0, .3)' }"></view>
			<view v-if="showShade" :style="{width: '750rpx', height: $store.state.myHeight + 'rpx', position: 'absolute', top: '0', left: '0', backgroundColor: '#F6F3FC' }"></view>
		</view>
		
		<!-- cc 精品好游scroll -->
		<scroll-view class="hotGame" scroll-y style="width: 100%;" v-if="hotGameCount">
			
			<!-- cc 顶部标题导航栏站位元素 -->
			<view :style="{ width: '750rpx', height: $store.state.statusBarHeight + 160 + 'rpx' }"></view>
			
			<!-- cc 精品好游 -->
			<view class="hotGame-item" v-for="(item, index) in hotGameData" :key="index" :style="{ background: index == 0 ? 'linear-gradient(to bottom, transparent, #F6F3FC)' : '#F6F3FC' }"
				@click="handleRouter(`/pages/view/gameDetail/gameDetail?gameId=${ item.game_id }`)" >
				<image class="hotGame-item-hotImg" :src="item.hot_image" mode="scaleToFill"></image>
				<view class="hotGame-item-box" :style="{ background: index == 0 ? 'linear-gradient(to bottom, transparent, rgba(255,255,255,0.3))' : '#FFFFFF' }">
					<view class="hotGame-item-tags">
						<image class="hotGame-item-tagImage" src="@/static/images/index/tagst.png" mode="scaleToFill" />
						<text class="hotGame-item-tag">#{{ item.one_word.replace(/\n/g, '') }}</text>
					</view>
					
					<view class="hotGame-item-detail">
						<text class="hotGame-item-title">{{ item.gamename }}</text>
						<view class="hotGame-item-star">
							<image class="hotGame-item-star-img" src="@/static/images/index/hot_new.png"></image>
							<text class="hotGame-item-star-text">{{ item.star_cnt }}</text>
						</view>
					</view>
					
					<view class="hotGame-item-info">
						<view v-if="item.game_start_time" class="hotGame-item-info-server">
							<text class="hotGame-item-info-server-time">{{ item.game_start_time | dateFormat('hh:mm') }}</text>
							<text class="hotGame-item-info-server-text"> 开服 | </text>
						</view>
						<text v-if="item.classify == 5" class="hotGame-item-info-server-text">H5 </text>
						<text v-if="index < 3" class="hotGame-item-info-server-type" v-for="(value, index) in item.type" :key="index">{{ value }}</text>
						<text class="hotGame-item-info-server-text"> | 已有{{ item.popularity_cnt }}人在玩</text>
					</view>
				</view>
			</view>
			
			<u-loadmore bg-color="#F6F3FC" height="30" marginTop="0" fontSize="24" marginBottom="32" :status="loadingStatus" loadingIcon="spinner" @loadmore="loadMoreGameData" />
		</scroll-view>
	</view>
</template>

<script>
	export default {
		props:{
			// cc 是否利用遮罩盖住后面的高斯模糊背景 防止底部滚动之后显示出奇怪的背景颜色
			showShade: {
				type: Boolean,
				default: false // 默认不遮盖  一旦滚动到一定的距离之后再动态遮盖
			},
			isReachBottom: {
				type: Boolean,
				default: false // 是否触底加载更多 默认false
			}
		},
		data() {
			return {
				// cc 精品好游数据
				hotGameData: [],
				hotGameCount: 0,
				// cc 获取数据时的参数
				formData:{
					is_mp4: 1,
					offset: 10,
					page:1
				},
				// cc 动态加载 加载状态
				loadingStatus: 'loading',
				isLoading: false
			}
		},
		// 组件挂载到实例生命周期函数
		mounted() {
			console.log('hotGame-mounted')
			// cc 获取精品好游数据
			this.getHotGameData()
		},
		watch: {
			isReachBottom(val) {
				if (val) {
					this.loadMoreGameData()
				}
			},
		},
		methods: {
			// cc 获取精品好游数据
			getHotGameData() {
				this.$api.get('/game/multilistnew', {
					client_id: this.$store.state.client_id,
					...this.formData
				}).then(res => {
					console.log('hotGameData', res);
					
					this.hotGameData = this.hotGameData.concat(res.data.data.list)  
					this.hotGameCount = res.data.data.count
					this.isLoading = false
					if (Object.keys(this.hotGameData).length >= this.hotGameCount) {
						this.loadingStatus = 'nomore'
					}
					// this.hotGameData.forEach((item) => { 
					// 	// item.mp4_url_new = common.setVideoUrl(item.mp4_url);
					// 	// item.one_word = item.one_word.replace(/\n/g, '')
						
					// 	console.log('one_word', item.one_word);
					// })
				})
			},
			// cc 动态加载响应事件
			loadMoreGameData() {
				if (Object.keys(this.hotGameData).length < this.hotGameCount && !this.isLoading) {
					this.formData.page++
					this.isLoading = true
					this.loadingStatus = 'loading'
					this.getHotGameData()
				} else {
					this.loadingStatus = 'nomore'
					this.isLoading = false
				}
			},
			// cc 点击跳转页面
			handleRouter(url) {
				console.log('handleRouter', url);
				
				uni.navigateTo({
					url
				})
			}
		}
	}
</script>

<style lang="scss" scoped>
	.hotGame_layout {
		width: 100%;
		height: 100%;
		
		.hotGame-bg {
			position: fixed;
			top: 0;
			width: 100%;
			height: 100%;
			
			&-img {
				width: 100%;
				height: 100%;
				transform: scale(1.2);
				filter: blur(20rpx);
			}
		}
		
		.hotGame {
			
			&-item {
				width: 750rpx;
				display: flex;
				flex-direction: column;
				padding: 0 32rpx 40rpx;
				box-sizing: border-box;
				
				&-hotImg {
					width: 686rpx;
					height: 362rpx;
					border-radius: 20rpx 20rpx 0 0;
				}
				
				&-box {
					width: 686rpx;
					height: 186rpx;
					display: flex;
					flex-direction: column;
					padding: 18rpx 24rpx 24rpx;
					box-sizing: border-box;
					border-radius: 0 0 20rpx 20rpx;
					justify-content: space-between;
				}
				
				&-tags {
					display: flex;
					flex-direction: row;
					align-items: center;
					position: relative;
					height: 32rpx;
				}
				
				&-tagImage {
					width: 16rpx;
					height: 16rpx;
					position: absolute;
					left: 16rpx;
					top: 8rpx;
				}
				
				&-tag {
					white-space: nowrap;
					overflow: hidden;
					text-overflow: ellipsis;
					line-height: 32rpx;
					background-color: #F4F4F4;
					border-radius: 16rpx;
					box-sizing: border-box;
					padding: 2rpx 3rpx 2rpx 40rpx;
				}
				
				&-detail {
					display: flex;
					flex-direction: row;
					width: 100%;
					height: 64rpx;
					justify-content: space-between;
					overflow: hidden;
				}
				
				&-title {
					color: #1C1C1C;
					font-size: 40rpx;
					font-family: PingFang SC;
					font-weight: 600;
					line-height: 56rpx;
					white-space: nowrap;
					flex: 1;
					overflow: hidden;
					text-overflow: ellipsis;
					align-self: flex-end;
				}
				
				&-star {
					height: 60rpx;
					align-self: flex-start;
					
					&-img {
						width: 32rpx;
						height: 40rpx;
						margin-right: 24rpx;
					}
					
					&-text {
						font-size: 44rpx;
						color: #FF5927;
						line-height: 60rpx;
						font-family: PingFang SC;
						font-weight: 600;
					}
				}
			
				&-info {
					display: flex;
					flex-direction: row;
					justify-content: flex-start;
					align-items: center;
					font-size: 24rpx;
					
					&-server {
						display: flex;
						flex-direction: row;
						align-items: center;
						
						&-time {
							color: #FF5927;
						}
						
						&-type {
							color: #666666;
							margin-right: 8rpx;
						}
						
						&-text {
							color: #666666;
						}
					}
				}
			}
		}
	}
</style>