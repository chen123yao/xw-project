<template>
	<view class="welfareGame_layout">
		<!-- cc 背景图片 固定定位 -->
		<view class="welfareGame-bg">
			<image v-if="welfareGameData[0]" class="welfareGame-bg-img" :src="welfareGameData[0].image" mode="scaleToFill" />
			<view :style="{width: '750rpx', height: $store.state.myHeight + 'rpx', position: 'absolute', top: '0', left: '0', backgroundColor: 'rgba(0, 0, 0, .3)' }"></view>
			<view v-if="showShade" :style="{width: '750rpx', height: $store.state.myHeight + 'rpx', position: 'absolute', top: '0', left: '0', backgroundColor: '#F6F3FC' }"></view>
		</view>
		
		<!-- cc 福利手游scroll -->
		<scroll-view class="welfareGame" scroll-y style="width: 100%;" v-if="welfareGameDataCount">
			
			<!-- cc 顶部标题导航栏站位元素 -->
			<view :style="{ width: '750rpx', height: $store.state.statusBarHeight + 160 + 'rpx' }"></view>
			
			<!-- cc 福利手游首个标题 -->
			<view v-if="welfareGameData" class="welfareGame-firstItem">
				<!-- cc 调用专题组件 -->
				<itemSpecial :specialData="welfareGameData[0]" :specialType="3"></itemSpecial>
				<!-- cc 部分专题游戏展示 -->
				<scroll-view v-if="welfareGameData[0].game_list_count" class="special_scroll" scroll-x="true">
					<view v-if="index < 6" class="special_scroll-item" v-for="(value, index) in welfareGameData[0].game_list" :key="index">
						<vue-gameIcon :iconTitleStyle="{ fontSize: '24rpx', color: '#666666', fontWeight: '400', marginTop: '4rpx', height: '68rpx' }"
							:iconData='value'></vue-gameIcon>
					</view>
				</scroll-view>
			</view>
			
			<!-- cc 福利手游 -->
			<view class="welfareGame-item" v-for="(item, index) in welfareGameData.slice(1)" :key="index">
				<view class="welfareGame-item-box">
					<!-- cc 顶部标题组件 -->
					<itemTop class="item-top" :top_title="item.topic_name" :img_height="32" :right_url="`/pages/index/children/specialDetail?specialName=${ item.topic_name }&specialId=${ item.topic_id }`"></itemTop>
					<!-- cc 调用专题组件 -->
					<itemSpecial :specialData="item" :specialType="index % 2 == 1 ? 2 : 1"></itemSpecial>
					<!-- cc 部分专题游戏展示 -->
					<scroll-view v-if="index % 2 == 0" class="special_scroll" scroll-x="true">
						<view v-if="index < 6" class="special_scroll-item" v-for="(value, index) in item.game_list" :key="index">
							<vue-gameIcon :iconTitleStyle="{ fontSize: '24rpx', color: '#666666', fontWeight: '400', marginTop: '4rpx', height: '68rpx' }"
								:iconData='value'></vue-gameIcon>
						</view>
					</scroll-view>
					<!-- cc 专题前三游戏 打分布局 -->
					<view v-else class="gameItem-box">
						<vue-gameItem v-if="index < 3 && gameColorArray[index]" :itemData='value' :contentTagsColor="[gameColorArray[(index) * 2],gameColorArray[(index) * 2 + 1]]" :itemWidth="686" :tagType="5"
							:itemRankIndex="index" :itemBMargin="32" :iconWidth="120" v-for="(value, index) in item.game_list" :key="index"></vue-gameItem>
					</view>
				</view>
			</view>
		</scroll-view>
	</view>
</template>

<script>
	import itemTop from '../components/index-item-top.vue'
	import itemSpecial from '../components/index-item-special.vue'
	
	export default {
		components: {
			itemTop,
			itemSpecial
		},
		props:{
			// cc 是否利用遮罩盖住后面的高斯模糊背景 防止底部滚动之后显示出奇怪的背景颜色
			showShade: {
				type: Boolean,
				default: false // 默认不遮盖  一旦滚动到一定的距离之后再动态遮盖
			}
		},
		data() {
			return {
				// cc 福利手游数据
				welfareGameData: [],
				welfareGameDataCount: 0,
				// cc 获取数据时的参数
				formData:{
					new_special: 1,
					offset: 10,
					page:1
				},
				
				// cc 新开服游戏列表、游戏列表 item tags color
				gameColorArray: [],
			}
		},
		// 组件挂载到实例生命周期函数
		mounted() {
			console.log('welfareGame-mounted')
			// cc 获取福利手游数据
			this.getwelfareGameData()
			
			// cc 给页面中显示的gameItem tags color 随机
			if (true) {
				// console.log('gameColorArrayLength: ', res.data.data.list.length);
				let gameColorIndexArray = [ ...this.$common.getRandomColorIndexArray([], 6) ]
				// console.log('gameColorIndexArray: ', this.gameColorIndexArray);
				this.gameColorArray = { ...this.$common.getRandomColorArray(gameColorIndexArray) }
				// console.log('gameColorArray: ', this.gameColorArray);
			}
		},
		methods: {
			// cc 获取福利手游数据
			getwelfareGameData() {
				this.$api.get('game/extend_category', {
					client_id:this.$store.state.client_id,
					extend_type:2,
					...this.formData
				}).then(res=>{
					// this.getRandomColor() 
					this.welfareGameData = res.data.data.list
					this.welfareGameDataCount = res.data.data.count
				})
			}
		}
	}
</script>

<style lang="scss" scoped>
	.welfareGame_layout {
		width: 100%;
		height: 100%;
		
		// cc 专题顶部标题组件的样式
		.item-top {
			margin-top: 28rpx;
			margin-bottom: 24rpx;
		}
		
		.welfareGame-bg {
			position: fixed;
			top: 0;
			width: 100%;
			height: 100%;
			
			&-img {
				width: 100%;
				height: 100%;
				transform: scale(1.2);
				filter: blur(20rpx);
			}
		}
		
		.welfareGame {
			
			.special_scroll {
				width: 686rpx;
				// height: 192rpx;
				padding: 24rpx 32rpx 0;
				box-sizing: border-box;
				white-space: nowrap;
				overflow: hidden;
				background-color: #ffffff;
				border-radius: 0 0 20rpx 20rpx;
				
				::-webkit-scrollbar {
					display: none;
				}
				
				&-item {
					display: inline-block;
					width: 120rpx;
					margin-right: 24rpx;
					
					&:last-child {
						margin-right: 0rpx;
					}
				}
			}
			
			.gameItem-box {
				padding-top: 32rpx;
			}
			
			&-firstItem {
				width: 750rpx;
				display: flex;
				flex-direction: column;
				padding: 0 32rpx 32rpx;
				box-sizing: border-box;
				background: linear-gradient(to bottom, transparent, #F6F3FC);
			}
			
			&-item {
				width: 750rpx;
				display: flex;
				flex-direction: column;
				padding: 0 32rpx 32rpx;
				box-sizing: border-box;
				background: #F6F3FC;
				
				&-box {
					background-color: #fff;
					border-radius: 20rpx;
				}
			}
		}
	}
</style>