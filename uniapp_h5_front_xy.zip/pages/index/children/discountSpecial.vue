<template>
	<view class="discountSpecial_layout">
		<!-- cc 背景图片 固定定位 -->
		<view class="discountSpecial-bg">
			<image v-if="discountSpecialData[0]" class="discountSpecial-bg-img" :src="discountSpecialData[0].hot_image" mode="scaleToFill" />
			<view :style="{width: '750rpx', height: $store.state.myHeight + 'rpx', position: 'absolute', top: '0', left: '0', backgroundColor: 'rgba(0, 0, 0, .3)' }"></view>
			<view v-if="showShade" :style="{width: '750rpx', height: $store.state.myHeight + 'rpx', position: 'absolute', top: '0', left: '0', backgroundColor: '#F6F3FC' }"></view>
		</view>
		
		<!-- cc 折扣专题scroll -->
		<scroll-view class="discountSpecial" scroll-y style="width: 100%;" v-if="discountSpecialCount" @scrolltolower="loadMoreGameDataSpecia">
			
			<!-- cc 顶部标题导航栏站位元素 -->
			<view :style="{ width: '750rpx', height: $store.state.statusBarHeight + 160 + 'rpx' }"></view>
			
			<!-- cc 折扣专题 -->
			<view class="discountSpecial-item" :class="!index && 'discountSpecial-firstItem'" v-for="(item, index) in discountSpecialData" :key="index">
				<!-- cc 第一个游戏 -->
				<view v-if="!index" class="discountSpecial-firstItem-first" @click="handleRouter(`/pages/view/gameDetail/gameDetail?gameId=${ item.game_id }`)">
					<image class="discountSpecial-firstItem-first-img" mode="scaleToFill" :src="item.hot_image"></image>
					<view class="discountSpecial-firstItem-shade"></view>
				</view>
				<!-- cc 其余游戏 -->
				<view v-else class="discountSpecial-item-box">
					<!-- cc 专题前三游戏 打分布局 -->
					<vue-gameItem v-if="gameColorArray[2 * index]" :itemData='item' :contentTagsColor="[gameColorArray[(index) * 2],gameColorArray[(index) * 2 + 1]]" :tagType="3" :isShowMaxWidth="true" :itemBMargin="32" 
						:iconWidth="120"></vue-gameItem>
				</view>
			</view>
			
			<u-loadmore bg-color="#F6F3FC" height="30" marginTop="0" fontSize="24" marginBottom="32" :status="loadingStatus" loadingIcon="spinner" @loadmore="loadMoreGameDataSpecia"/>
		</scroll-view>
	</view>
</template>

<script>
	export default {
		props:{
			// cc 是否利用遮罩盖住后面的高斯模糊背景 防止底部滚动之后显示出奇怪的背景颜色
			showShade: {
				type: Boolean,
				default: false // 默认不遮盖  一旦滚动到一定的距离之后再动态遮盖
			},
			isReachBottom: {
				type: Boolean,
				default: false // 是否触底加载更多 默认false
			}
		},
		data() {
			return {
				// cc 折扣专题数据
				discountSpecialData: [],
				discountSpecialCount: 0,
				// cc 获取数据时的参数
				formData:{
					offset: 10,
					page:1
				},
				// cc 动态加载 加载状态
				loadingStatus: 'loading',
				isLoading: false,
				
				// cc 新开服游戏列表、游戏列表 item tags color
				gameColorIndexArray: [],
				gameColorArray: []
			}
		},
		// 组件挂载到实例生命周期函数
		mounted() {
			console.log('discountSpecial-mounted')
			// cc 获取折扣专题数据
			this.getDiscountSpecialData()
		},
		watch: {
			isReachBottom(val) {
				if (val) {
					this.loadMoreGameData()
				}
			},
		},
		methods: {
			// cc 获取折扣专题数据
			getDiscountSpecialData() {
				this.$api.get('/game/custom_category', {
					client_id: this.$store.state.client_id,
					...this.formData
				}).then(res => {
					console.log('discountSpecialData', res);
					
					this.discountSpecialData = this.discountSpecialData.concat(res.data.data.list[0].game_list)  
					this.discountSpecialCount = res.data.data.list[0].game_list_count
					this.isLoading = false
					if (Object.keys(this.discountSpecialData).length >= this.discountSpecialCount) {
						this.loadingStatus = 'nomore'
					}
					
					if (res.data.data.list[0].game_list.length) {
						// console.log('gameColorArrayLength: ', res.data.data.list.length);
						this.gameColorIndexArray = [ ...this.$common.getRandomColorIndexArray(this.gameColorIndexArray, res.data.data.list[0].game_list.length * 2) ]
						// console.log('gameColorIndexArray: ', this.gameColorIndexArray);
						this.gameColorArray = { ...this.$common.getRandomColorArray(this.gameColorIndexArray) }
						// console.log('gameColorArray: ', this.gameColorArray);
					}
					
					// this.discountSpecialData.forEach((item) => { 
					// 	// item.mp4_url_new = common.setVideoUrl(item.mp4_url);
					// 	// item.one_word = item.one_word.replace(/\n/g, '')
						
					// 	console.log('one_word', item.one_word);
					// })
				})
			},
			loadMoreGameDataSpecia() {
				if (Object.keys(this.discountSpecialData).length < this.discountSpecialCount && !this.isLoading) {
					this.formData.page++
					this.isLoading = true
					this.loadingStatus = 'loading'
					this.getDiscountSpecialData()
				} else {
					this.loadingStatus = 'nomore'
					this.isLoading = false
				}
			},
			// cc 点击跳转该游戏详情页面
			handleRouter(url) {
				console.log('handleRouter', url);
				
				uni.navigateTo({
					url
				})
			}
		}
	}
</script>

<style lang="scss" scoped>
	.discountSpecial_layout {
		width: 100%;
		height: 100%;
		
		.discountSpecial-bg {
			position: fixed;
			top: 0;
			width: 100%;
			height: 100%;
			
			&-img {
				width: 100%;
				height: 100%;
				transform: scale(1.2);
				filter: blur(20rpx);
			}
		}
		
		.discountSpecial {
			background-color: #F6F3FC;
			height: 100%;
			
			&-item {
				width: 750rpx;
				display: flex;
				flex-direction: column;
				padding: 0 0 40rpx;
				box-sizing: border-box;
				background-color: #F6F3FC;
			}
		
			&-firstItem {
				width: 750rpx;
				padding: 0 !important;
				
				&-first {
					width: 100%;
					height: 484rpx;
					background-color: #F6F3FC;
					position: relative;
					
					&-img {
						width: 100%;
						height: 100%;
					}
				}
				
				&-shade {
					width: 750rpx;
					height: 63rpx;
					background-color: #F6F3FC;
					border-top-left-radius: 62rpx;
					position: absolute;
					left: 0;
					bottom: -1rpx;
					
					&::after {
						content: '';
						background-image: url('@/static/images/index/right_bottom_radius.png');
						width: 62rpx;
						height: 64rpx;
						background-size: 100% 100%;
						position: absolute;
						right: 0;
						top: -63rpx;
					}
				}
			}
		}
	}
</style>