<template>
	<view class="item-top_layout">
		<view class="top-left">
			<text class="top-left-title">{{ top_title }}</text>
			<image v-if="top_img" class="top-left-img" :src="top_img" mode="heightFix" :style="{ height: img_height + 'rpx', marginTop: img_top && (img_top + 'rpx') }"></image>
		</view>
		
		<text v-if="isMore" class="top-right" @click="handleRouter(right_url)">更多</text>
	</view>
</template>

<script>
	export default {
		props: {
			// cc 顶部专题名称
			top_title: {
				type: String,
				default: '专题名称'
			},
			// cc 顶部专题名称对应图标
			top_img: {
				type: String,
				default: '' // 
			},
			// cc	专题点击之后跳转页面
			right_url: {
				type: String,
				default: '' //
			},
			// cc 顶部专题对应图标 距离顶部的距离
			img_height: {
				type: Number,
				default: 0 // rpx
			},
			// cc 顶部专题对应图标 距离顶部的距离
			img_top: {
				type: Number,
				default: 0 // rpx
			},
			// cc 是否显示更多按钮 默认显示
			isMore: {
				type: Boolean,
				default: true
			},
			// cc 是否做跳转特殊处理  默认否
			isSpecial: {
				type: Boolean,
				default: false
			}
		},
		methods:{
			handleRouter(url) {
				console.log(url);
				if (this.isSpecial) {
					if(this.$common.isLogin()){
						uni.setStorage({
							key: 'active',
							data: 1
						})
						
						uni.switchTab({
							url
						})
					}
				} else {
					uni.navigateTo({
						url: url
					})
				}
			}
		}
	}
</script>

<style lang="scss">
	.item-top_layout {
		width: 686rpx;
		height: 44rpx;
		display: flex;
		flex-direction: row;
		justify-content: space-between;    
		box-sizing: border-box;
		align-items: center;
		white-space: nowrap;
		padding: 0 32rpx;
		// z-index: 999;
		
		.top-left {
			height: 100%;
			display: flex;
			flex-direction: row;
			align-items: center;
			
			&-title {
				font-size: 32rpx;
				color: #1C1C1C;
				line-height: 34rpx;
				font-weight: 600;
				font-family: PingFang SC;
				display: block;
			}
			
			&-img {
				display: block;
				margin-left: 12rpx;
			}
		}
		
		.top-right {
			display: block;
			height: 40rpx;    
			line-height: 40rpx;
			font-size: 28rpx;
			font-family: PingFang SC;
			font-weight: 500;
			color: #999999;
		}
			
	}
</style>