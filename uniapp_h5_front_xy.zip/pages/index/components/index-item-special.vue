<template>
	<view class="item-special_layout" :class="specialType == 2 ? 'specialBRadius' : specialType == 3 ? 'item-special_firstLayout' : ''" 
		:style="{ 'backgroundImage': 'url(' + specialData.image + ')' }" @click="handleRouter(specialData.game_id)">
		<view v-if="specialType == 1 || specialType == 3" class="special-box">
			<image v-if="specialType == 1" class="special-box-icon" :src="specialData.new_icon || specialData.icon"></image>
			<view class="special-box-title" :class="specialType == 3 && 'special-box-firstTitle'">
				<text class="special-box-text">{{specialData.game_name}}</text>
				<text class="special-box-text">{{specialData.one_word}}</text>
			</view>
		</view>
		<view v-if="specialType == 3" class="special-btn" @click="specialRouter(specialData.topic_name, specialData.game_id)">查看更多
			<text class="special-btn-right">»</text>
		</view>
	</view>
</template>

<script>
	export default {
		props: {
			// cc 专题组件数据
			specialData: {
				type: Object,
				default: () => {}
			},
			// cc 专题组件类型 1普通
			specialType: {
				type: Number,
				default: 1 // 
			}
		},
		methods:{
			handleRouter(id) {
				if (this.specialType == 3) {
					return
				}
				uni.navigateTo({
					url: `/pages/view/gameDetail/gameDetail?gameId=${ id }`
				})
			},
			//专题跳转
			specialRouter(name, id) {
				uni.navigateTo({
					url: `/pages/index/children/specialDetail?specialName=${ name }&specialId=${ id }`
				})
			},
		}
	}
</script>

<style lang="scss">
	.specialBRadius {
		border-radius: 12rpx;
	}
	
	.item-special_firstLayout {
			width: 686rpx !important;
			margin-left: 0 !important;
	}
	
	.item-special_layout {
		width: 622rpx;
		height: 294rpx; 
		box-sizing: border-box;
		margin-left: 32rpx;
		border-top-left-radius: 12rpx;
		border-top-right-radius: 12rpx;
		position: relative;
		// z-index: 999;
		background-size: 100% 100%;
		
		.special-box {
			background-color: rgba(0,0,0,0.5);
			width: 100%;
			height: 100rpx;
			position: absolute;
			bottom: 0;
			left: 0;
			
			&-icon {
				width: 108rpx;
				height: 108rpx;
				position: absolute;
				left: 20rpx;
				bottom: 16rpx;
			}
			
			&-title {
				height: 76rpx;
				width: calc(100% - 152rpx);
				position: absolute;
				left: 152rpx;
				bottom: 12rpx;
				display: flex;
				flex-direction: column;
				justify-content: space-between;
			}
			
			&-firstTitle { 
				width: calc(100% - 250rpx) !important;
				left: 40rpx !important;
			}
			
			&-text {
				font-size: 28rpx;
				color: #FFFFFF;
				overflow: hidden;
				white-space: nowrap;
				text-overflow: ellipsis;
				
				&:last-child {
					font-size: 24rpx;
					color: #E4E4E4;
				}
			}
		}
		
		.special-btn {
			position: absolute;
			width: 218rpx;
			height: 62rpx;
			background: #FF5927;
			bottom: 16rpx;
			right: -8rpx;
			color: #FFEBF2;
			font-size: 28rpx;
			font-family: PingFang SC;
			font-weight: 500;
			line-height: 62rpx;
			text-align: center;
			border-radius: 30rpx 0 0 30rpx;
			display: flex;
			justify-content: center;
			align-items: center;
			
			&::after {
				content: '';
				background: rgba(255, 89, 39, .5);
				height: 8rpx;
				width: 8rpx;
				border-top-right-radius: 8rpx;
				position: absolute;
				bottom: 62rpx;
				right: 0;
				font-family: PingFang SC;
			}
			
			&-right {
				font-size: 40rpx;
				line-height: 62rpx;
				height: 62rpx;
				display: inline-block;
				margin-left: 8rpx;
			}
		}
		
		.top-left {
			height: 100%;
			display: flex;
			flex-direction: row;
			align-items: center;
			
			&-title {
				font-size: 32rpx;
				color: #1C1C1C;
				line-height: 34rpx;
				font-weight: 600;
				font-family: PingFang SC;
				display: block;
			}
			
			&-img {
				display: block;
				margin-left: 12rpx;
			}
			
		}
		
		.top-right {
			display: block;
			height: 40rpx;    
			line-height: 40rpx;
			font-size: 28rpx;
			font-family: PingFang SC;
			font-weight: 500;
			color: #999999;
		}
			
	}
</style>