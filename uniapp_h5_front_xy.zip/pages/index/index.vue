<template>
	<view class="container">
		<!-- cc 顶部状态栏预留的位置 -->
		<view class="topTitleStatusBarHeight" :style="{ opacity: statusBarOpacity }"></view>
		
		<!-- cc 首页顶部标题导航栏 固定定位不动 -->
		<view class="topTitel_layout" :style="{ background: topTitleBgc }">
			
			<!-- cc 搜索框、消息 -->
			<vue-topBar left_url="/pages/view/search/search" right_url="/pages/my/myMessage/index" :topBarStyle="topBarStyle"></vue-topBar>
			
			<!-- cc 标题导航栏 -->
			<view class="titleList_layout">
				<u-tabs :list="titleList" :duration="200" :lineColor="lineColor" :activeStyle="activeStyle" :inactiveStyle="inactiveStyle" lineWidth="48rpx" lineHeight="6rpx" @change="change"></u-tabs>
			</view>
		</view>
		
		<!-- cc 首页swiper部分 -->
		<view class="content_layout" v-if="$store.state.client_id">
			<!-- cc 首页推荐 -->
			<recommend v-show="currentPage == 0" ref="recommend" :showShade="showShade"></recommend>
			<!-- cc 精品好游 -->
			<hotGame v-show="currentPage == 1" :isReachBottom="isReachBottom" ref="hotGame" :showShade="showShade"></hotGame>
			<!-- cc 福利手游 -->
			<welfareGame v-show="currentPage == 2" ref="welfareGame" :showShade="showShade"></welfareGame>
			<!-- cc 折扣专题 -->
			<discountSpecial v-show="currentPage == 3" ref="discountSpecial" :showShade="showShade"></discountSpecial>
		</view>
	</view>
</template>

<script>
	import recommend from "./children/recommend.vue"
	import hotGame from "./children/hotGame.vue"
	import welfareGame from "./children/welfareGame.vue"
	import discountSpecial from "./children/discountSpecial.vue"
	
	export default {
		// cc 引入子组件
		components: {
			recommend, // 首页推荐
			hotGame, // 精品好游
			welfareGame, // 福利手游
			discountSpecial // 折扣专题
		},
		data() {
			return {
				titleList: [{
						id: 0,
						name: '推荐'
					},
					{
						id: 1,
						name: '精品好游'
					},
					{
						id: 2,
						name: '福利手游'
					},
					{
						id: 3,
						name: '折扣专题'
					}
				],
				// cc 当前页面下标
				currentPage: 0,
				// cc 是否页面触底
				isReachBottom: false,
				// cc 是否能切换标题导航栏
				isCanChange: false,
				scrollMove: 0,
				lineColor: '#fff',
				activeStyle: { color: '#fff', fontSize: '34rpx', fontWeight: '700' },
				inactiveStyle: { color: '#fff', fontSize: '34rpx', fontWeight: '400' },
				// cc 顶部状态栏透明度
				statusBarOpacity: 0,
				// cc 顶部title背景色
				topTitleBgc: 'transparent',
				// cc 动态判断是否显示遮盖高斯模糊的背景
				showShade: false,
				// cc 顶部topbar动态样式
				topBarStyle: {
					searchColor: '#fff',
					textColor: '#c1c1c1',
					bellColor:'#fff'
				}
			}
		},
		methods: {
			handleActive(e) {
				this.currentPage = e
			},
			// cc 设置顶部title背景色
			setTopTitleBgc(bgc1, opacity) {
				this.topTitleBgc = bgc1
				this.statusBarOpacity = opacity
			},
			change(event) {
				this.currentPage = event.index
				this.isReachBottom = false
				
				uni.pageScrollTo({
					scrollTop: 0,
					duration: 0
				});
				
				this.showShade = false
			}
		},
		onPageScroll(event) {
			// console.log('onPageScroll', event);
			if (event.scrollTop > 40 / (750 / this.$store.state.myWidth)) {
				this.setTopTitleBgc('#fff', 1)
				
				this.topBarStyle.searchColor = '#C1C1C1'
				this.topBarStyle.textColor = '#C1C1C1'
				this.topBarStyle.bellColor = '#000000'
				this.lineColor = '#FF5927'
				this.activeStyle.color = '#666666'
				this.inactiveStyle.color = '#666666'
				
				if (event.scrollTop > (this.$store.state.statusBarHeight + 500) / (750 / this.$store.state.myWidth)) {
					this.showShade = true
				} else {
					this.showShade = false
				}
			} else {
				this.setTopTitleBgc('transparent', 0)
				
				this.topBarStyle.searchColor = '#FFFFFF'
				this.topBarStyle.textColor = '#C1C1C1'
				this.topBarStyle.bellColor = '#FFFFFF'
				this.lineColor = '#FFFFFF'
				this.activeStyle.color = '#FFFFFF'
				this.inactiveStyle.color = '#FFFFFF'
			}
		},
		// cc 页面级响应事件 触底加载更多 根据不同的页面下标 将当前页面下标设置为该下标
		onReachBottom() {
			this.isReachBottom = true
		}
	}
</script>

<style lang="scss" scoped>
	.container {
		width: 750rpx;
		font-size: 14px;
		background-color: #FFFFFF;
		// height: calc(100vh - 50px - env(safe-area-inset-bottom));
		height: 100vh;
		
		.topTitleStatusBarHeight {
			position: fixed;
			z-index: 1;
			top: 0;
			left: 0;
			width: 750rpx;
			height: env(safe-area-inset-top);
			// transition: opacity .5s;
			background-color: transparent;
			background: linear-gradient(to bottom, #CCCCCC, #FFFFFF);
		}
		
		.topTitel_layout {
			top: env(safe-area-inset-top);
			left: 0;
			z-index: 1;
			width: 750rpx;
			height: 160rpx;
			position: fixed;
			// transition: all .5s;
		}
		
		.titleList_layout {
			width: 100%;
			display: flex; 
			flex-direction: row; 
			justify-content: center;
		}
		
		.contentSwiper_layout {
			width: 100%;
			height: 100%;
			position: fixed;
			top: 0;
			
			.contentSwiper {
				width: 100%;
				height: 100%;
			}
		}
		
		.content_layout {
			// margin-top: 160rpx;
			// height: calc(100vh - 50px - env(safe-area-inset-bottom) - 160rpx);
			padding-bottom: calc(50px + env(safe-area-inset-bottom));
		}
	}
</style>
