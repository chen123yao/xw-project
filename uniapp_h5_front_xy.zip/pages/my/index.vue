<template>
	<view class="my" :style="{paddingTop: $store.state.statusBarHeight + 56 + 'rpx'}">
		<view class="top-title-box" :style="{height:$store.state.statusBarHeight+56+'rpx'}">
			<view class="safeArea-box" :style="{height:$store.state.statusBarHeight+'rpx'}"></view>
			<view class="top-title">
				<view class="titleLeft" :style="{opacity: opacity}">
					<text class="titlename" style="margin-left: 12rpx;" v-if="Object .keys(userInfo).length">{{userInfo.nickname}}</text>
				</view>
				<view class="titleRight">
					<u-icon name="bell" color="#000" size="56" style="margin-left: 12px;"
						@click="handleRouter('/pages/my/myMessage/index')"></u-icon>
						
					<image src="@/static/images/my/exit.png" mode="scaleToFill"
						@click="loginOut" style="width: 50rpx;height: 50rpx;margin-left:32rpx"></image>
				</view>
			</view>
		</view>
		<!-- 头像 -->
		<view class="avatar">
			<view class="login" @click="handleRouter('/pages/my/children/login')" v-if="!Object.keys(userInfo).length">
				<image class="images2" mode="scaleToFill" src="@/static/images/my/myAvart.png"></image>
				<view class="loginText">
					<text class="h1">点击后登录</text>
					<text class="loginText-text">未实名认证 &nbsp ></text>
				</view>
			</view>
			<view class="login" v-else>
				<image class="images2" mode="scaleToFill" @click="handleRouter('/pages/my/myAdministration/index')"
					:src="/http/i.test(userInfo.avatar)?userInfo.avatar:'https:'+userInfo.avatar"></image>
				<view class="loginText">
					<text class="h1"
						@click="handleRouter('/pages/my/myAdministration/index')">{{userInfo.nickname}}</text>
					<text class="loginText-text" v-if="userInfo.is_real_name">已实名认证</text>
					<text class="loginText-text" v-else
						@click.stop="handleRouter('/pages/my/myAdministration/children/changeRealname/index1')">未实名认证&nbsp; ></text>
				</view>
			</view>
		</view>
		<!-- 常用功能 -->
		<view class="mycard">
			<view class="h2">常用功能</view>
			<view class="grid">
				<view class="grid-item" v-for="(item,index) in commonList" :key='index'
					@click="handleRouter(item.router,item.type)">
					<image :src="item.url" mode="widthFix" class="images"></image>
					<text class="grid-text">{{item.name}}</text>
				</view>
			</view>
		</view>
		<!-- 我的资产 -->
		<view class="mycard">
			<view class="h2">我的资产</view>
			<view class="grid">
				<view style="display: flex;justify-content: space-between;flex-direction:row;align-items: center;"
					@click="handleRouter('/pages/my/FlatGoldCoins/FlatGoldCoins?ptb_cnt='+userInfo.ptb_cnt,1)">
					<image v-if="!Object.keys(userInfo).length" src="../../static/images/my/wdl-ptb.png" mode="widthFix"
						class="images"></image>
					<image v-else class="img" src="../../static/images/my/ptb.png" mode="widthFix"></image>
					<view class="" style="margin-left: 10rpx;">
						<view style="justify-content: space-between;flex-direction:row;align-items: center;"
							v-if="Object.keys(userInfo).length">
							<text class="myrate">{{userInfo.ptb_cnt}}</text>
							<text style="font-weight: 300;font-size:22rpx;">个</text>
						</view>
						<view class="">
							<text class="grid-text">平台币</text>
						</view>
					</view>
				</view>
				<view
					style="display: flex;justify-content: space-between;flex-direction:row;align-items: center;margin:0rpx 30rpx;"
					@click="handleRouter('/pages/my/coupons/coupons',1)">
					<image v-if="!Object.keys(userInfo).length" src="../../static/images/my/wdl-yhq.png" mode="widthFix"
						class="images"></image>
					<image class="img" src="../../static/images/my/yhq.png" mode="widthFix" v-else></image>
					<view class="" style="margin-left: 10rpx;">
						<view style="justify-content: space-between;flex-direction:row;align-items: center;"
							v-if="Object.keys(userInfo).length">
							<text class="myrate">{{userInfo.coupon_count}}</text>
							<text style="font-weight: 300;font-size:22rpx;">张</text>
						</view>
						<view class="">
							<text class="grid-text">优惠券</text>
						</view>
					</view>
				</view>
				<view style="display: flex;justify-content: space-between;flex-direction:row;align-items: center;"
					@click="handleRouter('/pages/my/integral/index',1)">
					<image v-if="!Object.keys(userInfo).length" src="../../static/images/my/wdl-jf.png" mode="widthFix"
						class="images"></image>
					<image class="img" src="../../static/images/my/jf.png" mode="widthFix" v-else></image>
					<view style="margin-left: 10rpx;">
						<view style="justify-content: space-between;flex-direction:row;align-items: center;"
							v-if="Object.keys(userInfo).length">
							<text class="myrate">{{userInfo.my_integral}}</text>
							<text style="font-weight: 300;font-size:22rpx;">分</text>
						</view>
						<view class="">
							<text class="grid-text">积分</text>
						</view>
					</view>

				</view>
			</view>
		</view>
		<!-- 综合功能 -->
		<view class="mycard">
			<view class="h2">综合功能</view>
			<view class="grid" style="margin-bottom: 32rpx;">
				<view class="grid-item" v-for="(item,index) in mergeList" :key='index'
					@click="handleRouter(item.router,item.type)"
					v-if="($store.state.platform=='ios'?item.status!=1:true)&&index<5">
					<image :src="item.url" mode="widthFix" class="images"></image>
					<text class="grid-text">{{item.name}}</text>
				</view>
			</view>
			<view class="grid">
				<view class="grid-item item" v-for="(item,index) in mergeList" :key='index'
					@click="handleRouter(item.router,item.type)" style="flex: 1;"
					v-if="($store.state.platform=='ios'?item.status!=1:true)&&index>4">
					<image :src="item.url" mode="widthFix" class="images"></image>
					<text class="grid-text">{{item.name}}</text>
				</view>
			</view>
		</view>
		<view class="my-games" style="display:flex;flex-direction:column">
			<view class="game_line" :style="{opacity:line_opacity}">
				<view class="lins"></view>
				<view class="lins" style="width: 50rpx;"></view>
			</view>
			<myGameList ref="myGameList"></myGameList>
		</view>
	</view>
</template>

<script>
	import myGameList from './children/myGameList/myGameList.vue'
	export default {
		components: {
			myGameList
		},
		data() {
			return {
				opacity: 0,
				line_opacity: 0,
				commonList: [{
						url: '../../static/images/my/swyx.png',
						router: '/pages/getMoney/index',
						name: '试玩游戏',
						type: 3,

					},
					{
						url: '../../static/images/my/xyzp.png',
						name: '幸运转盘',
						router: '/pages/getMoney/index',
						type: 4
					},
					{
						url: '../../static/images/my/lqzx.png',
						name: '领券中心',
						router: '/pages/my/children/couponsCore/index',
						type: 1
					},
					{
						url: '../../static/images/my/jfsc.png',
						name: '积分商城',
						router: '/pages/my/children/pointMall/index',
						type: 1
					},
					{
						url: '../../static/images/my/qmtg.png',
						name: '全民推广',
						router: '/pages/my/children/share/index',
						type: 1
					}
				],
				mergeList: [{
						url: '../../static/images/my/kfzx.png',
						name: '客服中心',
						router: '/pages/customerService/index',
						type: 1
					},
					{
						url: '../../static/images/my/rwzx.png',
						name: '任务中心',
						router: '/pages/getMoney/index',
						type: 5
					},
					{
						url: '../../static/images/my/czfl.png',
						name: '充值返利',
						router: '/pages/customerService/children/rechargeRebate/index',
						type: 1
					},
					{
						url: '../../static/images/my/yjfk.png',
						name: '意见反馈',
						router: '/pages/my/comprehensive/feedback/feedback',
						type: 1,
					},
					{
						url: '../../static/images/my/yxlb.png',
						name: '游戏礼包',
						router: '/pages/my/comprehensive/gameGiftBag/gameGiftBag',
						type: 1,
					},
					{
						url: '../../static/images/my/yxzx.png',
						name: '游戏资讯',
						router: '/pages/my/comprehensive/gameConsulting/gameConsulting',
						type: 0,
					},
					{
						url: '../../static/images/my/xf.png',
						name: '新服',
						router: '/pages/my/serverList/serverList',
						type: 0,
					},
					{
						url: '../../static/images/my/phb.png',
						name: '排行榜',
						router: '/pages/my/rankList/rankList',
						type: 0,
					},
					{
						url: '../../static/images/my/jy.png',
						name: '交易',
						router: '/pages/transaction/index',
						type: 0,
					},{}
				],
			}
		},
		computed: {
			userInfo() {
				return this.$store.state.userInfo
			},
		},
		watch: {
			userInfo: {
				handler(val) {
					if (Object.keys(val).length) {
						this.$refs.myGameList.getPageData()
					} else {
						this.$refs.myGameList.clearData()
					}
				},
			}
		},
		methods: {
			handleRouter(url, type) {
				if (type == 1) {
					if (this.$common.isLogin()) {
						uni.navigateTo({
							url
						})
					}
				} else if (type==3||type==4||type==5){
					if(this.$common.isLogin()){
						if(type==3){
							uni.setStorage({
								key: 'active',
								data: 1
							})
						}else if(type==4){
							uni.setStorage({
								key: 'active',
								data: 2
							})
						}else if(type==5){
							uni.setStorage({
								key: 'active',
								data: 0
							})
						}
						uni.switchTab({
							url
						})
					}
				}else{
					uni.navigateTo({
						url
					})
				}
			},
			// 退出登录
			loginOut() {
				this.$api.get("/user/logout", {}).then(res => {
					// 返回上一页
					uni.navigateBack({
							delta: 1
						}),
					// 清空本地存储的登录数据
					uni.setStorageSync('mem-username', '')
					uni.setStorageSync('mem-password', '')
					uni.setStorageSync('sms-mobile', '')
					this.$store.commit("setUserToken", {});
					this.$store.commit('setUserInfo', {});
					uni.setStorageSync('mem-openid','')
					// this.$store.commit('setSelectedGame','')
				})
			}
		},
		onPageScroll(e) {
			// console.log(e,'eee');
			this.opacity = e.scrollTop/80
			this.line_opacity =  e.scrollTop/400
			if(this.opacity>=1) {
				this.opacity = 1
			}
		},
		onShow() {
		  this.$common.getuserInfo()
		  if(this.$refs.myGameList){
			  if(Object.keys(this.userInfo).length){
			  	  this.$refs.myGameList.getPageData()
			  }else {
			  	this.$refs.myGameList.clearData()
			  }
		  }
		},
		// onReachBottom() {
		// 	if(this.$refs.myGameList) {
		// 		this.$refs.myGameList.getMoreData()
		// 	}
		// }
	}
</script>



<style lang="scss">
	.my {
		padding: 0 32rpx 0;
		background-color: #f5f5f5;
		.top-title-box {
			position: fixed;
			width: 100%;
			left: 0;
			top: 0;
			z-index: 99;
			.safeArea-box {
				background: linear-gradient(to bottom, #CCCCCC, #f5f5f5 100%);
			}
			.top-title {
				width: 100%;
				padding: 0 44rpx;
				height: 56rpx;
				box-sizing: border-box;
				display: flex;
				align-items: center;
				justify-content: space-between;
				background-color: #f5f5f5;
				.titleLeft {
					.titlename {
						font-weight: 700;
						font-size: 30rpx;
						color: #1c1c1c;
					}
				}

				.titleRight {
					display: flex;
					align-items: center;
				}
			}
		}

		.avatar {
			.login {
				display: flex;
				align-items: center;

				.images2 {
					width: 140rpx;
					height: 140rpx;
					border-radius: 140rpx;
					margin-right: 12rpx;
				}

				.loginText {
					display: flex;
					flex-direction: column;
					align-items: flex-start;

					.h1 {
						margin-bottom: 12rpx;
						font-size: 40rpx;
						font-weight: 700;
						color: #1C1C1C;
					}

					.loginText-text {
						font-size: 26rpx;
						font-weight: 400;
						color: #252525;
						background-color: #E9E8EA;
						border-radius: 20rpx;
						padding: 2rpx 12rpx;
					}
				}
			}
		}

		.mycard {
			padding: 36rpx 24rpx;
			margin-top: 48rpx;
			border-radius: 20rpx;
			background-color: #fff;

			.h2 {
				font-size: 36rpx;
				font-weight: 700;
				color: #1C1C1C;
				margin-bottom: 28rpx;
			}
			.img {
				width: 60rpx;
				height: 60rpx;
				margin-right: 15rpx;
			}

			.grid {
				display: flex;
				justify-content: space-between;
				align-items: center;
			}

			.grid-item {
				display: flex;
				flex-direction: column;
				align-items: center;

			}

			.images {
				display: block;
				width: 48rpx;
				height: 48rpx;
				margin-bottom: 12rpx;
			}

			.grid-text {
				color: #1C1C1C;
				font-size: 28rpx;
				font-weight: 300;
			}
		}
		.my-games {
			.game_line{
				position: sticky;
				left: 0;
				top: 56rpx;
				display: flex;
				flex-direction: column;
				justify-content: center;
				align-items: center;
				padding-bottom: 20rpx;
				padding-top: 40rpx;
				height: 40rpx;
				width: 100%;
				background-color: #f5f5f5;
				z-index: 99;
			}
			.lins{
				margin:4rpx 0;
				width: 70rpx;
				height: 7rpx;
				border-radius: 30rpx;
				background-color: #e6e6e6;
			}
			.item {
				flex: 1;
				margin: 0 -5rpx 0 -5rpx;
			}
		}
	}
</style>
