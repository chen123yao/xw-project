<template>
	<view class="container">
		<view class="container-topTitle">
			<view class="container-topTitle-box">
				<view class="container-topTitle-box-left">
					<image class="container-topTitle-box-left-img" src="@/static/images/left.png" mode="heightFix" @click="back" />
					<text class="container-topTitle-box-left-text">排行榜</text>
				</view>
			</view>
		</view>
		
		<view class="container-content">
			<view class="content">
				<view class="nav-tabs">
					<view class="nav-item" :class="{active:index==active}" @click="handletab(index)" v-for="(item,index) in tabList" :key="index">
						{{item}}
					</view>
				</view>
				<view class="rank-list" v-if="list.length">
					<view class="rank-card" @click="handleRouter(`/pages/view/gameDetail/gameDetail?gameId=${ list[0].game_id }`)" >
						<image :src="list[0].hot_image" mode="scaleToFill" class="card-img"></image>
						<view class="card-content">
							<view class="card-num">
								<!-- <image src="@/static/images/rate-rate.png" mode="widthFix" class="num-img"></image> -->
								<view class="number">NO：1</view>
							</view>
							<view class="coverFlow">
								<view class="gamenames">{{list[0].gamename}}</view>
								<view class="tags">
									<image class="tagImage" src="@/static/images/index/tagst.png" mode="widthFix" style="width: 25rpx;min-width: 25rpx;margin-right: 8rpx;" />
									<text class="tag">{{list[0].one_word.length>26?list[0].one_word.slice(0,24)+'..':list[0].one_word}}</text>
								</view>
								<view class="listBottom">
									<view class="" style="display: flex;align-items: center;" v-if="list[0].start_time.length">
										<text style="color: #FF5927;" v-if="typeof list[0].start_time=='number'"> {{list[0].start_time|dateFormat('hh:mm')}}</text>
										<text style="color: #FF5927;" v-else> {{list[0].start_time[0]|dateFormat('hh:mm')}}</text>
										<text> 开服 | </text>
									</view>
									<text class="type" v-for="(v,i) in list[0].type" :key="i">{{v}}</text>
									<text>| {{list[0].popularity_cnt}}在玩</text>
								</view>
							</view>
						</view>
					</view>
					<view class="rank-item" v-for="(item, index) in list" :key="index" v-if="index>0">
						<vue-gameItem v-if="gameColorArray[index]" :itemData="item" :contentTagsColor="gameColorArray && [gameColorArray[(index) * 2],gameColorArray[(index) * 2 + 1]]" :itemWidth="702" :hasPadding="false" :tagType="1" 
							:itemBMargin="32" :iconWidth="140" :isShowMaxWidth="true" :itemRankIndex="index + 1"></vue-gameItem>
						<view class="lines" v-if="index!== list.length-1"></view>
					</view>
					<u-loadmore :status="status" loading-text="努力加载中" loadmore-text="加载更多" nomore-text="没有更多了"
					 fontSize="28" line height="80" iconColor="#ff5927"  iconSize="48" loadingIcon="circle"	/>
				</view>
				<vue-loading :isNoData="isNoData" v-else></vue-loading>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				formData: {
					page: 1,
					offset: 10
				},
				tabList: [],
				list: [],
				active: 0,
				status: 'loadmore',
				isNoData: false,
				
				gameColorIndexArray: [],
				gameColorArray: [],
			}
		},
		methods: {
			back() {
				uni.navigateBack()
			},
			handletab(index) {
				this.active = index
				this.formData.page = 1
				this.list = []
				
				this.gameColorIndexArray = []
				this.gameColorArray = []
				
				this.getpageData(this.formData)
				
				uni.pageScrollTo({
					scrollTop: 0,
					duration: 0
				});
			},
			getpageData(data = {}) {
				this.$api.get('game/rank_category', {
					...data,
					client_id:this.$store.state.client_id
				}).then(res => {
					if (this.tabList.length < 3){
							res.data.data.list.map(item => {
							this.tabList.push(item.topic_name)
						})
					}
					// console.log('code: ', res.data.code, this.active);
					if (res.data.code==200){
						this.list = this.list.concat(res.data.data.list[this.active].game_list)
						this.count = res.data.data.list[this.active].game_list_count
						// console.log('code: ', res.data.code, this.active, this.list, this.count);
						if(!this.count) {
							this.isNoData = true
						}
						if(res.data.data.list[this.active].game_list.length) {
							this.status = "loadmore"
						}
						if(this.list.length>=this.count) {
							this.status = "nomore"
						}
						
						if (res.data.data.list[this.active].game_list.length) {
							// console.log('gameColorArrayLength: ', res.data.data.list.length);
							this.gameColorIndexArray = [ ...this.$common.getRandomColorIndexArray(this.gameColorIndexArray, res.data.data.list[this.active].game_list.length * 2) ]
							// console.log('gameColorIndexArray: ', this.gameColorIndexArray);
							this.gameColorArray = { ...this.$common.getRandomColorArray(this.gameColorIndexArray) }
							// console.log('gameColorArray: ', this.gameColorArray);
						}
					}
				})
			},
			// cc 点击跳转页面
			handleRouter(url) {
				console.log('handleRouter', url);
				
				uni.navigateTo({
					url
				})
			},
		},
		onLoad() {
			this.getpageData(this.formData)
		},
		onReachBottom() {
			if(this.count>this.list.length&&this.status== "loadmore") {	
				this.status = "loading"
				this.formData.page++
				this.getpageData(this.formData)
			}
		},
		
	}
</script>

<style lang="scss">
	.container {
		background-color: #FFFFFF;
		width: 750rpx;
		height: 100vh;
		
		&-topTitle {
			position: fixed;
			// background-color: #FFFFFF;
			background: linear-gradient(to bottom, #CCCCCC, #FFFFFF env(safe-area-inset-top));
			z-index: 999;
			top: 0;
			width: 750rpx;
			height: 176rpx;
			padding: 0 34rpx 16rpx;
			box-sizing: border-box;
			display: flex;
			flex-direction: column;
			justify-content: flex-end;
			box-shadow: 0rpx 0rpx 12rpx rgba(0, 0, 0, 0.16);
			
			&-box {
				box-sizing: border-box;
				display: flex;
				flex-direction: row;
				justify-content: space-between;
				align-items: center;
				
				&-left {
					display: flex;
					flex-direction: row;
					align-items: center;
					
					&-img {
						height: 34rpx;
					}
					
					&-text {
						margin-left: 48rpx;
						font-size: 40rpx;
						line-height: 56rpx;
						font-family: PingFang SC;
						font-weight: 600;
						color: #1C1C1C;
					}
				}
				
				&-right {
					display: block;
					width: 35rpx;
					height: 35rpx;
				}
			}
		}
		
		&-content {
			width: 750rpx;
			padding: 176rpx 0 0;
			box-sizing: border-box;
			color: #1C1C1C;
			font-family: PingFang SC;
			min-height: 100vh;
			
			.content {
				min-height: 100vh;
				background-color: #FFFFFF;
				.nav-tabs {
					padding: 40rpx 32rpx;
					display: flex;
					align-items: center; 
					position: sticky;
					top: 176rpx;
					z-index: 90;
					background-color: #FFFFFF;
					.nav-item {
						height: 64rpx;
						padding: 0 32rpx;
						margin-right: 32rpx;
						line-height: 60rpx;
						border-radius: 32rpx;
						font-size: 32rpx;
						font-weight: 400;
						color: #666;
						background-color: #f1f1f1;
						box-sizing: border-box;
						&.active {
							font-weight: 500;
							color: #ff5927;
							background-color: #fff;
							border: 2rpx solid #ff5927;
						}
					}
				}
				.rank-list {
					padding: 0 32rpx;
					
					.rank-card {
						position: relative;
						border-radius: 40rpx;
						margin-bottom: 64rpx;
						overflow: hidden;
						.card-img {
							display: block;
							width: 100%;
							height: 396rpx;
						}
						.card-content {
							position: absolute;
							top: 0;
							left: 0;
							width: 100%;
							height: 100%;
							display: flex;
							flex-direction: column;
							align-items: flex-start;
							justify-content: space-between;
							.card-num {
								position: relative;
								width: 100rpx;
								.num-img {
									display: block;
									width: 100rpx;
								}
								.number {
									position: absolute;
									left: 0rpx;
									top: 5rpx;
									width: 100%;
									height: 100%;
									display: flex;
									align-items: flex-start;
									justify-content: center;
									font-size: 24rpx;
									font-weight: 600;
									color: #FFFFFF;
									transform: scale(0.8);
									transform-origin: 20rpx 0rpx;
								}
							}
							.coverFlow {
								width: 100%;
								padding: 10rpx 24rpx 24rpx;
								box-sizing: border-box;
								background-image: linear-gradient(to top, rgba(0, 0, 0, .4), rgba(255, 255, 255, 0.1));
								.gamenames{
									width: 375rpx;
									color: #fff;
									font-weight: 900;
									font-size: 40rpx;
									padding: 0rpx 30rpx;
									border-radius: 11px;
									background-color: rgba(0, 0, 0, 0.3);
									margin-bottom: 8rpx;
									box-sizing: border-box;
								}
								.tags {
									display: flex;
									align-items: center;
									margin-bottom: 10rpx;
									width: 100%;
									color: #fff;
									font-weight: 300;
									font-size: 24rpx;
									padding: 4rpx 20rpx 4px 20rpx;
									border-radius: 20rpx;
									box-sizing: border-box;
									background-color: rgba(0, 0, 0, 0.3);
									overflow: hidden;
									.tag {
										flex: 1;
										text-overflow: ellipsis;
										overflow: hidden;
										white-space: nowrap;
									}
								}
								.listBottom {
									display: flex;
									align-items: center;
									font-size: 24rpx;
									color: #fff;
									.type {
										margin: 0 6rpx;
									}
								}
							}
						}
					}
					.rank-item {
						.lines {						
							margin-left: 160rpx;
							margin-bottom: 32rpx;
							border-bottom: 2rpx solid #EFEFEF;
						}
					}
				}
			}
		}
	}
</style>
