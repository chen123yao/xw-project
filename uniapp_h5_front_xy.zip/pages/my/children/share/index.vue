<template>
	<view class="container">
		<!-- cc 游戏专题详情页面顶部标题 -->
		<view class="container-topTitle">
			<view class="container-topTitle-box">
				<view class="container-topTitle-box-left">
					<image class="container-topTitle-box-left-img" src="@/static/images/left.png" mode="heightFix" @click="back" />
					<text class="container-topTitle-box-left-text">全民推广</text>
				</view>
				
				<view class="container-topTitle-box-right" @click="handleRouter('/pages/my/children/withdrawalRecord/index')">
					<u-icon name="more-dot-fill" color="#000" size="42" class="more-dot-fill"></u-icon>
				</view>
			</view>
		</view>
		
		<view class="container-content">
			<view class="content">
				<image style="width: 100%;height: 2074rpx;" src="@/static/images/my/share-bgi2.png" mode="scaleToFill"></image>
				<view class="image-btn" @click="handleisShowMyPopup"></view>
				<view class="textAll">
					<view style="display: flex;align-items: flex-start;justify-content: center;">
						<view class="text_le">
							<text class="text">{{shareData.share_total}}</text>
							<text class="text1">累计收入</text>
						</view> 
						<view class="line"></view>
						<view class="text_mi">
							<text class="text">{{shareData.share_remain}}</text>
							<text class="text1">可兑换平台币</text>
						</view>
						<view class="line"></view>
						<view class="text_ri">
							<text class="text">{{shareData.mem_cnt}}</text>
							<text class="text1">邀请人数</text>
						</view>		
					</view>
					<view class="ling" @click="getPay"></view>
				</view>
				<u-popup :show="txshow" mode="center" @close="close" class="pop1" zIndex="900" overlayStyle="z-index:900" customStyle="background:transparent;" @touchmove.native.prevent.stop="toucnMove">
					<image src="@/static/images/my/share-popup.png" mode="widthFix"></image>
					<view class="getPTB">
						<view class="titlelie">
							<text class="lineText">领取平台币</text>
							<input v-model="form.amount" type="number" placeholder="请输入领取数量" class="input"></input>
						</view>
						<view @click.stop="withdraw" class="buttons">
							提交
						</view>
					</view>
					<image src="@/static/images/comment-close.png" mode="widthFix" @click="close" style="position: absolute;right: 42rpx;top: 260rpx;width: 40rpx;height: 40rpx;"></image>
				</u-popup>
			</view>
			<vue-myPopup :isShowMyPopup="isShowMyPopup" @close="close"></vue-myPopup>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				shareData: {},
				txshow:false,
				form: {
					amount: '',
					share_type: 1
				},
				isShowMyPopup: false,
			}
		},
		methods: {
			back() {
				uni.navigateBack()
			},
			handleRouter(url) {
				uni.navigateTo({
					url
				})
			},
			//获取数据
			getData() {
				this.$api.get("share/detail", {
					share_type: 'app',
					client_id: this.$store.state.client_id	
				}).then(res => {
					if (res.data.code == 200) {
						this.shareData = {
							...res.data.data
						}
					}
				})
			},
			getPay() {
				this.txshow = true
			},
			close() {
				this.form.amount = ""
				// this.payWay.name = ""
				this.txshow = false
				this.isShowMyPopup = false 
			},
			//领取按钮
			withdraw() {
				if (this.form.amount == '' || this.form.amount == 0) {
					uni.showToast({
						title:'领取数量不能为空',
						icon:'none'
					})
					return
				}
				this.$api.get(`financial/withdraw`, {
					...this.form
				}).then(res => {
					console.log(res);
					if (res.data.code == 200) {
						uni.showToast({
							title:res.data.msg,
							icon:'none'
						})
						this.close()
						this.getData()
					} else if (res.data.code == 44208) {
						uni.showToast({
							title:'请先完善账户信息',
							icon:'none',
							success: () => {
								setTimeout(()=>{
									uni.navigateTo({
										url:'/pages/my/myAdministration/children/withdrawalList/index'
									})
								},400)
							}
						})
					} else {
						uni.showToast({
							icon: "none",
							title: res.data.msg
						})
					}
				})
			},
			toucnMove(e) {
				e.stopPropagation()
			},
			handleisShowMyPopup() {
				// this.isShowMyPopup = true
			}
		},
		mounted() {
			this.getData()
		}
	}
</script>

<style lang="scss">
	.container {
		background-color: #FFFFFF;
		width: 750rpx;
		height: 100vh;
		
		&-topTitle {
			position: fixed;
			// background-color: #FFFFFF;
			background: linear-gradient(to bottom, #CCCCCC, #FFFFFF env(safe-area-inset-top));
			z-index: 999;
			top: 0;
			width: 750rpx;
			height: 176rpx;
			padding: 0 34rpx 16rpx;
			box-sizing: border-box;
			display: flex;
			flex-direction: column;
			justify-content: flex-end;
			box-shadow: 0rpx 0rpx 12rpx rgba(0, 0, 0, 0.16);
			
			&-box {
				box-sizing: border-box;
				display: flex;
				flex-direction: row;
				justify-content: space-between;
				align-items: center;
				
				&-left {
					display: flex;
					flex-direction: row;
					align-items: center;
					
					&-img {
						height: 34rpx;
					}
					
					&-text {
						margin-left: 48rpx;
						font-size: 40rpx;
						line-height: 56rpx;
						font-family: PingFang SC;
						font-weight: 600;
						color: #1C1C1C;
					}
				}
				
				&-right {
					display: block;
					width: 35rpx;
					height: 35rpx;
				}
			}
		}
		
		&-content {
			width: 750rpx;
			padding: 176rpx 0 0;
			box-sizing: border-box;
			color: #1C1C1C;
			font-family: PingFang SC;
			min-height: 100vh;
			
			.content {
				position: relative;
				.image-btn {
					position: absolute;
					top: 1364rpx;
					left: 50%;
					transform: translateX(-50%);
					width: 400rpx;
					height: 94rpx;
				}
				.textAll {
					position: absolute;
					top: 1560rpx;
					left: 32rpx;
					width: 688rpx;
					height: 386rpx;
					padding: 72rpx 68rpx 0;
					box-sizing: border-box;
					.text {
						display: block;
						margin-bottom: 40rpx;
						text-align: center;
						font-size: 48rpx;
						font-weight: 500;
						color: #FF4810;
						line-height: 34rpx;
					}
					.text1 {
						white-space: nowrap;
						font-size: 32rpx;
						line-height: 30rpx;
						font-weight: 500;
						color: #252525;
					}
					.line {
						width: 1px;
						min-width: 1px;
						height: 78rpx;
						margin: 0 36rpx;
						background: #060606;
						opacity: 0.14;
					}
					.ling {
						margin-top: 54rpx;
						margin-left: 76rpx;
						width: 400rpx;
						height: 94rpx;
					}
				}
				.getPTB {
					position: absolute;
					top:360rpx;
					width: 100%;
					padding: 32rpx;
					box-sizing: border-box;
				}
				.titlelie {
					display: flex;
					align-items: center;
					padding: 0 16rpx 30rpx;
					border-bottom: 1px solid #ececec;
					.lineText {
						margin-right: 54rpx;
						font-size: 32rpx;
						font-weight: 500;
						white-space: nowrap;
						color: #252525;
						line-height: 30rpx;
						.input {
							flex: 1;
						}
					}
				}
				.buttons {
					width: 320rpx;
					height: 74rpx;
					margin: 60rpx auto 0;
					font-size: 32rpx;
					color: #FF4810;
					line-height: 74rpx;
					text-align: center;
					background: rgba(255,177,25,0);
					border: 1px solid #E3E3E3;
					border-radius: 36rpx;
				}
			}
		}
	}
</style>