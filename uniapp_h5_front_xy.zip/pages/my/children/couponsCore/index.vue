<template>
	<view class="container coupons">
		
		<!-- <view class="topStatusBarBgc"></view> -->
			
		<!-- cc 游戏专题详情页面顶部标题 -->
		<view class="coupons-topTitle">
			<view class="coupons-topTitle-box">
				<view class="coupons-topTitle-box-left">
					<image class="coupons-topTitle-box-left-img" src="@/static/images/left.png" mode="heightFix" @click="back" />
					<text class="coupons-topTitle-box-left-text">领券中心</text>
				</view>
			
				<image class="coupons-topTitle-box-right" src="@/static/images/my/my_details.png" mode="heightFix" @click="handleRouter('/pages/my/coupons/coupons')"></image>
			</view>
		</view>
		
		<view class="coupons-content">
			<image style="width: 100%;" src="@/static/images/my/lqzx-banner.png" mode="widthFix" ></image>
			<view class="content">
				<view class="date-head">
					<view class="data-item" v-for="item in 3">
						<text class="top_text">{{new Date()/1000 + 86400*(item-1) | dateFormat('yyyy.MM.dd')}}</text>
						<view class="data-text" >
							<text class="top_text">{{item == 1 ? '今日': '即将开始'}}</text>
							<view class="lines" v-if="item!=3"></view>
						</view>
					</view>
				</view>
				<view class="today-coupons">
					<view class="h1">今日好券</view>
					<scroll-view scroll-x="true" class="counps-list" v-if="todayCoupons.length">
						<view class="coupons-item" v-for="(item,index) in 5" :key="index">
							<image class="img_bg" src="@/static/images/my/lqzx-back.png" mode="scaleToFill" />
							<view class="tCoupon">
								<view style="flex-direction: row;">
									<text class="img_text">￥</text>
									<text class="img_text1">{{item.coupons_amount}}</text>
								</view>
								<text class="img_text2">{{item.title}}</text>
								<text class="img_text3">{{item.name}}</text>
							</view>
							<view class="img_btn" v-if="!item.have_got" @click.stop="handleClick($event,item.id,item.period_type)" >
								<text class="img_text4">立即领取</text>
							</view>
							<view class="img_btn" v-else >
								<text class="img_text4" style="color:#999999 ;">已领取</text>
							</view>
						</view>
					</scroll-view>
					<view v-else >
						<vue-loading :isNoData="true" style="width: 300rpx;margin: 0 auto;"></vue-loading>
					</view>
				</view>
				<view class="good-coupons-wrapper">
					<view class="good-coupons">
						<view class="h1">优选好券</view>
						<view class="nav-tabs">
							<view class="tabslist">
								<view class="tab" :class="{active:active==index}" @click="tabClick(index)" v-for="(item,index) in myGame" :key="index">
									<image :src="item.list[0].game.icon" mode="scaleToFill" style="display: block;width: 150rpx;height: 150rpx;"></image>
									<view :style="{color:active==index?'#000000':'#666666',fontWeight:active==index?'bold':'400'}" class="tabs_text">{{item.list[0].game.name.replace(/\uff08/g, "(").replace( /\uff09/g, ")")}}</view>
									<view class="tabLine" :style="`transform:translateX(${active*170}rpx)`" v-if="!index"></view>
								</view>
							</view>
						</view>
					</view>
				</view>
				<view v-if="pageData" style="padding: 0 32rpx;background-color: #fff;">
					<view class="list-groups"  v-for="(data,key,i) in pageData" :key='i' v-if="i==active">
						<view class="good-coupons-list" v-for="(item,index) in data.list" :key='index'>
							<vue-couponsItem :item="item"></vue-couponsItem>
						</view>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isNoData: false,
				todayCoupons: [],
				active: 0,
				pramas:{
					offset:10,
					game_num:4,
				},
				pageData: null,
				myGame: [],
			}
		},
		methods: {
			back() {
				uni.navigateBack()
			},
			handleRouter(url) {
				uni.navigateTo({
					url
				})
			},
			//今日优惠券
			getTodayCouponsData(){
				this.$api.get('/user/coupons/today_list').then(res=>{
					if(res.data.code==200){
						this.isNoData = true
						this.todayCoupons = res.data.data.list
					}else{
						uni.showToast({
							title:res.data.msg,
							icon:'none',
						})
						return
					}
				})
			},
			//优惠券
			getPageData() {
				this.$api.get('/user/coupons/rand_games',{
					...this.pramas
				}).then(res => {
					console.log(res)
					if (res.data.code == 200) {
						if (res.data.data) {
							this.pageData = res.data.data.data
							this.myGame = res.data.data.data
						}
						// console.log(this.myGame)
					} else {
						uni.showToast({
							title: res.data.msg,
							icon: 'none',
						})
						return
					}
				})
			},
			tabClick(index) {
					this.active = index
			},
		},
		mounted() {
			this.getTodayCouponsData()
			this.getPageData()
		}
	}
</script>

<style lang="scss">
	.container {
		background-color: #f5f5f5;
		width: 750rpx;
		height: 100vh;
	}
	
	.coupons {
		&-topTitle {
			position: fixed;
			// background-color: #FFFFFF;
			background: linear-gradient(to bottom, #CCCCCC, #FFFFFF env(safe-area-inset-top));
			z-index: 999;
			top: 0;
			width: 750rpx;
			height: 176rpx;
			padding: 0 34rpx 16rpx;
			box-sizing: border-box;
			display: flex;
			flex-direction: column;
			justify-content: flex-end;
			box-shadow: 0rpx 0rpx 12rpx rgba(0, 0, 0, 0.16);
			
			&-box {
				box-sizing: border-box;
				display: flex;
				flex-direction: row;
				justify-content: space-between;
				align-items: center;
				
				&-left {
					display: flex;
					flex-direction: row;
					align-items: center;
					
					&-img {
						height: 34rpx;
					}
					
					&-text {
						margin-left: 48rpx;
						font-size: 40rpx;
						line-height: 56rpx;
						font-family: PingFang SC;
						font-weight: 600;
						color: #1C1C1C;
					}
				}
				
				&-right {
					display: block;
					width: 35rpx;
					height: 35rpx;
				}
			}
		}
		
		&-content {
			width: 750rpx;
			padding: 176rpx 0 0;
			box-sizing: border-box;
			color: #1C1C1C;
			font-family: PingFang SC;
			min-height: 100vh;
			
			.h1 {
				margin-bottom: 44rpx;
				font-size: 32rpx;
				font-weight: 800;
				color: #000000;
			}
			
			.content {
				padding: 32rpx;
				height: 100%;
				background-color: #f5f5f5;
				
				.date-head {
					display: flex;
					align-items: center;
					justify-content: space-between;
					overflow: hidden;
					.data-item {					
						.top_text {
							color: #999;
							font-size: 32rpx;
							font-weight: bold;
						}
						&:nth-child(1) .top_text {
							color: #FF4810;
						}
						&:nth-last-child(1) {
							display: flex;
							flex-direction: column;
							align-items: flex-end;
						}
						.data-text {
							position: relative;
							margin-top: 15rpx;
							width: 150rpx;
							height: 60rpx;
							text-align: center;
							line-height: 60rpx;
							background-color: #fff;
							border: 2rpx solid #E1E1E1;
							border-radius: 30rpx;
							.lines {
								position: absolute;
								width: 400rpx;
								height: 15rpx;
								right: 0;
								top: 50%;
								transform: translate(100%,-50%);
								background: #e6e6e6;
							}
						}
					}
				}
				.today-coupons {
					// position: sticky;
					// top: 88rpx;
					// width: 100%;
					height: 520rpx;
					margin-top: 42rpx;
					padding: 40rpx 0 26rpx 20rpx;
					background: #fff;
					border-radius: 40rpx;
					z-index: 90;
					box-sizing: border-box;
					.counps-list {
						white-space: nowrap;
						.coupons-item {
							display: inline-block;
							margin-right: 20rpx;
							position: relative;
							width: 250rpx;
							height: 302rpx;
							.img_bg {
								position: absolute;
								top: 0;
								left: 0;
								display: block;
								width: 250rpx;
								height: 302rpx;
							}
							.tCoupon {
								position: relative;
								height: 248rpx;
								padding-top: 52rpx;
								display: flex;
								flex-direction: column;
								align-items: center;
								box-sizing: border-box;
								z-index: 2;
								.img_text {
									font-size: 32rpx;
									color: #252525;
									line-height: 36rpx;
								}
								.img_text1 {
									font-size: 48rpx;
									color: #252525;
									line-height: 36rpx;
								}
								.img_text2 {
									margin: 24rpx 0;
									font-size: 24rpx;
									font-weight: 800;
									color: #666666;
									line-height: 22rpx;
								}
								.img_text3 {
									font-size: 22rpx;
									font-weight: 800;
									color: #C1C1C1;
									line-height: 22rpx;
								}
							}
							.img_btn {
								position: relative;
								height: 54rpx;
								line-height: 54rpx;
								font-weight: 800;
								font-size: 22rpx;
								color: #FF4810;
								text-align: center;
								z-index: 2;
							}
						}
					}
				}
				.good-coupons-wrapper {
					position: sticky;
					top: 88rpx;
					width: 100%;
					margin-top: 40rpx;
					background-color: #f5f5f5;
					.good-coupons {
						padding: 40rpx 0 26rpx 20rpx;
						min-height: 270px;
						background: #fff;
						border-radius: 40rpx;
						.tabslist{
							width: 100%;
							display: flex;
							align-items: center;
							z-index: 90;
							box-sizing: border-box;
							background: #fff;
							.tab {
								position: relative;
								width: 150rpx;
								margin-right: 20rpx;
								text-align: center;
								font-size: 32rpx;
								font-weight: 400;
								line-height: 50rpx;
								color: #666;
								&.active {
									line-height: 46rpx;
									font-size: 36rpx;
									font-weight: 600;
									color: #1c1c1c;
								}
							}
							.tabs_text{
								color: #666666;
								font-weight: 400;
								font-size: 30rpx;
								line-height: 36rpx;
								margin: 20rpx 0;
								word-wrap:anywhere;
								display: -webkit-box;
								overflow: hidden;
								-webkit-box-orient: vertical;
								line-clamp: 2;
								-webkit-line-clamp: 2; //显示几行
							}
							.tabLine {
								position: absolute;
								left: calc(50% - 24rpx);
								bottom: -8rpx;
								width: 48rpx;
								height: 4rpx;
								background-color: #FF5927;
								border-radius: 4rpx;
								transition-property: transform;
								transition-duration:0.4s;
							}
						}
					}
				}
				.list-groups {
					background-color: #fff;
					padding: 40rpx 0 20rpx;
					::v-deep .coupons-item:nth-child(1) {
						margin-top: 0;
					}
				}
			}
		}
	}
</style>