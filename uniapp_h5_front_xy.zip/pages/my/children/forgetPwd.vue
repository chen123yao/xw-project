<template>
	<view class="forgetPwd">
		<view class="title">忘记密码</view>
		<view class="inputs-box">
			<text class="input-title">手机号</text>
			<view class="inputs">
				<input type="number" class="input" v-model="form1['sms-mobile']" placeholder="请输入已绑定的手机号" maxlength="20" style="flex:1;" placeholder-style="color:#e1e1e1"/>
				<image src="@/static/images/close.png" v-if="form1['sms-mobile']" @click="form1['sms-mobile']=''" mode="widthFix" style="width: 30rpx;height: 30rpx;margin-left: 20rpx;"></image>
			</view>
		</view>
		<view class="inputs-box">
			<text class="input-title">验证码</text>
			<view class="inputs">
				<input type="number" maxlength="6" v-model="form1['sms-code']" class="input" placeholder="请输入验证码" style="flex:1" placeholder-style="color:#e1e1e1"/>
				<vue-verificationCode @click="getCode" :contentCode='contentCode'></vue-verificationCode>	
			</view>
		</view>
		<view class="inputs-box">
			<text class="input-title">新密码</text>
			<view class="inputs">
				<input type="text" class="input" v-if="is_eye"  v-model="form2.password"  placeholder="请输入新密码" maxlength="20" @confirm='doLogin' style="flex:1;" placeholder-style="color:#e1e1e1"/>
				<input type="password" class="input" v-else  v-model="form2.password" placeholder="请输入新密码" maxlength="20" @confirm='doLogin' style="flex:1;" placeholder-style="color:#e1e1e1"/>
				<image src="@/static/images/my/eye_open.png" v-if="is_eye" mode="widthFix" @click="is_eye=false" style="width: 30rpx;height: 30rpx;margin-left:20rpx;"></image>
				<image src="@/static/images/my/eye_close.png" v-else mode="widthFix" @click="is_eye=true" style="width: 30rpx;height: 30rpx;margin-left:20rpx;"></image>
			</view>
		</view>
		<view class="inputs-box">
			<text class="input-title">再次确认</text>
			<view class="inputs">
				<input type="text" class="input" v-if="is_eye1"  v-model="form2.passwordAgain"  placeholder="请输入新密码" maxlength="20" @confirm='doLogin' style="flex:1;" placeholder-style="color:#e1e1e1"/>
				<input type="password" class="input" v-else  v-model="form2.passwordAgain" placeholder="请输入新密码" maxlength="20" @confirm='doLogin' style="flex:1;" placeholder-style="color:#e1e1e1"/>
				<image src="@/static/images/my/eye_open.png" v-if="is_eye1" mode="widthFix" @click="is_eye1=false" style="width: 30rpx;height: 30rpx;margin-left:20rpx;"></image>
				<image src="@/static/images/my/eye_close.png" v-else mode="widthFix" @click="is_eye1=true" style="width: 30rpx;height: 30rpx;margin-left:20rpx;"></image>
			</view>
		</view>
		<view class="mybutton" @click="handleConfirm">设置新密码</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				form1: {
					"sms-mobile": "",
					"sms-code": "",
					"sms-type": 5
				},
				contentCode: 0,
				is_eye: false,
				is_eye1: false,
				form2: {
					password: "",
					passwordAgain: "",
					verify_token: ""
				}
			}
		},
		methods: {
			// 发送验证码
			getCode() {
				if (!this.form1['sms-mobile']) {
					uni.showToast({
						title: "请输入手机号",
						icon: "none"
					})
					return;
				}
				this.$api.get("v8/sms/send", {
					...this.form1
				}).then(res => {
					if(res.data.code==200){
						this.contentCode++
					}else{
						uni.showToast({
							title: res.data.msg,
							icon: "none"
						})
					}	
				})
			},
			// 确认验证码
			handleConfirm() {
			   this.$api.get("findpwd/sms/check", {
					...this.form1
				}).then(res => {
					uni.showToast({
						title: res.data.msg,
						icon: "none"
					})
					this.form2.verify_token = res.data.data.verify_token;
					this.submitPassword()
				})
			},
			// 提交密码修改
			submitPassword() {
				if (this.form2.password != this.form2.passwordAgain || this.form2.password == 0) {
					uni.showToast({
						title: '输入密码不一致',
						icon: "none"
					})
					return;
				}
				this.$api.get("findpwd/password/reset", {
					...this.form2
				}).then(res => {
					if (res.data.code == 200) {
						uni.showToast({
							title: "修改密码成功",
							icon: "none"
						})
						setTimeout(() => {
							uni.navigateBack({
								delta: 1
							})
						}, 400)
					} else {
						uni.showToast({
							title: res.data.msg,
							icon: "none"
						})
					}
				})
			}
		}
	}
</script>

<style lang="scss">
	.forgetPwd {
		padding: 0 32rpx;
		background-color: #fff;
		.title {
			padding: 80rpx 0;
			color: #1C1C1C;
			font-weight: 700;
			font-size:48rpx;
		}
		.inputs-box {
			.input-title {
				font-size: 36rpx;
				font-weight: 700;
				color: #1C1C1C;
			}
			.inputs {
				display: flex;
				align-items: center;
				margin-bottom: 48rpx;
				padding:12rpx 0;
				border-bottom:1px solid #efefef;
				.input {
					font-size: 28rpx;
				}
			}
		}
		.mybutton {
			text-align: center;
			border: 1px solid #efefef;
			color: #FF5927;
			padding:24rpx 0;
			border-radius: 60rpx;
			font-size: 30rpx;
			font-weight: 700;
			lines: 1;
			margin-bottom: 48rpx;
		}
	}
</style>