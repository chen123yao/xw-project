<template>
	<view class="login">
		<view class="bg-imgs" style="position: relative;">
			<image src="@/static/images/my/login-backimage.png" mode="widthFix" style="width: 100%;"></image>
			<image class="Loginimages" :src="userFormat.icon"></image>
			<view class="back" @click="handleback">
				<image src="@/static/images/back.png"
					style="width: 44rpx;height: 44rpx;display: block;margin-left: -8rpx;"></image>
			</view>
		</view>
		<view class="body">
				<view class="log">
					<text class="h1 log_text">登录</text>
				</view>
			<view class="qita" v-if="notPhone">
				<view class="userInfo">
					<text class="h2">账号</text>
					<view class="select flex" >
						<input type="text" class="inputs" v-model="form['mem-username']" placeholder="请输入手机号或账号" maxlength="20" style="flex:1" placeholder-style="color:#e1e1e1"/>
						<image src="@/static/images/down_999.png" mode="widthFix" style="width: 30rpx;height: 30rpx;margin-left:20rpx;"></image>
					</view>
					<text class="h2">密码</text>
					<view class="select flex">
						<input type="text" class="inputs" v-if="is_eye" v-model="form['mem-password']"  placeholder="请输入密码" maxlength="20" @confirm='doLogin' style="flex:1" placeholder-style="color:#e1e1e1"/>
						<input type="password" class="inputs" v-else v-model="form['mem-password']" placeholder="请输入密码" maxlength="20" @confirm='doLogin' style="flex:1" placeholder-style="color:#e1e1e1"/>
						<image src="@/static/images/my/eye_open.png" v-if="is_eye" mode="widthFix" @click="is_eye=false" style="width: 30rpx;height: 30rpx;margin-left:20rpx;"></image>
						<image src="@/static/images/my/eye_close.png" v-else mode="widthFix" @click="is_eye=true" style="width: 30rpx;height: 30rpx;margin-left:20rpx;"></image>
					</view>
				</view>
				<view class="agreement flex" style="justify-content: flex-start;">
					<checkbox style="transform: scale(0.7);" color="#FF5927" :checked="is_agree" @click="is_agree = !is_agree" />
					<text style="font-size: 28rpx;">我已仔细阅读并同意</text>
					<text style="color: #FF5927;font-size: 28rpx;font-weight: 700;" @click="handleAmunt(2)">《用户协议》</text>
					<text style="font-size: 28rpx;">与</text>
					<text style="color: #FF5927;font-size: 28rpx;font-weight: 700;" @click="handleAmunt(1)">《隐私政策》</text>
				</view>		
				<text class="mybutton" @click="doLogin">立即登录</text>
			</view>
		
			<!-- 手机号登录 -->
			<view class="myPhone" v-else>
				<view class="userInfo">
					<text class="h2">手机号</text>
					<view class="select flex" >
						<input type="text" class="inputs" v-model="phone['sms-mobile']" placeholder="请输入手机号" maxlength="20" style="flex:1" placeholder-style="color:#e1e1e1"/>
						<image src="@/static/images/down_999.png" mode="widthFix" style="width: 30rpx;height: 30rpx;margin-left:20rpx;"></image>
					</view>
					<text class="h2">验证码</text>
					<view class="select flex" >
						<input type="number" maxlength="6" v-model="phone['sms-code']" class="inputs" placeholder="请输入验证码" style="flex:1" placeholder-style="color:#e1e1e1"/>
						<verificationCode @click="getCode" :contentCode='contentCode'></verificationCode>	
					</view>
				</view>
				<view class="agreement flex" style="justify-content: flex-start;">
					<checkbox style="transform: scale(0.7);" color="#FF5927" :checked="is_agree" @click="is_agree = !is_agree"/>
					<text style="font-size: 28rpx;">我已仔细阅读并同意</text>
					<text style="color: #FF5927;font-size: 28rpx;font-weight: 700;" @click="handleAmunt(2)">《用户协议》</text>
					<text style="font-size: 28rpx;">与</text>
					<text style="color: #FF5927;font-size: 28rpx;font-weight: 700;" @click="handleAmunt(1)">《隐私政策》</text>
				</view>
				<text class="mybutton" @click="iphoneLogin">登录/注册</text>
			</view>
			<view class="phonelogin">
				<text class="text phone" :style="{color: !notPhone ? '#666' : '#000000',fontWeight:!notPhone ? '400 ': '700'}" @click="notPhone=true">账号登录</text>
				<text class="text" style="margin: 0 56rpx;">|</text>
				<text class="text phone" :style="{color: notPhone ? '#666' : '#000000',fontWeight:notPhone? '400 ': '700'}" @click="notPhone=false">手机登录/注册</text>
				<text class="text" style="margin: 0 56rpx;">|</text>
				<text class="text" style="color: #666;" @click="forgetPw">忘记密码</text>
			</view>
		</view>
	</view>
</template>

<script>
	import verificationCode from '@/components/vue-verificationCode/vue-verificationCode.vue';
	export default {
		components: {
			verificationCode
		},
		data() {
			return {
				notPhone: true,
				is_eye:false,
				is_agree: false,
				form: {
					"mem-username": "",
					"mem-password": ""
				},
				codeText: "",
				contentCode: 0,
				phone: {
					"sms-mobile": '',
					"sms-phone": '2',
					"sms-code": '',
					"sms-type": '2',
				},
			}
		},
		computed: {
			userFormat() {
				return this.$store.state.userFormat
			},
			userInfo() {
				return this.$store.state.userInfo
			},
			client_id(){
				return this.$store.state.client_id
			}
		},
		methods: {
			//返回
			handleback() {
				uni.navigateBack()
			},
			doLogin() {
				if(this.is_agree == false){
					uni.showToast({
						title: '请勾选阅读并同意《用户协议》',
						icon: 'none'
					})
					return;
				}
				this.$api.get("user/login", {
					client_id: this.client_id,
					...this.form,
				}).then(res => {
					console.log(res, 'doLogindoLogindoLogindoLogin')
					// 将登录获取的数据记录下来
					if (res.data.code == 200) {
						this.$store.commit("setUserToken", res.data.data.user_token);
						// 将用户名密码记录在本地
						uni.setStorageSync('mem-username', this.form["mem-username"])
						uni.setStorageSync('mem-password', this.form["mem-password"])
						uni.showToast({
							title: '登录成功',
							success: () => {
							this.$common.getuserInfo();
								// 返回上一页
								setTimeout(() => {
									uni.navigateBack({
										delta: 1,
									})
								}, 300)
							}
						})
						// 获取用户信息
					} else {
						uni.showToast({
							title: res.data.msg,
							icon: 'none'
						})
					}
				})
			},
			// 获取验证码
			getCode() {
				if (!this.phone['sms-mobile']) {
					uni.showToast({
						title: "请输入手机号",
						icon: "none"
					})
					return;
				}
				this.$api.get("v8/sms/send", {
					client_id: this.client_id,
					...this.phone
				}).then(res => {
					console.log(res,'sssssssssssss')
					if(res.data.code==200){
						this.contentCode++
					}else{
						uni.showToast({
							title: res.data.msg,
							icon: "none"
						})
					}	
				})
			},
			// 手机号登陆
			iphoneLogin() {
				if(this.is_agree == false){
					uni.showToast({
						title: '请勾选阅读并同意《用户协议》',
						icon: 'none'
					})
					return;
				}
				this.$api.get("v8/user/loginm", {
					client_id: this.client_id,
					...this.phone
				}).then(res => {
					// 将登录获取的数据记录下来
					if (res.data.code == 200) {
						if (res.data.data.is_pwd) {
							uni.setStorageSync('mem-username', this.phone['sms-mobile'])
							uni.setStorageSync('sms-mobile', this.phone['sms-mobile'])
							this.$store.commit("setUserToken", res.data.data.user_token);
							uni.showToast({
								title: '登录成功',
								success: () => {
									// 返回上一页
									setTimeout(() => {
										uni.navigateBack({
											delta: 1,
										})
									}, 300)
								}
							})
							// 获取用户信息
							this.$common.getuserInfo();
						} else {
							uni.setStorageSync('mem-username', this.phone['sms-mobile'])
							uni.setStorageSync('sms-mobile', this.phone['sms-mobile'])
							this.$store.commit("setUserToken", res.data.data.user_token);
							//跳转
							uni.navigateTo({
								url: '/pages/my/children/bindingPssword/bindingPssword'
							})
						}
					} else {
						uni.showToast({
							title: res.data.msg,
							icon: 'none'
						})
					}
				})
			},
			//忘记密码
			forgetPw() {
				uni.navigateTo({
					url: `/pages/my/children/forgetPwd`
				})
			},
			// 协议
			handleAmunt(type){
				console.log(type)
				uni.navigateTo({
					url:'/pages/my/children/agreement/index?type='+ type
				})
				// nvue-agreement
			},
		}
	}
</script>

<style lang="scss">
	.h1 {
		font-size: 40rpx;
		font-weight: 700;
		color: #1C1C1C;
	}
	.h2 {
		display: block;
		margin-bottom: 8rpx;
		font-size: 36rpx;
		font-weight: 700;
		color: #1C1C1C;
	}
	.flex {
		display: flex;
		align-items: center;
		justify-content: space-between;
	}
	.login {
		.bg-imgs {
			.Loginimages {
				width: 180rpx;
				height: 180rpx;
				position: absolute;
				left: 0;
				right: 0;
				bottom: 20rpx;
				margin: 0 auto;
				border-radius: 30rpx;
				z-index: 2;
				animation: lgoinImageRun 0.5s;
				animation-timing-function: cubic-bezier(.8,1.63,.79,.69);
			}

			.back {
				position: fixed;
				width: 66rpx;
				height: 66rpx;
				top: 120rpx;
				left: 32rpx;
				border-radius: 66rpx;
				display: flex;
				align-items: center;
				justify-content: center;
				background-color: rgba(28, 28, 28, 0.5);
			}
		}
		.body {
			margin-top: 20rpx;
			padding: 0 32rpx;
			.userInfo {
				margin-top: 36rpx;
				.select{
					margin-bottom: 48rpx;
					padding-bottom:12rpx;
					border-bottom:1px solid #efefef;
					.inputs {
						font-size: 28rpx;
					}
				}
			}
			::v-deep .uni-checkbox-input {
				border-color: #d1d1d1!important;
			}
			.mybutton {
				display: block;
				text-align: center;
				border: 1px solid #efefef;
				color: #FF5927;
				padding:24rpx 0;
				border-radius: 60rpx;
				font-size: 30rpx;
				font-weight: 700;
				lines: 1;
				margin-top: 48rpx;
				margin-bottom: 48rpx;
			}
			.phonelogin {
				display: flex;
				align-items: center;
				justify-content: center;
				margin-bottom: 80rpx;
				.text {
					font-size: 26rpx;
					color: #1C1C1C;
				}
			}
			.phone{
				color: #666;
			}
		}
	}
	@keyframes lgoinImageRun {
		0% {
			bottom: 500rpx
		}
		100% {
			bottom: 0;
		}
	}
</style>
