<template>
	<view class="container">
		<view class="container-topTitle">
			<view class="container-topTitle-box">
				<view class="container-topTitle-box-left">
					<image class="container-topTitle-box-left-img" src="@/static/images/left.png" mode="heightFix" @click="back" />
					<text class="container-topTitle-box-left-text">领取记录</text>
				</view>
			</view>
		</view>
		
		<view class="container-content">
			<view class="list" v-if="pageData.length">
				<view class="list-item" v-for="(item,index) in pageData" :key="index">
					<view class="item-left">
						<view class="item-title">领取数量</view>
						<text class="item-date">{{item.create_time | dateFormat("yyyy-MM-dd hh:mm:ss")}}</text>
					</view>
					<text class="item-num">+{{item.ptb_cnt}}平台币</text>
				</view>
				<u-loadmore :status="status" loading-text="努力加载中" loadmore-text="加载更多" nomore-text="没有更多了"
				 fontSize="28" line height="80" iconColor="#ff5927"  iconSize="48" loadingIcon="circle"	/>
			</view>
			<vue-loading :isNoData="isNoData" v-else></vue-loading>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				fromData: {
					page: 1,
					offset: 10
				},
				pageData: [],
				count: 0,
				isNoData: false,
				status: 'loadmore'
			}
		},
		methods: {
			back() {
				uni.navigateBack()
			},
			getPageData() {
				this.$api.get("financial/withdraw/list", {
					...this.fromData
				}).then(res => {
					this.pageData = this.pageData.concat(res.data.data.list)
					this.count = res.data.data.count
					if(!res.data.data.count) {
						this.isNoData = true
					} 
					if(this.pageData.length>=this.count) {
						this.status = "nomore"
					} else {
						this.status1 = "loadmore"
					}
				})
			},
		},
		onLoad() {
			this.getPageData()
		},
		onReachBottom() {
			if(this.count>this.pageData.length && this.status == "loadmore") {
				this.status = "loading"
				this.fromData.page++
				this.getPageData()
			}
		}
	}
</script>

<style lang="scss">
	.container {
		background-color: #FFFFFF;
		width: 750rpx;
		height: 100vh;
		
		&-topTitle {
			position: fixed;
			// background-color: #FFFFFF;
			background: linear-gradient(to bottom, #CCCCCC, #FFFFFF env(safe-area-inset-top));
			z-index: 999;
			top: 0;
			width: 750rpx;
			height: 176rpx;
			padding: 0 34rpx 16rpx;
			box-sizing: border-box;
			display: flex;
			flex-direction: column;
			justify-content: flex-end;
			box-shadow: 0rpx 0rpx 12rpx rgba(0, 0, 0, 0.16);
			
			&-box {
				box-sizing: border-box;
				display: flex;
				flex-direction: row;
				justify-content: space-between;
				align-items: center;
				
				&-left {
					display: flex;
					flex-direction: row;
					align-items: center;
					
					&-img {
						height: 34rpx;
					}
					
					&-text {
						margin-left: 48rpx;
						font-size: 40rpx;
						line-height: 56rpx;
						font-family: PingFang SC;
						font-weight: 600;
						color: #1C1C1C;
					}
				}
				
				&-right {
					display: block;
					width: 35rpx;
					height: 35rpx;
				}
			}
		}
		
		&-content {
			width: 750rpx;
			padding: 206rpx 0 0;
			box-sizing: border-box;
			color: #1C1C1C;
			font-family: PingFang SC;
			min-height: 100vh;
			
			.list {
				padding: 0 32rpx;
				.list-item {
					display: flex;
					align-items: center;
					justify-content: space-between;
					padding: 40rpx 0;
					border-bottom: 1px solid #ececec;
					&:nth-child(1) {
						padding-top: 64rpx;
					}
					.item-title {
						margin-bottom: 26rpx;
						font-size: 32rpx;
						font-weight: 500;
						color: #000000;
						line-height: 30rpx;
					}
					.item-date {
						font-size: 24rpx;
						font-weight: 500;
						color: #999999;
						line-height: 18rpx;
					}
					.item-num {
						font-size: 30rpx;
						font-weight: 500;
						color: #FF4810;
						line-height: 26rpx;
					}
				}
			}
		}
	}
</style>