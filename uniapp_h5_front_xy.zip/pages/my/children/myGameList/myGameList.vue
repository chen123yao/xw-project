<template>
	<view class="myGameList">
		<view class="nav-tabs">
			<u-tabs :list="myGame" @click="click"  lineWidth="40rpx" lineHeight="2px" lineColor="#ff5927" :activeStyle="{color: '#1c1c1c',fontWeight: 'bold'}"
			:inactiveStyle="{color: '#999'}" :current="active" itemStyle="padding-left: 15px; padding-right: 15px; height: 84rpx;" style="border-bottom: 1rpx solid #eee;"></u-tabs>
		</view>
		<view class="" v-if="pageData">
			<view class="game-list-box" v-for="(value,key,index) in pageData" :key="index" v-if="index==active" :style="{minHeight:myHeight-364+'rpx'}">
				<template v-if="value.list.length">				
					<view class="item" v-for="(item,i) in value.list" :key="i">
						<view class="itemLeft" style="display: flex;align-items: center;" @click="handleRouter(item.game_id)">
							<image :src="item.new_icon||item.icon" mode="widthFix" style="width: 126rpx;height: 126rpx;margin-right: 24rpx;"></image>
							<view class="gameDetail">
								<text class="game_name" v-if="$store.state.platform == 'android'">{{item.name.length>10?item.name.slice(0,8)+'..':item.name}}</text>
								<text class="game_name game_name_ios" v-else>{{item.name}}</text>
								<text class="text" style="margin: 6rpx 0;" v-if="active==0">最近游戏时间：{{item.time_str}}</text>
								<text class="text" style="margin: 6rpx 0;" v-else-if="active==1">收藏时间：{{item.collect_time|dateFormat('MM.dd')}}</text>
								<text class="text" style="font-size: 24rpx;color: #999;">当前游戏小号{{item.trumpet_num}}</text>
							</view>
						</view>
					</view>
<!-- 					<u-loadmore :status="status" loading-text="努力加载中" loadmore-text="加载更多" nomore-text="没有更多了"
					 fontSize="28" line height="80" /> -->
				</template>
				<view class="" style="display: flex;flex-direction: column;align-items: center;justify-content: center;" :style="{height:myHeight-412+'rpx'}" v-else>					
					<vue-loading :isNoData="isNoData"></vue-loading>
				</view>
			</view>
		</view>
		<view class="buttony" v-if="!Object.keys(userInfo).length">
			<text class="mybutton" @click="handleRoute('/pages/my/children/login')">登录后查看</text>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				active: 0,
				myGame: [{
						id: 0,
						name: '玩过'
					},
					{
						id: 1,
						name: '收藏'
					},
					{
						id: 2,
						name: '预约'
					}
				],
				params: {
					page: 1,
					offset: 10,
				},
				pageData: null,
				isNoData: false,
				count: [],
			}
		},
		computed: {
			myHeight() {
				return uni.getSystemInfoSync().windowHeight * (750 / uni.getSystemInfoSync().windowWidth)
			},
			userInfo(){
				return this.$store.state.userInfo
			}
		},
		methods: {
			click(item) {
				this.active = item.id
				console.log(this.active);
			},
			getPageData(){
				this.$api.get("user/my_games",{
					...this.params
				}).then(res => {
					this.isNoData = true
					if(res.data.code==200){
						this.pageData = res.data.data
						if(res.data.data) {
							Object.keys(this.pageData).forEach((item,index)=>{
								this.count[index] = this.pageData[item].count
							})
						}
					}
				})
			},
			// getMoreData() {  //下拉加载更多bug暂不修复
			// 	console.log(this.count[this.active],'this.count[active]');
			// 	if(this.pageData && this.count[this.active] > this.pageData['player_games'].length && this.status == "loadmore"){
			// 		this.status = "loading"
			// 		this.params.page++
			// 		this.getPageData()	
			// 	}
			// },
			clearData(){
				this.pageData = null
			},
			handleRoute(url){
				uni.navigateTo({
					url
				})
			},
			handleRouter(id){
				// if(this.getpack(package_name)){
				// 	plus.runtime.launchApplication( {pname:package_name}, err => {uni.showToast({ title:'打开失败',icon:'none'	})} );
				// }else{
				uni.navigateTo({
					url: `/pages/view/gameDetail/gameDetail?gameId=${id}`
				})	
			}
		},
		mounted(){
			if(Object.keys(this.userInfo).length){
				this.getPageData()
			}else{
				this.clearData()
			}
		}
	}
</script>

<style lang="scss">
	.myGameList {
		.nav-tabs {
			position: sticky;
			top: 136rpx;
			padding: 0 24rpx;
			padding-top: 36rpx;
			height: 84rpx;
			z-index: 99;
			background-color: #fff;
			border-radius: 20rpx 20rpx 0 0;
			// border-bottom: 1px solid #efefef;
			::v-deep .u-tabs__wrapper__nav__item {
				flex: 1;
			}
		}
		.game-list-box {
			padding: 48rpx 24rpx 0;
			background-color: #fff;
			border-radius: 0 0 20rpx 20rpx;
			box-sizing: border-box;
			.item{
				display: flex;
				align-items: center;
				justify-content: space-between;
				padding-bottom: 32rpx;
				margin-bottom: 32rpx;
				border-bottom:1px solid #ECECEC;
				&:nth-last-child(1) {
					border-color: transparent;
				}
				.gameDetail {
					display: flex;
					flex-direction: column;
					.game_name{
						font-size: 36rpx;
						font-weight: 700;
						color: #1C1C1C;
					}
					.game_name_ios {
						lines: 1;
						text-overflow: ellipsis;
						width: 450rpx;
					}
					.text{
						font-size: 24rpx;
						color: #666;
					}
				}
			}
		}
		.buttony{
			display: flex;
			height: 480rpx;
			flex-direction: row;
			justify-content: center;
			align-items: center;
			background-color: #fff;
		}
		.mybutton {
			color: #ff5927;
			font-size: 34rpx;
			border-radius: 40rpx;
			padding: 12rpx 60rpx;
			border: 1px solid #f5f5f5;
		
		}
	}
</style>