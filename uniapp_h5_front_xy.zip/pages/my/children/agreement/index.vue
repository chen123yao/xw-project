<template>
	<view class="container">
		<view class="container-topTitle">
			<view class="container-topTitle-box">
				<view class="container-topTitle-box-left">
					<image class="container-topTitle-box-left-img" src="@/static/images/left.png" mode="heightFix" @click="back" />
					<text class="container-topTitle-box-left-text">{{ title }}</text>
				</view>
			</view>
		</view>
		
		<view class="container-content">
			<web-view :src="url" style="margin-top: 205rpx;"></web-view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				type: 0,
				url: '',
				title: ''
			}
		},
		onLoad(option) {
			console.log(option)
			this.type = option.type
			this.url = 'https://page.4000yx.com/active/agreement?agent_id=' + this.$store.state.client_id +'&type=' + this.type
			
		},
		onReady() {
			this.title = this.type == 1 ? '隐私策略': '用户协议'
		},
		methods:{
			back() {
				uni.navigateBack()
			},
		}
	}
</script>

<style lang="scss">
	.container {
		background-color: #FFFFFF;
		width: 750rpx;
		height: 100vh;
		
		&-topTitle {
			position: fixed;
			// background-color: #FFFFFF;
			background: linear-gradient(to bottom, #CCCCCC, #FFFFFF env(safe-area-inset-top));
			z-index: 999;
			top: 0;
			width: 750rpx;
			height: 176rpx;
			padding: 0 34rpx 16rpx;
			box-sizing: border-box;
			display: flex;
			flex-direction: column;
			justify-content: flex-end;
			box-shadow: 0rpx 0rpx 12rpx rgba(0, 0, 0, 0.16);
			
			&-box {
				box-sizing: border-box;
				display: flex;
				flex-direction: row;
				justify-content: space-between;
				align-items: center;
				
				&-left {
					display: flex;
					flex-direction: row;
					align-items: center;
					
					&-img {
						height: 34rpx;
					}
					
					&-text {
						margin-left: 48rpx;
						font-size: 40rpx;
						line-height: 56rpx;
						font-family: PingFang SC;
						font-weight: 600;
						color: #1C1C1C;
					}
				}
				
				&-right {
					display: block;
					width: 35rpx;
					height: 35rpx;
				}
			}
		}
		
		&-content {
			width: 750rpx;
			padding: 176rpx 0 0;
			box-sizing: border-box;
			color: #1C1C1C;
			font-family: PingFang SC;
			min-height: 100vh;
		}
	}
</style>
