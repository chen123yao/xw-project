<template>
	<view class="container shopping">
		<!-- cc 游戏专题详情页面顶部标题 -->
		<view class="shopping-topTitle">
			<view class="shopping-topTitle-box">
				<view class="shopping-topTitle-box-left">
					<image class="shopping-topTitle-box-left-img" src="@/static/images/left.png" mode="heightFix" @click="back" />
					<text class="shopping-topTitle-box-left-text">积分商城</text>
				</view>
			
				<image class="shopping-topTitle-box-right" src="@/static/images/my/my_details.png" mode="heightFix" @click="handleRouter('/pages/my/integral/integral')"></image>
			</view>
		</view>
		
		<view class="shopping-content">
			<view class="content">
				<view class="demoTitle">
					<image src="@/static/images/my/pointMall/jfsc_banner.png" mode="widthFix" style="width: 100%;"></image>
				</view>
				<view class="demotext">
					<text class="text_le">我的积分：{{userInfo.my_integral}}</text>
					<view class="text_ri">
						<image class="ri_img" src="@/static/images/my/pointMall/rhhqjf.png" mode="widthFix" @click="isShow= true"></image>
						<text class="ri_text"  @click="isShow= !isShow">如何获得积分</text>
					</view>
				</view>
				<view class="itemlist">
					<view class="item" style="width:328rpx;">
						<view class="item_head" @click="handleRouter('/pages/getMoney/index',2)">
							<image src="@/static/images/my/pointMall/jfsc-xyzp.png" style="width: 140rpx;" mode="widthFix"></image>
							<text class="head_text">积分“转”大奖</text>
						</view>
						<text class="item_mi">幸运转盘</text>
						<view class="item_bo" @click="handleRouter('/pages/getMoney/index',2)">
							<text class="bo_text" >立即兑换</text>
						</view>
					</view>
					<view class="item" style="width:328rpx;" v-for="item in pageData" :key='item.id'>
						<view class="item_head" v-if="item.goods_img" >
							<image :src="item.goods_img" style="width: 140rpx;" mode="widthFix"></image>
							<text class="head_text">{{item.goods_content.length>12?item.goods_content.slice(0,10)+'..':item.goods_content}}</text>
						</view>
						<view class="item_head" v-else >
							<image :src="item.integral<=500?'../../../../static/images/my/jfsc-5ptb.png':(item.integral>500&&item.integral<=1000)?'../../../../static/images/my/jfsc-10ptb.png':(item.integral>1000&&item.integral<=2000)?'../../../../static/images/my/jfsc-20ptb.png':'../../../../static/images/my/jfsc-30ptb.png'" style="width: 140rpx;" mode="widthFix"></image>
							<text class="head_text">{{item.goods_content.length>12?item.goods_content.slice(0,10)+'..':item.goods_content}}</text>
						</view>
						<text class="item_mi">{{item.goods_name.length>12?item.goods_name.slice(0,10)+'..':item.goods_name}}</text>
						<view class="item_bo" @click="handleClick(item)">
							<text class="bo_text" >立即兑换</text>
						</view>
					</view>
				</view>
				<u-popup :show="isShow" :round="40" mode="center" @close="close" @open="open" class="pop1" zIndex="900" overlayStyle="z-index:900">
					<image src="@/static/images/my/pointMall/jfsc-jfgz.png" style="border-radius:40rpx;width: 600rpx;" mode="widthFix" class="showimg"></image>
					<text class="show_text1">1.每日签到，实名认证，充值获取积分。</text>
					<text class="show_text2">2.完成游戏任务，获取积分。</text>
					<view class="show_box" @click="close">
						<text class="show_text3" >我知道了</text>
					</view>
				</u-popup>
				<u-popup :show="exchangeShow" :round="40" mode="center" @close="close" @open="open" class="pop1" zIndex="900" overlayStyle="z-index:900">
					<image src="@/static/images/my/pointMall/jfsc-qrdh.png" style="border-radius: 40rpx;width: 600rpx;"  mode="widthFix" class="showimg"></image>
					<view class="img_box" style="position:absolute;bottom: 48rpx;padding: 0 46rpx;" v-if="subData">
						<view style="background: #F7F7FF;display:flex;padding:30rpx;border-radius:10rpx;">
							<image style="width: 90rpx;height: 90rpx;border-radius:45rpx " src="@/static/images/ptbicon.png" mode="widthFix"></image>
							<view style="margin-left:30rpx ;">
								<text style="color:#252525;font-weight: bold;font-size: 30rpx; ">{{subData.goods_name}}</text>
								<text style="display: block;color:#FF4810;font-size:28rpx;font-weight: 400;margin-top: 10rpx;">您将消耗{{subData.integral}}积分</text>
							</view>
						</view>
						<view v-if="userInfo.my_integral<subData.integral" class="img_text2" style="margin-top:10rpx ;border-radius: 10rpx;background: #F7F7FF;display:flex;align-items: center;">
							<text style="width: 28rpx;height: 28rpx;border-radius:28rpx;background:#19BFFF ;margin-right:15rpx;color: #fff;font-size: 20rpx;font-weight:400 ;text-align: center;">!</text>
							<text style="color: #19BFFF;font-size: 26rpx;font-weight: 400;white-space: nowrap;">您的积分不足，快去完成任务赚取吧</text>
						</view>
						<view class="img_text3" style="margin-top:10rpx ;border-radius: 10rpx;background: #F7F7FF;text-align: center;font-size: 28rpx;color:#999999;font-weight:400;">
							可兑换数量 {{subData.remain_cnt-subData.change_cnt}}/{{subData.remain_cnt}}
						</view>
						<view  style="margin-top: 24rpx;border-radius: 35rpx;height: 70rpx;background:#F0F0F0;display:flex;">
							<view  @click="close" class="" style="border-radius: 35rpx 0 0 35rpx;border:1rpx solid #F0F0F0;width:50%;color: #666666;font-size: 26rpx;font-weight: 400;text-align: center;line-height: 70rpx;">
								我再想想
							</view>
							<view @click.native="subPtb" class="con" style="background:#fff;border:1rpx solid #FF4810;width:50%;color: #666666;font-size: 26rpx;font-weight: 400;text-align: center;line-height: 70rpx;">
								确认兑换
							</view>
						</view>
						<view style="color: #252525;font-size: 28rpx;font-weight: 400;margin:20rpx 0;">商品说明：</view>
						<view class="text_img">确认兑换，不予退还</view>
						<view class="text_img">兑换的平台币可以于平台任何游戏的充值</view>
						<view class="text_img">部分商品出现无法兑换等问题，请联系平台客服</view>
						<view class="text_img">在法律允许范围内，本平台拥有最终解释权</view>
					</view>
				</u-popup>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isShow: false,
				exchangeShow: false,
				clickShow: true,
				pageData: [],
				subData: null,
				count: 0,
				form: {
					page: 1,
				},
			}
		},
		computed: {
			userInfo(){
				return this.$store.state.userInfo
			},
			myWidth() {
				return uni.getSystemInfoSync().windowWidth
			},
		},
		methods: {
			back() {
				uni.navigateBack()
			},
			handleRouter(url,data=0) {
				if(data) {
					console.log(url,555);
					uni.setStorage({
						key: 'active',
						data: 2
					})
					uni.switchTab({
						url
					})
					return
				}
				uni.navigateTo({
					url
				})
			},
			getPageData() {
				this.$api.get(
					"app/shop/integralList", {
						mg_mem_id: this.userInfo.mem_id,
						...this.form			
					}
				).then((res) => {
					if(res.data.code==200){
					this.count = res.data.data.count;
					this.pageData = this.pageData.concat(res.data.data.list);	
					}
				});
			},
			open() {},
			close() {
				this.isShow = false
				this.exchangeShow =false
			},
			handleClick(item) {
				if (item.mem_times == 1 && item.is_exchange == 1) {
					uni.showToast({
						icon: "none",
						title: "该商品只能兑换一次!",
					});
					return;
				} else {
					this.exchangeShow = true;
					this.subData = item;
				}
			},
			//确认兑换
			subPtb() {
				if (this.clickShow) {
					this.clickShow = false;
					this.$api.get("app/shop/exchange_ptb", {
						ptb_cnt: this.subData.exchange_amount,
						integral: this.subData.integral,
						good_id: this.subData.id,
					}).then((res) => {
						if (res.data.code == 200) {
							if (this.subData.exchange_type == 1) {
								uni.showToast({
									icon: "none",
									title: "兑换成功",
									success: () => {
										setTimeout(() => {
											this.pageData = [];
											this.exchangeShow = false;
											this.$common.getuserInfo();
											this.getPageData();
											this.clickShow = true;
										}, 300);
									},
								});
							} else {
								uni.showToast({
									icon: "none",
									title: "已确认兑换，请联系客服兑换",
									success: () => {
										setTimeout(() => {
											this.pageData = [];
											this.exchangeShow = false;
											this.$common.getuserInfo();
											this.getPageData();
											this.clickShow = true;
											uni.navigateTo({
												url: '/pages/my/children/myService/index'
											})
										}, 300);
									},
								});
							}
						}else{
							console.log('999');
							uni.showToast({
								icon: "none",
								title: res.data.msg,
							});
							this.clickShow = true;
							return;
						}
					});
				}
			},
		},
		onLoad(){
			this.getPageData();
		}
	}
</script>

<style lang="scss">
	.container {
		background-color: #FFFFFF;
		width: 750rpx;
		height: 100vh;
	}
	
	.shopping {
		&-topTitle {
			position: fixed;
			// background-color: #FFFFFF;
			background: linear-gradient(to bottom, #CCCCCC, #FFFFFF env(safe-area-inset-top));
			z-index: 999;
			top: 0;
			width: 750rpx;
			height: 176rpx;
			padding: 0 34rpx 16rpx;
			box-sizing: border-box;
			display: flex;
			flex-direction: column;
			justify-content: flex-end;
			box-shadow: 0rpx 0rpx 12rpx rgba(0, 0, 0, 0.16);
			
			&-box {
				box-sizing: border-box;
				display: flex;
				flex-direction: row;
				justify-content: space-between;
				align-items: center;
				
				&-left {
					display: flex;
					flex-direction: row;
					align-items: center;
					
					&-img {
						height: 34rpx;
					}
					
					&-text {
						margin-left: 48rpx;
						font-size: 40rpx;
						line-height: 56rpx;
						font-family: PingFang SC;
						font-weight: 600;
						color: #1C1C1C;
					}
				}
				
				&-right {
					display: block;
					width: 35rpx;
					height: 35rpx;
				}
			}
		}
		
		&-content {
			width: 750rpx;
			padding: 176rpx 0 0;
			box-sizing: border-box;
			color: #1C1C1C;
			font-family: PingFang SC;
			min-height: 100vh;
			
			.content {
				.demotext{
					display: flex;
					justify-content: space-between;
					padding:10rpx 28rpx;
					.text_le{
						color: #252525;
						font-size:26rpx ;
						font-weight: 500;
					}
					.text_ri{
						display: flex;
						align-items: center;
						.ri_img{
							width:28rpx ;
							height: 28rpx;
							margin-right:6rpx ;
							margin-top:2rpx ;
						}
						.ri_text{
							font-size:26rpx ;
							font-weight: 500;
							color: #999999;
						}
					}
				}
				.itemlist{
					flex-wrap: wrap;
					padding:32rpx 28rpx;
					background: #F6F6F8;
					display:flex;
					justify-content: space-between;
					.item{
						padding:16rpx;
						margin-bottom: 40rpx;
						height: 360rpx;
						background: #FFFFFF;
						border-radius:40rpx ;
						display: flex;
						flex-direction: column;
						align-items: center;
						box-sizing: border-box;
						.item_head{
							width: 100%;
							height:200rpx;
							background: #F6F6F8;
							border-radius: 20px;
							display: flex;
							flex-direction: column;
							justify-content: center;
							align-items: center;
							.head_text{
								margin-top:10rpx ;
								font-size:26rpx ;
								color:#FF6A3D ;
								font-weight: 500;
							}
						}
						.item_mi{
							font-size:36rpx ;
							font-weight: 800;
							color: #000000;
							text-align: center;
							margin-top:15rpx ;
						}
						.item_bo{
							border: 2rpx solid #E3E3E3;
							width:140rpx ;
							height: 48rpx;
							border-radius:24rpx ;
							display:flex;
							justify-content: center;
							align-items: center;
							margin-top:20rpx ;
							.bo_text{
								color: #FF4810;
								font-size:26rpx ;
								font-weight: bold;
								
							}
						}
					}
				}
				.pop1 {
					.show_text1{
						color:#252525;
						font-size: 30rpx;
						font-weight: bold;
						position:absolute;
						top:230rpx ;
						left:60rpx ;
					}
					.show_text2{
						color:#252525;
						font-size: 30rpx;
						font-weight: bold;
						position:absolute;
						top:300rpx ;
						left:60rpx ;
					}
					.show_text3{
						position:absolute;
						top:400rpx ;
						left:200rpx ;
						width:210rpx ;
						height: 80rpx;
						border: 2rpx solid #E3E3E3;
						border-radius: 40rpx;
						color: #FF4810;
						text-align: center;
						line-height: 80rpx;
						font-size: 30rpx;
						font-weight: 500;
					}
				}
				.img_text2{
					padding: 10rpx 30rpx;
				}
				.img_text3{
					padding: 10rpx 0;
				}
				.con{
					border-radius: 0 35rpx 35rpx 35rpx;
				}
				.text_img{
					font-size: 24rpx;
					color: #999999;
					font-weight: 400;
				}
			}
		}
	}	
</style>