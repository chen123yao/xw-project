<template>
	<view class="container coupons">
		<view class="coupons-topTitle">
			<view class="coupons-topTitle-box">
				<view class="coupons-topTitle-box-left">
					<image class="coupons-topTitle-box-left-img" src="@/static/images/left.png" mode="heightFix" @click="back" />
					<text class="coupons-topTitle-box-left-text">我的优惠券</text>
				</view>
			</view>
		</view>
		
		<view class="coupons-content">
			<view class="nav-tabs">
				<u-tabs :list="TitleList" @click="click"  lineWidth="60rpx" lineHeight="2px" lineColor="#ff5927" :activeStyle="{color: '#000',fontWeight: 'bold'}" 
				:inactiveStyle="{color: '#1c1c1c'}" :current="active" itemStyle="padding-left: 15px; padding-right: 15px; height: 70rpx;"></u-tabs>
			</view>
			<view class="show-list" v-if="0==active">
				<template v-if="validCouponsList.length">
					<view  class="cell"  v-for="(item,index) in validCouponsList">
					 <vue-couponsItem :item="item.coupon"></vue-couponsItem>
					</view>
					<u-loadmore :status="status[0]" loading-text="努力加载中" loadmore-text="加载更多" nomore-text="没有更多了"
					 fontSize="28" line height="80" iconColor="#ff5927"  iconSize="48" loadingIcon="circle"	/>
				</template>
				<vue-loading :isNoData="isNoData[0]" v-else></vue-loading>
			</view>
			<view class="show-list" v-else-if="1==active">
				<template v-if="usedCouponsList.length">
					<view  class="cell"  v-for="(item,index) in usedCouponsList">
						<vue-couponsItem :item="item.coupon"></vue-couponsItem>
					</view>
					<u-loadmore :status="status[1]" loading-text="努力加载中" loadmore-text="加载更多" nomore-text="没有更多了"
					 fontSize="28" line height="80" iconColor="#ff5927"  iconSize="48" loadingIcon="circle"	/>
				</template>
				<vue-loading :isNoData="isNoData[1]" v-else></vue-loading>
			</view>
			<view class="show-list" v-else>
				<template v-if="unValidCouponsList.length">
					<view  class="cell"  v-for="(item,index) in unValidCouponsList">
						<vue-couponsItem :item="item.coupon"></vue-couponsItem>
					</view>
					<u-loadmore :status="status[2]" loading-text="努力加载中" loadmore-text="加载更多" nomore-text="没有更多了"
					 fontSize="28" line height="80" iconColor="#ff5927"  iconSize="48" loadingIcon="circle"	/>
				</template>
				<vue-loading :isNoData="isNoData[2]" v-else></vue-loading>
			</view>
		</view>	
	</view>
</template>

<script>
	export default {
		data() {
			return {
				active: 0,
				validCouponsList: [],
				usedCouponsList: [],
				unValidCouponsList: [],
				isNoData: [false,false,false],
				status: ['loadmore','loadmore','loadmore'],
				TitleList: [{
						id: 0,
						name: '可使用'
					},
					{
						id: 1,
						name: '已使用'
					},
					{
						id: 2,
						name: '已过期'
					}
				],
				params: [{
					page: 1,
					offset: 10,
					status: 1,
					count: 0,
				},
				{
					page: 1,
					offset: 10,
					status: 2,
					count: 0,
				},
				{
					page: 1,
					offset: 10,
					status: 3,
					count: 0,
				}],
			}
		},
		methods: {
			back() {
				uni.navigateBack()
			},
			click(item) {
					this.active = item.id
			},
			// 1.可使用
			getValidCouponsData() {
				this.$api.get('/user/coupons/list', {
					...this.params[0]
				}).then(res => {
					if (res.data.code == 200) {
						this.validCouponsList = this.validCouponsList.concat(res.data.data.list)
						this.params[0].count = res.data.data.count
						if(!res.data.data.count) {
							this.isNoData[0] = true
						}
						if(this.validCouponsList.length>=this.params[0].count) {
							this.status[0] = "nomore"
						} else {
							this.status[0] = "loadmore"
						}
					} else {
						uni.showToast({
							title:res.data.msg,
							icon: "none"
						})
					}
				})
			},
			// 2.已使用
			getUsedCouponsData() {
				this.$api.get('/user/coupons/list', {
					...this.params[1]
				}).then(res => {
					if (res.data.code == 200) {
						this.usedCouponsList = this.usedCouponsList.concat(res.data.data.list) ;
						this.params[1].count = res.data.data.count
						if(!res.data.data.count) {
							this.isNoData[1] = true
						}
						if(this.usedCouponsList.length>=this.params[1].count) {
							this.status[1] = "nomore"
						} else {
							this.status[1] = "loadmore"
						}
					} else {
						uni.showToast({
							title:res.data.msg,
							icon: "none"
						})
					}
				})
			},
			// 3.已过期
			getUnValidCouponsData() {
				this.$api.get('/user/coupons/list', {
					...this.params[2]
				}).then(res => {
					if (res.data.code == 200) {
						this.unValidCouponsList = this.unValidCouponsList.concat(res.data.data.list) ;
						this.params[2].count = res.data.data.count
						if(!res.data.data.count) {
							this.isNoData[2] = true
						}
						if(this.unValidCouponsList.length>=this.params[2].count) {
							this.status[2] = "nomore"
						} else {
							this.status[2] = "loadmore"
						}
					} else {
						uni.showToast({
							title:res.data.msg,
							icon: "none"
						})
					}
				})
			}
		},
		onLoad() {
			this.getValidCouponsData()
			this.getUsedCouponsData()
			this.getUnValidCouponsData()
		},
		onReachBottom() {
			if(!this.active) {
				if(this.params[0].count>this.validCouponsList.length && this.status[0] == "loadmore"){
					this.status[0] = "loading"
					this.params[0].page++
					this.getValidCouponsData()	
				}
			} else if(1==this.active){
				if(this.params[1].count>this.usedCouponsList.length && this.status[1] == "loadmore"){
					this.status[1] = "loading"
					this.params[1].page++
					this.getUsedCouponsData()	
				}
			} else {
				if(this.params[2].count>this.unValidCouponsList.length && this.status[2] == "loadmore"){
					this.status[2] = "loading"
					this.params[2].page++
					this.getUnValidCouponsData()	
				}
			}
		}
	}
</script>

<style lang="scss">
	.container {
		background-color: #FFFFFF;
		width: 750rpx;
		height: 100vh;
	}
	
	.coupons {
		&-topTitle {
			position: fixed;
			// background-color: #FFFFFF;
			background: linear-gradient(to bottom, #CCCCCC, #FFFFFF env(safe-area-inset-top));
			z-index: 999;
			top: 0;
			width: 750rpx;
			height: 176rpx;
			padding: 0 34rpx 16rpx;
			box-sizing: border-box;
			display: flex;
			flex-direction: column;
			justify-content: flex-end;
			box-shadow: 0rpx 0rpx 12rpx rgba(0, 0, 0, 0.16);
			
			&-box {
				box-sizing: border-box;
				display: flex;
				flex-direction: row;
				justify-content: space-between;
				align-items: center;
				
				&-left {
					display: flex;
					flex-direction: row;
					align-items: center;
					
					&-img {
						height: 34rpx;
					}
					
					&-text {
						margin-left: 48rpx;
						font-size: 40rpx;
						line-height: 56rpx;
						font-family: PingFang SC;
						font-weight: 600;
						color: #1C1C1C;
					}
				}
				
				&-right {
					display: block;
					width: 35rpx;
					height: 35rpx;
				}
			}
		}
		
		&-content {
			width: 750rpx;
			padding: 206rpx 0 0;
			box-sizing: border-box;
			color: #1C1C1C;
			font-family: PingFang SC;
			min-height: 100vh;
			
			.nav-tabs {
				position: sticky;
				left: 0;
				top: 88rpx;
				width: 100%;
				height: 84rpx;
				padding-top: 10rpx;
				background-color: #fff;
				z-index: 99;
				// ::v-deep .u-tabs__wrapper__nav__item {
				// 	flex: 1;
				// }
			}
			.show-list {
				padding: 0 32rpx;
			}
		}
	}
</style>