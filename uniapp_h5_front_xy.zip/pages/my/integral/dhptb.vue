<template>
	<view class="container">
		<view class="container-topTitle">
			<view class="container-topTitle-box">
				<view class="container-topTitle-box-left">
					<image class="container-topTitle-box-left-img" src="@/static/images/left.png" mode="heightFix" @click="back" />
					<text class="container-topTitle-box-left-text">兑换平台币</text>
				</view>
			</view>
		</view>
		
		<view class="container-content">
			<view class="box">
				<view class="head">
					<text class="head_text1">我的积分</text>
					<text class="head_text2">{{userInfo.my_integral}}</text>
				</view>
				<view class="head">
					<text class="head_text1">兑换平台币</text>
					<text class="head_text2" style="color: #999999;">({{userInfo.itg_ptb_rate || 100}}积分 = 1平台币)</text>
				</view>
				<view style="margin:32rpx 0rpx;">
					<input v-model="ptb_cnt" class="head_text1" type="number" value="" placeholder="请输入平台币数量"/>
				</view>
				<view class="head">
					<text class="head_text1">需消耗：</text>
					<text class="head_text2">{{userInfo.itg_ptb_rate*ptb_cnt || 0}}积分</text>
				</view>
				<view class="but" @click="exchangePtb">兑换平台币</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				ptb_cnt: ""
			}
		},
		computed: {
			userInfo(){
				return this.$store.state.userInfo
			},
		},
		methods: {
			back() {
				uni.navigateBack()
			},
			exchangePtb() {
				this.$api.get( "app/shop/goods/exchange_ptb",{
					ptb_cnt: this.ptb_cnt
				}).then(res => {
					console.log(res);
					if(res.data.code==200){
						uni.showToast({
							title:res.data.msg,
							icon:"none"
						})
						this.ptb_cnt=""
						this.$common.getuserInfo()
					}else{
						uni.showToast({
							title:res.data.msg,
							icon:"none"
						})
					}	
				})
			}
		}
	}
</script>

<style lang="scss">
	.container {
		background-color: #FFFFFF;
		width: 750rpx;
		height: 100vh;
		
		&-topTitle {
			position: fixed;
			// background-color: #FFFFFF;
			background: linear-gradient(to bottom, #CCCCCC, #FFFFFF env(safe-area-inset-top));
			z-index: 999;
			top: 0;
			width: 750rpx;
			height: 176rpx;
			padding: 0 34rpx 16rpx;
			box-sizing: border-box;
			display: flex;
			flex-direction: column;
			justify-content: flex-end;
			box-shadow: 0rpx 0rpx 12rpx rgba(0, 0, 0, 0.16);
			
			&-box {
				box-sizing: border-box;
				display: flex;
				flex-direction: row;
				justify-content: space-between;
				align-items: center;
				
				&-left {
					display: flex;
					flex-direction: row;
					align-items: center;
					
					&-img {
						height: 34rpx;
					}
					
					&-text {
						margin-left: 48rpx;
						font-size: 40rpx;
						line-height: 56rpx;
						font-family: PingFang SC;
						font-weight: 600;
						color: #1C1C1C;
					}
				}
				
				&-right {
					display: block;
					width: 35rpx;
					height: 35rpx;
				}
			}
		}
		
		&-content {
			width: 750rpx;
			padding: 206rpx 0 0;
			box-sizing: border-box;
			color: #1C1C1C;
			font-family: PingFang SC;
			min-height: 100vh;
	
			.box{
				padding:0rpx 32rpx ;
				.head{
					display: flex;
					justify-content: space-between;
					padding:32rpx 0;
					.head_text1{
						font-size: 30rpx;
						color:#909399;
						font-weight:400 ;
					}
					.head_text2{
						font-size: 30rpx;
						color: #ff8500;
						font-weight: 600;
						font-family: PingFang SC;
					}
				}
				.but{
					margin-top: 40rpx;
					border: solid 1px #E4E4E4;
					line-height:80rpx;
					height: 80rpx;
					border-radius: 40rpx;	
					text-align: center;
					color: rgb(255, 72, 16);
					font-size: 30rpx;
					font-weight: 600;
				}
			}
		}
	}
</style>