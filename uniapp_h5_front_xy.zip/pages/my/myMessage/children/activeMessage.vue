<template>
	<view class="container">
		<!-- cc 游戏专题详情页面顶部标题 -->
		<view class="container-topTitle">
			<view class="container-topTitle-box">
				<view class="container-topTitle-box-left">
					<image class="container-topTitle-box-left-img" src="@/static/images/left.png" mode="heightFix" @click="back" />
					<text class="container-topTitle-box-left-text">互动消息</text>
				</view>
			
				<image class="container-topTitle-box-right" :src="isActive?'../../../../static/images/my/message/xxxx.png':'../../../../static/images/my/message/rwzx-xgnc.png'" mode="heightFix" @click="handleDelete"></image>
			</view>
		</view>
		
		<view class="container-content">
			<view class="box">
				<view class="like" @click="tozan" v-if="likeDate.is_like_read">
					<view class="head_le">
						<view class="le_box">
							<image class="le_img" src="@/static/images/zan-acitve.png" ></image>
						</view>
						<text class="head_text1">当前有{{likeDate.is_like_read}}条新点赞</text>
					</view>
					<view class="haed_ri">
						<image class="ri_img" src="@/static/images/left-gred.png" ></image>
					</view>
				</view>
				<view class="msg-list" v-if="pageDate.length">
					<view class="middle" v-for="(item,index) in pageDate" @click="handleDel(item,index)">
						<view class="mid_le" v-if="isActive" >
							<view class="le_box2" v-if="!item.noActive"></view>
							<image class="le_box1" v-else src="@/static/images/down_acitve.png" ></image>
						</view>
						<view class="mid_ri">
							<view class="ri_head">
								<view style="display: flex;">
									<image class="mid_img" :src="item.mem_avatar" mode="" ></image>
									<view>
										<view class="mid_text1">{{item.mem_name}}</view>
										<view class="mid_text2">{{item.time_str}} · {{item.game_name}}</view>
									</view>
								</view>
								<text class="mid_text3">回复</text>
							</view>
							<text class="ri_mid" >{{item.content}}</text>
							<view class="ri_bot" v-if="item.parent_comment">
								<text class="bot_text">{{item.parent_comment.content}}</text>
							</view>
						</view>
					</view>
					<u-loadmore :status="status" loading-text="努力加载中" loadmore-text="加载更多" nomore-text="没有更多了"
					 fontSize="28" line height="80" iconColor="#ff5927"  iconSize="48" loadingIcon="circle"	/>
				</view>
				 <vue-loading :isNoData="isNoData" v-else></vue-loading>
			</view>
		</view>
		<view class="bottom" v-if="isActive" >
			<view class="bot_box" @click="handleNotall"  v-if="selectAll">
				<image class="le_box1"  src="@/static/images/down_acitve.png" ></image>
				<text class="bottom_text">全不选</text>	
			</view>
			<view class="bot_box"  @click="handleAll"  v-else>
				<view class="le_box2"></view>
				<text class="bottom_text" >全选</text>	
			</view>
			<view class="bot_box1" @click="getDelDate">
				<text class="box1_text">删除当前{{isNumber}}条评论</text>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isActive: false,
				isNoData: false,
				selectAll: false,
				isNumber: 0,
				status: 'loadmore',
				count: 0,
				params: {
					page: 1,
					offset: 10,
				},
				likeDate: [],
				pageDate: [],
			}
		},
		methods: {
			back() {
				uni.navigateBack()
			},
			handleDelete() {
				if(this.count){
					// uni.vibrateShort({
					// 	success: () => {
					// 		uni.showToast({
					// 			title:'?????????',
					// 			icon:"none"
					// 		})
							
							
					// 	},fail() {
					// 		uni.showToast({
					// 			title:'!!!!!!!!',
					// 			icon:"none"
					// 		})
					// 	}
					// })
					
					this.isActive = !this.isActive
					this.isNumber = this.pageDate.filter(item => {
						return item.noActive == true
					}).length
				}else{
					this.isActive = false
				}
			},
			tozan(){
				uni.navigateTo({
					url:"/pages/my/myMessage/children/activeMessage/Myzan1"
				})
			},
			//消息数据
			getPageData(){
				this.$api.get("v8/comments/message_list",{
					...this.params
				}).then(res=> {
					if(res.data.data && res.data.data.list) {
						this.pageDate = this.pageDate.concat(res.data.data.list)
						this.count = res.data.data.count
					}
					if(!res.data.count) {
						this.isNoData = true
					}
					this.likeDate = res.data.data
					this.status = "loadmore"
					if(this.pageDate.length >= this.count) {
						this.status = "nomore"
					}
				})
			},
			//确认删除
			getDelDate(){
				let comment_ids = []
				this.pageDate.map(item => {
					if (item.noActive) {
						comment_ids.push(item.id)
					}
				})
				this.$api.get("v8/comments/del_message",{
					del_type: "comment",
					comment_ids
				}).then(res=>{
					if(res.data.code==200){
						this.pageDate = []
						this.params.page = 1
						setTimeout(()=>{
							this.getPageData()
						},1000)
						this.isActive = false
					}else{
						uni.showToast({
							title:res.data.msg,
							icon:"none"
						})
					}
				})
			},
			//全选
			handleAll() {
				this.isNumber = 0
				this.pageDate.map(item => {
					item.noActive = true
					if (item.noActive) {
						this.isNumber++
					}
				})
				this.selectAll = true	
			},
			//全不选
			handleNotall(){
				this.isNumber = this.pageDate.length
					this.pageDate.map(item => {
						item.noActive = false
						if (!item.noActive) {
							this.isNumber--
						}
					})
				this.selectAll = false			
			},
			//筛选
			handleDel(item,i) {
				if(this.isActive){
					this.pageDate[i].noActive = !this.pageDate[i].noActive
					this.isNumber = this.pageDate.filter(item => {
						return item.noActive == true
					}).length
					if (this.isNumber == this.pageDate.length) {
						this.selectAll = true
					} else {
						this.selectAll = false
					}
				}else{
					//回复评论
					let itemstr = JSON.stringify(item.parent_comment)
					uni.navigateTo({
						url: `/pages/view/gamedetail/commentDetail1?gameid=${item.game_id}&item=${itemstr}&type=${this.type}`
					})
				}
			},
		},
		onLoad(){
			this.getPageData()
		},
		onReachBottom() {
			if(this.count>this.pageDate.length && this.status == "loadmore"){
				this.status = "loading"
				this.params.page++
				this.getPageData()	
			}
		}
	}
</script>

<style lang="scss">
	.container {
		background-color: #FFFFFF;
		width: 750rpx;
		height: 100vh;
		
		&-topTitle {
			position: fixed;
			// background-color: #FFFFFF;
			background: linear-gradient(to bottom, #CCCCCC, #FFFFFF env(safe-area-inset-top));
			z-index: 999;
			top: 0;
			width: 750rpx;
			height: 176rpx;
			padding: 0 34rpx 16rpx;
			box-sizing: border-box;
			display: flex;
			flex-direction: column;
			justify-content: flex-end;
			box-shadow: 0rpx 0rpx 12rpx rgba(0, 0, 0, 0.16);
			
			&-box {
				box-sizing: border-box;
				display: flex;
				flex-direction: row;
				justify-content: space-between;
				align-items: center;
				
				&-left {
					display: flex;
					flex-direction: row;
					align-items: center;
					
					&-img {
						height: 34rpx;
					}
					
					&-text {
						margin-left: 48rpx;
						font-size: 40rpx;
						line-height: 56rpx;
						font-family: PingFang SC;
						font-weight: 600;
						color: #1C1C1C;
					}
				}
				
				&-right {
					display: block;
					width: 35rpx;
					height: 35rpx;
				}
			}
		}
		
		&-content {
			width: 750rpx;
			padding: 176rpx 0 0;
			box-sizing: border-box;
			color: #1C1C1C;
			font-family: PingFang SC;
			min-height: 100vh;
			
			.box {
				padding: 32rpx 32rpx 0 ;
				.like {
					display: flex;
					background: #F4F4F4;
					padding: 40rpx 32rpx;
					border-radius: 40rpx;
					align-items: center;
					justify-content: space-between;
					margin-bottom: 40rpx;
					.head_le{
						display: flex;
						align-items: center;
						.le_box{
							width: 64rpx;
							height: 64rpx;
							border-radius: 64rpx;
							background: #fff;
							display: flex;
							flex-direction: column;
							justify-content: center;
							align-items: center;
							margin-right: 32rpx;
						}
						.head_text1{
							font-size: 30rpx;
							font-weight: 400;
							color: #666666;
						}
						.le_img{
							width: 30rpx;
							height: 30rpx;
						}
					}
					.ri_img{
						display: flex;
						width: 20rpx;
						height: 30rpx;
					}
				}
				.middle{
					display: flex;
					align-items: center;
					margin-bottom: 40rpx;
					.le_box2{
						width: 40rpx;
						height: 40rpx;
						border-radius: 40rpx;
						border: 2rpx solid #EFEFEF;
						margin-right: 32rpx;
					}
					.le_box1{
						width: 40rpx;
						height: 40rpx;
						border-radius: 40rpx;
						border: 2rpx solid #FF5927;
						margin-right: 32rpx;
					}
					.mid_ri{
						flex: 1;
						padding: 24rpx;
						background: #F4F4F4;
						border-radius: 40rpx;
					}
					.ri_head{
						display: flex;
						justify-content: space-between;
						align-items: center;
					}
					.mid_img{
						width: 80rpx;
						height: 80rpx;
						border: 1rpx solid #E4E4E4;
						border-radius: 80rpx;
						margin-right: 32rpx;
					}
					.mid_text1{
						font-size: 34rpx;
						font-weight: bold;
						color: #1C1C1C;
					}
					.mid_text2{
						font-size: 24rpx;
						font-weight: 400;
						color: #666666;
					}
					.mid_text3{
						font-size: 28rpx;
						font-weight: 400;
						color: #666666;
					}
					.ri_mid{
						font-size: 30rpx;
						font-weight: 400;
						color: #1C1C1C;
						margin-top: 15rpx;
					}
					.ri_bot{
						margin-top: 20rpx;
						padding: 15rpx 24rpx;
						border-radius: 16rpx;
						background: #E4E4E4;
					}
					.bot_text{	
						color: #666666;
						font-size: 28rpx;
						font-weight: 400;
						text-overflow: ellipsis;
						lines: 1;
					}
				}
			}
		}
		.bottom{
			width: 100%;
			box-sizing: border-box;
			position: fixed;
			bottom: 0rpx;
			padding: 20rpx 32rpx;
			display: flex;
			align-items: center;
			justify-content: space-between;
			background: #fff;
			.bottom_text{
				color: #666666;
				font-size: 30rpx;
				font-weight: 400;
			}
			.bot_box{
				flex-direction: row;
				align-items: center;
			}
			.bot_box1{
				padding: 18rpx 150rpx;
				border: 2rpx solid #E4E4E4;
				border-radius: 40rpx;
			}
			.box1_text{
				font-size: 26rpx;
				font-weight: 400;
				color: #FF5927;
			}
		}
	}
</style>