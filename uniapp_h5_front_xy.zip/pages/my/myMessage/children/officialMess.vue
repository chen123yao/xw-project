<template>
	<view class="officialMess container">
		<view class="container-topTitle">
			<view class="container-topTitle-box">
				<view class="container-topTitle-box-left">
					<image class="container-topTitle-box-left-img" src="@/static/images/left.png" mode="heightFix" @click="back" />
					<text class="container-topTitle-box-left-text">官方通知</text>
				</view>
			</view>
		</view>
		
		<view class="container-content">
			<view class="notice-list" v-if="pageData.length">			
				<view class="notice" v-for="(item,index) in pageData" :key='index'>
					<view class="text1" @click="handleRouter(item.game_id)">{{item.title}}</view>
					<view class="text2">{{item.content}}</view>
					<view class="text3">{{item.create_time|dateFormat('yyyy/MM/dd hh:mm:ss')}}</view>
				</view>
				<u-loadmore :status="status" loading-text="努力加载中" loadmore-text="加载更多" nomore-text="没有更多了"
				 fontSize="28" line height="80" iconColor="#ff5927"  iconSize="48" loadingIcon="circle"	/>
			</view>
			<vue-loading :isNoData="isNoData" v-else></vue-loading>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				status: 'loadmore',
				isNoData:false,
				params: {
					page: 1,
					offset: 10,
					type: 2
				},
				count:0,
				pageData: [],
			}
		},
		methods: {
			back() {
				uni.navigateBack()
			},
			/* 消息列表 */
			getPageData() {
				this.$api.get("msg/list", {
					...this.params
				}).then(res => {
					this.status = "loadmore"
					if(res.data.data && res.data.data.list) {
						this.pageData = this.pageData.concat(res.data.data.list);
						this.count = res.data.data.count
					}
					if(!res.data.data.count) {
						this.isNoData = true
					}
					if(this.pageData.length >= this.count) {
						this.status = "nomore"
					}
					this.pageData.map(item => {
						var reg = /<[^<>]+>/g
						item.content=item.content.replace(reg,'')
					})					
				})
			},
		},
		onLoad() {
			this.getPageData()
		},
		onReachBottom() {
			if(this.count>this.pageData.length && this.status == "loadmore"){
				this.status = "loading"
				this.params.page++
				this.getPageData()	
			}
		}
	}
</script>

<style lang="scss">
	.container {
		background-color: #FFFFFF;
		width: 750rpx;
		height: 100vh;
		
		&-topTitle {
			position: fixed;
			// background-color: #FFFFFF;
			background: linear-gradient(to bottom, #CCCCCC, #FFFFFF env(safe-area-inset-top));
			z-index: 999;
			top: 0;
			width: 750rpx;
			height: 176rpx;
			padding: 0 34rpx 16rpx;
			box-sizing: border-box;
			display: flex;
			flex-direction: column;
			justify-content: flex-end;
			box-shadow: 0rpx 0rpx 12rpx rgba(0, 0, 0, 0.16);
			
			&-box {
				box-sizing: border-box;
				display: flex;
				flex-direction: row;
				justify-content: space-between;
				align-items: center;
				
				&-left {
					display: flex;
					flex-direction: row;
					align-items: center;
					
					&-img {
						height: 34rpx;
					}
					
					&-text {
						margin-left: 48rpx;
						font-size: 40rpx;
						line-height: 56rpx;
						font-family: PingFang SC;
						font-weight: 600;
						color: #1C1C1C;
					}
				}
				
				&-right {
					display: block;
					width: 35rpx;
					height: 35rpx;
				}
			}
		}
		
		&-content {
			width: 750rpx;
			padding: 206rpx 0 0;
			box-sizing: border-box;
			color: #1C1C1C;
			font-family: PingFang SC;
			min-height: 100vh;
			
			.notice-list {		
				padding: 32rpx;
				.notice {
					margin-bottom: 40rpx;
					padding: 24rpx;
					background: #F4F4F4;
					border-radius: 40rpx;
					.text1{
						color: #1C1C1C;
						font-size: 32rpx;
						font-weight: bold;
					}
					.text2{
						color: #666666;
						font-size: 30rpx;
						font-weight: 400;
						line-height: 45rpx;
					}
					.text3{
						color: #C1C1C1;
						font-weight: 400;
						font-size: 28rpx;
					}
				}
			}
		}
	}
</style>