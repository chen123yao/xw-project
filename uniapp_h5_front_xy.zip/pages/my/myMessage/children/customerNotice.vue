<template>
	<view class="container">
		<view class="container-topTitle">
			<view class="container-topTitle-box">
				<view class="container-topTitle-box-left">
					<image class="container-topTitle-box-left-img" src="@/static/images/left.png" mode="heightFix" @click="back" />
					<text class="container-topTitle-box-left-text">客服通知</text>
				</view>
			</view>
		</view>
		
		<view class="container-content">
			<view class="notice-list" v-if="pageData">
				<view class="head" v-for="(item,index) in pageData['account_sell']" :key="'account_sell'+index">
					<view class="head_1">
						<text class="text1" >小号出售提醒</text>
						<text class="text2" :style="{color:item.status==1?'#19BFFF':item.status==2?'#FF4810':'#666666',fontSize:'28rpx'}">{{item.status==1?'待支付':item.status==2?'已支付':'支付失败'}}</text>
					</view>
					<text class="text3">{{item.gamename}}</text>
					<text class="text3">当前区服：{{item.server_name}}</text>
					<view class="head_2">
						<text class="text3">小号ID：{{item.mg_mem_id}}</text>
						<text class="text1">￥{{item.price}}</text>
					</view>
					<text class="text3" style="font-size: 26rpx;color: #999999;">{{item.create_time|dateFormat('yyyy/MM/dd hh:mm:ss')}}</text>
				</view>
				<view class="head" v-for="(item,index) in pageData['account_buy']" :key="'account_buy'+index">
					<view class="head_1">
						<text class="text1" >小号购买提醒</text>
						<text class="text2" :style="{color:item.status==1?'#19BFFF':item.status==2?'#FF4810':'#666666',fontSize:'28rpx'}">{{item.status==1?'待支付':item.status==2?'已支付':'支付失败'}}</text>
					</view>
					<text class="text3">{{item.gamename}}</text>
					<text class="text3">当前区服：{{item.server_name}}</text>
					<view class="head_2">
						<text class="text3">小号ID：{{item.mg_mem_id}}</text>
						<text class="text1">￥{{item.price}}</text>
					</view>
					<text class="text3" style="font-size: 26rpx;color: #999999;">{{item.create_time|dateFormat('yyyy/MM/dd hh:mm:ss')}}</text>
				</view>
				<view class="head" v-for="(item,index) in pageData['rebate_list']" :key="'rebate_list'+index">
					<view class="head_1">
						<text class="text1" >返利发放提醒</text>
						<text class="text2" :style="{color:item.status==1?'#19BFFF':item.status==2?'#FF4810':'#666666',fontSize:'28rpx'}">{{item.status==1?'待支付':item.status==2?'已支付':'支付失败'}}</text>
					</view>
					<text class="text3">{{item.name}}</text>
					<text class="text3">当前区服：{{item.server_name}}</text>
					<view class="head_2">
						<text class="text3">小号ID：{{item.mg_mem_id}}</text>
					</view>
					<text class="text3" style="font-size: 26rpx;color: #999999;">{{item.create_time|dateFormat('yyyy/MM/dd hh:mm:ss')}}</text>
				</view>
				<view class="head" v-for="(item,index) in pageData['feedback']" :key="'feedback'+index">
					<view class="head_1">
						<text class="text1" >我的反馈</text>
						<text class="text2" :style="{color:item.status==1?'#19BFFF':item.status==2?'#FF4810':'#666666',fontSize:'28rpx'}">{{item.status==1?'待支付':item.status==2?'已支付':'支付失败'}}</text>
					</view>
					<text class="text3">{{item.content}}</text>
					<text class="text3">官方回复：{{item.reply_content}}</text>
					
					<text class="text3" style="font-size: 26rpx;color: #999999;">{{item.create_time|dateFormat('yyyy/MM/dd hh:mm:ss')}}</text>
				</view>
			</view>
			<vue-loading :isNoData="isNoData" v-else></vue-loading>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				params:{
					page:1,
					offset:10 
				},
				pageData: null,
				isNoData: false,
			}
		},
		methods: {
			back() {
				uni.navigateBack()
			},
			getPageData(){
				this.$api.get("service/service_notice",{
					...this.params
				}).then(res=> {
					if(res.data.code==200){
						this.isNoData = true
						this.pageData = res.data.data
					}  
				})
			}
		},
		onLoad() {
			this.getPageData()
		}
	}
</script>

<style lang="scss">
	.container {
		background-color: #FFFFFF;
		width: 750rpx;
		height: 100vh;
		
		&-topTitle {
			position: fixed;
			// background-color: #FFFFFF;
			background: linear-gradient(to bottom, #CCCCCC, #FFFFFF env(safe-area-inset-top));
			z-index: 999;
			top: 0;
			width: 750rpx;
			height: 176rpx;
			padding: 0 34rpx 16rpx;
			box-sizing: border-box;
			display: flex;
			flex-direction: column;
			justify-content: flex-end;
			box-shadow: 0rpx 0rpx 12rpx rgba(0, 0, 0, 0.16);
			
			&-box {
				box-sizing: border-box;
				display: flex;
				flex-direction: row;
				justify-content: space-between;
				align-items: center;
				
				&-left {
					display: flex;
					flex-direction: row;
					align-items: center;
					
					&-img {
						height: 34rpx;
					}
					
					&-text {
						margin-left: 48rpx;
						font-size: 40rpx;
						line-height: 56rpx;
						font-family: PingFang SC;
						font-weight: 600;
						color: #1C1C1C;
					}
				}
				
				&-right {
					display: block;
					width: 35rpx;
					height: 35rpx;
				}
			}
		}
		
		&-content {
			width: 750rpx;
			padding: 206rpx 0 0;
			box-sizing: border-box;
			color: #1C1C1C;
			font-family: PingFang SC;
			min-height: 100vh;
			
			.notice-list {
				padding: 32rpx;
				.head{
					margin-bottom: 40rpx;
					padding: 24rpx;
					background: #F4F4F4;
					border-radius: 40rpx;
				}
				.head_1{
					display:flex;
					justify-content: space-between;
				}
				.text1{
					color: #1C1C1C;
					font-size: 32rpx;
					font-weight: bold;
				}
				.text2{
					color: #666666;
					font-size: 30rpx;
					font-weight: bold;
					line-height: 45rpx;
				}
				.text3{
					display: block;
					color: #666666;
					font-size: 28rpx;
					line-height: 45rpx;
					font-weight: bold;
				}
				.head_2{
					padding-bottom: 15rpx;
					display:flex;
					justify-content: space-between;
					border-bottom: 1rpx solid #E9E9E9;
				}
			}
		}
	}
</style>