<template>
	<view class="message">
		
		<view class="message-topTitle">
			<view class="message-topTitle-box">
				<image class="message-topTitle-box-left" src="@/static/images/left.png" mode="heightFix" @click="back" />
				<text class="message-topTitle-box-text">消息</text>
			</view>
		</view>
		
		<view class="msg-content" v-if="pageData">
			<view class="box1" @click="handleRouter('/pages/my/myMessage/children/officialMess')">
				<image class="box1-left" src="@/static/images/my/message/gftz.png" mode="scaleToFill"></image>
				<view class="box1-right">
					<view class="box1-right-title">
						<text class="text1">官方通知</text>
						<text class="text3">{{pageData.create_time|dateFormat('yyyy/MM/dd')}}</text>
					</view>
					<text class="text2" v-if="pageData.title">{{pageData.title}}</text>
					<text class="text2" v-else>暂无新通知</text>
				</view>
			</view>
			<view class="box1" @click="handleRouter('/pages/my/myMessage/children/activeMessage')">
				<view class="" style="position: relative;">					
					<image class="box1-left" src="@/static/images/my/message/hdxx.png" mode="scaleToFill">
					</image>
					<view v-if="likeDate.is_comment_read" class="comment_read" style="">{{likeDate.is_comment_read}}</view>
				</view>
				<view class="box1-right">
					<view class="box1-right-title">
						<text class="text1">互动消息</text>
						<text class="text3">{{page2Data.time_str}}</text>
					</view>
					<text class="text2" v-if="likeDate.is_comment_read">您有新消息</text>
					<text class="text2" v-else>暂无消息</text>
				</view>
			</view>
			<view class="box1" @click="handleRouter('/pages/my/myMessage/children/customerNotice')">
				<image class="box1-left" src="@/static/images/my/message/kftz.png" mode="scaleToFill"></image>
				<view class="box1-right">
					<view class="box1-right-title">
						<text class="text1">客服通知</text>
						<text class="text3">今天</text>
					</view>
					<text class="text2">[消息列表]</text>
				</view>
			</view>
			<view class="box1" @click="handleRouter('/pages/customerService/children/problem')">
				<image class="box1-left" src="@/static/images/my/message/cjwt.png" mode="scaleToFill"></image>
				<view class="box1-right">
					<view class="box1-right-title">
						<text class="text1">常见问题</text>
						<text class="text3">今天</text>
					</view>
					<text class="text2">HI，您好，请在底部选择你要咨询的...</text>
				</view>
			</view>
		</view>
		<vue-loading :isNoData="isNoData" v-else style="margin-top: 190rpx;"></vue-loading>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isNoData: false,
				params: {
					page: 1,
					offset: 1,
					type: 2
				},
				pageData: null,
				page2Data: [],
				likeDate: [],
			}
		},
		methods: {
			back() {
				uni.navigateBack()
			},
			// 官方通知
			getPageData() {
				this.$api.get("msg/list", {
					...this.params
				}).then(res => {
					this.isNoData = true
					if(res.data.data && res.data.data.list) {
						this.pageData = res.data.data.list[0];
					}
				})
			},
			getPage2Date(){
				this.$api.get("v8/comments/message_list",{	
					offset:1,
				}).then(res=> {
					this.page2Data = res.data.data.list[0]
					this.likeDate = res.data.data
				})
			},
			handleRouter(url){
				uni.navigateTo({
					url
				})
			}
		},
		onLoad(){
			this.getPageData()
		},
		onShow(){
			this.getPage2Date()
		}
	}
</script>

<style lang="scss">
	.message {
		width: 750rpx;
		height: 100vh;
		
		&-topTitle {
			position: fixed;
			// background-color: #FFFFFF;
			background: linear-gradient(to bottom, #CCCCCC, #FFFFFF env(safe-area-inset-top));
			z-index: 999;
			top: 0;
			width: 750rpx;
			height: 176rpx;
			padding-left: 34rpx;
			padding-bottom: 16rpx;
			box-sizing: border-box;
			display: flex;
			flex-direction: column;
			justify-content: flex-end;
			box-shadow: 0rpx 0rpx 12rpx rgba(0, 0, 0, 0.16);
			
			&-box {
				box-sizing: border-box;
				display: flex;
				flex-direction: row;
				align-items: center;
				
				&-left {
					// width: 22rpx;
					height: 34rpx;
				}
				
				&-text {
					margin-left: 48rpx;
					font-size: 40rpx;
					line-height: 56rpx;
					font-family: PingFang SC;
					font-weight: 600;
					color: #1C1C1C;
				}
			}
		}
		
		
		// padding-top: 44px;
		.top-bar {
			position: fixed;
			left: 0;
			top: 0;
			width: 100%;
			padding: 0 32rpx 0 16rpx;
			display: flex;
			align-items: center;
			height: 44px;
			box-sizing: border-box;
			font-size: 16px;
			color: #000;
			box-shadow: 0 0 10rpx rgba(160, 160, 160, 0.3);
			.arrow-left {
				margin-right: 32rpx;
			}
		}
		.msg-content {
			padding: 0 32rpx;
			padding-top: 176rpx;
			box-sizing: border-box;
			.box1 {
				display: flex;
				align-items: center;
				justify-content: space-between;
				.box1-left {
					display: block;
					width: 100rpx;
					height: 100rpx;
					margin-right: 40rpx;
					border-radius: 100rpx;
				}
				.comment_read {
					position: absolute;
					top: 25rpx;
					left: 65rpx;
					width: 30rpx;
					height: 30rpx;
					background: #FF5927;
					border-radius: 30rpx;
					font-size:20rpx;
					font-weight: 300;
					color: #fff;
					text-align: center;
					line-height: 34rpx;
				}
				.box1-right {
					flex: 1;
					padding: 32rpx 0;
					border-bottom:1rpx solid #efefef;
					.box1-right-title {
						display: flex;
						align-items: flex-start;
						justify-content: space-between;
						margin-bottom: 15rpx;
						.text1 {
							color: #1C1C1C;
							font-weight: bold;
							font-size: 32rpx;
						}
						.text3 {
							color: #C1C1C1;
							font-weight: 400;
							font-size: 28rpx;
						}
					}
					.text2{
						color: #666666;
						font-weight: 400;
						font-size: 30rpx;
					}
				}
			}
		}
	}
</style>