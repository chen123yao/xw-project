<template>
	<!-- cc 账号管理页面 -->
	<view class="container account">
		<!-- cc 账号管理页面顶部标题 -->
		<view class="account-topTitle">
			<view class="account-topTitle-box">
				<image class="account-topTitle-box-left" src="@/static/images/left.png" mode="heightFix" @click="back" />
				<text class="account-topTitle-box-text">账号管理</text>
			</view>
		</view>
		
		<!-- cc 是否请求数据中 显示loading界面 -->
		<!-- <u-loading-page class="account-loading" :loading="loadingData < 2" icon-size="72" font-size="30" loading-mode="spinner"></u-loading-page> -->
		
		<!-- cc 账号管理页面内容显示区域 -->
		<view class="account-content">
			<!-- cc 头像 -->
			<view class="account-content-avatar">
				<u-avatar :src="$store.state.userInfo.avatar" :size="248" style="margin: 0 auto;"></u-avatar>
				<image class="account-content-avatar-btn" src="@/static/images/userp.png" mode="scaleToFill" @click="changeAvatar"></image>
			</view>
			
			<view style="width:100%; height: 2rpx; margin-top: 56rpx; background-color: #EFEFEF;"></view>
			
			<view class="account-content-item">
				<text class="account-content-item-left">手机号</text>
				<view class="account-content-item-right">
					<text v-if="$store.state.userInfo.has_bind_mobile == 2">{{ $store.state.userInfo.mobile }}</text>
					<text v-else style="width: 100%; text-align: end;" @click="handleRouter('/pages/my/myAdministration/children/bindingMobile')">待绑定</text>
				</view>
			</view>
			
			<view class="account-content-item">
				<text class="account-content-item-left">昵称</text>
				<view class="account-content-item-right" @click="nickName.show = true">
					<text >{{ $store.state.userInfo.nickname }}</text>
					<image class="account-content-item-right-arrow" src="@/static/images/left_search.png"></image>
				</view>
			</view>
			
			<view class="account-content-item">
				<text class="account-content-item-left">密码修改</text>
				<view class="account-content-item-right" @click="handleRouter('/pages/my/myAdministration/children/changePassword')">
					<image class="account-content-item-right-arrow" src="@/static/images/left_search.png"></image>
				</view>
			</view>
			
			<view class="account-content-item">
				<text class="account-content-item-left">实名认证</text>
				<view class="account-content-item-right" @click="handleRouter('/pages/my/myAdministration/children/changeRealname')">
					<text v-if="$store.state.userInfo.is_real_name">已认证</text>
					<text v-else>未认证</text>
					<image class="account-content-item-right-arrow" src="@/static/images/left_search.png"></image>
				</view>
			</view>
		</view>
		
		<!-- cc 修改昵称面板 -->
		<u-popup class="account-nickName" :show="nickName.show" zIndex="10085" :round="40" :overlayStyle="{background: 'rgba(0, 0, 0, 0.8)'}" mode="center" @close="selectReset">
			<view class="account-nickName-layout">
				<text class="account-nickName-layout-title">修改昵称</text>
				
				<view class="account-nickName-layout-content">
					<view class="account-nickName-layout-content-item">
						<u--input placeholder="请输入昵称" v-model="nickName['value']" :customStyle="{background: '#FFFFFF', padding: '0 38rpx 32rpx', lineHeight: '28rpx', boxSizing: 'border-box'}"
							placeholderStyle="font-size: 28rpx; color: #999999;" maxlength="11" fontSize="28" color="#666666" type="text" clearable shape="circle" @confirm="handleSearch"></u--input>
					</view>
				</view>
				<!-- cc 下拉面板确定取消按钮layout -->
				<view class="account-nickName-layout-confirmLayout">
					<!-- cc 重置 -->
					<view class="account-nickName-layout-confirmLayout-reset" @click="selectReset">取消</view>
					<!-- cc 确认 -->
					<view class="account-nickName-layout-confirmLayout-confirm" @click="selectConfirm">确认</view>
				</view>
			</view>
		</u-popup>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				// cc 修改昵称
				nickName: {
					value: "",
					show: false,
				},
			}
		},
		methods: {
			// cc 返回上一级页面
			back() {
				uni.navigateBack({
					delta: 1
				});
			},
			// cc 跳转
			handleRouter(url){
				uni.navigateTo({
					url
				})
			},
			selectConfirm() {
				this.$api.get("user/nickname/update",{
					nickname: this.nickName.value,
				}).then(res => {
					if(res.data.code==200){
						uni.showToast({
							icon: 'none',
							title: res.data.msg
						})
						this.$common.getuserInfo()
					}
					else{
						uni.showToast({
							icon: 'none',
							title: res.data.msg
						})
					}
				})
				this.nickName.show = false
				this.nickName.value = ''
			},
			selectReset() {
				this.nickName.show = false
				this.nickName.value = ''
			},
			// 进入图库选图上传
			changeAvatar() {
				let that = this;
				uni.chooseImage({
					count: 1,
					sourceType: ['album'], //从相册选择
					success(file) {
						uni.uploadFile({
							url: that.$store.state.httpAPI+"asset/upload",
							files: [{
								name: "file",
								uri: file.tempFilePaths[0]
							}],
							success(res) {
								let avatar = JSON.parse(res.data).data.url;
								console.log('avatar', avatar);
								that.avatarUpload({
									avatar: avatar
								})
							},
						})
					}
				})
			},
			// 头像数据上传
			avatarUpload(params) {
				console.log('avatarUpload', params);
				this.$api.get("user/avatar/update",{ ...params
				}).then(res => {
					this.$common.getuserInfo();
				})
			},
		}
	}
</script>

<style lang="scss" scoped>
	::v-deep .u-fade-zoom-enter-active {
		justify-content: flex-start !important;
		margin-top: 262rpx;
	}
	
	::v-deep .u-fade-zoom-leave-active {
		justify-content: flex-start !important;
		margin-top: 262rpx;
	}
	
	.container { 
		background-color: #FFFFFF;
		width: 750rpx;
		height: 100vh;
		padding-bottom: 24rpx;
	}
	
	.account {
		
		&-loading {
			width: 750rpx;
			top: 176rpx !important;
		}
		
		&-topTitle {
			position: fixed;
			// background-color: #FFFFFF;
			background: linear-gradient(to bottom, #CCCCCC, #FFFFFF env(safe-area-inset-top));
			z-index: 999;
			top: 0;
			width: 750rpx;
			height: 176rpx;
			padding-left: 34rpx;
			padding-bottom: 16rpx;
			box-sizing: border-box;
			display: flex;
			flex-direction: column;
			justify-content: flex-end;
			// box-shadow: 0rpx 0rpx 12rpx rgba(0, 0, 0, 0.16);
			
			&-box {
				box-sizing: border-box;
				display: flex;
				flex-direction: row;
				align-items: center;
				
				&-left {
					// width: 22rpx;
					height: 34rpx;
				}
				
				&-text {
					margin-left: 48rpx;
					font-size: 40rpx;
					line-height: 56rpx;
					font-family: PingFang SC;
					font-weight: 600;
					color: #1C1C1C;
				}
			}
		}
		
		&-content {
			width: 750rpx;
			padding: 232rpx 32rpx 0;
			box-sizing: border-box;
			color: #1C1C1C;
			font-family: PingFang SC;
			position: relative;
			
			&-avatar {
				width: 248rpx;
				height: 248rpx;
				margin: 0 auto;
			  position: relative;
				
				&-btn {
					width: 48rpx;
					height: 48rpx;
					position: absolute;
					right: 4rpx;
					bottom: 4rpx;
				}
			}
			
			&-item {
				padding: 32rpx 24rpx;
				display: flex;
				flex-direction: row;
				justify-content: space-between;
				align-items: center;
				border-bottom: 2rpx solid #EFEFEF;
				
				&-left {
					font-size: 28rpx;
					font-family: PingFang SC;
					font-weight: 500;
					color: #1C1C1C;
					letter-spacing: 4rpx;
				}
				
				&-right {
					font-size: 28rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #666666;
					letter-spacing: 4rpx;
					display: flex;
					flex-direction: row;
					align-items: center;
					flex: 1;
					justify-content: flex-end;
					
					&-arrow {
						width: 16rpx;
						height: 24rpx;
						transform: rotate(180deg);
						margin-left: 24rpx;
					}
				}
			}
		}
		
		&-nickName {
			&-layout {
				width: 599rpx;
				box-sizing: border-box;
				background-color: #FFFFFF;
				border-radius: 40rpx;
				padding: 32rpx 32rpx 43rpx;
				display: flex;
				flex-direction: column;
				
				&-title {
					align-self: flex-start;
					font-size: 32rpx;
					font-family: PingFang SC;
					font-weight: 500;
					color: #000000;
				}
				
				&-content {
					margin-top: 60rpx;
					
					&-item {
						width: 100%;
						display: flex;
						flex-direction: row;
						justify-content: space-between;
						align-items: center;
						border-bottom: 2rpx solid #EFEFEF;
						
						&-left {
							font-size: 28rpx;
							font-family: PingFang SC;
							font-weight: 500;
							color: #1C1C1C;
							letter-spacing: 4rpx;
						}
						
						&-right {
							font-size: 28rpx;
							font-family: PingFang SC;
							font-weight: 400;
							color: #666666;
							letter-spacing: 4rpx;
							display: flex;
							flex-direction: row;
							align-items: center;
							margin-right: 26rpx;
							
							&-arrow {
								width: 16rpx;
								height: 24rpx;
								transform: rotate(180deg);
								margin-left: 24rpx;
							}
						}
					}
				}
				
				&-confirmLayout {
					width: 507rpx;
					height: 58rpx;
					box-sizing: border-box;
					position: relative;
					padding-top: 47rpx;
					margin-bottom: 43rpx;
					align-self: center;
					
					&-reset {
						background-color: #EFEFEF;
						width: 297rpx;
						height: 100%;
						color: #666666;
						font-size: 21rpx;
						display: flex;
						padding-left: 128rpx;
						align-items: center;
						justify-content: flex-start;
						box-sizing: border-box;
						border-radius: 29rpx;
						position: absolute;
						left: 0;
					}
					
					&-confirm {
						background-color: #FFFFFF;
						width: 255rpx;
						height: 100%;
						color: #FF5927;
						font-style: 21rpx;
						display: flex;
						padding-right: 107rpx;
						align-items: center;
						justify-content: flex-end;
						box-sizing: border-box;
						border-radius: 0rpx 29rpx 29rpx 29rpx;
						position: absolute;
						right: 0;
						border: 1rpx solid #FF5927;
					}
				}
			}
		}
	}
</style>