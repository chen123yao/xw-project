<template>
	<!-- cc 账号管理绑定手机号页面 -->
	<view class="container binding">
		<!-- cc 账号管理页面绑定手机号顶部标题 -->
		<view class="binding-topTitle">
			<view class="binding-topTitle-box">
				<image class="binding-topTitle-box-left" src="@/static/images/left.png" mode="heightFix" @click="back" />
				<text class="binding-topTitle-box-text">绑定手机号</text>
			</view>
		</view>
		
		<!-- cc 账号管理绑定手机号页面内容显示区域 -->
		<view class="binding-content">
			<text class="binding-content-title">当前未绑定手机号</text>
			
			<view class="binding-content-item">
				<u--input placeholder="请输入手机号" v-model="form1['sms-mobile']" :customStyle="{background: '#FFFFFF', padding: '40rpx 20rpx', lineHeight: '28rpx', boxSizing: 'border-box'}"
					placeholderStyle="font-size: 28rpx; color: #999999;" maxlength="11" fontSize="28" color="#1c1c1c" type="number" clearable shape="circle" :formatter="formatter" @confirm="handleSearch"></u--input>
			</view>
			
			<view class="binding-content-item">
				<u--input placeholder="请输入验证码" v-model="form1['sms-code']" :customStyle="{background: '#FFFFFF', padding: '40rpx 20rpx', lineHeight: '28rpx', boxSizing: 'border-box'}"
					placeholderStyle="font-size: 28rpx; color: #999999;" maxlength="11" fontSize="28" color="#1c1c1c" type="number" clearable shape="circle" :formatter="formatter" @confirm="handleSearch"></u--input>
				<view class="binding-content-item-right">
					<u-toast ref="uToast"></u-toast>
					<u-code :seconds="seconds" @end="end" @start="start" ref="uCode" @change="codeChange"></u-code>
					<text @tap="getCode">{{tips}}</text>
				</view>
			</view>
			
			<view class="binding-content-btn" @click="handleBind">
				<text>验证手机号</text>
			</view>
			
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				contentCode: 0,
				codeText1: "",
				form1: {
					"sms-mobile": "",
					"sms-code": "",
					"sms-type": 4,
				},
				tips: '',
				// refCode: null,
				seconds: 60,
			}
		},
		methods: {
			// cc 返回上一级页面
			back() {
				uni.navigateBack({
					delta: 1
				});
			},
			codeChange(text) {
				this.tips = text;
			},
			getCode() {
				if(this.$refs.uCode.canGetCode) {
					if (uni.$u.test.mobile(this.form1['sms-mobile'])) {
						// 模拟向后端请求验证码
						uni.showLoading({
							title: '正在获取验证码'
						})
						
						// setTimeout(() => {
						// 	uni.hideLoading();
						// 	// 这里此提示会被this.start()方法中的提示覆盖
						// 	uni.$u.toast('验证码已发送');
						// 	// 通知验证码组件内部开始倒计时
						// 	this.$refs.uCode.start();
						// }, 1000);
						
						this.$api.get("v8/sms/send",{
								...this.form1
						}).then(res => {
							if(res.data.code==200){
								uni.hideLoading();
								// 这里此提示会被this.start()方法中的提示覆盖
								uni.$u.toast('验证码已发送');
								// 通知验证码组件内部开始倒计时
								this.$refs.uCode.start();
							}else{
								uni.showToast({
									title: res.data.msg,
									icon: "none"
								})
							}	
						})
						
					} else {
						uni.$u.toast('请输入正确的手机号');
					}
				} else {
					uni.$u.toast('倒计时结束后再发送');
				}
			},
			end() {
				// uni.$u.toast('倒计时结束');
			},
			start() {
				// uni.$u.toast('倒计时开始');
			},
			// 完成绑定
			handleBind() {
				this.$api.get("user/bind_phone", {
					"sms-mobile": this.form1["sms-mobile"],
					"sms-code": this.form1["sms-code"]
				}).then(res => {
					if (res.data.code == 200) {
						uni.showToast({
							title:"绑定成功",
							success: () => {
								setTimeout(() => {
									this.$common.getuserInfo();
									uni.navigateBack()
								}, 300)
							}
						})
					} else {
						uni.showToast({
							title: res.data.msg,
							icon: 'none'
						})
						return
					}
				})
			}
		}
	}
</script>

<style lang="scss" scoped>
	.container { 
		background-color: #FFFFFF;
		width: 750rpx;
		height: 100vh;
		// padding-bottom: 24rpx;
	}
	
	.binding {
		overflow: hidden;
		
		&-loading {
			width: 750rpx;
			top: 176rpx !important;
		}
		
		&-topTitle {
			position: fixed;
			// background-color: #FFFFFF;
			background: linear-gradient(to bottom, #CCCCCC, #FFFFFF env(safe-area-inset-top));
			z-index: 999;
			top: 0;
			width: 750rpx;
			height: 176rpx;
			padding-left: 34rpx;
			padding-bottom: 16rpx;
			box-sizing: border-box;
			display: flex;
			flex-direction: column;
			justify-content: flex-end;
			box-shadow: 0rpx 0rpx 12rpx rgba(0, 0, 0, 0.16);
			
			&-box {
				box-sizing: border-box;
				display: flex;
				flex-direction: row;
				align-items: center;
				
				&-left {
					// width: 22rpx;
					height: 34rpx;
				}
				
				&-text {
					margin-left: 48rpx;
					font-size: 40rpx;
					line-height: 56rpx;
					font-family: PingFang SC;
					font-weight: 600;
					color: #1C1C1C;
				}
			}
		}
		
		&-content {
			width: 750rpx;
			margin-top: 213rpx;
			padding: 0 32rpx;
			box-sizing: border-box;
			color: #1C1C1C;
			font-family: PingFang SC;
			position: relative;
			display: flex;
			flex-direction: column;
			align-items: center;
			
			&-title {
				font-size: 32rpx;
				font-family: PingFang SC;
				font-weight: 600;
				color: #000000;
				
				&-btn {
					width: 48rpx;
					height: 48rpx;
					position: absolute;
					right: 4rpx;
					bottom: 4rpx;
				}
			}
			
			&-item {
				width: 100%;
				display: flex;
				flex-direction: row;
				justify-content: space-between;
				align-items: center;
				border-bottom: 2rpx solid #EFEFEF;
				
				&-left {
					font-size: 28rpx;
					font-family: PingFang SC;
					font-weight: 500;
					color: #1C1C1C;
					letter-spacing: 4rpx;
				}
				
				&-right {
					font-size: 28rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #666666;
					letter-spacing: 4rpx;
					display: flex;
					flex-direction: row;
					align-items: center;
					margin-right: 26rpx;
					
					&-arrow {
						width: 16rpx;
						height: 24rpx;
						transform: rotate(180deg);
						margin-left: 24rpx;
					}
				}
			}
			
			&-btn {
				margin-top: 40rpx;
				padding: 27rpx 129rpx;
				color: #FF5927;
				font-size: 27rpx;
				box-sizing: border-box;
				font-weight: 600;
				font-family: PingFang SC;
				border-radius: 40rpx;
				border: 2rpx solid #e1e1e1;
				text-align: center;
				align-self: center;
				display: inline-block;
			}
		}
	}
</style>