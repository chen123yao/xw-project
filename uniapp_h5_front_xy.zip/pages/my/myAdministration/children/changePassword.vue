<template>
	<!-- cc 账号管理修改密码页面 -->
	<view class="container password">
		<!-- cc 账号管理页面修改密码顶部标题 -->
		<view class="password-topTitle">
			<view class="password-topTitle-box">
				<image class="password-topTitle-box-left" src="@/static/images/left.png" mode="heightFix" @click="back" />
				<text class="password-topTitle-box-text">修改密码</text>
			</view>
		</view>
		
		<!-- cc 账号管理修改密码页面内容显示区域 -->
		<view class="password-content">
			
			<view class="password-content-item">
				<u--input placeholder="请输入原密码" v-model="form['oldpwd']" :customStyle="{background: '#FFFFFF', padding: '40rpx 20rpx', lineHeight: '28rpx', boxSizing: 'border-box'}"
					placeholderStyle="font-size: 28rpx; color: #999999;" fontSize="28" color="#1c1c1c" :type="isshow1 ? 'text' : 'password'" clearable shape="circle"></u--input>
				<view class="password-content-item-right">
					<image @click="isshow1 = !isshow1" class="password-content-item-right-img" :src="isshow1 ? '../../../../static/images/my/password.png':'../../../../static/images/my/nopassword.png'" mode="scaleToFill"></image>
				</view>
			</view>
			
			<view class="password-content-item">
				<u--input placeholder="请输入新密码" v-model="form['newpwd']" :customStyle="{background: '#FFFFFF', padding: '40rpx 20rpx', lineHeight: '28rpx', boxSizing: 'border-box'}"
					placeholderStyle="font-size: 28rpx; color: #999999;" fontSize="28" color="#1c1c1c" :type="isshow2 ? 'text' : 'password'" clearable shape="circle"></u--input>
				<view class="password-content-item-right">
					<image @click="isshow2 = !isshow2" class="password-content-item-right-img" :src="isshow2 ? '../../../../static/images/my/password.png':'../../../../static/images/my/nopassword.png'" mode="scaleToFill"></image>
				</view>
			</view>
			
			<view class="password-content-item">
				<u--input placeholder="请再次输入新密码" v-model="form['newpwdAgain']" :customStyle="{background: '#FFFFFF', padding: '40rpx 20rpx', lineHeight: '28rpx', boxSizing: 'border-box'}"
					placeholderStyle="font-size: 28rpx; color: #999999;" fontSize="28" color="#1c1c1c" :type="isshow3 ? 'text' : 'password'" clearable shape="circle"></u--input>
				<view class="password-content-item-right">
					<image @click="isshow3 = !isshow3" class="password-content-item-right-img" :src="isshow3 ? '../../../../static/images/my/password.png':'../../../../static/images/my/nopassword.png'" mode="scaleToFill"></image>
				</view>
			</view>
			
			<view class="password-content-btn" @click="handleChange">
				<text>确认</text>
			</view>
			
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isshow1: false,
				isshow2: false,
				isshow3: false,
				form: {
					oldpwd: "",
					newpwd: "",
					newpwdAgain: ""
				},
			}
		},
		methods: {
			// cc 返回上一级页面
			back() {
				uni.navigateBack({
					delta: 1
				});
			},
			handleChange() {
				if(this.form.newpwd != this.form.newpwdAgain){
					uni.showToast({
						title:'两次密码不一致',
						icon:'none'
					})
					return ;
				}
				this.$api.get("user/passwd/update",{
					...this.form
				}).then(res => {
					if(res.data.code==200){
						uni.showToast({
							title:res.data.msg,
							icon:"none",
						}),
						setTimeout(()=>{
							this.$api.get("/user/logout", {}).then(res => {
								// 返回上一页                            
								uni.navigateBack({
									delta:2
								})
								uni.navigateTo({
									url: '/pages/my/children/login'
								})
								// 清空本地存储的登录数据
								uni.setStorageSync('mem-username', '')
								uni.setStorageSync('mem-password', '')
								uni.setStorageSync('sms-mobile', '')
								this.$store.commit('setInit', {});
								this.$store.commit('setLoginInfo', {});
								this.$store.commit('setUserInfo', {});
								uni.setStorageSync('mem-openid','')
								this.$store.commit('setSelectedGame','')
							})
						},200)
					}else{
						uni.showToast({
							title:res.data.msg,
							icon:"none",	
						})
					}
				})
			}
		}
	}
</script>

<style lang="scss" scoped>
	.container { 
		background-color: #FFFFFF;
		width: 750rpx;
		height: 100vh;
		// padding-bottom: 24rpx;
	}
	
	.password {
		overflow: hidden;
		
		&-loading {
			width: 750rpx;
			top: 176rpx !important;
		}
		
		&-topTitle {
			position: fixed;
			// background-color: #FFFFFF;
			background: linear-gradient(to bottom, #CCCCCC, #FFFFFF env(safe-area-inset-top));
			z-index: 999;
			top: 0;
			width: 750rpx;
			height: 176rpx;
			padding-left: 34rpx;
			padding-bottom: 16rpx;
			box-sizing: border-box;
			display: flex;
			flex-direction: column;
			justify-content: flex-end;
			box-shadow: 0rpx 0rpx 12rpx rgba(0, 0, 0, 0.16);
			
			&-box {
				box-sizing: border-box;
				display: flex;
				flex-direction: row;
				align-items: center;
				
				&-left {
					// width: 22rpx;
					height: 34rpx;
				}
				
				&-text {
					margin-left: 48rpx;
					font-size: 40rpx;
					line-height: 56rpx;
					font-family: PingFang SC;
					font-weight: 600;
					color: #1C1C1C;
				}
			}
		}
		
		&-content {
			width: 750rpx;
			margin-top: 213rpx;
			padding: 0 32rpx;
			box-sizing: border-box;
			color: #1C1C1C;
			font-family: PingFang SC;
			position: relative;
			display: flex;
			flex-direction: column;
			align-items: center;
			
			&-title {
				font-size: 32rpx;
				font-family: PingFang SC;
				font-weight: 600;
				color: #000000;
				
				&-btn {
					width: 48rpx;
					height: 48rpx;
					position: absolute;
					right: 4rpx;
					bottom: 4rpx;
				}
			}
			
			&-item {
				width: 100%;
				display: flex;
				flex-direction: row;
				justify-content: space-between;
				align-items: center;
				border-bottom: 2rpx solid #EFEFEF;
				
				&-left {
					font-size: 28rpx;
					font-family: PingFang SC;
					font-weight: 500;
					color: #1C1C1C;
					letter-spacing: 4rpx;
				}
				
				&-right {
					font-size: 28rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #666666;
					letter-spacing: 4rpx;
					display: flex;
					flex-direction: row;
					align-items: center;
					margin-right: 26rpx;
					
					&-img {
						width: 32rpx;
						height: 20rpx;
					}
				}
			}
			
			&-btn {
				margin-top: 40rpx;
				padding: 27rpx 171rpx;
				color: #FF5927;
				font-size: 27rpx;
				box-sizing: border-box;
				font-weight: 600;
				font-family: PingFang SC;
				border-radius: 40rpx;
				border: 2rpx solid #e1e1e1;
				text-align: center;
				align-self: center;
				display: inline-block;
			}
		}
	}
</style>