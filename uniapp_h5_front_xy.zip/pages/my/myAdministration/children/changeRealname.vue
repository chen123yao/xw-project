<template>
	<!-- cc 账号管理修改密码页面 -->
	<view class="container realname">
		<!-- cc 账号管理页面修改密码顶部标题 -->
		<view class="realname-topTitle">
			<view class="realname-topTitle-box">
				<image class="realname-topTitle-box-left" src="@/static/images/left.png" mode="heightFix" @click="back" />
				<text class="realname-topTitle-box-text">实名认证</text>
			</view>
		</view>
		
		<!-- cc 账号管理修改密码页面内容显示区域 -->
		<view class="realname-content">
			<text class="realname-content-title">根据国家规定，游戏用户需要进行实名认证</text>
			<text class="realname-content-tip">信息仅用于认证且绝对保密</text>
			<text class="realname-content-tip">未成年人游戏支付额度有限制</text>
			
			<view v-if="hasIdentify && pageData" class="realname-content-box">
				<text class="realname-content-box-text">姓名: {{pageData.real_name}}</text>
				<text class="realname-content-box-text">身份证号: {{pageData.id_card}}</text>
				<text class="realname-content-box-text" style="font-size: 24rpx; color: #ff5927;">已认证</text>
			</view>
			
			<view v-else class="realname-content-box">
				<view class="realname-content-box-item">
					<u--input placeholder="请输入您的真实姓名" v-model="form['realname']" :customStyle="{background: '#FFFFFF', padding: '40rpx 20rpx', lineHeight: '28rpx', boxSizing: 'border-box'}"
						placeholderStyle="font-size: 28rpx; color: #999999;" fontSize="28" color="#1c1c1c" type="text" clearable shape="circle"></u--input>
				</view>
				
				<view class="realname-content-box-item" @click="showPicker">
					<u--input placeholder="请输入证件" v-model="form['label']" :customStyle="{background: '#FFFFFF', padding: '40rpx 20rpx', lineHeight: '28rpx', boxSizing: 'border-box'}"
						placeholderStyle="font-size: 28rpx; color: #999999;" fontSize="28" color="#1c1c1c" disabledColor="#FFF" disabled type="text" clearable shape="circle" suffixIcon="arrow-down"
						suffixIconStyle="font-size: 30rpx;color: #C1C1C1"></u--input>
					<u-picker style="flex: none;" :show="show" :columns="array" title="请选择证件类型" @cancel="closePicker" showToolbar @change="changePicker" @confirm="confirmPicker" @close="closePicker"></u-picker>
				</view>
				
				<view class="realname-content-box-item">
					<u--input placeholder="请输入您的证件号码" v-model="form['idcard']" :customStyle="{background: '#FFFFFF', padding: '40rpx 20rpx', lineHeight: '28rpx', boxSizing: 'border-box'}"
						placeholderStyle="font-size: 28rpx; color: #999999;" fontSize="28" color="#1c1c1c" type="text" clearable shape="circle"></u--input>
				</view>
				
				<view class="realname-content-box-btn" @click="handleBinding">
					<text>确认</text>
				</view>
			</view>
			
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				show: false,
				hasIdentify: false,
				pageData: null,
				form: {
					realname: "",
					type: "",
					label: "",
					idcard: ""
				},
				
				array: [['大陆居民身份证', '台胞证']],
				index: 0
			}
		},
		onLoad() {
			if(this.$store.state.userInfo.is_real_name){
				this.hasIdentify = true;
				this.getIdentify();
			}else{
				this.hasIdentify = false
			}
		},
		methods: {
			// cc 返回上一级页面
			back() {
				uni.navigateBack({
					delta: 1
				});
			},
			showPicker() {
				this.show = true
				this.form.type = this.index + 1
				this.form.label = this.array[0][this.index]
			},
			closePicker() {
				this.show = false
				this.index = 0
				this.form.type = ''
				this.form.label = ''
			},
			changePicker(e) {
				console.log('changePicker', e);
				this.form.type = e.index + 1
				this.index = e.index
				this.form.label = this.array[0][e.index]
			},
			confirmPicker(e) {
				console.log('confirmPicker', e);
				this.form.type = e.indexs[0] + 1
				this.index = e.indexs[0]
				this.form.label = e.value[0]
				this.show = false
			},
			// cc 获取认证信息
			getIdentify(){
				this.$api.get("wap/identify/info").then(res=>{
					this.pageData = res.data.data
				})
			},
			handleBinding() {
				// if(this.form.realname == ''){
				// 	uni.showToast({
				// 		title:'请输入真实姓名',
				// 		icon:'none'
				// 	})
				// 	return ;
				// }
				
				// if(!uni.$u.test.idCard(this.form.idcard)){
				// 	uni.showToast({
				// 		title:'请输入正确的证件号码',
				// 		icon:'none'
				// 	})
				// 	return ;
				// }
				
				this.$api.get("wap/identify/set",{
					...this.form
				}).then(res => {
					console.log('wap/identify/set', res)
					if (res.data.code){
						uni.showToast({
							title: '认证成功',
							type: 'success',
							icon: "none"
						})
						this.$common.getuserInfo();
						uni.navigateBack({
							delta: 1
						})
					} else{
						uni.showToast({
							title: '请填写完整信息！',
							icon: 'none',
						})
					}
				})
			}
		}
	}
</script>

<style lang="scss" scoped>
	.container { 
		background-color: #FFFFFF;
		width: 750rpx;
		height: 100vh;
		// padding-bottom: 24rpx;
	}
	
	.realname {
		overflow: hidden;
		
		&-loading {
			width: 750rpx;
			top: 176rpx !important;
		}
		
		&-topTitle {
			position: fixed;
			// background-color: #FFFFFF;
			background: linear-gradient(to bottom, #CCCCCC, #FFFFFF env(safe-area-inset-top));
			z-index: 999;
			top: 0;
			width: 750rpx;
			height: 176rpx;
			padding-left: 34rpx;
			padding-bottom: 16rpx;
			box-sizing: border-box;
			display: flex;
			flex-direction: column;
			justify-content: flex-end;
			box-shadow: 0rpx 0rpx 12rpx rgba(0, 0, 0, 0.16);
			
			&-box {
				box-sizing: border-box;
				display: flex;
				flex-direction: row;
				align-items: center;
				
				&-left {
					// width: 22rpx;
					height: 34rpx;
				}
				
				&-text {
					margin-left: 48rpx;
					font-size: 40rpx;
					line-height: 56rpx;
					font-family: PingFang SC;
					font-weight: 600;
					color: #1C1C1C;
				}
			}
		}
		
		&-content {
			width: 750rpx;
			margin-top: 220rpx;
			padding: 0 32rpx;
			box-sizing: border-box;
			color: #1C1C1C;
			font-family: PingFang SC;
			position: relative;
			display: flex;
			flex-direction: column;
			align-items: center;
			
			&-title {
				font-size: 26rpx;
				font-family: PingFang SC;
				font-weight: 600;
				color: #000000;
			}
			
			&-tip {
				font-size: 23rpx;
				font-family: PingFang SC;
				font-weight: 500;
				color: #999999;
				margin-top: 15rpx;
			}
			
			&-box {
				width: 100%;
				padding-top: 49rpx;
				display: flex;
				flex-direction: column;
				align-items: center;
				
				&-text {
					font-size: 32rpx;
					font-family: PingFang SC;
					font-weight: 500;
					color: #000000;
					margin-bottom: 25rpx;
				}
				
				&-item {
					width: 100%;
					display: flex;
					flex-direction: row;
					justify-content: space-between;
					align-items: center;
					border-bottom: 2rpx solid #EFEFEF;
					
					&-left {
						font-size: 28rpx;
						font-family: PingFang SC;
						font-weight: 500;
						color: #1C1C1C;
						letter-spacing: 4rpx;
					}
					
					&-right {
						font-size: 28rpx;
						font-family: PingFang SC;
						font-weight: 400;
						color: #666666;
						letter-spacing: 4rpx;
						display: flex;
						flex-direction: row;
						align-items: center;
						margin-right: 26rpx;
						
						&-img {
							width: 32rpx;
							height: 20rpx;
						}
					}
				}
				
				&-btn {
					margin-top: 40rpx;
					padding: 27rpx 171rpx;
					color: #FF5927;
					font-size: 27rpx;
					box-sizing: border-box;
					font-weight: 600;
					font-family: PingFang SC;
					border-radius: 40rpx;
					border: 2rpx solid #e1e1e1;
					text-align: center;
					align-self: center;
					display: inline-block;
				}
			}
		}
	}
</style>