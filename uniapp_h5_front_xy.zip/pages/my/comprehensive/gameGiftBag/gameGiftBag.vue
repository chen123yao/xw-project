<template>
	<view class="container">
		<view class="container-topTitle">
			<view class="container-topTitle-box">
				<view class="container-topTitle-box-left">
					<image class="container-topTitle-box-left-img" src="@/static/images/left.png" mode="heightFix" @click="back" />
					<text class="container-topTitle-box-left-text">游戏礼包</text>
				</view>
			</view>
		</view>
		
		<view class="container-content">
			<view class="content">
				<view class="list" v-if="pageData.length">
					<view class="item" v-for="(item,index) in pageData" :key="index" @click="toDetail(item.game_id)">
						<image :src="item.new_icon||item.icon" mode="scaleToFill" class="game-icon"></image>
						<view class="item-right">
							<view class="text-box">
								<view class="game-name">{{item.gift_name}}</view>
								<view class="text1">礼包类型：{{item.scope}}</view>
								<view class="text1">礼包码：{{item.code}}</view>
								<view class="text1">兑换期限：{{item.end_time | dateFormat("yyyy-MM-dd")}}</view>
							</view>
							<view class="button" @click="copy(item.code)">复制</view>
						</view>
					</view>
					<u-loadmore :status="status" loading-text="努力加载中" loadmore-text="加载更多" nomore-text="没有更多了"
					 fontSize="28" line height="80" iconColor="#ff5927"  iconSize="48" loadingIcon="circle"	/>
				</view>
				<vue-loading :isNoData="isNoData" v-else></vue-loading>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isNoData:false,
				formData: {
					page: 1,
					offset: 10,
				},
				count:0,
				status: 'loadmore',
				pageData: [],
			}
		},
		methods: {
			back() {
				uni.navigateBack()
			},
			getpageData() {
				this.$api.get('/user/gift/list', {
					...this.formData
				}).then(res => {
					if (res.data.code == 200) {
						this.status="loadmore"
						this.count = res.data.data.count
						this.pageData = this.pageData.concat(res.data.data.list);
						if(!res.data.data.count) {
							this.isNoData=true
						}
						if(this.pageData.length>=this.count) {
							this.status="nomore"
						}
					} else {
						uni.showToast({
							title: res.data.msg,
							icon: "none"
						})
					}
				})
			},
			toDetail(id){
				uni.navigateTo({
					url:'/pages/view/gamedetail/gamedetail?gameid='+id
				})
			},
			//复制
			copy(value) {
				uni.setClipboardData({
					data: value,
				});
			}
		},
		mounted() {
			this.getpageData()
		},
		onReachBottom() {
			if(this.count>this.pageData.length&&this.status=="loadmore") {
				this.status = "loading"
				this.formData.page++
				this.getpageData()
			}
		}
	}
</script>

<style lang="scss">
	.container {
		background-color: #FFFFFF;
		width: 750rpx;
		height: 100vh;
		
		&-topTitle {
			position: fixed;
			// background-color: #FFFFFF;
			background: linear-gradient(to bottom, #CCCCCC, #FFFFFF env(safe-area-inset-top));
			z-index: 999;
			top: 0;
			width: 750rpx;
			height: 176rpx;
			padding: 0 34rpx 16rpx;
			box-sizing: border-box;
			display: flex;
			flex-direction: column;
			justify-content: flex-end;
			box-shadow: 0rpx 0rpx 12rpx rgba(0, 0, 0, 0.16);
			
			&-box {
				box-sizing: border-box;
				display: flex;
				flex-direction: row;
				justify-content: space-between;
				align-items: center;
				
				&-left {
					display: flex;
					flex-direction: row;
					align-items: center;
					
					&-img {
						height: 34rpx;
					}
					
					&-text {
						margin-left: 48rpx;
						font-size: 40rpx;
						line-height: 56rpx;
						font-family: PingFang SC;
						font-weight: 600;
						color: #1C1C1C;
					}
				}
				
				&-right {
					display: block;
					width: 35rpx;
					height: 35rpx;
				}
			}
		}
		
		&-content {
			width: 750rpx;
			padding: 206rpx 0 0;
			box-sizing: border-box;
			color: #1C1C1C;
			font-family: PingFang SC;
			min-height: 100vh;
			
			.content {
				padding: 0 36rpx;
				.item {
					display: flex;
					align-items: flex-start;
					padding-top: 48rpx;
					.game-icon {
						width: 160rpx;
						min-width: 160rpx;
						height: 160rpx;
						margin-right: 24rpx;
						border-radius: 40rpx;
					}
					.item-right {
						flex: 1;
						display: flex;
						align-items: center;
						justify-content: space-between;
						height: 160rpx;
						padding-bottom: 48rpx;
						border-bottom: 2rpx solid #efefef;
						overflow: hidden;
						.text-box {
							flex: 1;
							overflow: hidden;
							.game-name {
								width: 100%;
								font-size: 36rpx;
								font-weight: 500;
								line-height: 50rpx;
								color: #1C1C1C;
								white-space: nowrap;
								text-overflow: ellipsis;
								overflow: hidden;
							}
							.text1 {
								line-height: 28rpx;
								font-size: 20rpx;
								font-weight: 400;
								color: #666666;
								margin-top: 8rpx;
							}
						}
						.button {
							width: 104rpx;
							min-width: 104rpx;
							height: 48rpx;
							text-align: center;
							line-height: 44rpx;
							font-size: 24rpx;
							font-weight: 600;
							color: #ff5927;
							border: 2rpx solid #E4E4E4;
							border-radius: 16px;
							box-sizing: border-box;
						}
					}
				}
			}
		}
	}
</style>
