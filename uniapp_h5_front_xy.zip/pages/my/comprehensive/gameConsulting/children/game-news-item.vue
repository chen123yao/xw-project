<template>
	<view class="item-box">
		<view class="item-head">
			<image :src="item.img" mode="scaleToFill" class="item-head-img"></image>
			<view class="head-title">{{item.post_title}}</view>
		</view>
		<view class="item-bottom">
			<image class="game-icon" :src="item.game2.new_icon||item.game2.icon" mode="scaleToFill"></image>
			<view class="bottom-text">
				<view class="bottom-text-left">
					<view class="text1">{{item.title}}</view>
					<view class="text2">{{item.start_time | dateFormat('yyyy-MM-dd hh:mm')}}</view>
				</view>
				<view class="bottom-text-right">
					<image src="@/static/images/seeall.png" mode="scaleToFill" style="width: 28rpx;height: 16rpx;margin: 16rpx;"></image>
					<text class="text-num">{{item.post_hits}}</text>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		props: ['item']
	}
</script>

<style lang="scss">
	.item-box {
		.item-head {
			position: relative;
			.item-head-img {
				display: block;
				width: 100%;
				height: 345rpx;
			}
			.head-title {
				position: absolute;
				bottom: 0;
				width: 100%;
				height: 70rpx;
				padding-left: 224rpx;
				line-height: 70rpx;
				font-size: 28rpx;
				font-weight: 600;
				color: #FFFFFF;
				white-space: nowrap;
				text-overflow: ellipsis;
				overflow: hidden;
				box-sizing: border-box;
				background-image: linear-gradient(to top, rgba(0, 0, 0, 0.5), rgba(111, 111, 111, 0.5));
			}
		}
		.item-bottom {
			display: flex;
			align-items: flex-end;
			height: 116rpx;
			padding: 0 24rpx 24rpx;
			box-sizing: border-box;
			.game-icon {
				display: block;
				width: 176rpx;
				min-width: 176rpx;
				height: 176rpx;
				margin-right: 24rpx;
				border-radius: 40rpx;
			}
			.bottom-text {
				flex: 1;
				display: flex;
				align-items: center;
				justify-content: space-between;
				height: 88rpx;
				box-sizing: border-box;
				overflow: hidden;
				.bottom-text-left {
					flex: 1;
					overflow: hidden;
					.text1 {
						width: 100%;
						height: 34rpx;
						font-size: 24rpx;
						font-weight: 500;
						line-height: 34rpx;
						color: #1C1C1C;
						white-space: nowrap;
						text-overflow: ellipsis;
						overflow: hidden;
					}
					.text2 {
						margin-top: 16rpx;
						height: 28rpx;
						font-size: 20rpx;
						font-weight: 400;
						line-height: 28rpx;
						color: #666666;
					}
				}
				.bottom-text-right {
					display: flex;
					align-items: center;
					.text-num {
						font-size: 24rpx;
						font-weight: 400;
						color: #666666;
					}
				}
			}
		}
	}
</style>