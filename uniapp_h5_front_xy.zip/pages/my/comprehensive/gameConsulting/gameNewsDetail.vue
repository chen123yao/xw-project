<template>
	<view class="container">
		<!-- cc 游戏专题详情页面顶部标题 -->
		<view class="container-topTitle">
			<view class="container-topTitle-box">
				<view class="container-topTitle-box-left">
					<image class="container-topTitle-box-left-img" src="@/static/images/left.png" mode="heightFix" @click="back" />
					<text class="container-topTitle-box-left-text">资讯详情</text>
				</view>
				
				<!-- <view class="container-topTitle-box-right" @click="isShowMyPopup = true">
					<u-icon name="more-dot-fill" color="#000" size="42" class="more-dot-fill" ></u-icon>
				</view> -->
			</view>
		</view>
		
		<view class="container-content">
			<view class="content">
				<view class="box_head" @click="handleRouterdetail(detailList.game_id)">
					<view class="head_left">
						<image :src="detailList.icon" mode="scaleToFill" class="game-icon"></image>
					</view>
					<view class="head_mid">
						<view class="head_mid1">{{detailList.title}}</view>
						<view style="display:flex;margin-top: 24rpx;">
							<view class="text">{{detailList.start_time | dateFormat('yyyy-MM-dd hh:mm')}}</view>
							<view class="text" style="margin: -4rpx 20rpx;">|</view>
							<view class="text">{{post_hits}} 浏览</view>
						</view>
					</view>
				</view>
				<view class="box_middle">
					<view class="title">{{detailList.excerpt}}</view>
					<image :src="detailList.img" mode="widthFix" style="width: 100%;border-radius: 20rpx;margin-bottom: 36rpx;"></image>
					<text class="texts">{{content}}</text>
				</view>
			</view>
		</view>
		<vue-myPopup :isShowMyPopup="isShowMyPopup" @close="close"></vue-myPopup>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isShowMyPopup: false,
				post_hits: '',
				detailList: null,
				content:'',
			}
		},
		methods: {
			back() {
				uni.navigateBack()
			},
			close() {
				this.isShowMyPopup = false
			},
			//跳转游戏详情页
			handleRouterdetail(id) {
				uni.navigateTo({
					url: `/pages/view/gameDetail/gameDetail?gameId=${id}`
				})
			},
			getPageData(params) {
				this.$api.get('/news/detail', {
					...params
				}).then(res => {
					if (res.statusCode == 200) {
						let cont =''
						this.detailList = res.data.data.data;
						cont = this.detailList.content;
						var reg = /<[^<>]+>/g 
						this.content=cont.replace(reg,'')
					}
				})
			},
		},
		onLoad(option) {
			this.getPageData({
				news_id: option.news_id
			})
			this.post_hits = option.post_hits
		},
	}
</script>

<style lang="scss">
	.container {
		background-color: #FFFFFF;
		width: 750rpx;
		height: 100vh;
		
		&-topTitle {
			position: fixed;
			// background-color: #FFFFFF;
			background: linear-gradient(to bottom, #CCCCCC, #FFFFFF env(safe-area-inset-top));
			z-index: 999;
			top: 0;
			width: 750rpx;
			height: 176rpx;
			padding: 0 34rpx 16rpx;
			box-sizing: border-box;
			display: flex;
			flex-direction: column;
			justify-content: flex-end;
			box-shadow: 0rpx 0rpx 12rpx rgba(0, 0, 0, 0.16);
			
			&-box {
				box-sizing: border-box;
				display: flex;
				flex-direction: row;
				justify-content: space-between;
				align-items: center;
				
				&-left {
					display: flex;
					flex-direction: row;
					align-items: center;
					
					&-img {
						height: 34rpx;
					}
					
					&-text {
						margin-left: 48rpx;
						font-size: 40rpx;
						line-height: 56rpx;
						font-family: PingFang SC;
						font-weight: 600;
						color: #1C1C1C;
					}
				}
				
				&-right {
					display: block;
					width: 35rpx;
					height: 35rpx;
				}
			}
		}
		
		&-content {
			width: 750rpx;
			padding: 256rpx 0 0;
			box-sizing: border-box;
			color: #1C1C1C;
			font-family: PingFang SC;
			min-height: 100vh;
			
			.content {
				padding: 0 32rpx;
				.box_head {
					position: sticky;
					top: 166rpx;
					display: flex;
					align-items: center;
					justify-content: center;
					width: 100%;
					padding: 40rpx 0 32rpx;
					border-bottom: 2rpx solid #ECECEC;
					box-sizing: border-box;
					background-color: #fff;
					z-index: 99;
					.game-icon {
						display: block;
						width: 120rpx;
						min-width: 120rpx;
						height: 120rpx;
						margin-right: 24rpx;
					}
					.head_mid {
						flex: 1;
						height: 120rpx;
						display: flex;
						flex-direction: column;
						justify-content: center;
						overflow: hidden;
						.head_mid1 {
							width: 100%;
							height: 30rpx;
							font-size: 32rpx;
							font-weight: 800;
							color: #252525;
							line-height: 30rpx;
							white-space: nowrap;
							text-overflow: ellipsis;
							overflow: hidden;
						}
						.text {
							height: 24rpx;
							font-size: 24rpx;
							font-weight: bold;
							color: #666666;
						}
					}
				}
				.box_middle {
					.title {
						font-size: 40rpx;
						font-weight: 700;
						color: #252525;
						margin: 36rpx 0
					}
					.texts{
						color: #666666;
						font-weight: 300;
						font-size: 32rpx;
						line-height: 42rpx;
						padding-bottom: 60rpx;
					}
				}
			}
		}
	}
</style>