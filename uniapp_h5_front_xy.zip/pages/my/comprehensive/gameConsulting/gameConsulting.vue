<template>
	<view class="container">
		<view class="container-topTitle">
			<view class="container-topTitle-box">
				<view class="container-topTitle-box-left">
					<image class="container-topTitle-box-left-img" src="@/static/images/left.png" mode="heightFix" @click="back" />
					<text class="container-topTitle-box-left-text">游戏资讯</text>
				</view>
			</view>
		</view>
		
		<view class="container-content">
			<view class="content">
				<view class="tabslist">
					<view class="tab" :class="{active:active==index}" @click="tabClick(index)" v-for="(item,index) in tabslist" :key="index">
						{{item}}
						<view class="tabLine" :style="`transform:translateX(${active*144}rpx)`" v-if="!index"></view>
					</view>
				</view>
				<view class="show-list" v-if="0==active">
					<template v-if="pageData1.length">
						<view class="list-item" v-for="(item,index) in pageData1" :key="index" @click="handleRouterdetail(item.news_id,item.post_hits)">
							<gameNewsItem :item="item"></gameNewsItem>
						</view>
						<u-loadmore :status="status[0]" loading-text="努力加载中" loadmore-text="加载更多" nomore-text="没有更多了"
							 fontSize="28" line height="80" iconColor="#ff5927"  iconSize="48" loadingIcon="circle"	/>
					</template>
					<vue-loading :isNoData="isNoData[0]" v-else></vue-loading>
				</view>
				<view class="show-list" v-if="1==active">
					<template v-if="pageData2.length">
						<view class="list-item" v-for="(item,index) in pageData2" :key="index" @click="handleRouterdetail(item.news_id,item.post_hits)">
							<gameNewsItem :item="item"></gameNewsItem>
						</view>
						<u-loadmore :status="status[1]" loading-text="努力加载中" loadmore-text="加载更多" nomore-text="没有更多了"
							 fontSize="28" line height="80" iconColor="#ff5927"  iconSize="48" loadingIcon="circle"	/>
					</template>
					<vue-loading :isNoData="isNoData[1]" v-else></vue-loading>
				</view>
				<view class="show-list" v-if="2==active">
					<template v-if="pageData3.length">
						<view class="list-item" v-for="(item,index) in pageData3" :key="index" @click="handleRouterdetail(item.news_id,item.post_hits)">
							<gameNewsItem :item="item"></gameNewsItem>
						</view>
						<u-loadmore :status="status[2]" loading-text="努力加载中" loadmore-text="加载更多" nomore-text="没有更多了"
							 fontSize="28" line height="80" iconColor="#ff5927"  iconSize="48" loadingIcon="circle"	/>
					</template>
					<vue-loading :isNoData="isNoData[2]" v-else></vue-loading>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import gameNewsItem from './children/game-news-item.vue'
	export default {
		components: {
			gameNewsItem
		},
		data() {
			return {
				active: 0,
				tabslist: ['福利', '资讯', '攻略'],
				isNoData: [false,false,false],
				status: ['loadmore','loadmore','loadmore'],
				pageData1:[],
				pageData2:[],
				pageData3:[],
				params: [
					{
						page: 1,
						offset: 10,
						type: 2 ,
						count:0,
					},
					{
						page: 1,
						offset: 10,
						type:1,
						count:0,
					},
					{
						page: 1,
						offset: 10,
						type:3,
						count:0,
					}
				]
			}
		},
		methods: {
			back() {
				uni.navigateBack()
			},
			tabClick(index) {
					this.active = index
			},
			//1.福利
			getflData(data = {}) {
				this.$api.get('/news/list', {
					...this.params[0]
				}).then(res => {
					if (res.data.code == 200) {
						this.pageData1 = this.pageData1.concat(res.data.data.list)
						this.params[0].count = res.data.data.count
						if(!res.data.data.count) {
							this.isNoData[0] = true
						}
						if(this.pageData1.length>=this.params[0].count) {
							this.status[0] = "nomore"
						} else {
							this.status[0] = "loadmore"
						}
					} else {
						uni.showToast({
							title:res.data.msg,
							icon: "none"
						})
					}
				})
			},
			//2.资讯
			getzxData(data = {}) {
				this.$api.get('/news/list', {
					...this.params[1]
				}).then(res => {
					if (res.data.code == 200) {
						this.pageData2 = this.pageData2.concat(res.data.data.list)
						this.params[1].count = res.data.data.count
						if(!res.data.data.count) {
							this.isNoData[1] = true
						}
						if(this.pageData2.length>=this.params[1].count) {
							this.status[1] = "nomore"
						} else {
							this.status[1] = "loadmore"
						}
					} else {
						uni.showToast({
							title:res.data.msg,
							icon: "none"
						})
					}
				})
			},
			//3.攻略
			getglData(data = {}) {
				this.$api.get('/news/list', {
					...this.params[2]
				}).then(res => {
					if (res.data.code == 200) {
						this.pageData3 = this.pageData3.concat(res.data.data.list)
						this.params[2].count = res.data.data.count
						if(!res.data.data.count) {
							this.isNoData[2] = true
						}
						if(this.pageData3.length>=this.params[2].count) {
							this.status[2] = "nomore"
						} else {
							this.status[2] = "loadmore"
						}
					} else {
						uni.showToast({
							title:res.data.msg,
							icon: "none"
						})
					}
				})
			},
			handleRouterdetail(id,post_hits) {
				uni.navigateTo({
					url: `/pages/my/comprehensive/gameConsulting/gameNewsDetail?news_id=${id}&post_hits=${post_hits}`
				})
			},
		},
		onLoad() {
			this.getflData()
			this.getzxData()
			this.getglData()
		},
		onReachBottom() {
			if(!this.active) {
				if(this.params[0].count>this.pageData1.length && this.status[0] == "loadmore"){
					this.status[0] = "loading"
					this.params[0].page++
					this.getflData()	
				}
			} else if(1==this.active){
				if(this.params[1].count>this.pageData2.length && this.status[1] == "loadmore"){
					this.status[1] = "loading"
					this.params[1].page++
					this.getzxData()	
				}
			} else {
				if(this.params[2].count>this.pageData3.length && this.status[2] == "loadmore"){
					this.status[2] = "loading"
					this.params[2].page++
					this.getglData()	
				}
			}
		}
	}
</script>

<style lang="scss">
	.container {
		background-color: #FFFFFF;
		width: 750rpx;
		height: 100vh;
		
		&-topTitle {
			position: fixed;
			// background-color: #FFFFFF;
			background: linear-gradient(to bottom, #CCCCCC, #FFFFFF env(safe-area-inset-top));
			z-index: 999;
			top: 0;
			width: 750rpx;
			height: 176rpx;
			padding: 0 34rpx 16rpx;
			box-sizing: border-box;
			display: flex;
			flex-direction: column;
			justify-content: flex-end;
			box-shadow: 0rpx 0rpx 12rpx rgba(0, 0, 0, 0.16);
			
			&-box {
				box-sizing: border-box;
				display: flex;
				flex-direction: row;
				justify-content: space-between;
				align-items: center;
				
				&-left {
					display: flex;
					flex-direction: row;
					align-items: center;
					
					&-img {
						height: 34rpx;
					}
					
					&-text {
						margin-left: 48rpx;
						font-size: 40rpx;
						line-height: 56rpx;
						font-family: PingFang SC;
						font-weight: 600;
						color: #1C1C1C;
					}
				}
				
				&-right {
					display: block;
					width: 35rpx;
					height: 35rpx;
				}
			}
		}
		
		&-content {
			width: 750rpx;
			padding: 206rpx 0 0;
			box-sizing: border-box;
			color: #1C1C1C;
			font-family: PingFang SC;
			min-height: 100vh;
			
			.content {
				.tabslist{
					position: sticky;
					top: 166rpx;
					width: 100%;
					display: flex;
					align-items: center;
					padding: 48rpx 32rpx;
					z-index: 90;
					box-sizing: border-box;
					background: #fff;
					.tab {
						position: relative;
						width: 80rpx;
						margin-right: 64rpx;
						text-align: center;
						font-size: 32rpx;
						font-weight: 400;
						line-height: 50rpx;
						color: #666;
						&.active {
							line-height: 46rpx;
							font-size: 36rpx;
							font-weight: 600;
							color: #1c1c1c;
						}
					}
					.tabLine {
						position: absolute;
						left: calc(50% - 24rpx);
						bottom: -8rpx;
						width: 48rpx;
						height: 4rpx;
						background-color: #FF5927;
						border-radius: 4rpx;
						transition-property: transform;
						transition-duration:0.4s;
					}
				}
				.show-list {
					padding: 0 32rpx 32rpx;
					.list-item {
						margin-bottom: 48rpx;
						border-radius: 40rpx;
						overflow: hidden;
						box-shadow: 0px 0px 4px rgba(0,0,0,0.16);
					}
				}
			}
		}
	}
</style>
