<template>
	<view class="container">
		<!-- cc 游戏专题详情页面顶部标题 -->
		<view class="container-topTitle">
			<view class="container-topTitle-box">
				<view class="container-topTitle-box-left">
					<image class="container-topTitle-box-left-img" src="@/static/images/left.png" mode="heightFix" @click="back" />
					<text class="container-topTitle-box-left-text">意见反馈</text>
				</view>
			
				<image class="container-topTitle-box-right" src="@/static/images/wen-icon.png" mode="heightFix" @click="show=true"></image>
			</view>
		</view>
		
		<view class="container-content">
			<view class="content">
				<text class="text1">请选择问题类型</text>
				<view class="boxAll">
					<view class="but"  v-for="(item,index) in typeList" :key="index" @click="buttonClick(item.id)" :class="{buttonColor:item.id==feedbackData.flag}">
						{{item.name}}
					</view>
				</view>
				<view class="text_box">
					<textarea v-model="feedbackData.content" class="box_input"  placeholder-style="color:#E4E4E4;font-size:24rpx;" placeholder="提出您宝贵的意见或建议有助于我们为您提供更好的服务" />
					<view class="upload">
						<vue-upLoadImage :max_number='3'  @upLoadSuccess='uploadSuccess'></vue-upLoadImage>
					</view>
				</view>
				<view class="input_p">
					<input class="p_text" type="number" v-model="feedbackData.linkman" placeholder-style="color:#E4E4E4;font-size: 28rpx;" placeholder="请留下您的手机号"/>
				</view>
				<view class="input_p" >
					<input class="p_text" v-model="feedbackData.qq" type="number" placeholder-style="color:#E4E4E4;font-size:28rpx;" placeholder="请留下您的QQ号"/>
				</view>
				<view class="input_p input_text" @click="submit">提交</view>
			</view>
			<u-popup :show="show" mode="center" @close="close" round="40" class="pop1" zIndex="900" overlayStyle="z-index:900" :closeOnClickOverlay="false" customStyle="width:600rpx;padding:36rpx;box-sizing: border-box;" @touchmove.native.prevent.stop="toucnMove">
				<view class="title">
					<image class="title_img" src="@/static/images/wenred.png" mode=""></image>
					<text class="title_text">帮助</text>
				</view>
				<text class="box-center-text">想要：想要APP上搭载怎样的新功能？</text>
				<text class="box-center-text">体验：APP使用中，有遇到哪些问题/疑惑？</text>
				<text class="box-center-text">心情：你喜欢APP哪里？想要得到怎样的延伸？</text>
				<text class="box-center-text">感想：你不喜欢APP哪里，想要得到怎样的改善？</text>
				<text class="box-center-text">建议：随时说说，你对APP有哪些好建议？</text>
				<text class="box-center-text">推荐：你用过哪些功能或体验较好的游戏APP？好在哪里？</text>
				<view class="btn1" @click="close">我知道了</view>
			</u-popup>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				typeList: [{
					id: 1,
					name: '盒子建议'
				}, {
					id: 2,
					name: '游戏反馈'
				}, {
					id: 3,
					name: '其他建议'
				}],
				fileList: [],
				feedbackData: {
					qq: '',
					linkman: '',
					content: '',
					flag: 1
				},
				show: false
			}
		},
		methods: {
			back() {
				uni.navigateBack()
			},
			close() {
				this.show = false
			},
			//按钮点击
			buttonClick(id) {
				this.feedbackData.flag = id
			},
			uploadSuccess(data) {
				this.fileList = data;
			},
			// 提交数据
			submit() {
				if (!this.feedbackData.linkman && !this.feedbackData.qq) {
					return uni.showToast({
						icon: 'none',
						title: '手机号和qq必须填一个'
					})
				} else if (this.feedbackData.content == false) {
					return uni.showToast({
						icon: 'none',
						title: '请填写内容'
					})
				}
				let data = {
					image: this.fileList.toString(),
					...this.feedbackData
				}
				this.$api.get('/game/feedback', {
					...data
				}).then(res => {
					console.log(111,res)
					if (res.data.code == 200) {
						uni.showToast({
							icon: 'none',
							title: res.data.msg
						})
						setTimeout(()=>{
							uni.navigateBack({
								delta: 1
							})
						},200)
						
					} else {
						uni.showToast({
							icon: 'none',
							title: res.data.msg
						})
					}
				})
			}
		}
	}
</script>

<style lang="scss">
	.container {
		background-color: #FFFFFF;
		width: 750rpx;
		height: 100vh;
		
		&-topTitle {
			position: fixed;
			// background-color: #FFFFFF;
			background: linear-gradient(to bottom, #CCCCCC, #FFFFFF env(safe-area-inset-top));
			z-index: 999;
			top: 0;
			width: 750rpx;
			height: 176rpx;
			padding: 0 34rpx 16rpx;
			box-sizing: border-box;
			display: flex;
			flex-direction: column;
			justify-content: flex-end;
			box-shadow: 0rpx 0rpx 12rpx rgba(0, 0, 0, 0.16);
			
			&-box {
				box-sizing: border-box;
				display: flex;
				flex-direction: row;
				justify-content: space-between;
				align-items: center;
				
				&-left {
					display: flex;
					flex-direction: row;
					align-items: center;
					
					&-img {
						height: 34rpx;
					}
					
					&-text {
						margin-left: 48rpx;
						font-size: 40rpx;
						line-height: 56rpx;
						font-family: PingFang SC;
						font-weight: 600;
						color: #1C1C1C;
					}
				}
				
				&-right {
					display: block;
					width: 35rpx;
					height: 35rpx;
				}
			}
		}
		
		&-content {
			width: 750rpx;
			padding: 205rpx 0 0;
			box-sizing: border-box;
			color: #1C1C1C;
			font-family: PingFang SC;
			min-height: 100vh;
			
			.content {
				padding: 40rpx 32rpx 0;
				.text1{
					font-size:32rpx ;
					font-weight: 500;
					color: #1C1C1C;
				}
				.boxAll{
					margin-top:40rpx ;
					display: flex;
					justify-content: space-between;
					.but{
						height: 64rpx;
						padding:0 24rpx ;
						line-height: 62rpx;
						color: #666666;
						font-weight: 400;
						font-size: 28rpx;
						text-align: center;
						background: #F4F4F4;
						border-radius: 40rpx;
						border: 2rpx solid #f4f4f4;
						box-sizing: border-box;
					}
					.buttonColor {
						color:#FF5927 ;
						font-weight:700 ;
						background-color: #fff;
						border: 2rpx solid #FF5927;
					}
				}
				.text_box{
					margin-top: 40rpx;
					padding:21rpx ;
					border-radius: 20rpx;
					border: 2rpx solid #E4E4E4;
					.box_input{
						height: 190rpx;
						color: #666666;
						font-size: 26rpx;
						font-weight: 400;
					}
				}
				.input_p{
					height: 72rpx;
					line-height: 72rpx;
					margin-top:40rpx ;
					border-radius: 36rpx;
					border: 2rpx solid #E4E4E4;
					padding: 0 24rpx;
					box-sizing: border-box;
					.p_text{
						height: 68rpx;
						line-height: 68rpx;
						font-size: 30rpx;
						font-weight: 400;
						color: #666666;
					}
					&.input_text{
						color: #FF5927;
						font-size: 32rpx;
						text-align: center;
						font-weight: 500;
					}
				}
			}
			.pop1 {
				.title{
					display: flex;
					align-items: center;
				}
				.title_img{
					width:42rpx ;
					height: 42rpx;
					border-radius: 42rpx;
					margin-right: 12rpx;
				}
				.title-text{
					color: #1C1C1C;
					font-size: 32rpx;
					font-weight: bold;
				}
				.box-center-text {
					color: #666666;
					padding: 0 10rpx;
					margin-top: 20rpx;
					font-size: 28rpx;
					align-items: center;
				}
				.btn1 {
					width: 174rpx;
					height: 60rpx;
					font-size: 28rpx;
					line-height: 60rpx;
					text-align: center;
					font-weight: bold;
					color: #FF4810;
					margin: 32rpx auto 0;
					border: 2rpx solid #E3E3E3;
					border-radius: 30rpx;
				}
			}
		}
	}
</style>
