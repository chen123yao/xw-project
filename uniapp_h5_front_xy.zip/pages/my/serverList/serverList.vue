<template>
	<view class="container">
		<view class="container-topTitle">
			<view class="container-topTitle-box">
				<view class="container-topTitle-box-left">
					<image class="container-topTitle-box-left-img" src="@/static/images/left.png" mode="heightFix" @click="back" />
					<text class="container-topTitle-box-left-text">新服</text>
				</view>
			</view>
		</view>
		
		<view class="container-content">
			<view class="content">
				<view class="server-list" v-if="Object.keys(this.pageData).length">
					<view class="server-item" v-for="(myList,myKey,myIndex) in pageData" :key="myIndex">
						<view class="serve-title" v-if="!myIndex">
							今日 {{weekday[new Date(myList[0].game_start_time*1000).getDay()]}}
						</view>
						<view class="serve-title" v-else>
							{{(typeof myList[0].game_start_time=='number'? myList[0].game_start_time: myList[0].game_start_time[0]) | dateFormat('MM月dd日')}}
							{{weekday[new Date((typeof myList[0].game_start_time=='number'? myList[0].game_start_time: myList[0].game_start_time[0])*1000).getDay()]}}
						</view>
						<view class="lines-box">
							<view class="lines" :class="{first:!myIndex}"></view>
						</view>
						<view class="card-list" :style="{paddingTop:!myIndex?'56rpx':'24rpx'}">
							<view class="server-card" v-for="(item,index) in myList" :key="index" @click="handleRouter(item.game_id)" :style="{marginBottom:(index==myList.length-1)?'24rpx':'56rpx'}">
								<view class="card-top">
									<view v-if="typeof item.ser_name=='string'" class="ser_name txt1" style="color: #FF5927;">{{item.ser_name}}</view>
									<view v-else class="server_name txt1" style="color: #FF5927;">{{item.ser_name[0]}}</view>
									<template v-if="typeof item.game_start_time=='object'" >
										<view class="serverTimes txt1" v-for="(i,v) in item.game_start_time" v-if="v<5"	:key='v'>{{i|dateFormat('hh:mm')}}</view>
									</template>
									<view v-else class="serverTimes txt1">{{item.game_start_time|dateFormat('hh:mm')}}</view>
								</view>
								<image :src="item.hot_image" mode="widthFix" class="card-img"></image>
								<view class="gameDetail">
									<view class="detatilLeft">
										<view class="gamename" style="margin-bottom:10rpx ;">{{item.gamename}}</view>
										<view class="listBottom">
											<view class="type text" v-if="item.classify==5">H5</view>
											<view class="type text" v-for="(v,i) in item.type" :key="i" v-if="i<2">{{v}}</view>
											<view class="text">| 已有{{item.popularity_cnt}}人在玩</view>
										</view>
									</view>
									<view class="detatilRight">
										<view class="rate_item" v-if="item.rate<1">
											<view class="rate_text">{{(item.rate*10).toFixed(1)}} </view>
											<view class="rate_text" style="font-size: 20rpx;"> 折</view>
										</view>
										<view v-else-if="item.has_coupons" class="rates" style="color:#19BFFF;">优惠券</view>
									</view>
								</view>
							</view>
						</view>
					</view>
					<u-loadmore :status="status" loading-text="努力加载中" loadmore-text="加载更多" nomore-text="没有更多了"
					 fontSize="28" line height="80" iconColor="#ff5927"  iconSize="48" loadingIcon="circle"	/>
				</view>
				<vue-loading :isNoData="isNoData" v-else></vue-loading>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				page:1,
				status: 'loadmore',
				isNoData: false,
				count: 99,
				pageData: {},
				weekday: ["周日", "周一", "周二", "周三", "周四", "周五", "周六"],
			}
		},
		methods: {
			back() {
				uni.navigateBack()
			},
			//获取开服数据
			getpageData() {
				this.$api.get('/gameserver/newlist', {
					page: this.page,
					client_id:this.$store.state.client_id ? this.$store.state.client_id : 4231
				}).then(res => {
					if(Object.keys(this.pageData).length){
						this.pageData = Object.assign({},this.pageData, res.data.data.list)
					}else{
						this.pageData = res.data.data.list
					}
					if(!res.data.data.count) {
						this.status = "nomore"
					} else {
						this.status = "loadmore"
					}
					this.isNoData = true
					console.log(this.pageData,'pageDatapageData');
				})
			},
			handleRouter(id) {
				uni.navigateTo({
					url: `/pages/view/gameDetail/gameDetail?gameId=${id}`
				})
			},
		},
		onLoad() {
			this.getpageData()
		},
		onReachBottom() {
			if(this.count>Object.keys(this.pageData).length && this.status=="loadmore") {
				this.status = "loading"
				this.page++
				this.getpageData()
			}
		}
	}
</script>

<style lang="scss">
	.container {
		background-color: #f5f5f5;
		width: 750rpx;
		height: 100vh;
		
		&-topTitle {
			position: fixed;
			// background-color: #FFFFFF;
			background: linear-gradient(to bottom, #CCCCCC, #FFFFFF env(safe-area-inset-top));
			z-index: 999;
			top: 0;
			width: 750rpx;
			height: 176rpx;
			padding: 0 34rpx 16rpx;
			box-sizing: border-box;
			display: flex;
			flex-direction: column;
			justify-content: flex-end;
			box-shadow: 0rpx 0rpx 12rpx rgba(0, 0, 0, 0.16);
			
			&-box {
				box-sizing: border-box;
				display: flex;
				flex-direction: row;
				justify-content: space-between;
				align-items: center;
				
				&-left {
					display: flex;
					flex-direction: row;
					align-items: center;
					
					&-img {
						height: 34rpx;
					}
					
					&-text {
						margin-left: 48rpx;
						font-size: 40rpx;
						line-height: 56rpx;
						font-family: PingFang SC;
						font-weight: 600;
						color: #1C1C1C;
					}
				}
				
				&-right {
					display: block;
					width: 35rpx;
					height: 35rpx;
				}
			}
		}
		
		&-content {
			width: 750rpx;
			padding: 176rpx 0 0;
			box-sizing: border-box;
			color: #f5f5f5;
			font-family: PingFang SC;
			min-height: 100vh;
			
			.content {
				padding: 0 32rpx 32rpx;
				background-color: #f5f5f5;
				min-height: 100vh;
				.serve-title {
					position: sticky;
					top: 88rpx;
					height: 114rpx;
					display: flex;
					align-items: center;
					font-size: 36rpx;
					font-weight: 600;
					line-height: 50rpx;
					color: #1c1c1c;
					background-color: #f5f5f5;
					z-index: 90;
				}
				.lines-box {
					display: flex;
					justify-content: flex-end;
					.lines {
						position: relative;
						width: 400rpx;
						height: 2rpx;
						top: -57rpx;
						background-color: #000;
						transform: translateY(-50%);
						z-index: 91;
						&.first {
							width: 100%;
							top: 2rpx;
							background-color: #fff;
						}
					}
				}
				.card-list {
					.server-card {
						.card-top {
							display: flex;
							align-items: center;
							.ser_name {
								padding: 6rpx 14rpx;
								border-top-left-radius: 20rpx;
								border: 1rpx solid #C1C1C1;
								border-bottom: transparent;
							}
							.txt1 {
								color: #C1C1C1;
								font-size: 24rpx;
							}
							.serverTimes {
								padding: 6rpx 16rpx;
								background-color: #F2F2F2;
							}
						}
						.card-img {
							display: block;
							width: 100%;
							border-radius: 20rpx;
							border-top-left-radius: 0;
						}
						.gameDetail {
							display: flex;
							align-items: center;
							justify-content: space-between;
							padding-top: 16rpx;
							.text {
								color: #666666;
								font-size: 26rpx;
							}
							.gamename {
								font-size: 32rpx;
								font-weight: 600;
								color: #1C1C1C;
							}
							.listBottom {
								display: flex;
								align-items: center;
								.type {
									margin-right: 12rpx;
								}
							}
							.detatilRight {
								.rate_item {
									border: 2rpx solid #E4E4E4;
									display: flex;
									align-items: flex-end;
									justify-content: center;
									border-radius:32rpx;
									padding: 8rpx 16rpx;
								}
								.rate_text{
									color: #FF5927;
									font-size: 28rpx;
									font-weight: 600;
								}
								.rates {
									font-size: 26rpx;
									font-weight: 600;
									color: #FF5927;
									padding: 8rpx 20rpx;
									border-radius: 32rpx;
									border: 2rpx solid #E4E4E4;
								}
							}
						}
					}
				}
			}
		}
	}
</style>
