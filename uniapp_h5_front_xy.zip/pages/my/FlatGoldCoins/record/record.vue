<template>
	<view class="container">
		<view class="container-topTitle">
			<view class="container-topTitle-box">
				<view class="container-topTitle-box-left">
					<image class="container-topTitle-box-left-img" src="@/static/images/left.png" mode="heightFix" @click="back" />
					<text class="container-topTitle-box-left-text">账号记录</text>
				</view>
			</view>
		</view>
		
		<view class="container-content">
			<view class="nav-tabs">
				<u-tabs :list="TitleList" @click="click"  lineWidth="60rpx" lineHeight="2px" lineColor="#ff5927" :activeStyle="{color: '#000',fontWeight: 'bold'}" 
				:inactiveStyle="{color: '#1c1c1c'}" :current="active" itemStyle="padding-left: 15px; padding-right: 15px; height: 70rpx;"></u-tabs>
			</view>
			<view class="show-list" v-if="0==active">
				<template v-if="ObtainList.length">
					<view  class="cell"  v-for="(item,index) in ObtainList">
						<view class="cell_left">
							<text class="left_text1" v-if="item.status==1">充值失败-未确认</text>
							<text class="left_text1" v-if="item.status==2">充值成功</text>
							<text class="left_text1" v-if="item.status==3">充值失败</text>
							<text class="left_text2">{{item.create_time | dateFormat('yyyy-MM-dd hh:mm')}}</text>
						</view>
						<text class="cell_right" :style="{color:item.status==1?'#999999':'#FF4810'}">+{{item.ptb_cnt}} 平台币</text>
					</view>
					<u-loadmore :status="status0" loading-text="努力加载中" loadmore-text="加载更多" nomore-text="没有更多了"
					 fontSize="28" line height="80" iconColor="#ff5927"  iconSize="48" loadingIcon="circle"	/>
				</template>
				<vue-loading :isNoData="isNoData" v-else></vue-loading>
			</view>
			<view class="show-list" v-else>
				<template v-if="exchangeList.length">
					<view  class="cell"  v-for="(item,index) in exchangeList">
						<view class="cell_left">
							<text class="left_text1">游戏充值</text>
							<text class="left_text2" style="color:#999999;">{{item.create_time | dateFormat('yyyy-MM-dd hh:mm')}}</text>
						</view>
						<text class="cell_right" style="color:#999999;">-{{item.amount}}元</text>
					</view>
					<u-loadmore :status="status1" loading-text="努力加载中" loadmore-text="加载更多" nomore-text="没有更多了"
					 fontSize="28" line height="80" iconColor="#ff5927"  iconSize="48" loadingIcon="circle"	/>
				</template>
				<vue-loading :isNoData="isNoData" v-else></vue-loading>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				active: 0,
				ObtainList: [],
				exchangeList: [],
				isNoData: false,
				status0: 'loadmore',
				status1: 'loadmore',
				TitleList: [{
						id: 0,
						name: '充值记录'
					},
					{
						id: 1,
						name: '消费记录'
					}
				],
				params: [{
					page: 1,
					offset: 10,
					itg_type: 1,
					count:0,
				}, {
					page: 1,
					count:0,
					offset: 10,
				
				}],
			}
		},
		methods: {
			back() {
				uni.navigateBack()
			},
			click(item) {
					this.active = item.id
			},
			// 1.充值记录
			getObtainData() {
				this.$api.get('/app/ptb/recharge/record_list', {
					...this.params[0]
				}).then(res => {
					if (res.data.code == 200) {
						this.ObtainList = this.ObtainList.concat(res.data.data.list)
						this.params[0].count = res.data.data.count
						if(!res.data.data.count) {
							this.isNoData = true
						}
						if(this.ObtainList.length>=this.params[0].count) {
							this.status0 = "nomore"
						} else {
							this.status0 = "loadmore"
						}
					} else {
						uni.showToast({
							title:res.data.msg,
							icon: "none"
						})
					}
				})
			},
			// 2.消费记录
			getExchangeData() {
				this.$api.get('/app/sdk/order/list', {
					...this.params[1]
				}).then(res => {
					if (res.data.code == 200) {
						this.exchangeList = this.exchangeList.concat(res.data.data.list) ;
						this.params[1].count = res.data.data.count
						if(!res.data.data.count) {
							this.isNoData = true
						}
						if(this.exchangeList.length>=this.params[1].count) {
							this.status1 = "nomore"
						} else {
							this.status1 = "loadmore"
						}
					} else {
						uni.showToast({
							title:res.data.msg,
							icon: "none"
						})
					}
				})
			},
		},
		onLoad() {
			this.getObtainData()
			this.getExchangeData()
		},
		onReachBottom() {
			if(!this.active) {
				if(this.params[0].count>this.ObtainList.length && this.status0 == "loadmore"){
					this.status0 = "loading"
					this.params[0].page++
					this.getObtainData()	
				}
			} else {
				if(this.params[1].count>this.exchangeList.length && this.status1 == "loadmore"){
					this.status1 = "loading"
					this.params[1].page++
					this.getExchangeData()	
				}
			}
		}
	}
</script>

<style lang="scss">
	.container {
		background-color: #FFFFFF;
		width: 750rpx;
		height: 100vh;
		
		.container {
			&-topTitle {
				position: fixed;
				// background-color: #FFFFFF;
				background: linear-gradient(to bottom, #CCCCCC, #FFFFFF env(safe-area-inset-top));
				z-index: 999;
				top: 0;
				width: 750rpx;
				height: 176rpx;
				padding: 0 34rpx 16rpx;
				box-sizing: border-box;
				display: flex;
				flex-direction: column;
				justify-content: flex-end;
				box-shadow: 0rpx 0rpx 12rpx rgba(0, 0, 0, 0.16);
				
				&-box {
					box-sizing: border-box;
					display: flex;
					flex-direction: row;
					justify-content: space-between;
					align-items: center;
					
					&-left {
						display: flex;
						flex-direction: row;
						align-items: center;
						
						&-img {
							height: 34rpx;
						}
						
						&-text {
							margin-left: 48rpx;
							font-size: 40rpx;
							line-height: 56rpx;
							font-family: PingFang SC;
							font-weight: 600;
							color: #1C1C1C;
						}
					}
					
					&-right {
						display: block;
						width: 35rpx;
						height: 35rpx;
					}
				}
			}
			
			&-content {
				width: 750rpx;
				padding: 206rpx 0 0;
				box-sizing: border-box;
				color: #1C1C1C;
				font-family: PingFang SC;
				min-height: 100vh;
				
				.nav-tabs {
					position: sticky;
					left: 0;
					top: 88rpx;
					width: 100%;
					height: 84rpx;
					padding-top: 10rpx;
					background-color: #fff;
					z-index: 99;
					// ::v-deep .u-tabs__wrapper__nav__item {
					// 	flex: 1;
					// }
				}
				.show-list {
					padding: 0 32rpx;
					.cell{
						display: flex;
						justify-content: space-between;
						padding:40rpx 0;
						border-bottom:1rpx solid #ECECEC;
						align-items: center;
						.left_text1{
							display: block;
							font-size:32rpx ;
							color: #000000;
							font-weight: bold;
							margin-bottom:20rpx ;
						}
						.left_text2{
							font-size:24rpx ;
							color: #999999;
							font-weight:400 ;
						}
						.cell_right{
							color: #FF4810;
							font-size:32rpx ;
							font-weight: 400;
						}
					}
				}
			}
		}
	}
</style>