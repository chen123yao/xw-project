<!-- h5游戏开玩 -->
<template>
	<view class="container">

		<web-view :src="game_url"></web-view>
		<image src="@/static/images/loading.gif" width="40%" mode="widthFix" class="image"></image>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				game_url: ""
			}
		},
		onLoad(options) {
			this.game_url = this.$common.aesDecrypt(options.game_url, "aaa");
			console.log('this.game_url', this.game_url)
		},

	}
</script>

<style lang="scss" scoped>
	.container {
		position: relative;
		overflow: hidden;

		.image {
			position: absolute;
			top: 50%;
			left: 50%;
			transform: translate(-50%, -50%);
		}
	}
</style>
