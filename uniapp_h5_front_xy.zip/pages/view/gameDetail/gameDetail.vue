<template>
	<page-meta :page-style="isShowServerPanel ? 'overflow: hidden' : ''"></page-meta>
	<view class="container detail" id="container">
		<!-- cc 顶部背景部分 -->
		<view class="detail-gameBg">
			<!-- cc 顶部背景骨架屏 -->
			<u-skeleton :title="false" :rows=".5" :rowsWidth="750" :rowsHeight="422" :animate="true" :loading="!pageData"></u-skeleton>
			<!-- cc 顶部背景图片 -->
			<view v-if="pageData" class="detail-gameBg-img" id="gameBgImg" :style="{ 'backgroundImage': 'url(' + pageData.app_hot_image + ')' }"></view>
		</view>
		
		<!-- cc 顶部图标 -->
		<view class="detail-icon detail-icon-left" :style="{ opacity: scrollStyle.iconTitleOpacity }" ref="iconleft" @click="back"></view>
		<!-- <view class="detail-icon detail-icon-right" :style="{ opacity: scrollStyle.iconTitleOpacity }" ref="iconright" @click="propupmother"></view> -->
		
		<!-- cc 顶部icon name download 默认隐藏 -->
		<view v-if="scrollStyle.topTitleOpacity" class="detail-topDetail" :style="{ opacity: scrollStyle.topTitleOpacity }">
			<image class="detail-topDetail-back" src="@/static/images/back.png" mode="scaleToFill" @click="back"></image>
			<image class="detail-topDetail-icon" :src="pageData.new_icon || pageData.icon" mode="scaleToFill"></image>
			<text class="detail-topDetail-gameName">{{ pageData.gamename }}</text>
			<view v-if="scrollStyle.downloadOpactiy" class="detail-topDetail-download" :style="{ opacity: scrollStyle.downloadOpactiy }">{{ downloadContent.text }}</view>
		</view>
		
		<!-- cc 顶部背景图片占位格 -->
		<view style="height: 422rpx; width: 750rpx; background-color: transparent;"></view>
		
		<!-- cc 游戏内容区 -->
		<view class="detail-content">
			<!-- cc 背景面板毛玻璃效果 --> 
			<u-sticky :offsetTop="0" :customNavHeight="0" :zIndex="999" bgColor="#FFFFFF" style="overflow: hidden;">
				<view class="detail-content-blur">
					<!-- <image :src="pageData.app_hot_image" mode="scaleToFill"></image> -->
					<view class="detail-content-blur-before"></view>
					<view v-if="pageData" class="detail-content-blur-img" blurEffect="light" :style="{ 'backgroundImage': 'url(' + pageData.app_hot_image + ')' }"></view>
					<view class="detail-content-blur-after"></view>
					
					<!-- cc 骨架屏 -->
					<view v-if="!pageData" class="detail-content-blur-normal">
						<!-- cc 顶部背景骨架屏 -->
						<u-skeleton :titleHeight="44" :titleWidth="310" :rows=".5" :rowsHeight="24" :rowsWidth="328" :animate="true" :avatar="true" :avatarSize="136" avatarShape="square" :loading="!pageData"></u-skeleton>
						<u-skeleton class="skeletonflexNone" style="width: 96rpx;" :animate="true" :title="false" :titleWidth="0" :rows="0" :rowsWidth="0" :avatar="true" :avatarSize="96" avatarShape="square" :loading="!pageData"></u-skeleton>
					</view>
					<!-- cc 正常情况下的游戏icon name 描述等 -->
					<view v-else class="detail-content-blur-normal" :style="{ opacity: scrollStyle.blurTitleOpacity }">
						<image class="detail-content-blur-normal-icon" :src="pageData.new_icon || pageData.icon" mode="scaleToFill"></image>
						<view class="detail-content-blur-normal-content">
							<!-- cc 游戏名称 -->
							<text class="detail-content-blur-normal-content-title">{{ pageData.gamename }}</text>
							<!-- cc 游戏标题 -->
							<view class="detail-content-blur-normal-content-tags">
								<text v-if="pageData.gc_id" class="detail-content-blur-normal-content-tags-gc">{{ pageData.gc_id }}出品</text>
								<text>{{ pageData.popularity_cnt }}人在玩</text>
							</view>
						</view>
						<!-- cc 游戏评分 -->
						<view class="detail-content-blur-normal-grade">
							<text class="detail-content-blur-normal-grade-score">{{ pageData.star_cnt }}</text>
							<text class="detail-content-blur-normal-grade-title">评分</text>
						</view>
					</view>
				</view>
				
				<!-- cc 福利到下载布局整个是可以隐藏的所以得包起来 -->
				<view class="detail-content-leafPlane" id="leafplane">
					<!-- cc 游戏相关福利信息 骨架屏 -->
					<view v-if="!pageData" class="detail-content-welfare">
						<u-skeleton class="skeletonflexNone" :title="false" :rows=".5" :rowsWidth="208" :rowsHeight="96" :animate="true" :loading="!pageData"></u-skeleton>
						<u-skeleton class="skeletonflexNone" :title="false" :rows=".5" :rowsWidth="302" :rowsHeight="96" :animate="true" :loading="!pageData"></u-skeleton>
						<u-skeleton class="skeletonflexNone" :title="false" :rows=".5" :rowsWidth="96" :rowsHeight="96" :animate="true" :loading="!pageData"></u-skeleton>
					</view>
					
					<!-- cc 游戏相关福利信息 优惠券、开服时间、游戏折扣 -->
					<view v-else class="detail-content-welfare">
						<!-- cc 优惠券 -->
						<view class="detail-content-welfare-coupon" @click="toCouponPlane(pageData.coupons.count, pageData.game_id)">
							<image class="detail-content-welfare-coupon-img" :src="pageData.coupons.count ? '../../../static/images/view/rateQuan.png' : '../../../static/images/view/yhq-black.png'" mode="scaleToFill"></image>
							<text class="detail-content-welfare-coupon-text" :style="{ color: pageData.coupons.count ? '#1c1c1c' : '#666666' }">优惠券</text>
						</view>
						
						<!-- cc 开服信息 -->
						<view class="detail-content-welfare-server" @click="toServerPlane(pageData.game_start_time, pageData.game_id)">
							<image class="detail-content-welfare-server-img" src="@/static/images/view/PlayGame.png" mode="scaleToFill"></image>
							<view v-if="pageData.serlistNew.count && pageData.game_start_time" class="detail-content-welfare-server-content">
								<text class="detail-content-welfare-server-content-server">{{ pageData.serlistNew.list[0].server_name }}</text>
								<text class="detail-content-welfare-server-content-timer">今天&nbsp;{{ pageData.serlistNew.list[0].start_time | dateFormat('hh:mm') }}</text>
							</view>
							<text v-else class="detail-content-welfare-server-text">动态开服</text>
							<image v-if="pageData.serlistNew.count && pageData.game_start_time" class="detail-content-welfare-server-right" src="@/static/images/view/999_right.png" mode="scaleToFill"></image>
						</view>
						
						<!-- cc 折扣信息 -->
						<view class="detail-content-welfare-discount" :style="{ 'backgroundImage': 'url(' + (pageData.rate < 1 ? '../../../static/images/view/zhekou.png' : '../../../static/images/view/nozhekou.png') + ')' }">
							<text v-if="pageData.rate < 1" class="detail-content-welfare-discount-text">{{ (pageData.rate * 10).toFixed(1) }}</text>
							<text v-else class="detail-content-welfare-discount-text-noDiscount">无折扣</text>
							<text v-if="pageData.rate < 1" class="detail-content-welfare-discount-littleText">折</text>
						</view>
					</view>
					
					<!-- cc 游戏下载布局 骨架屏-->
					<view v-if="!pageData" class="detail-content-download">
						<u-skeleton style="border-radius: 24rpx;" class="skeletonflexNone" :title="false" :rows=".5" :rowsWidth="686" :rowsHeight="80" :animate="true" :loading="!pageData"></u-skeleton>
					</view>
					
					<!-- cc 游戏下载布局 -->
					<view v-else class="detail-content-download">
						<view class="detail-content-download-btn" @click="downloadGame">
							<image class="detail-content-download-btn-img" :src="downloadContent.img" mode="widthFix" />
							<text class="detail-content-download-btn-text">{{ downloadContent.text }}</text>
							<text v-if="pageData.game_task_content" class="detail-content-download-btn-tips">{{ pageData.game_task_content }}</text>
						</view>
					</view>
				</view>
				
				<!-- cc 收藏、福利、攻略 骨架屏 -->
				<view v-if="!pageData" class="detail-content-welfareNext">
					<u-skeleton class="skeletonflexNone" :title="false" :rows=".5" :rowsWidth="120" :rowsHeight="40" :animate="true" :loading="!pageData"></u-skeleton>
					<view class="detail-content-welfareNext-line"></view>
					<u-skeleton class="skeletonflexNone" :title="false" :rows=".5" :rowsWidth="116" :rowsHeight="40" :animate="true" :loading="!pageData"></u-skeleton>
					<view class="detail-content-welfareNext-line"></view>
					<u-skeleton class="skeletonflexNone" :title="false" :rows=".5" :rowsWidth="182" :rowsHeight="40" :animate="true" :loading="!pageData"></u-skeleton>
				</view>
				
				<!-- cc 收藏、福利、攻略 -->
				<view v-else class="detail-content-welfareNext">
					<view class="detail-content-welfareNext-box" @click="collectOperation(pageData.game_id)">
						<image class="detail-content-welfareNext-box-img" :src="pageData.is_collect == 1 ? '../../../static/images/view/ysc.png' : '../../../static/images/view/sc.png'" mode="heightFix"></image>
						<text class="detail-content-welfareNext-box-text">{{ pageData.is_collect == 1 ? '已收藏' : '收藏' }}</text>
					</view>
					<view class="detail-content-welfareNext-line"></view>
					<view class="detail-content-welfareNext-box" @click="handleRouter('/pages/view/gameDetail/children/welfare/index?gameId=' + pageData.game_id)">
						<image class="detail-content-welfareNext-box-img" src="@/static/images/view/fl.png" mode="heightFix"></image>
						<text class="detail-content-welfareNext-box-text">福利</text>
					</view>
					<view class="detail-content-welfareNext-line"></view>
					<view class="detail-content-welfareNext-box" @click="handleRouter('/pages/view/gameDetail/children/information?gameId=' + pageData.game_id)">
						<image class="detail-content-welfareNext-box-img" src="@/static/images/view/zxgl.png" mode="heightFix"></image>
						<text class="detail-content-welfareNext-box-text">资讯攻略</text>
					</view>
				</view>
			</u-sticky>
			
			<!-- cc 轮播图 骨架屏 -->
			<scroll-view v-if="!pageData" class="detail-content-scrollBar" scroll-x="true">
				<u-skeleton class="detail-content-scrollBar-item" :title="false" :rows=".5" :rowsWidth="200" :rowsHeight="368" :animate="true" :loading="!pageData" v-for="(text, index) in 4"></u-skeleton>
			</scroll-view>
			
			<scroll-view v-else class="detail-content-scrollBar" scroll-x="true">
				<!-- cc 游戏相关视屏 -->
				<video v-if="pageData.mp4_type==1" class="detail-content-scrollBar-video" :src="pageData.mp4_url_new" objectFit="fill"
					:enable-progress-gesture='false' :poster='pageData.hot_image'></video>
				<!-- cc 轮播图图片 -->
				<image class="detail-content-scrollBar-item" v-for="(value, index) in pageData.image" :key="'img' + index" @click="previewImage(index, pageData.image)"
					:src="/http/i.test(value) ? value : 'https:' + value"></image>
			</scroll-view>
			
			<!-- cc 游戏简介 骨架屏 -->
			<view v-if="!pageData" class="detail-content-detail">
				<view class="detail-content-detail-title">
					<u-skeleton :title="false" :rows=".5" :rowsWidth="80" :rowsHeight="40" :animate="true" :loading="!pageData"></u-skeleton>
					<u-skeleton class="skeletonflexNone" :title="false" :rows=".5" :rowsWidth="122" :rowsHeight="28" :animate="true" :loading="!pageData"></u-skeleton>
				</view>
				
				<view class="detail-content-detail-tags">
					<u-skeleton class="skeletonflexNone detail-content-detail-tags-item" :title="false" :rows=".5" :rowsWidth="i ? 104 : 180" 
						:rowsHeight="48" :animate="true" :loading="!pageData" v-for="(v, i) in 3"></u-skeleton>
				</view>
				
				<view class="detail-content-detail-content">
					<u-skeleton class="skeletonflexNone" :title="false" :rows="3" :rowsWidth="686" :rowsHeight="28" :animate="true" :loading="!pageData"></u-skeleton>
				</view>
			</view>
			
			<!-- cc 游戏简介 骨架屏 -->
			<view v-else class="detail-content-detail">
				<!-- cc 简介顶部标题和更多按钮 -->
				<view class="detail-content-detail-title">
					<text class="detail-content-detail-title-left">简介</text>
					<text @click="handleRouter(`/pages/view/gameDetail/children/introduce?content=${ pageData.desc }&title=${ pageData.gamename}`)">查看全部</text>
				</view>
				
				<!-- cc 简介中的游戏类型标签 -->
				<view class="detail-content-detail-tags">
					<view v-if="pageData.detailtype == 1" class="detail-content-detail-tags-itemFirst"> 
						<text>NO:{{ pageData.tag }} 新游榜 </text>
						<image class="detail-content-detail-tags-itemFirst-right" src="@/static/images/view/right-blue.png" mode="scaleToFill" />
					</view>
					<view v-if="pageData.detailtype == 2" class="detail-content-detail-tags-itemFirst">
						<text>NO:{{ pageData.tag }} 热门榜 </text>
						<image class="detail-content-detail-tags-itemFirst-right" src="@/static/images/view/right-blue.png" mode="scaleToFill" />
					</view>
					<view class="detail-content-detail-tags-item" v-for="(item, index) in pageData.type" :key="'type' + index" @click="handleToGameList('cate', pageData.category_id[index], item)">
						<text>{{ item }}</text>
						<image class="detail-content-detail-tags-item-right" src="@/static/images/view/right-gred.png" mode="scaleToFill" />
					</view>
				</view>
				
				<!-- cc 简介的具体内容 -->
				<view class="detail-content-detail-content">
					<text>{{ pageData.desc }}</text>
				</view>
			</view>
			
			<!-- cc 游戏评价 -->
			<view v-if="pageData" class="detail-content-evaluate">
				<!-- cc 评价顶部标题和更多按钮 -->
				<view class="detail-content-evaluate-title">
					<text class="detail-content-evaluate-title-left">评价</text>
					<text @click="handleRouter(`/pages/view/gameDetail/children/evaluate?gameId=${ pageData.game_id }`)">查看全部</text>
				</view>
				
				<!-- cc 评价中的主体部分内容 -->
				<view class="detail-content-evaluate-content">
					<!-- cc 评价左侧总评分值 评分人数 -->
					<view class="detail-content-evaluate-content-left">
						<text class="detail-content-evaluate-content-left-score">{{ pageData.star_cnt }}</text>
						<u-rate :count="5" v-model="pageData.star_cnt / 2" :size="16" active-color="#FF5927" inactive-color="#C1C1C1" :gutter="8" :allowHalf="true" :readonly="true" inactiveIcon="star-fill"></u-rate>
						<text class="detail-content-evaluate-content-left-text">{{ pageData['star_all'] }}人在评分</text>
					</view>
					
					<!-- cc 右侧各分段评分人数详情 -->
					<view class="detail-content-evaluate-content-right">
						<view class="detail-content-evaluate-content-right-item" v-for="(item, index) in 5">
							<u-rate :count="5 - index" :minCount="0" :value="0" :size="24" inactive-color="#C1C1C1" :gutter="8" :readonly="true" inactiveIcon="star-fill"></u-rate>
							<u-line-progress :percentage="pageData['star' + (5 - index)]" activeColor="#FF5927" inactiveColor="#EFEFEF" :showText="false" :height="10" style="width: 300rpx; margin-left: 16rpx;"></u-line-progress>
						</view>
					</view>
				</view>
				
				<!-- cc 评价的具体评论内容 -->
				<view class="detail-content-evaluate-comment">
					<!-- cc 总评论条数 -->
					<text v-if="evaluateData" class="detail-content-evaluate-comment-total">当前共有{{ pageData.comment_count }}条评论</text>
					<text v-else class="detail-content-evaluate-comment-total">当前共有0条评论</text>
					
					<!-- cc 首条评论数据 -->
					<view v-if="evaluateData" class="detail-content-evaluate-comment-first">
						<!-- cc 首条评论玩家信息 -->
						<view class="detail-content-evaluate-comment-first-playerInfo" @click="handleRouter(`/pages/view/gameDetail/children/evaluate?gameId=${ pageData.game_id }`)">
							<u-avatar :src="/http/i.test(evaluateData.mem_avatar)?evaluateData.mem_avatar:'https:'+ evaluateData.mem_avatar" :size="80"></u-avatar>
							<view class="detail-content-evaluate-comment-first-playerInfo-info">
								<view class="detail-content-evaluate-comment-first-playerInfo-info-name">{{ evaluateData.mem_name }}</view>
								<view class="detail-content-evaluate-comment-first-playerInfo-info-time">{{ evaluateData.create_time | dateFormat('yyyy-MM-dd hh:mm:ss') }}</view>
							</view>
						</view>
						
						<!-- cc 首条评论玩家游戏时长 -->
						<view class="detail-content-evaluate-comment-first-evaluate" @click="handleRouter(`/pages/view/gameDetail/children/evaluate?gameId=${ pageData.game_id }`)">
							<u-rate :count="5" v-model="evaluateData.star_cnt / 2" :size="24" active-color="#FF5927" inactive-color="#C1C1C1" :gutter="8" :allowHalf="true" :readonly="true" inactiveIcon="star-fill"></u-rate>
							<text class="detail-content-evaluate-comment-first-evaluate-time">游戏时长{{ playerGameTime }}分钟</text>
						</view>
						
						<!-- cc 首条评论内容 -->
						<view class="detail-content-evaluate-comment-first-content" @click="handleRouter(`/pages/view/gameDetail/children/evaluate?gameId=${ pageData.game_id }`)">
							<text class="detail-content-evaluate-comment-first-content-text">{{ evaluateData.content }}</text>
							<image v-if="evaluateData.content_img.length > 0" class="detail-content-evaluate-comment-first-content-img" :src="evaluateData.content_img[0]" mode="aspectFill"></image>
						</view>
						
						<!-- cc 点赞点踩回复数量 -->
						<view class="detail-content-evaluate-comment-first-zan" @click="handleRouter(`/pages/view/gameDetail/children/evaluate?gameId=${ pageData.game_id }`)">
							<u-icon name="thumb-up" color="#666666" size="34"></u-icon>
							<text>{{ evaluateData.like_cnt }}</text>
							<u-icon name="thumb-down" color="#666666" size="34"></u-icon>
							<text>{{ evaluateData.hate_cnt }}</text>
							<image src="@/static/images/view/contens.png" mode="scaleToFill" />
							<text>{{ evaluateData.sum ? evaluateData.sum : 0 }}</text>
						</view>
						
						<!-- cc 首条评论相关回复 -->
						<view v-if="evaluateData.sub.length" class="detail-content-evaluate-comment-first-reply" @click="handleRouter(`/pages/view/gameDetail/children/evaluate?gameId=${ pageData.game_id }`)">
							<view v-if="index < 2" class="detail-content-evaluate-comment-first-reply-item" v-for="(item, index) in evaluateData.sub" :key="'sub' + index">
								<text class="detail-content-evaluate-comment-first-reply-item-name">{{ item.mem_name }}：</text>
								<text class="detail-content-evaluate-comment-first-reply-item-content">{{ item.content }}</text>
							</view>
							<text class="detail-content-evaluate-comment-first-reply-more">查看全部{{ evaluateData.sum ? evaluateData.sum : 0 }}条评论</text>
						</view>
						<view class="detail-content-evaluate-comment-first-btn" @click="handleRouter(`/pages/view/gameDetail/children/evaluate?gameId=${ pageData.game_id }`)">查看全部评论</view>
					</view>
				</view>
			</view>
		
			<!-- cc 相关游戏 -->
			<view class="detail-content-relatedGame">
				<!-- cc 相关游戏 -->
				<view class="detail-content-relatedGame-title">
					<text class="detail-content-relatedGame-title-left">相关游戏</text>
					<view class="detail-content-relatedGame-title-right" @click="changeRelatedGame">
						<image class="detail-content-relatedGame-title-right-img" id="refresh" src="@/static/images/view/Refresh-icon.png" mode="heightFix" />
						<text>换一批</text>
					</view>
				</view>
				
				<!-- cc 相关游戏面板 -->
				<view class="detail-content-relatedGame-gamePlane">
					<view v-if="relevantData" v-for="index in 6">
						<vue-gameIcon v-if="(index - 1) < relevantData.length" :iconWidth="176" :iconBMargin="40" :iconTitleStyle="{ fontSize: '24rpx', color: '#1C1C1C', fontWeight: '500', marginTop: '8rpx' }"
						 :iconTagStyle="{ fontSize: '20rpx', width: '99rpx', top: '4rpx', color: '#fff', fontWeight: '400' }" :iconData='relevantData[index - 1]'></vue-gameIcon>
						<view v-else style="width: 176rpx; height: 252rpx; margin-bottom: 40rpx;" />
					</view>
				</view>
			</view>
		</view>
	</view>
	<!-- cc 顶部游戏类型下拉面板 -->
	<view v-if="isShowServerPanel" class="serverPanel" @touchmove.stop.prevent="preventTouchMove">
		<u-popup :show="isShowServerPanel" :closeOnClickOverlay="false" :round="40" mode="bottom" @close="isShowServerPanel = false">
			<view class="serverPanel-layout">
				<!-- cc 开标信息标题 -->
				<text class="serverPanel-layout-title">全部开服</text>
				<!-- cc 开服信息关闭按钮 -->
				<image class="serverPanel-layout-close" src="@/static/images/close.png" mode="scaleToFill" @click="closeServerPanel"></image>
				<!-- cc 下拉面板内容区scroll -->
				<scroll-view v-if="pageData" class="serverPanel-layout-scroll" :scroll-y="true">
					<view class="serverPanel-layout-scroll-content">
						<view class="serverPanel-layout-scroll-content-item" v-for="(item, index) in pageData.serlistNew.list" :key="'server' + index">
							<text class="serverPanel-layout-scroll-content-item-top">{{ item.server_name }}</text>
							<text v-if="item.start_time * 1000 >= new Date(new Date().toLocaleDateString()).getTime() && item.start_time * 1000 < new Date(new Date(new Date().toLocaleDateString()).getTime() + 24 * 3600000)" 
								:class="!index && 'serverPanel-layout-scroll-content-item-active'">今天 {{ item.start_time|dateFormat('hh:mm') }}</text>
							<text v-else>{{ item.start_time | dateFormat("MM月dd日") }} {{ item.start_time | dateFormat("hh:mm") }}</text>
						</view>
					</view>
				</scroll-view>
			</view>
		</u-popup>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				// cc 当前游戏详情页的游戏ID
				gameId: '',
				// cc 对应的渠道ID
				agentId: '',
				// cc 游戏详情请求数据
				pageData: null,
				// cc 游戏评论数据
				evaluateData: null,
				// cc 相关游戏数据
				relevantData: null,
				// cc 用于第一个评论玩家的游戏时长  随机一个数
				playerGameTime: Math.floor(Math.random() * (100 - 1) + 1),
				// cc 游戏详情轮播图图片数据
				imageData: [],
				// cc 根据游戏类型确定download模块显示的内容
				downloadContent: {
					text: '下载',
					img: '../../../static/images/view/downLoad.png'
				},
				disabled: false,
				timeOutId: 0,
				// cc 顶部页面滑动时的样式改变
				scrollStyle: {
					topTitleOpacity: 0,
					blurTitleOpacity: 1,
					iconTitleOpacity: 1,
					downloadOpactiy: 0
				},
				// cc 相关游戏更换事件 节流阀 默认关闭
				isChangeRelevant: false,
				// cc 开服信息显示状态 默认false
				isShowServerPanel: false,
				// cc 页面滚动高度 默认0
				scrollOffsetY: 0
			}
		},
		onLoad(option) {
			this.game_id = option.gameId
			this.disabled = false
			this.getGameData()
		},
		// cc 页面级滚动事件
		onPageScroll(event) {
			// cc 顶部游戏背景高度
			let bg_height = 422 / (750 / this.$store.state.myWidth)
			// cc 
			let leafPlane_height = 312 / (750 / this.$store.state.myWidth)
			// cc 隐藏折叠布局的开始高度
			let hideLeaf_height = (422 + 180) / (750 / this.$store.state.myWidth)
			
			console.log('scrollHeight: ', event.scrollTop, 'bg_height: ', bg_height, 'leafPlane_height：', leafPlane_height, 'hideLeaf_height：', hideLeaf_height);
		
			this.scrollStyle.topTitleOpacity = 0 + (event.scrollTop > 160 ? event.scrollTop - 160 : 0) / 70
			this.scrollStyle.blurTitleOpacity = 1 - (event.scrollTop > 80 ? event.scrollTop - 80 : 0) / 130
			this.scrollStyle.iconTitleOpacity = 1 - event.scrollTop / (bg_height - 60)
			this.scrollStyle.downloadOpactiy = 0 + (event.scrollTop > hideLeaf_height ? event.scrollTop - hideLeaf_height : 0) / 120
			
			let gameBgImg = document.getElementById('gameBgImg')
			gameBgImg.style.scale = 1 - (event.scrollTop < 0 ? event.scrollTop : 0) / 96
			
			let leafplane = document.getElementById('leafplane')
			leafplane.style.height = leafPlane_height - (event.scrollTop > hideLeaf_height ? (event.scrollTop < (hideLeaf_height + leafPlane_height) ? (event.scrollTop - hideLeaf_height) : leafPlane_height) : 0) + 'px'
			console.log('leafplane.style.height: ', leafplane.style.height);
			leafplane.style.opacity = (1 - (event.scrollTop > hideLeaf_height ? event.scrollTop - hideLeaf_height : 1) / 120).toFixed(2)
		},
		methods: {
			// cc 返回上一页
			back() {
				uni.navigateBack({
					delta: 1
				}); 
			},
			// cc 获取游戏数据
			getGameData() {
				console.log('game_id', this.game_id);
				this.$api.get('game/detail', {
					game_id: this.game_id,
					client_id: this.$store.state.client_id
				}).then(res => {
					console.log('game_detail:', res)
					
					this.pageData = res.data.data;
					
					if (this.pageData.classify == 5) {
						this.downloadContent = {
							text : '开玩',
							img : '../../../static/images/view/play-game.png'
						}
					} else {
						this.downloadContent = {
							text: '下载',
							img: '../../../static/images/view/downLoad.png'
						}
					}
					
					if (this.pageData.game_task_content != '' && this.pageData.game_task_content != null) {
						this.downloadContent.text = '试玩'
					}
										
					// cc  处理相关视频文件地址
					this.pageData.mp4_url_new = this.$common.setVideoUrl(this.pageData.mp4_url);
					console.log('mp4_url_new:', this.pageData.mp4_url_new)
					this.imageData = this.pageData.image.map(item => {
						if (item.indexOf('http') == 0) {
							return item
						} else {
							item = 'https:' + item
							return item
						}
					})
					
					// cc 获取顶部更多游戏相关游戏数据
					this.getRelatedGameData()
					
					if (res.data.data.comment.length > 0) {
						this.evaluateData = res.data.data.comment[0]
						// console.log(this.evaluateitem)
						if (typeof this.evaluateData.content == 'string') {
							try {
								this.evaluateData.content = JSON.parse(this.evaluateData.content);
								return true;
							} catch (e) {
								return false;
							}
						}
					} else {
						this.evaluateData = null
					}
				})
			},
			// cc 获取更多相关游戏数据
			getRelatedGameData() {
				this.$api.get('game/related_game', {
					cate_id: this.pageData.cate_id,
					tags: 0,
					client_id: this.$store.state.client_id || 4231
				}).then(res => {			
					if (res.data.code == 200) {
						this.relevantData = res.data.data
					}
				})
			},
			// cc 相关游戏更换响应事件
			changeRelatedGame() {
				// cc 判断开关是否打开
				if(!this.isChangeRelevant) {
					// cc 打开开关
					this.isChangeRelevant = true
					
					// cc 获取切换图标 用来翻转动画
					let refreshImg = document.getElementById('refresh')
					
					let rotate = refreshImg.style.rotate.split("d")[0];
					rotate = Number(rotate) + 180
					refreshImg.style.rotate = `${ rotate }deg`
					
					setTimeout(() => {
						refreshImg.style.transition = 'all 600ms'
						this.isChangeRelevant = false // cc 将节流阀开关关闭
					}, 600)
					
					// cc 将相关游戏数据清空
					this.relevantData = null
					this.getRelatedGameData()
				}
			},
			// cc 游戏收藏响应事件
			collectOperation() {
				if (this.$common.isLogin()) {
					this.$api.get('game/check_collect', {
						game_id: this.pageData.game_id,
						status: this.pageData.is_collect == 1 ? 2 : 1,
						client_id: this.$store.state.client_id
					}).then(res => {
						if (res.data.code == 200) {
							uni.showToast({
								title: '操作成功',
								success: () => {
									setTimeout(() => {
										console.log('123321');
										this.getGameData()
									}, 300)
								}
							})
						} else {
							uni.showToast({
								title: res.data.msg,
								icon: 'none',
								success: () => {
									setTimeout(() => {
										uni.navigateTo({
											url: '/pages/my/children/login',
										})
										return false;
									}, 600)
								}
							})
						}
					})
				}
			},
			// cc 轮播图图片点击预览
			previewImage(index, img) {
				console.log('previewImage', index, img);
				this.$common.previewImage(index, img)
			},
			// cc 优惠券页面跳转响应事件
			toCouponPlane(hasCoupon, gameId) {
				if (hasCoupon) {
					this.handleRouter(`/pages/view/gameDetail/children/coupon?gameId=${ gameId }`)
				}
			},
			// cc 获取页面滚动条高度
			// getScrollOffset() {
			// 	if (window.pageXOffset) {
			// 		return {
			// 			x: window.pageXOffset,
			// 			y: window.pageYOffset
			// 		}
			// 	} else {
			// 		return {
			// 			x: document.documentElement.scrollLeft + document.body.scrollLeft,
			// 			y: document.documentElement.scrollTop + document.body.scrollTop
			// 		}
			// 	}
			// },
			// cc 开服信息面板事件
			toServerPlane(hasServer, gameId) {
				if (hasServer) {
					// console.log('scrolloffsetY111', this.getScrollOffset().y) 
					// this.scrollOffsetY = this.getScrollOffset().y
					this.isShowServerPanel = true
				}
			},
			// cc 关闭开服信息面板事件
			closeServerPanel() {
				this.isShowServerPanel = false
				// setTimeout(() => {
				// 	uni.pageScrollTo({
				// 		scrollTop: this.scrollOffsetY,
				// 		duration: 0,
				// 		success: () => {
				// 			console.log('111111');
				// 			console.log('scrolloffsetY222', this.getScrollOffset().y)
				// 			this.scrollOffsetY = 0
				// 		},
				// 		fail: () => {
				// 			console.log('222222');
				// 		}
				// 	});
				// }, 0)
			},
			// 开服信息面板滑动响应事件
			serverScroll(event) {
				this.stopPropagation()
				// event.stopPropagetion()
			},
			preventTouchMove() {},
			// cc 跳转对应的页面
			handleRouter(url) {
				console.log('url', url);
				uni.navigateTo({
					url
				})
			},
			// cc 游戏类型路由跳转
			handleToGameList(type, id, name) {
				uni.setStorage({
					key:'gameHall',
					data: `${type}-${id}-${name}`,
					success: function () {
						console.log('success', `${type}-${id}-${name}`);
					}
				})
				uni.switchTab({
					url: '/pages/gameList/index'
				})
			},
			// cc 游戏下载按钮点击响应
			downloadGame() {
				// window.open(this.pageData.down_url)
				if (this.pageData.classify == 4) {
					window.open(this.pageData.down_url)
				} else if (this.pageData.classify == 5) {
					if (this.$common.isLogin()) {
						let game_url = this.pageData.down_url + "&token=" + this.$store.state.user_token +
							"&link=uniapp_h5&client_id=" + this.$store.state.client_id;
						// let newUrl = this.$common.aesEncrypt(game_url, "aaa");
						console.log('newUrl', game_url);
						// let routeData = this.$router.resolve({
						// 	path: "/pages/view/h5Play/index",
						// 	query: {
						// 		game_url: newUrl
						// 	}
						// })
						
						window.open(game_url)
					}
				}
			},
		},
	}
</script>

<style lang="scss" scoped>
	::v-deep .u-skeleton__wrapper__content {
		justify-content: center;
	}
	
	::v-deep .u-skeleton__wrapper__avatar--square {
		border-radius: 30rpx !important;
	}
	
	::v-deep .uni-video-container {
		border-radius: 40rpx !important;
		overflow: hidden;
	}
	
	::v-deep .uni-video-bar {
		border-radius: 0 0 40rpx 40rpx !important;
	}
	
	.skeletonflexNone {
		flex: none;
	}
	
	.container {
		width: 750rpx;
		height: 100vh;
		position: relative;
	}
	
	.detail {
		position: relative;
		
		&-gameBg {
			width: 750rpx;
			height: 422rpx;
			position: fixed;
			top: 0;
			left: 0;
			// z-index: 10010;
			
			&-img {
				width: 750rpx;
				height: 422rpx;
				// background-size: 750rpx 422rpx;
				transform-origin: center center;
				background-repeat: no-repeat;
				background-size: cover;
				background-position: center bottom;
			}
		}
		
		&-topDetail {
			position: fixed;
			width: 750rpx;
			top: 80rpx;
			box-sizing: border-box;
			height: 80rpx;
			display: flex;
			flex-direction: row;
			padding: 0 32rpx;
			z-index: 1000;
			align-items: center;
			opacity: 0;
			
			&-back {
				width: 34rpx;
				height: 34rpx;
				margin-right: 24rpx;
			}
			
			&-icon {
				width: 80rpx;
				height: 80rpx;
				border-radius: 24rpx;
				margin-right: 24rpx;
			}
			
			&-gameName {
				flex: 1;
				font-size: 36rpx;
				color: #FFFFFF;
				font-weight: 600;
				overflow: hidden;
				text-overflow: ellipsis;
				white-space: nowrap;
			}
			
			&-download {
				position: fixed;
				right: 32rpx;
				top: 99rpx;
				font-size: 26rpx;
				color: #FFFFFF;
				border: 2rpx solid #efefef;
				border-radius: 30rpx;
				padding: 8rpx 32rpx;
				box-sizing: border-box;
				letter-spacing: 6rpx;
				opacity: 0;
			}
		}
		
		&-icon {
			position: fixed;
			width: 66rpx;
			height: 66rpx;
			justify-content: center;
			align-items: center;
			top: 100rpx;
			border-radius: 50%;
			background-color: rgba(28, 28, 28, .5);
			opacity: 1;
			// z-index: 10090;
			
			&-left {
				left: 32rpx;
				background-image: url('@/static/images/back.png');
				background-size: 40rpx 40rpx;
				background-repeat: no-repeat;
				background-position: center;
			}
			
			&-right {
				right: 32rpx;
				background-image: url('@/static/images/more.png');
				background-size: 40rpx 40rpx;
				background-repeat: no-repeat;
				background-position: center;
			}
		}
		
		&-content {
			background-color: #ffffff !important;
			display: flex;
			flex-direction: column;
			box-sizing: border-box;
			position: relative;
			// z-index: 10095;
			
			&-blur {
				width: 750rpx;
				height: 180rpx;
				overflow: hidden;
				position: relative !important;
				// margin-bottom: 48rpx;
				
				&-before {
					width: 750rpx;
					height: 180rpx;
					// position: absolute;
					// bottom: 0;
					// left: 0;
					background-color: rgba(28, 28, 28, 1);
				}
				
				&-img {
					width: 1000rpx;
					height: 200rpx;
					filter: blur(25rpx);
					background-position: center;
					background-size: 1000rpx 200rpx;
					position: absolute;
					top: 0;
					left: -125rpx;
					transform: scale(1.2);
				}
				
				&-after {
					width: 750rpx;
					height: 180rpx;
					position: absolute;
					bottom: 0;
					left: 0;
					background-color: rgba(244, 244, 244, .3);
				}
				
				&-normal {
					width: 750rpx;
					height: 180rpx;
					position: absolute;
					bottom: 0;
					left: 0;
					padding: 16rpx 38rpx 16rpx 32rpx;
					box-sizing: border-box;
					display: flex;
					flex-direction: row;
					align-items: center;
					justify-content: space-between;
					opacity: 0;
					
					&-icon {
						width: 136rpx;
						height: 136rpx;
					}
					
					&-content {
						flex: 1;
						display: flex;
						flex-direction: column;
						margin-left: 24rpx;
						padding: 16rpx 0;
						justify-content: space-between;
						height: 136rpx;
						box-sizing: border-box;
						color: #FFFFFF;
						
						&-title {
							font-size: 44rpx;
							font-weight: 600;
							overflow: hidden;
							max-width: 400rpx;
							text-overflow: ellipsis;
							white-space: nowrap;
						}
						
						&-tags {
							display: flex;
							flex-direction: row;
							font-size: 24rpx;
							font-family: PingFang SC;
							font-weight: 400;
							letter-spacing: 2rpx;
							
							&-gc::after {
								content: '|';
								margin: 0 20rpx;
							}
						}
					}
				
					&-grade {
						width: 96rpx;
						height: 96rpx;
						border-radius: 32rpx;
						border: 2rpx solid #FFFFFF;
						box-sizing: border-box;
						justify-content: center;
						align-items: center;
						margin-bottom: 4rpx;
						display: flex;
						flex-direction: column;
						align-items: center;
						justify-content: space-between;
						color: #FFFFFF;
						font-family: PingFang SC;
						
						&-score {
							font-size: 44rpx;
							font-weight: 600;
						}
						
						&-title {
							font-size: 24rpx;
							font-weight: 400;
							line-height: 34rpx;
						}
					}
				}
			}
			
			&-leafPlane {
				background-color: #FFFFFF;
				height: 312rpx;
				position: relative !important;
			}
			
			&-welfare {
				width: 750rpx;
				height: 200rpx;
				display: flex;
				flex-direction: row;
				align-items: center;
				justify-content: space-between;
				padding: 48rpx 32rpx 56rpx;
				box-sizing: border-box;
				position: relative !important;
				// margin-bottom: 56rpx;
				
				&-coupon {
					background-color: #F4F4F4;
					border-radius: 32rpx;
					width: 208rpx;
					height: 100%;
					padding: 28rpx 24rpx;
					box-sizing: border-box;
					display: flex;
					flex-direction: row;
					justify-content: space-between;
					align-items: center;
					
					&-img {
						width: 48rpx;
						height: 32rpx;
					}
					
					&-text {
						font-size: 28rpx;
						color: #666666;
						line-height: 40rpx;
						font-family: PingFang SC;
						font-weight: 500;
					}
				}
				
				&-server {
					background-color: #F4F4F4;
					border-radius: 32rpx;
					width: 302rpx;
					height: 100%;
					padding: 10rpx 24rpx;
					box-sizing: border-box;
					display: flex;
					flex-direction: row;
					justify-content: space-between;
					align-items: center;
					font-family: PingFang SC;
					font-weight: 500;
					
					&-img {
						width: 48rpx;
						height: 32rpx;
					}
					
					&-content {
						display: flex;
						flex-direction: column;
						align-items: center;
						justify-content: space-between;
						
						&-server {
							font-size: 20rpx;
							color: #C1C1C1;
						}
						
						&-timer {
							font-size: 28rpx;
							color: #666666;
							font-weight: 500;
						}
					}
					
					&-text {
						width: 254rpx;
						text-align: center;
						font-size: 28rpx;
						color: #666666;
					}
					
					&-right {
						width: 16rpx;
						height: 24rpx;
					}
				}
				
				&-discount {
					background-size: 96rpx 96rpx;
					width: 96rpx;
					height: 96rpx;
					padding: 28rpx 0rpx;
					box-sizing: border-box;
					display: flex;
					flex-direction: row;
					justify-content: space-between;
					align-items: center;
					font-family: PingFang SC;
					font-weight: 500;
					color: #FFFFFF;
					
					&-text {
						margin-left: 12rpx;
						font-weight: 500;
						font-size: 30rpx;
						letter-spacing: 2rpx;
						
						&-noDiscount {
							font-weight: 500;
							width: 96rpx;
							text-align: center;
							font-size: 24rpx;
							letter-spacing: 1rpx;
						}
					}
				
					&-littleText {
						margin-right: 12rpx;
						font-size: 24rpx;
						transform-origin: center center;
						transform: scale(0.8);
						align-self: flex-end;
					}
				}
			}
		
			&-download {
				position: relative !important;
				width: 750rpx;
				height: 104rpx;
				padding: 0 32rpx 0rpx;
				box-sizing: border-box;
				// margin-bottom: 64rpx;
				
				&-btn {
					width: 686rpx;
					height: 80rpx;
					display: flex;
					position: relative;
					flex-direction: row;
					border: 2rpx solid #E4E4E4;
					border-radius: 42rpx;;
					align-items: center;
					justify-content: center;
					
					&-img {
						width: 36rpx;
						height: 36rpx;
						margin-right: 24rpx;
					}
					
					&-text {
						font-size: 32rpx;
						color: #FF5927;
						font-family: PingFang SC;
						font-weight: 600;
						letter-spacing: 20rpx;
					}
					
					&-tips {
						display: block;
						position: absolute;
						right: 40rpx;
						top: -18rpx;
						height: 38rpx;
						background-color: #FFFFFF;
						text-align: center;
						color: #FF5927;
						font-size: 20rpx;
						line-height: 38rpx;
						padding: 0 6rpx;
					}
				}
			}
			
			&-welfareNext {
				width: 750rpx;
				height: 126rpx;
				display: flex;
				flex-direction: row;
				justify-content: space-between;
				align-content: center;
				box-sizing: border-box;
				padding: 40rpx 54rpx 40rpx;
				border-bottom: 2rpx solid #EFEFEF;
				position: relative !important;
				background-color: #FFFFFF;
				// margin-bottom: 40rpx;
				
				&-line {
					width: 2rpx;
					height: 44rpx;
					background-color: #C1C1C1;
				}
				
				&-box {
					height: 44rpx;
					display: flex;
					flex-direction: row;
					justify-content: space-between;
					align-items: center;
					
					&-img {
						height: 32rpx;
						margin-right: 16rpx;
					}
					
					&-text {
						color: #666666;
						font-size: 32rpx;
						font-family: PingFang SC;
						font-weight: 500;
						letter-spacing: 6rpx;
					}
				}
			}
			
			&-scrollBar {
				width: 750rpx;
				height: 480rpx;
				padding: 40rpx 32rpx 72rpx;
				box-sizing: border-box;
				white-space: nowrap;
				overflow: hidden;
				
				::-webkit-scrollbar {
					display: none;
				}
				
				&-item {
					display: inline-block;
					width: 200rpx;
					height: 368rpx;
					margin-right: 24rpx;
					border-radius: 40rpx;
					
					&:last-child {
						margin-right: 0rpx;
					}
				}
				
				&-video {
					width: 686rpx;
					height: 368rpx;
					border-radius: 40rpx;
					margin-right: 24rpx;
					overflow: hidden !important;
				}
			}
		
			&-detail {
				width: 750rpx;
				padding: 0 32rpx 72rpx;
				box-sizing: border-box;
				
				&-title {
					display: flex;
					flex-direction: row;
					justify-content: space-between;
					align-items: center;
					font-size: 28rpx;
					height: 56rpx;
					color: #666666;
					font-family: PingFang SC;
					font-weight: 400;
					letter-spacing: 2px;
					margin-bottom: 48rpx;
					
					&-left {
						font-size: 40rpx;
						color: #000000;
						font-weight: 600;
					}
				}
				
				&-tags {
					display: flex;
					flex-direction: row;
					align-items: center;
					height: 48rpx;
					margin-bottom: 26rpx;
					
					&-item,
					&-itemFirst {
						margin-right: 24rpx;
						padding: 0 16rpx 0 18rpx;
						display: flex;
						flex-direction: row;
						align-items: center;
						height: 48rpx;
						background: #D0F2FE;
						border-radius: 28rpx;
						color: #19BFFF;
						font-size: 24rpx;
						font-family: PingFang SC;
						
						&-right {
							width: 8rpx;
							height: 12rpx;
							margin-left: 16rpx;
						}
					}
					
					&-item {
						background: #F4F4F4;
						color: #666666;
					}
				}
				
				&-content {
					overflow: hidden;
					text-overflow: ellipsis;
					display: -webkit-box;
					-webkit-box-orient: vertical;
					-webkit-line-clamp: 3;
					line-height: 44rpx;
					white-space: normal;
					font-size: 28rpx;
					font-family: PingFang SC;
					color: #1C1C1C;
				}
			}
			
			&-evaluate {
				width: 750rpx;
				padding: 0 32rpx 72rpx;
				box-sizing: border-box;
				
				&-title {
					display: flex;
					flex-direction: row;
					justify-content: space-between;
					align-items: center;
					font-size: 28rpx;
					height: 56rpx;
					color: #666666;
					font-family: PingFang SC;
					font-weight: 400;
					letter-spacing: 2px;
					margin-bottom: 48rpx;
					
					&-left {
						font-size: 40rpx;
						color: #000000;
						font-weight: 600;
					}
				}
				
				&-content {
					height: 168rpx;
					display: flex;
					flex-direction: row;
					justify-content: space-between;
					margin-bottom: 44rpx;
					
					&-left {
						display: flex;
						flex-direction: column;
						align-items: center;
						align-self: flex-start;
						
						&-score {
							font-size: 80rpx;
							line-height: 112rpx;
							color: #FF5927;
							font-family: PingFang SC;
							font-weight: 600;
						}
						
						&-text {
							font-size: 24rpx;
							font-family: PingFang SC;
							font-weight: 400;
							color: #C1C1C1;
							letter-spacing: 2rpx;
							margin-top: 8rpx;
						}
					}
					
					&-right {
						display: flex;
						flex-direction: column;
						align-items: flex-end;
						align-self: flex-end;
						
						&-item {
							display: flex;
							flex-direction: row;
							justify-content: flex-end;
							align-items: center;
							margin-top: 8rpx;
						}
					}
				}
			
				&-comment {
					
					&-total {
						font-size: 28rpx;
						font-family: PingFang SC;
						font-weight: 400;
						color: #666666;
						letter-spacing: 2rpx;
					}
					
					&-first {
						margin-top: 48rpx;
						
						&-playerInfo {
							display: flex;
							flex-direction: row;
							align-items: center;
							
							&-info {
								font-family: PingFang SC;
								margin-left: 24rpx;
								
								&-name {
									font-size: 28rpx;
									font-weight: 600;
									color: #1C1C1C;
									letter-spacing: 4rpx;
								}
								
								&-time {
									padding-top: 10rpx;
									font-size: 20rpx;
									font-weight: 400;
									color: #666666;
								}
							}
						}
						
						&-evaluate {
							display: flex;
							flex-direction: row;
							align-items: center;
							padding-top: 24rpx;
							
							&-time {
								padding-left: 16rpx;
								font-size: 20rpx;
								font-family: PingFang SC;
								font-weight: 400;
								color: #666666;
								letter-spacing: 2rpx;
							}
						}
					
						&-content {
							padding-top: 28rpx;
							
							&-text {
								font-size: 28rpx;
								font-family: PingFang SC;
								font-weight: 600;
								line-height: 50rpx;
								color: #666666;
								overflow: hidden;
								text-overflow: ellipsis;
								display: -webkit-box;
								-webkit-box-orient: vertical;
								-webkit-line-clamp: 2;
								white-space: normal;
								letter-spacing: 2rpx;
								margin-bottom: 20rpx; 
							}
							
							&-img {
								border-radius: 20rpx;
								margin-bottom: 20rpx; 
								width: 686rpx;
							}
						}
						
						&-zan {
							display: flex;
							flex-direction: row;
							align-items: center;
							font-size: 24rpx;
							font-family: PingFang SC;
							font-weight: 400;
							color: #666666;
							letter-spacing: 2rpx;
							
							& > *:nth-child(n) {
								margin-right: 16rpx;
							}
							
							& > *:nth-child(2n) {
								margin-right: 56rpx;
							}
							
							& > *:nth-child(5) {
								width: 24rpx;
								height: 24rpx;
							}
						}
						
						&-reply {
							margin-top: 44rpx;
							padding: 16rpx;
							width: 686rpx;
							background-color: #F4F4F4;
							border-radius: 24rpx;
							font-size: 24rpx;
							font-family: PingFang SC;
							font-weight: 400;
							line-height: 34rpx;
							letter-spacing: 2rpx;
							box-sizing: border-box;
							
							&-item {
								display: flex;
								flex-direction: row;
								align-items: center;
								margin-bottom: 8rpx;
								
								&-name {
									color: #121212;
								}
								
								&-content { 
									color: #666666;
								}
							}
							
							&-more {
								display: inline-block;
								padding-top: 16rpx;
								color: #C1C1C1;
							}
						}
						
						&-btn {
							width: 686rpx;
							margin-top: 48rpx;
							box-sizing: border-box;
							border: 2rpx solid #E4E4E4;
							border-radius: 42rpx;
							padding: 20rpx 0 22rpx;
							font-size: 28rpx;
							font-family: PingFang SC;
							font-weight: 600;
							line-height: 40rpx;
							color: #FF5927;
							letter-spacing: 4rpx;
							text-align: center;
						}
					}
				}
			}
			
			&-relatedGame {
				width: 750rpx;
				padding: 0 32rpx;
				box-sizing: border-box;
				
				&-title {
					display: flex;
					flex-direction: row;
					justify-content: space-between;
					align-items: center;
					font-size: 28rpx;
					height: 56rpx;
					color: #666666;
					font-family: PingFang SC;
					font-weight: 400;
					letter-spacing: 2px;
					
					&-left {
						font-size: 40rpx;
						color: #000000;
						font-weight: 600;
					}
					
					&-right {
						display: flex;
						flex-direction: row;
						align-items: center;
						
						&-img {
							width: 26rpx;
							height: 26rpx;
							margin-right: 8rpx;
							transition: all 600ms;
						}
					}
				}
				
				&-gamePlane {
					padding: 40rpx 16rpx 140rpx;
					height: 508rpx;
					display: flex;
					flex-direction: row;
					flex-wrap: wrap;
					justify-content: space-between;
				}
			}
		}
	}
	
	.serverPanel {
		background-color: transparent;
		width: 100vw;
		height: 100vh;
		position: fixed;
		left: 0;
		bottom: 0;
		z-index: 10099;
		
		&-layout {
			width: 750rpx;
			height: 1100rpx;
			background-color: #FFFFFF;
			border-top-left-radius: 40rpx;
			border-top-right-radius: 40rpx;
			padding: 42rpx 32rpx 0rpx;
			position: relative;
			box-sizing: border-box;
			
			&-title {
				display: inline-block;
				margin: 0 auto;
				width: 100%;
				text-align: center;
				font-size: 32rpx;
				font-family: PingFang SC;
				font-weight: 600;
				color: #000000;
				letter-spacing: 4rpx;
			}
			
			&-close {
				width: 48rpx;
				height: 48rpx;
				position: absolute;
				top: 40rpx;
				right: 32rpx;
			}
			
			&-scroll {
				height: 100%;
				padding-top: 58rpx;
				
				::-webkit-scrollbar {
					display: none;
				}
				
				&-content {
					display: flex;
					flex-direction: row;
					flex-wrap: wrap;
					justify-content: space-between;
					
					&-item {
						width: 326rpx;
						height: 144rpx;
						box-sizing: border-box;
						display: flex;
						flex-direction: column;
						align-items: center;
						justify-content: center;
						font-size: 28rpx;
						font-family: PingFang SC;
						font-weight: 500;
						color: #1C1C1C;
						letter-spacing: 4rpx;
						background-color: #F8F8F8;
						border-radius: 40rpx;
						
						&:nth-child(n + 3) {
							margin-top: 32rpx;
						}
						
						&:last-child {
							margin-bottom: 120rpx;
						}
						
						&-top {
							font-size: 24rpx;
							font-weight: 400;
							color: #666666;
							margin-bottom: 6rpx;
						}
						
						&-active {
							color: #FF5927 !important;
						}
					}
				}
			}
		}
	}
</style>