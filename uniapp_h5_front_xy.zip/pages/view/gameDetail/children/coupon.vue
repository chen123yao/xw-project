<template>
	<!-- cc 游戏详情优惠券信息页面 -->
	<view class="container coupon">
		<!-- cc 优惠券页面顶部标题 -->
		<view class="coupon-topTitle">
			<view class="coupon-topTitle-box">
				<image class="coupon-topTitle-box-left" src="@/static/images/left.png" mode="heightFix" @click="back" />
				<text class="coupon-topTitle-box-text">优惠券</text>
			</view>
		</view>
		
		<!-- cc 是否请求数据中 显示loading界面 -->
		<u-loading-page class="coupon-loading" :loading="!couponData" icon-size="72" font-size="30" loading-mode="spinner"></u-loading-page>
		
		<!-- cc 优惠券页面内容显示区域 -->
		<view v-if="couponData && couponData.coupons.list.length" class="coupon-content">
			<view class="coupon-content-item" v-for="(item, index) in couponData.coupons.list" :key="'coupon' + index">
				
				<!-- cc 单个优惠券左侧金额显示 -->
				<view class="coupon-content-item-left">
					 <view class="coupon-content-item-left-money">{{ item.coupons_amount }}</view>
					 <text>{{ item.title }}</text>
				</view>
				
				<!-- cc 单个优惠券右侧时间信息显示 -->
				<view class="coupon-content-item-right">
					<!-- cc 右侧时间文字内容显示 -->
					<view class="coupon-content-item-right-top">
						<!-- cc 终止时间 -->
						<view>
							<view class="coupon-content-item-right-top-time">有效期至：{{ item.get_time_end | dateFormat('yyyy-MM-dd') }}</view>
							<view>领取时间：{{ item.get_time_begin | dateFormat('yyyy-MM-dd') }}后</view>
						</view>
						<!-- cc 领取、已领取按钮 -->
						<view v-if="item.have_got" class="coupon-content-item-right-top-btn coupon-content-item-right-top-btn-active">已领取</view>
						<view v-else class="coupon-content-item-right-top-btn" @click="handleClick(item.id, item.period_type)">领取</view>
					</view>
					<!-- cc 该优惠券适用于那个游戏 -->
					<text>适用于《{{ couponData.gamename }}》</text>
				</view>
			</view>
		</view>
		
		<u-loadmore v-if="couponData" bg-color="transparent" height="30" marginTop="0" fontSize="24" marginBottom="32" status="nomore" loadingIcon="spinner" />
	</view>
</template>

<script>
	export default {
		data() {
			return {
				// cc 获取优惠券数据参数
				params: {
					page: 1,
					offset: 20,
					status: 1,
					game_id: 0
				},
				// cc 优惠券数据
				couponData: null
			}
		},
		onLoad(option){
			this.params.game_id = option.gameId
			this.getCouponData()
		},
		methods: {
			// cc 获取优惠券数据
			getCouponData() {
				this.$api.get('game/detail', {
					...this.params
				}).then(res => {
					if (res.data.code == 200) {
						this.couponData = res.data.data	
					} else {
						// cc 加载失败
						uni.showToast({
							title: "加载失败",
							icon: "none"
						})
					}
				})
			},
			// cc 点击领取
			handleClick(id, period_type) {
				if(this.$common.isLogin()){
					this.$api.get("user/coupons/add", {
						coupon_id: id,
						period_type
					}).then(res => {
						uni.showToast({
							icon: "none",
							title: res.data.msg
						})
						this.getCouponData()
					})
				}
			},
			// cc 返回上一级页面
			back() {
				uni.navigateBack({
					delta: 1
				});
			}
		}
	}
</script>

<style lang="scss" scoped>
	.container { 
		background-color: #FFFFFF;
		width: 750rpx;
		height: 100vh;
	}
	
	.coupon {
		
		&-loading {
			width: 750rpx;
			top: 176rpx !important;
		}
		
		&-topTitle {
			position: sticky;
			// background-color: #FFFFFF;
			background: linear-gradient(to bottom, #CCCCCC, #FFFFFF env(safe-area-inset-top));
			top: 0;
			width: 750rpx;
			height: 176rpx;
			padding-left: 34rpx;
			padding-bottom: 16rpx;
			box-sizing: border-box;
			display: flex;
			flex-direction: column;
			justify-content: flex-end;
			box-shadow: 0rpx 0rpx 12rpx rgba(0, 0, 0, 0.16);
			
			&-box {
				box-sizing: border-box;
				display: flex;
				flex-direction: row;
				align-items: center;
				
				&-left {
					// width: 22rpx;
					height: 34rpx;
				}
				
				&-text {
					margin-left: 48rpx;
					font-size: 40rpx;
					line-height: 56rpx;
					font-family: PingFang SC;
					font-weight: 600;
					color: #1C1C1C;
				}
			}
		}
		
		&-content {
			width: 750rpx;
			padding: 48rpx 32rpx 0;
			box-sizing: border-box;
			
			&-item {
				display: flex;
				flex-direction: row;
				height: 162rpx;
				box-sizing: border-box;
				margin-bottom: 48rpx;
				font-family: PingFang SC;
				font-size: 20rpx;
				
				&-left {
					width: 190rpx;
					height: 100%;
					padding: 24rpx 0;
					box-sizing: border-box;
					background-color: #E9E9E9; 
					border-radius: 40rpx 0rpx 0rpx 40rpx;
					display: flex;
					flex-direction: column;
					align-items: center;
					justify-content: space-between;
					color: #666666;
					font-weight: 500;
					
					&-money {
						max-width: 190rpx;
						font-size: 60rpx;
						color: #1C1C1C;
						line-height: 82rpx;
						font-weight: 600;
						overflow: hidden;
						text-overflow: ellipsis;
						white-space: nowrap;
						letter-spacing: 0;
					}
				}
				
				&-right {
					flex: 1;
					height: 100%;
					padding: 16rpx 24rpx;
					box-sizing: border-box;
					background-color: #F8F8F8;
					border-radius: 0rpx 40rpx 40rpx 0rpx;
					display: flex;
					flex-direction: column;
					justify-content: space-between;
					font-weight: 400;
					color: #C1C1C1;
					letter-spacing: 4rpx;
					
					&-top {
						width: 100%;
						display: flex;
						flex-direction: row;
						justify-content: space-between;
						padding-bottom: 16rpx;
						border-bottom: 1rpx dashed #C1C1C1;
						align-items: flex-start;
						
						&-time {
							margin-bottom: 8rpx;
							font-size: 24rpx;
							color: #666666;
						}
						
						&-btn {
							margin-top: 8rpx;
							font-size: 24rpx;
							background-color: #FFFFFF;
							border-radius: 28rpx;
							width: 104rpx;
							height: 48rpx;
							line-height: 48rpx;
							text-align: center;
							font-weight: 500;
							color: #FF5927;
							box-sizing: border-box;
							border: 2rpx solid #E4E4E4;
							
							&-active {
								background-color: #dbdbdb;
								color: #FFFFFF;
								border: none;
							}
						}
					}
				}
			}
		}
	}
</style>