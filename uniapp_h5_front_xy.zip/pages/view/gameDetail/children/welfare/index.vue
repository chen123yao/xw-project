<template>
	<!-- cc 游戏详情福利页面 -->
	<view class="container welfare">
		<!-- cc 游戏详情福利页面顶部标题 -->
		<view class="welfare-topTitle">
			
			<view class="welfare-topTitle-blur">
				<view class="welfare-topTitle-blur-before"></view>
				<view v-if="welfareData" class="welfare-topTitle-blur-img" blurEffect="light" :style="{ 'backgroundImage': 'url(' + welfareData.app_hot_image + ')' }"></view>
				<view class="welfare-topTitle-blur-after"></view>
			</view>
			
			<view class="welfare-topTitle-center">
				<view class="welfare-topTitle-center-back" @click="back"></view>
				<view class="welfare-topTitle-center-box">
					<image v-if="welfareData" class="welfare-topTitle-center-box-icon" :src="welfareData.new_icon || welfareData.icon" mode="scaleToFill" />
					<view v-if="welfareData" class="welfare-topTitle-center-box-text">
						<text class="welfare-topTitle-center-box-text-name">{{ welfareData.gamename }}</text>
						<text class="welfare-topTitle-center-box-text-tag">{{ (welfareData.gc_id && (welfareData.gc_id + '出品 | ')) + welfareData.popularity_cnt + '人在玩' }}</text>
					</view> 
				</view>
			</view>
		</view>
		
		<!-- cc 是否请求数据中 显示loading界面 -->
		<u-loading-page class="welfare-loading" :loading="!welfareData" icon-size="72" font-size="30" loading-mode="spinner"></u-loading-page>
		
		<!-- cc 游戏详情福利页面内容显示区域 -->
		<view v-if="welfareData" class="welfare-content">
			<!-- cc 福利页面内容区tab栏 -->
			<u-tabs id="titleList" :list="titleList" :duration="200" :lineColor="lineColor" :activeStyle="activeStyle" :inactiveStyle="inactiveStyle" lineWidth="48rpx" lineHeight="4rpx" @change="(event) => {currentPage = event.index, isReachBottom = false}"></u-tabs>
			<view class="welfare-content-swiper">
				<!-- cc 礼包 -->
				<gift v-if="currentPage == 0" :giftData="welfareData.gift" @refreshGift="getWelfareData"></gift>
				<!-- cc 游戏福利 -->
				<welfare v-else-if="currentPage == 1" :welfareData="welfareData.post.activity"></welfare>
				<!-- cc 返利 -->
				<rebate v-else-if="currentPage == 2" :rebateData="welfareData.post.rebate"></rebate>
				<!-- cc VIP表 -->
				<vip v-else-if="currentPage == 3" :vipData="welfareData.post.viptable"></vip>
			</view>
		</view>
	</view>
</template>

<script>
	import gift from "./components/gift.vue"
	import welfare from "./components/welfare.vue"
	import rebate from "./components/rebate.vue"
	import vip from "./components/vip.vue"
	
	export default {
		// cc 引入子组件
		components: {
			gift, // 礼包
			welfare, // 游戏福利
			rebate, // 返利
			vip // VIP表
		},
		data() {
			return {
				// cc 游戏ID
				game_id: 0,
				// cc 游戏详情福利页面数据
				welfareData: null,
				// cc 是否加载中 默认false
				isLoading: false,
				// cc loadmore状态
				loadingStatus: 'loading',
				// cc 当前页面下标
				currentPage: 0,
				// cc 游戏福利tab list
				titleList: [{
						id: 0,
						name: '礼包'
					},
					{
						id: 1,
						name: '游戏福利'
					},
					{
						id: 2,
						name: '返利'
					},
					{
						id: 3,
						name: 'VIP表'
					}
				],
				// cc tabList 样式
				lineColor: '#FF5927',
				activeStyle: { color: '#1C1C1C', fontSize: '36rpx', fontWeight: '600' },
				inactiveStyle: { color: '#666666', fontSize: '32rpx', fontWeight: '400' },
			}
		},
		onLoad(option){
			this.game_id = option.gameId
			
			// cc 获取福利数据
			this.getWelfareData()
		},
		methods: {
			// cc 返回上一级页面
			back() {
				uni.navigateBack({
					delta: 1
				});
			},
			// cc 获取福利页面数据
			getWelfareData() {
				console.log('refreshGift');
				this.$api.get("/game/detail", {
					game_id: this.game_id
				}).then(res => {
					this.welfareData = res.data.data
					console.log('welfareData', this.welfareData)
				})
			}
		}
	}
</script>

<style lang="scss" scoped>
	::v-deep .u-tabs__wrapper__nav__item {
		padding: 0 32rpx;
		
		&:first-child {
			padding-left: 0rpx !important;
		}
	}
	
	.container { 
		background-color: #FFFFFF;
		width: 750rpx;
		height: 100vh;
		padding-bottom: 24rpx;
	}
	
	.welfare {
		
		&-loading {
			width: 750rpx;
			top: 100rpx !important;
		}
		
		&-topTitle {
			position: fixed;
			// background-color: #FFFFFF;
			background: linear-gradient(to bottom, #CCCCCC, #FFFFFF env(safe-area-inset-top));
			// z-index: 999;
			top: 0;
			width: 750rpx;
			height: 482rpx;
			overflow: hidden;
			
			&-blur {
				width: 750rpx;
				height: 482rpx;
				overflow: hidden;
				position: relative !important;
				
				&-before {
					width: 750rpx;
					height: 482rpx;
					position: absolute;
					bottom: 0;
					left: 0;
					background-color: rgba(28, 28, 28, 1);
				}
				
				&-img {
					width: 1000rpx;
					height: 500rpx;
					filter: blur(25rpx);
					background-position: center;
					background-size: 1000rpx 500rpx;
					position: absolute;
					top: 0;
					left: -125rpx;
					transform: scale(1.2);
				}
				
				&-after {
					width: 750rpx;
					height: 482rpx;
					position: absolute;
					bottom: 0;
					left: 0;
					background-color: rgba(244, 244, 244, .3);
				}
			}
			
			&-center {
				position: absolute;
				top: 0;
				left: 0;
				width: 750rpx;
				height: 482rpx;
				padding: 100rpx 32rpx 90rpx;
				box-sizing: border-box;
				display: flex;
				flex-direction: column;
				justify-content: space-between;
				align-items: flex-start;
				
				&-back {
					width: 66rpx;
					height: 66rpx;
					border-radius: 50%;
					background-color: rgba(28, 28, 28, .5);
					opacity: 1;
					background-image: url('@/static/images/back.png');
					background-size: 40rpx 40rpx;
					background-repeat: no-repeat;
					background-position: center;
				}
				
				&-box {
					width: 100%;
					box-sizing: border-box;
					display: flex;
					flex-direction: row;
					align-items: center;
					
					&-icon {
						height: 176rpx;
						width: 176rpx;
						border-radius: 40rpx;
					}
					
					&-text {
						flex: 1;
						box-sizing: border-box;
						display: flex;
						flex-direction: column;
						height: 104rpx;
						justify-content: space-between;
						align-items: flex-start;
						margin-left: 24rpx;
						font-size: 44rpx;
						font-family: PingFang SC;
						font-weight: 600;
						color: #FFFFFF;
						letter-spacing: 4rpx;
						overflow: hidden;
						
						&-name {
							width: 100%;
							overflow: hidden;
							white-space: nowrap;
							text-overflow: ellipsis;
						}
						
						&-tag {
							font-size: 24rpx;
							font-weight: 400;
						}
					}
				}
			}
		}
		
		&-content {
			width: 750rpx;
			position: fixed;
			top: 432rpx;
			left: 0;
			// z-index: 1000;
			padding: 32rpx;
			height: calc(100vh - 432rpx);
			box-sizing: border-box;
			background-color: #FFFFFF;
			border-top-left-radius: 40rpx;
			border-top-right-radius: 40rpx;
			font-family: PingFang SC;
			display: flex;
			flex-direction: column;
			
			&-swiper {
				flex: 1;
			}
		}
	}
</style>