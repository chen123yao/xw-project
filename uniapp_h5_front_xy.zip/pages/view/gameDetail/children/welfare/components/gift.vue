<template>
	<view class="gift">
		<!-- cc 礼物scroll -->
		<scroll-view id="scroll" class="gift-scroll" scroll-y v-if="giftData.length">
			<view class="gift-scroll-item" v-for="(item, index) in giftData" :key="'gift' + index">
				<view class="gift-scroll-item-top">
					<view class="gift-scroll-item-top-left">
						<image class="gift-scroll-item-top-left-icon" :src="item.icon" mode="scaleToFill"></image>
						<view class="gift-scroll-item-top-left-box">
							<view style="margin-bottom: 24rpx;">
								<text>{{ item.gift_name }}</text>
								<text>（</text>
								<text style="color: #FF5927;">{{ item.remain_cnt }}</text>
								<text>/</text>
								<text>{{ item.total_cnt}}</text>
								<text>）</text>
							</view>
							<u-line-progress :percentage="Math.floor(item.remain_cnt / item.total_cnt * 100)" :height="8" :showText="false" activeColor="#FF5927" inactiveColor="#EFEFEF"></u-line-progress>
						</view>
					</view>
					<view class="gift-scroll-item-top-btn" :style="{color: item.is_get_gift ? '#999' : '#FF5927' }" @click="getGift(item.gift_id, item.is_get_gift)">{{ item.is_get_gift ? '已领取' : '领取' }}</view>
				</view>
				<text class="gift-scroll-item-text">{{ item.content }}</text>
			</view>
			
			<u-loadmore v-if="giftData.length" bg-color="transparent" height="60" marginTop="0" fontSize="24" marginBottom="32" status="nomore" loadingIcon="spinner" />
		</scroll-view>
		
		<u-empty v-else class="gift-scroll-empty"
			:width="400" :height="400" :textSize="32" :marginTop="200" text="暂时找不到，去看看别的~" mode="data" icon="http://cdn.uviewui.com/uview/empty/data.png"></u-empty>
	</view>
</template>

<script>
	
	export default {
		props:{
			// cc 游戏礼包数据
			giftData: {
				type: Array,
				default: null
			}
		},
		data() {
			return {
				// cc 是否处于领取状态 默认false
				giftStatus: false
			}
		},
		// 组件挂载到实例生命周期函数
		mounted() {
			console.log('gift-mounted')
			// cc 动态设置scroll高度
			this.$nextTick(function() {
				document.getElementById('scroll').style.height = `${uni.getSystemInfoSync().windowHeight - (496 / (750 / uni.getSystemInfoSync().windowWidth)) - document.getElementById('titleList').offsetHeight}px`
			})
		},
		methods: {
			// 领取礼包
			getGift(gift_id, status) {
				console.log('getGift', gift_id, status, this.giftStatus);
				if (this.$common.isLogin()){
					if (!this.giftStatus) {
						this.giftStatus = true
						
						setTimeout(() => {
							this.giftStatus = false
						}, 1000)
								
						if (!status) {
							this.$api.get("user/gift/add", {
								gift_id,
							}).then(res => {
								if(res.data.code==200){
									uni.showToast({
										title: "领取成功",
										icon:'none',
										success: () => {
											setTimeout(() => {
												this.$emit('refreshGift',true)
											}, 200)
										}
									})
								} else {
									uni.showToast({
										title: res.data.msg,
										icon:'none',
										success: () => {
											setTimeout(() => {
												uni.navigateTo({
													url:'/pages/my/children/login'
												})
											}, 500)
										}
									})
								}
							})
								
						}
					}
				}
			}
		}
	}
</script>

<style lang="scss" scoped>
	.gift {
		width: 100%;
		height: 100%;
		
		&-scroll {
			width: 100%;
			// height: 100%;
			padding-top: 16rpx;
			box-sizing: border-box;
			background-color: #ffffff;
			
			::-webkit-scrollbar {
				display: none;
			}
			
			&-item {
				width: 100%;
				padding: 40rpx 0;
				border-bottom: 2rpx solid #EFEFEF;
				
				&-top {
					display: flex;
					flex-direction: row;
					justify-content: space-between;
					align-items: center;
					margin-bottom: 16rpx;
					
					&-left {
						display: flex;
						flex-direction: row;
						align-items: center;
						margin-right: 110rpx;
						flex: 1;
						
						&-icon {
							width: 120rpx;
							height: 120rpx;
							border-radius: 32rpx;
						}
						
						&-box {
							flex: 1;
							box-sizing: border-box;
							padding: 0 24rpx;
							display: flex;
							flex-direction: column;
							justify-content: center;
							color: #000000;
							font-size: 28rpx;
							font-family: PingFang SC;
							font-weight: 500;
						}
					}
					
					&-btn {
						width: 120rpx;
						padding: 6rpx 0;
						text-align: center;
						background-color: #FFFFFF;
						border-radius: 32rpx;
						border: 2rpx solid #E4E4E4;
						box-sizing: border-box;
						color: #FF5927;
					}
				}
				
				&-text {
					width: 100%;
					font-size: 24rpx;
					color: #666666;
					font-family: PingFang SC;
					font-weight: 400;
					overflow: hidden;
					text-overflow: ellipsis;
					white-space: nowrap;
				}
			}
		}
	}
</style>