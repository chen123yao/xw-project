<template>
	<view class="rebate">
		<!-- cc 返利scroll -->
		<scroll-view id="scroll" class="rebate-scroll" scroll-y v-if="rebateData.count">
			<view class="rebate-scroll-title"> 
				<text>{{ rebateData.list[0].title }}</text>
				<view class="rebate-scroll-title-btn" @click="handleRouter">返利申请</view>
			</view>
			
			<view class="rebate-scroll-content">
			  <view class="rebate-scroll-content-time">{{ rebateData.list[0].pub_time }}</view>
			  <text class="rebate-scroll-content-text">{{ rebateData.list[0].content.replace(/<[^<>]+>/g,'') }}</text>
			</view>
			<!-- <u-loadmore v-if="rebateData.count" bg-color="transparent" height="60" marginTop="0" fontSize="24" marginBottom="32" status="nomore" loadingIcon="spinner" /> -->
		</scroll-view>
		
		<u-empty v-else class="gift-scroll-empty"
			:width="400" :height="400" :textSize="32" :marginTop="200" text="暂时找不到，去看看别的~" mode="data" icon="http://cdn.uviewui.com/uview/empty/data.png"></u-empty>
	</view>
</template>

<script>
	
	export default {
		props:{
			// cc 游戏礼包数据
			rebateData: {
				type: Object,
				default: null
			}
		},
		data() {
			return {
			}
		},
		// 组件挂载到实例生命周期函数
		mounted() {
			console.log('rebate-mounted')
			// cc 动态设置scroll高度
			this.$nextTick(function() {
				document.getElementById('scroll').style.height = `${uni.getSystemInfoSync().windowHeight - (496 / (750 / uni.getSystemInfoSync().windowWidth)) - document.getElementById('titleList').offsetHeight}px`
			})
		},
		methods: {
			// cc 跳转返利页面
			handleRouter(){
				uni.navigateTo({
					url:'/pages/customerService/children/rechargeRebate/index'
				})
			}
		}
	}
</script>

<style lang="scss" scoped>
	.rebate {
		width: 100%;
		height: 100%;
		
		&-scroll {
			width: 100%;
			// height: 100%;
			padding-top: 16rpx;
			box-sizing: border-box;
			background-color: #ffffff;
			
			::-webkit-scrollbar {
				display: none;
			}
			
			&-title {
				display: flex;
				flex-direction: row;
				justify-content: space-between;
				color: #1c1c1c;
				font-size: 32rpx;
				font-family: PingFang SC;
				font-weight: 600;
				letter-spacing: 4rpx;
				
				&-btn {
					background-color: #FFFFFF;
					border: 2rpx solid #E4E4E4;
					padding: 8rpx 24rpx;
					// box-sizing: border-box;
					border-radius: 32rpx;
					// height: 48rpx;
					// width: 144rpx;
					font-size: 28rpx;
					text-align: center;
					// line-height: 48rpx;
					color: #FF5927;
				}
			}
			
			&-content {
				padding-top: 8rpx;
				font-size: 28rpx;
				color: #666666;
				font-family: PingFang SC;
				font-weight: 400;
				// letter-spacing: 4rpx;
				
				&-text {
					padding-top: 32rpx;
					line-height: 56rpx;
				}
			}
		}
	}
</style>