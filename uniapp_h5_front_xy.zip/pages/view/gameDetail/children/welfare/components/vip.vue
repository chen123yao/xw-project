<template>
	<view class="vip">
		<!-- cc Vip表scroll -->
		<scroll-view id="scroll" class="vip-scroll" scroll-y v-if="vipData.count">
			<view class="vip-scroll-title"> 
				<text>{{ vipData.list[0].title }}</text>
			</view>
			
			<view class="vip-scroll-content">
			  <view class="vip-scroll-content-time">{{ vipData.list[0].pub_time }}</view>
			  <view class="vip-scroll-content-box">
			    	<text class="vip-scroll-content-box-text" v-for="(item, index) in content" :key='index'>{{ item }}</text>
			  </view>
			</view>
			<!-- <u-loadmore v-if="vipData.count" bg-color="transparent" height="60" marginTop="0" fontSize="24" marginBottom="32" status="nomore" loadingIcon="spinner" /> -->
		</scroll-view>
		
		<u-empty v-else class="gift-scroll-empty"
			:width="400" :height="400" :textSize="32" :marginTop="200" text="暂时找不到，去看看别的~" mode="data" icon="http://cdn.uviewui.com/uview/empty/data.png"></u-empty>
	</view>
</template>

<script>
	
	export default {
		props:{
			// cc 游戏礼包数据
			vipData: {
				type: Object,
				default: null
			}
		},
		data() {
			return {
			}
		},
		// 组件挂载到实例生命周期函数
		mounted() {
			console.log('vip-mounted')
			// cc 动态设置scroll高度
			this.$nextTick(function() {
				document.getElementById('scroll').style.height = `${uni.getSystemInfoSync().windowHeight - (496 / (750 / uni.getSystemInfoSync().windowWidth)) - document.getElementById('titleList').offsetHeight}px`
			})
		},
		computed: {
			// cc vip内容格式
			content(){
				let mycontent = ''
				let contentList = []
				let array = []
				if(this.vipData.list.length>0){
				var reg = /<[^<>]+>/g
				mycontent = this.vipData.list[0].content.replace(reg,'')
				contentList = mycontent.split('\n')
				 array = contentList.filter(item=>{
						 if(item){
							 return item 
						 }
					 })
				}
				return array
			}
		}
	}
</script>

<style lang="scss" scoped>
	.vip {
		width: 100%;
		height: 100%;
		
		&-scroll {
			width: 100%;
			// height: 100%;
			padding-top: 16rpx;
			box-sizing: border-box;
			background-color: #ffffff;
			
			::-webkit-scrollbar {
				display: none;
			}
			
			&-title {
				display: flex;
				flex-direction: row;
				justify-content: space-between;
				color: #1c1c1c;
				font-size: 32rpx;
				font-family: PingFang SC;
				font-weight: 600;
				letter-spacing: 4rpx;
			}
			
			&-content {
				padding-top: 8rpx;
				font-size: 28rpx;
				color: #666666;
				font-family: PingFang SC;
				font-weight: 400;
				
				&-box {
					padding: 32rpx 24rpx 80rpx;
					display: flex;
					flex-direction: row;
					align-items: center;
					justify-content: center;
					flex-wrap: wrap;
					
					&-text {
						box-sizing: border-box;
						font-weight: 400;
						font-size: 36rpx;
						padding: 20rpx 0;
						border: 2rpx solid #DCDCDC;
						text-align: center;
						
						&:nth-child(2n + 1) {
							width: 40%;
						}
						
						&:nth-child(2n) {
							width: 60%;
						}
						
						&:nth-child(1) {
							border-top-left-radius: 40rpx;
						}
						
						&:nth-child(2) {
							border-top-right-radius: 40rpx;
						}
						
						&:nth-last-child(1) {
							border-bottom-right-radius: 40rpx;
						}
						
						&:nth-last-child(2) {
							border-bottom-left-radius: 40rpx;
						}
					}
				}
			}
		}
	}
</style>