<template>
	<view class="welfare">
		<!-- cc 游戏福利scroll -->
		<scroll-view id="scroll" class="welfare-scroll" scroll-y v-if="welfareData.count">
			
			<u-collapse accordion>
				<u-collapse-item :title="item.title" :titleStyle="{color:'#1c1c1c',fontWeight: '700'}" v-for="(item,index) in welfareData.list" :key="index">
					<text class="welfare-scroll-time">{{ item.pub_time }}</text>
					<text class="welfare-scroll-content">{{ item.content.replace(/<[^<>]+>/g,'') }}</text>
				</u-collapse-item>
			</u-collapse>
			
			<u-loadmore v-if="welfareData.count" bg-color="transparent" height="60" marginTop="0" fontSize="24" marginBottom="32" status="nomore" loadingIcon="spinner" />
		</scroll-view>
		
		<u-empty v-else class="gift-scroll-empty"
			:width="400" :height="400" :textSize="32" :marginTop="200" text="暂时找不到，去看看别的~" mode="data" icon="http://cdn.uviewui.com/uview/empty/data.png"></u-empty>
	</view>
</template>

<script>
	
	export default {
		props:{
			// cc 游戏礼包数据
			welfareData: {
				type: Object,
				default: null
			}
		},
		data() {
			return {
				// cc 是否处于领取状态 默认false
				welfareStatus: false
			}
		},
		// 组件挂载到实例生命周期函数
		mounted() {
			console.log('welfare-mounted')
			// cc 动态设置scroll高度
			this.$nextTick(function() {
				document.getElementById('scroll').style.height = `${uni.getSystemInfoSync().windowHeight - (496 / (750 / uni.getSystemInfoSync().windowWidth)) - document.getElementById('titleList').offsetHeight}px`
			})
		},
		methods: {
			// 领取礼包
			getGift(welfare_id, status) {
				console.log('getGift', welfare_id, status, this.welfareStatus);
				if (this.$common.isLogin()){
					if (!this.welfareStatus) {
						this.welfareStatus = true
						
						setTimeout(() => {
							this.welfareStatus = false
						}, 1000)
								
						if (!status) {
							this.$api.get("user/welfare/add", {
								welfare_id,
							}).then(res => {
								if(res.data.code==200){
									uni.showToast({
										title: "领取成功",
										icon:'none',
										success: () => {
											setTimeout(() => {
												this.$emit('refreshGift',true)
											}, 200)
										}
									})
								} else {
									uni.showToast({
										title: res.data.msg,
										icon:'none',
										success: () => {
											setTimeout(() => {
												uni.navigateTo({
													url:'/pages/my/children/login'
												})
											}, 500)
										}
									})
								}
							})
								
						}
					}
				}
			}
		}
	}
</script>

<style lang="scss" scoped>
	::v-deep .u-cell__title-text {
		color: #1C1C1C;
		font-size: 28rpx;
		font-weight: 600;
		letter-spacing: 4rpx;
		font-family: PingFang SC;
	}
	
	::v-deep .u-collapse .u-line:first-child {
		display: none;
	}
	
	::v-deep .u-collapse .u-cell__body {
		padding: 40rpx 0 !important;
	}
	
	::v-deep .u-collapse .u-cell .u-line {
		display: none;
	}
	
	::v-deep .u-collapse-item__content__text {
		padding: 0 0 40rpx !important;
	}
	
	::v-deep .u-collapse :nth-child(2) .u-cell__body {
		padding-top: 24rpx !important;
	}
	
	.welfare {
		width: 100%;
		height: 100%;
		
		&-scroll {
			width: 100%;
			// height: 100%;
			padding-top: 16rpx;
			box-sizing: border-box;
			background-color: #ffffff;
			
			::-webkit-scrollbar {
				display: none;
			}
			
			&-time {
				margin-bottom: 32rpx;
			}
		}
	}
</style>