<template>
	<!-- cc 游戏详情游戏资讯信息页面 -->
	<view class="container information">
		<!-- cc 游戏资讯页面顶部标题 -->
		<view class="information-topTitle">
			<view class="information-topTitle-box">
				<image class="information-topTitle-box-left" src="@/static/images/left.png" mode="heightFix" @click="back" />
				<text class="information-topTitle-box-text">游戏资讯</text>
			</view>
		</view>
		
		<!-- cc 是否请求数据中 显示loading界面 -->
		<u-loading-page class="information-loading" :loading="!informationData" icon-size="72" font-size="30" loading-mode="spinner"></u-loading-page>
		
		<!-- cc 游戏资讯页面内容显示区域 -->
		<view v-if="informationData" class="information-content">
			<view class="information-content-item" v-for="(item, index) in informationData" :key="'information' + index" @click="handleRouterDetail(item.news_id, item.read)">
				
				<!-- cc 单个游戏资讯顶部游戏背景显示 -->
				<view class="information-content-item-top" :style="{ 'backgroundImage': 'url(' + item.image + ')' }">
					 <view class="information-content-item-top-text">{{ item.title }}</view>
				</view>
				
				<!-- cc 单个游戏资讯底部资讯信息显示 -->
				<view class="information-content-item-bottom">
					<!-- cc 标题显示 -->
					<text class="information-content-item-bottom-title">{{ item.desc }}</text>
						
					<!-- cc 资讯信息时间显示 -->
					<text class="information-content-item-bottom-time">{{ item.pub_time }}</text>
					
					<!-- cc 已读人数 -->
					<view class="information-content-item-bottom-read">
						<image src="@/static/images/seeall.png" mode="scaleToFill" />
						<text>{{ item.read }}</text>
					</view>
				</view>
			</view>
		</view>
		
		<u-loadmore v-if="informationData" bg-color="transparent" height="30" marginTop="0" fontSize="24" marginBottom="48" status="nomore" loadingIcon="spinner" />
	</view>
</template>

<script>
	export default {
		data() {
			return {
				// cc 获取游戏资讯数据参数
				params: {
					page: 1,
					offset: 15,
					type: 3,
					game_id: 0
				},
				// cc 游戏资讯数据
				informationData: null
			}
		},
		onLoad(option){
			this.params.game_id = option.gameId
			this.getInformationData()
		},
		methods: {
			// cc 获取游戏资讯数据
			getInformationData() {
				this.$api.get('game/detail', {
					...this.params
				}).then(res => {
					if (res.data.code == 200) {
						this.informationData = res.data.data.post.news.list
						console.log('informationData', this.informationData);
					} else {
						// cc 加载失败
						uni.showToast({
							title: "加载失败",
							icon: "none"
						})
					}
				})
			},
			// cc 点击跳转
			handleRouterDetail(id, read) {
				console.log('post_hits: ', read);
				uni.navigateTo({
					url: `/pages/my/comprehensive/gameConsulting/gameNewsDetail?news_id=${ id }&post_hits=${ read }`
				})
			},
			// cc 返回上一级页面
			back() {
				uni.navigateBack({
					delta: 1
				});
			}
		}
	}
</script>

<style lang="scss" scoped>
	.container { 
		background-color: #FFFFFF;
		width: 750rpx;
		height: 100vh;
		padding-bottom: 24rpx;
	}
	
	.information {
		
		&-loading {
			width: 750rpx;
			top: 176rpx !important;
		}
		
		&-topTitle {
			position: sticky;
			// background-color: #FFFFFF;
			background: linear-gradient(to bottom, #CCCCCC, #FFFFFF env(safe-area-inset-top));
			top: 0;
			width: 750rpx;
			height: 176rpx;
			padding-left: 34rpx;
			padding-bottom: 16rpx;
			box-sizing: border-box;
			display: flex;
			flex-direction: column;
			justify-content: flex-end;
			box-shadow: 0rpx 0rpx 12rpx rgba(0, 0, 0, 0.16);
			
			&-box {
				box-sizing: border-box;
				display: flex;
				flex-direction: row;
				align-items: center;
				
				&-left {
					// width: 22rpx;
					height: 34rpx;
				}
				
				&-text {
					margin-left: 48rpx;
					font-size: 40rpx;
					line-height: 56rpx;
					font-family: PingFang SC;
					font-weight: 600;
					color: #1C1C1C;
				}
			}
		}
		
		&-content {
			width: 750rpx;
			padding: 48rpx 32rpx 0;
			box-sizing: border-box;
			
			&-item {
				height: 410rpx;
				box-sizing: border-box;
				margin-bottom: 48rpx;
				font-family: PingFang SC;
				font-size: 24rpx;
				
				&-top {
					width: 100%;
					height: 292rpx;
					box-sizing: border-box;
					border-radius: 40rpx 40rpx 0px 0px;
					background-size: cover;
					position: relative;
					
					&-text {
						width: 100%;
						height: 70rpx;
						line-height: 70rpx;
						padding: 0 24rpx;
						font-size: 28rpx;
						background-color: rgba(28,28,28,0.39);
						color: #FFFFFF;
						font-weight: 600;
						overflow: hidden;
						text-overflow: ellipsis;
						white-space: nowrap;
						letter-spacing: 2rpx;
						position: absolute;
						box-sizing: border-box;
						bottom: 0;
					}
				}
				
				&-bottom {
					flex: 1;
					width: 100%;
					height: 118rpx;
					padding: 16rpx 24rpx 24rpx;
					box-sizing: border-box;
					background-color: #FFFFFF;
					border-radius: 0rpx 0rpx 40rpx 40rpx;
					box-shadow: 0rpx 0rpx 8rpx rgba(0, 0, 0, 0.16);
					
					display: flex;
					flex-direction: column;
					justify-content: space-between;
					font-weight: 400;
					color: #1C1C1C;
					letter-spacing: 4rpx;
					position: relative;
					
					&-title {
						max-width: calc(100% - 24rpx - 100rpx);
						font-weight: 500;
						overflow: hidden;
						text-overflow: ellipsis;
						white-space: nowrap;
						letter-spacing: 2rpx;
					}
					
					&-time {
						font-size: 20rpx;
						color: #666666;
					}
					
					&-read {
						position: absolute;
						right: 24rpx;
						top: 34rpx;
						color: #666666; 
						letter-spacing: 0rpx;
						
						& > *:first-child {
							width: 32rpx;
							height: 16rpx;
							margin-right: 16rpx;
						}
					}
				}
			}
		}
	}
</style>