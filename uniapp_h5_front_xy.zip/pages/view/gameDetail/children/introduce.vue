<template>
	<!-- cc 游戏详情游戏简介页面 -->
	<view class="container introduce">
		<!-- cc 游戏简介页面顶部标题 -->
		<view class="introduce-topTitle">
			<view class="introduce-topTitle-box">
				<image class="introduce-topTitle-box-left" src="@/static/images/left.png" mode="heightFix" @click="back" />
				<text class="introduce-topTitle-box-text">简介</text>
			</view>
		</view>
		
		<!-- cc 游戏简介页面内容显示区域 -->
		<view class="introduce-content">
			<text class="introduce-content-title">关于&nbsp;{{ gameName }}</text>
			<view class="introduce-content-introduce">{{ gameIntroduce }}</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				// cc 游戏名称
				gameName: '',
				// cc 游戏简介
				gameIntroduce: ''
			}
		},
		onLoad(option){
			this.gameName = option.title
			this.gameIntroduce = option.content
		},
		methods: {
			// cc 返回上一级页面
			back() {
				uni.navigateBack({
					delta: 1
				});
			}
		}
	}
</script>

<style lang="scss" scoped>
	.container { 
		background-color: #FFFFFF;
		width: 750rpx;
		height: 100vh;
	}
	
	.introduce {
		
		&-topTitle {
			position: sticky;
			// background-color: #FFFFFF;
			background: linear-gradient(to bottom, #CCCCCC, #FFFFFF env(safe-area-inset-top));
			top: 0;
			width: 750rpx;
			height: 176rpx;
			padding-left: 34rpx;
			padding-bottom: 16rpx;
			box-sizing: border-box;
			display: flex;
			flex-direction: column;
			justify-content: flex-end;
			box-shadow: 0rpx 0rpx 12rpx rgba(0, 0, 0, 0.16);
			
			&-box {
				box-sizing: border-box;
				display: flex;
				flex-direction: row;
				align-items: center;
				
				&-left {
					// width: 22rpx;
					height: 34rpx;
				}
				
				&-text {
					margin-left: 48rpx;
					font-size: 40rpx;
					line-height: 56rpx;
					font-family: PingFang SC;
					font-weight: 600;
					color: #1C1C1C;
				}
			}
		}
		
		&-content {
			width: 750rpx;
			padding: 48rpx 32rpx;
			box-sizing: border-box;
			color: #1C1C1C;
			font-family: PingFang SC;
			
			&-title {
				box-sizing: border-box;
				margin-bottom: 32rpx;
				font-size: 44rpx;
				font-weight: 600;
				display: inline-block;
			}
			
			&-introduce {
				font-weight: 400;
				font-size: 28rpx;
				line-height: 64rpx;
			}
		}
	}
</style>