<template>
	<!-- cc 游戏详情评论页面 -->
	<view class="container commentDetail">
		<!-- cc 游戏评论页面顶部标题 -->
		<view class="commentDetail-topTitle">
			<view class="commentDetail-topTitle-box">
				<image class="commentDetail-topTitle-box-left" src="@/static/images/left.png" mode="heightFix" @click="back" />
				<image class="commentDetail-topTitle-box-icon" :src="gameIcon" mode="scaleToFill"></image>
				<text class="commentDetail-topTitle-box-text">{{ gameName }}</text>
			</view>
		</view>
		
		<!-- cc 是否请求数据中 显示loading界面 -->
		<!-- <u-loading-page class="commentDetail-loading" :loading="loadingData < 2" icon-size="72" font-size="30" loading-mode="spinner"></u-loading-page> -->
		
		<!-- cc 游戏评论详情页面内容显示区域 -->
		<view v-if="commentData" class="commentDetail-content">
			<!-- cc 评论详情页评论信息 -->
			<view class="commentDetail-content-evaluate">
				<!-- cc 评论详情页评论信息顶部评论玩家信息 -->
				<view class="commentDetail-content-evaluate-info">
					<!-- cc 玩家信息左侧头像 玩家名 -->
					<view class="commentDetail-content-evaluate-info-left">
						<!-- cc 头像 -->
						<u-avatar :src="commentData.mem_avatar" :size="80" style="margin-right: 24rpx;"></u-avatar>
						
						<view >
							<view>{{ commentData.mem_name }}</view>
							<text class="commentDetail-content-evaluate-info-left-playTime">游戏时长 {{ playerGameTime }}分钟</text>
						</view>
					</view>
					
					<!-- cc 评论评分 -->
					<u-rate :count="5" :value="commentData.star_cnt / 2" :size="24" inactive-color="#C1C1C1" activeColor="#FF5927" :gutter="8" :readonly="true"></u-rate>
				</view>
				
				<!-- cc 评论内容 -->
				<text class="commentDetail-content-evaluate-info-text">{{ commentData.content }}</text>
				
				<!-- cc 评论图片 -->
				<image class="commentDetail-content-evaluate-info-img" v-for="(value, index) in commentData.content_img" :key="'img' + index" @click="$common.previewImage(index, commentData.content_img)" 
					mode="aspectFill" :src="value"></image>
				
				<!-- cc 评论底部时间信息和点赞信息 -->
				<view class="commentDetail-content-evaluate-info-timeInfo">
					<!-- cc 评论时间 -->
					<text class="commentDetail-content-evaluate-info-timeInfo-left">{{ commentData.time_str }}</text>
					
					<!-- cc 点赞点踩回复数量 -->
					<view class="commentDetail-content-evaluate-info-timeInfo-zan">
						<u-icon name="thumb-up" :color="commentData.is_like == 2 ? '#FF5927' : '#666666'" size="34" @click="handleSupport(commentData, index, true)"></u-icon>
						<text :style="{ color: commentData.is_like == 2 ? '#FF5927' : '#666666' }" @click="handleSupport(commentData, index, true)">{{ commentData.like_cnt }}</text>
						<u-icon name="thumb-down" :color="commentData.is_hate == 2 ? '#FF5927' : '#666666'" size="34" @click="handleSupport(commentData, index, false)"></u-icon>
						<text :style="{ color: commentData.is_hate == 2 ? '#FF5927' : '#666666' }" @click="handleSupport(commentData, index, false)">{{ commentData.hate_cnt }}</text>
					</view>
				</view>
			</view>
			
			<!-- cc 评论详情评论回复信息 -->
			<view class="commentDetail-content-reply">
				<view style="display: flex; flex-direction: row; align-items: flex-end;">
					<text style="color: #000; font-size: 40rpx; margin-right: 16rpx;">回复</text>
					<text style="color: #666; font-size: 20rpx; font-weight: 400;">当前{{ replyData.count }}条评论</text>
				</view>
				
				<view class="commentDetail-content-reply-item" v-for="(item, index) in replyData.list" :key="'reply' + index">
					<!-- cc 评论玩家信息和评论内容 -->
					<view class="commentDetail-content-reply-item-top">
						<view class="commentDetail-content-reply-item-top-box">
							
							<!-- cc 头像 -->
							<u-avatar :src="item.mem_avatar" :size="80"></u-avatar>
							
							<!-- cc 姓名时间 -->
							<view style="display: flex; flex-direction: column; justify-content: space-between; padding-top: 4rpx;">
								<text class="commentDetail-content-reply-item-top-box-name">{{ item.mem_name }}</text>
								<text>{{ item.time_str }}</text>
							</view>
						</view>
						
						<!-- cc 评论内容 -->
						<view class="commentDetail-content-reply-item-content">
							<text class="commentDetail-content-reply-item-content-text">{{ item.content }}</text>
							
							<image class="commentDetail-content-reply-item-content-img" v-for="(value, index) in item.content_img" :key="'img' + index" @click="$common.previewImage(index, item.content_img)" 
								mode="aspectFill" :src="value"></image>
							<!-- <text class="commentDetail-content-reply-item-content-more">...查看更多</text> -->
							
							<!-- cc 点赞点踩回复数量 -->
							<view class="commentDetail-content-reply-item-content-zan">
								<u-icon name="thumb-up" :color="item.is_like == 2 ? '#FF5927' : '#666666'" size="34" @click="handleSupport(item, index, true)"></u-icon>
								<text :style="{ color: item.is_like == 2 ? '#FF5927' : '#666666' }" @click="handleSupport(item, index, true)">{{ item.like_cnt }}</text>
								<u-icon name="thumb-down" :color="item.is_hate == 2 ? '#FF5927' : '#666666'" size="34" @click="handleSupport(item, index, false)"></u-icon>
								<text :style="{ color: item.is_hate == 2 ? '#FF5927' : '#666666' }" @click="handleSupport(item, index, false)">{{ item.hate_cnt }}</text>
							</view>
						</view>
					</view>
				</view>
				
				<!-- cc 回复为0时的显示 -->
				<view class="commentDetail-content-reply-noMsg" v-if="replyData.count==0">
					<image src="@/static/images/sf-background.png" mode="widthFix" style="width: 100%;"></image>
					<view style="text-align: center;">暂无评论，快去评论吧！</view>
				</view>
			</view>
			
			<!-- cc 消息输入框 -->
			<!-- <u--input placeholder="请输入内容" border="surround" v-model="value" @change="change"></u--input> -->
		</view>
	</view>
</template>

<script>
	import { mapState } from "vuex";
	
	export default {
		computed: {
			...mapState({
				userInfo: "userInfo"
			})
		},
		data() {
			return {
				// cc 游戏ID
				game_id: 0,
				// cc 游戏名
				gameName: '',
				// cc 游戏icon
				gameIcon: '',
				// cc 用于评论玩家的游戏时长  随机一个数
				playerGameTime: Math.floor(Math.random() * (100 - 1) + 1),
				// cc 游戏详情评论数据
				commentData: null,
				// cc 评论相关数据请求参数
				commentParams: {
					page: 1,
					offset: 100,
					type_name: "game",
					parent_id: 0,
					object_id: 0
				},
				// cc 评论相关回复数据
				replyData: []
			}
		},
		onLoad(option){
			this.game_id = option.gameId
			this.gameName = option.gameName
			this.gameIcon = option.gameIcon
			let itemObj = JSON.parse(option.item)
			this.commentData = itemObj
			this.commentParams.parent_id = this.commentData.id
			this.commentParams.object_id = this.commentData.object_id
			console.log('commentData', this.commentData);
			
			this.getEvaluate()
		},
		methods: {
			// cc 返回上一级页面
			back() {
				uni.navigateBack({
					delta: 1
				});
			},
			// cc 获取游戏评论回复信息
			getEvaluate() {
				this.$api.get('v8/comments/sub_list', {
					...this.commentParams,
				}).then(res => {
					if (res.data.code == 200) {
						console.log(res.data.data.list)
						this.replyData = res.data.data
						
					}
				})
			},
			// cc 点赞点踩响应事件
			handleSupport(item, index, b) {
				if (this.$common.isLogin()){
					let params = {
						game_id: this.game_id,
						comment_id: item.id,
						comment_type: 0,
						type: 0
					}
					
					if (b) {
						params.comment_type = 1
						
						if (item.is_like == 2) {
							params.type = 1
						} else {
							params.type = 2
						}
					} else {
						params.comment_type = 2
						
						if (item.is_hate == 2) {
							params.type = 1
						} else {
							params.type = 2
						}
					}
					
					this.$api.get("comments/like", {
						...params
					}).then(res => {
						if (res.data.code == 200) {
							if (item.is_like == 1 && item.is_hate == 1) {
								if (b) {
									item.like_cnt++;
									item.is_like = 2
								} else {
									item.hate_cnt++;
									item.is_hate = 2
								}
							} else if (item.is_like == 1 && item.is_hate == 2) {
								if (b) {
									item.like_cnt++;
									item.is_like = 2;
									item.hate_cnt--;
									item.is_hate = 1;
								} else {
									item.hate_cnt--;
									item.is_hate = 1;
								}
							} else if (item.is_like == 2 && item.is_hate == 1) {
								if (b) {
									item.like_cnt--;
									item.is_like = 1;
								} else {
									item.hate_cnt++;
									item.is_hate = 2;
									item.like_cnt--;
									item.is_like = 1;
								}
							}
						} else {
							uni.showToast({
								title: res.data.msg,
								icon: 'none'
							})
						}
					})
				}
			},
			// cc 发表评论
			handleComments(item, index) {
				if (this.$common.isLogin()){
					uni.navigateTo({
						url: `/pages/view/gameDetail/children/comments?gameid=${ this.game_id }`
					})
				}
			}
		}
	}
</script>

<style lang="scss" scoped>
	.container { 
		background-color: #FFFFFF;
		width: 750rpx;
		height: 100vh;
		padding-bottom: 24rpx;
	}
	
	.commentDetail {
		
		&-loading {
			width: 750rpx;
			top: 176rpx !important;
		}
		
		&-topTitle {
			position: fixed;
			// background-color: #FFFFFF;
			background: linear-gradient(to bottom, #CCCCCC, #FFFFFF env(safe-area-inset-top));
			z-index: 999;
			top: 0;
			width: 750rpx;
			height: 176rpx;
			padding-left: 34rpx;
			padding-bottom: 4rpx;
			box-sizing: border-box;
			display: flex;
			flex-direction: column;
			justify-content: flex-end;
			box-shadow: 0rpx 0rpx 12rpx rgba(0, 0, 0, 0.16);
			
			&-box {
				box-sizing: border-box;
				display: flex;
				flex-direction: row;
				align-items: center;
				
				&-left {
					// width: 22rpx;
					height: 34rpx;
					margin-right: 24rpx;
				}
				
				&-icon {
					width: 80rpx;
					height: 80rpx;
					border-radius: 24rpx;
					margin-right: 24rpx;
				}
				
				&-text {
					font-size: 36rpx;
					font-family: PingFang SC;
					font-weight: 600;
					color: #1C1C1C;
				}
			}
		}
		
		&-content {
			width: 750rpx;
			color: #1C1C1C;
			font-family: PingFang SC;
			background-color: #F4F4F4;
			
			&-evaluate {
				padding: 224rpx 32rpx 48rpx;
				background-color: #FFFFFF;
				border-bottom: 16rpx solid #F4F4F4;
				
				
				&-info {
					display: flex;
					flex-direction: row;
					justify-content: space-between;
					align-items: center;
					
					&-left {
						display: flex;
						flex-direction: row;
						align-items: center;
						
						font-size: 32rpx;
						font-weight: 600;
						letter-spacing: 4rpx;
						// line-height: 44rpx;
						
						&-playTime {
							font-size: 20rpx;
							color: #666666;
							font-weight: 400;
							letter-spacing: 4rpx;
						}
					}
					
					&-text {
						display: inline-block;
						padding-top: 32rpx;
						color: #121212;
						text-align: justify;
						text-align-last: left;
						padding-bottom: 32rpx;
						line-height: 40rpx;
						font-size: 28rpx;
					}
					
					&-img {
						height: 320rpx;
						width: 100%;
						border-radius: 40rpx;
						margin-bottom: 32rpx;
					}
					
					&-timeInfo {
						display: flex;
						flex-direction: row;
						align-items: center;
						justify-content: space-between;
						font-family: PingFang SC;
						
						&-left {
							font-size: 24rpx;
							font-weight: 400;
							line-height: 34rpx;
							color: #C1C1C1;
							letter-spacing: 4rpx;
						}
						
						&-zan { 
							display: flex;
							flex-direction: row;
							align-items: center;
							font-size: 24rpx;
							font-family: PingFang SC;
							font-weight: 400;
							color: #666666;
							letter-spacing: 2rpx;
							// margin-bottom: 40rpx;
							
							& > *:nth-child(n) {
								margin-right: 16rpx;
							}
							
							& > *:nth-child(2) {
								margin-right: 56rpx;
							}
						}
					}
				}
			}
			
			&-reply {
				padding: 48rpx 32rpx 116rpx;
				background-color: #FFFFFF;
				width: 750rpx;
				box-sizing: border-box;
				font-family: PingFang SC;
				font-weight: 600;
				letter-spacing: 4rpx;
				
				&-item {
					padding: 48rpx 0;
					border-bottom: 2rpx solid #EFEFEF;
					
					&-top {
						font-size: 20rpx;
						font-family: PingFang SC;
						font-weight: 400;
						color: #c1c1c1;
						
						&-box {
							display: flex;
							flex-direction: row;
							align-content: center;
							
							& > *:first-child {
								margin-right: 24rpx;
							}
							
							&-name {
								font-size: 28rpx;
								font-weight: 600;
								color: #1C1C1C;
								letter-spacing: 2rpx;
							}
						}
					}
					
					&-content {
						width: 100%;
						font-size: 24rpx;
						font-family: PingFang SC;
						position: relative;
						
						&-text {
							// overflow: hidden;
							// text-overflow: ellipsis;
							// display: -webkit-box;
							// -webkit-box-orient: vertical;
							// -webkit-line-clamp: 2;
							display: inline-block;
							padding-top: 28rpx;
							// line-height: 48rpx;
							color: #666;
							text-align: justify;
							text-align-last: left;
							padding-bottom: 32rpx;
						}
						
						&-img {
							height: 320rpx;
							width: 100%;
							border-radius: 40rpx;
							margin-bottom: 32rpx;
						}
						
						&-more {
							color: #C1C1C1;
							font-size: 24rpx;
							float: left;
							background-color: #FFFFFF;
							width: 180rpx;
							height: 48rpx;
							line-height: 48rpx;
							position: absolute;
							bottom: 0;
							right: 0;
							text-align: end;
							background: linear-gradient(to right, transparent, #FFF 30%);
						}
						
						&-zan {
							display: flex;
							flex-direction: row;
							align-items: center;
							font-size: 24rpx;
							font-family: PingFang SC;
							font-weight: 400;
							color: #666666;
							letter-spacing: 2rpx;
							// margin-bottom: 40rpx;
							
							& > *:nth-child(n) {
								margin-right: 16rpx;
							}
							
							& > *:nth-child(2n) {
								margin-right: 88rpx;
							}
						}
					}
				}
				
				&-noMsg {
					width: 686rpx;
				}
			}
		}
	}
</style>