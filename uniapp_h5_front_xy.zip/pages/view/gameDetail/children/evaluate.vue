<template>
	<!-- cc 游戏详情评论页面 -->
	<view class="container evaluate">
		<!-- cc 游戏评论页面顶部标题 -->
		<view class="evaluate-topTitle">
			<view class="evaluate-topTitle-box">
				<image class="evaluate-topTitle-box-left" src="@/static/images/left.png" mode="heightFix" @click="back" />
				<text class="evaluate-topTitle-box-text">全部评论</text>
			</view>
		</view>
		
		<!-- cc 是否请求数据中 显示loading界面 -->
		<u-loading-page class="evaluate-loading" :loading="loadingData < 2" icon-size="72" font-size="30" loading-mode="spinner"></u-loading-page>
		
		<!-- cc 游戏评论页面内容显示区域 -->
		<view v-if="evaluateData" class="evaluate-content">
			<!-- cc 评价中的主体部分内容 -->
			<view class="evaluate-content-statistics">
				<!-- cc 评价左侧总评分值 评分人数 -->
				<view class="evaluate-content-statistics-left">
					<text class="evaluate-content-statistics-left-score">{{ evaluateData.star_cnt }}</text>
					<u-rate :count="5" v-model="evaluateData.star_cnt / 2" :size="16" active-color="#FF5927" inactive-color="#C1C1C1" :gutter="8" :allowHalf="true" :readonly="true" inactiveIcon="star-fill"></u-rate>
					<text class="evaluate-content-statistics-left-text">{{ evaluateData['star_all'] }}人在评分</text>
				</view>
				
				<!-- cc 右侧各分段评分人数详情 -->
				<view class="evaluate-content-statistics-right">
					<view class="evaluate-content-statistics-right-item" v-for="(item, index) in 5">
						<u-rate :count="5 - index" :minCount="0" :value="0" :size="24" inactive-color="#C1C1C1" activeColor="#FF5927" :gutter="8" :readonly="true" inactiveIcon="star-fill"></u-rate>
						<u-line-progress :percentage="evaluateData['star' + (5 - index)]" activeColor="#FF5927" inactiveColor="#EFEFEF" :showText="false" :height="10" style="width: 300rpx; margin-left: 16rpx;"></u-line-progress>
					</view>
				</view>
			</view>
			
			<!-- cc 发表评论按钮和账号头像显示 -->
			<view class="evaluate-content-info">
				<!-- cc 发表评论按钮 -->
				<view class="evaluate-content-info-sendBtn">
					<u-avatar :src="userInfo.avatar" :size="80"></u-avatar>
					<text>点击发表我的评论</text>
				</view>
				<!-- cc 评论评分 -->
				<u-rate :count="5" :value="5" :size="60" inactive-color="#C1C1C1" activeColor="#FF5927" :gutter="40" :readonly="true"></u-rate>
				<!-- cc 总共评论条数 -->
				<text>当前共{{ commentsCount }}条评论</text>
			</view>
			
			<!-- cc 游戏评论列表 -->
			<view class="evaluate-content-list">
				<view class="evaluate-content-list-item" v-for="(item, index) in commentsData" :key="'comment' + index">
					<!-- cc 评论玩家信息和评论内容 -->
					<view class="evaluate-content-list-item-top">
						<view class="evaluate-content-list-item-top-box" @click="commentsDetail(item)">
							
							<!-- cc 头像 -->
							<u-avatar :src="item.mem_avatar" :size="80"></u-avatar>
							
							<!-- cc 姓名时间 -->
							<view style="display: flex; flex-direction: column; justify-content: space-between; padding-top: 4rpx;">
								<text class="evaluate-content-list-item-top-box-name">{{ item.mem_name }}</text>
								<text>{{ item.time_str }}</text>
							</view>
						</view>
						
						<!-- cc 评论评分 -->
						<u-rate :count="5" :value="item.star_cnt / 2" :size="25" inactive-color="#C1C1C1" activeColor="#FF5927" :gutter="10" :readonly="true" style="margin-top: 24rpx;"></u-rate>
						
						<!-- cc 评论内容 -->
						<view class="evaluate-content-list-item-content">
							<text class="evaluate-content-list-item-content-text" @click="commentsDetail(item)">{{ item.content }}</text>
							
							<image class="evaluate-content-list-item-content-img" v-for="(value, index) in item.content_img" :key="'img' + index" @click="$common.previewImage(index, item.content_img)" 
								mode="aspectFill" :src="value"></image>
							<!-- <text class="evaluate-content-list-item-content-more">...查看更多</text> -->
							
							<!-- cc 点赞点踩回复数量 -->
							<view class="evaluate-content-list-item-content-zan">
								<u-icon name="thumb-up" :color="item.is_like == 2 ? '#FF5927' : '#666666'" size="34" @click="handleSupport(item, index, true)"></u-icon>
								<text :style="{ color: item.is_like == 2 ? '#FF5927' : '#666666' }" @click="handleSupport(item, index, true)">{{ item.like_cnt }}</text>
								<u-icon name="thumb-down" :color="item.is_hate == 2 ? '#FF5927' : '#666666'" size="34" @click="handleSupport(item, index, false)"></u-icon>
								<text :style="{ color: item.is_hate == 2 ? '#FF5927' : '#666666' }" @click="handleSupport(item, index, false)">{{ item.hate_cnt }}</text>
								<image src="@/static/images/view/contens.png" mode="scaleToFill" @click="commentsDetail(item)" />
								<text>{{ item.sum ? item.sum : 0 }}</text>
							</view>
						</view>
					</view>
					<!-- cc 评论回复 -->
					<view v-if="item.sub.length" class="evaluate-content-list-item-reply" @click="commentsDetail(item)">
						<view v-if="index < 2" class="evaluate-content-list-item-reply-item" v-for="(item, index) in item.sub" :key="'reply' + index">
							<text class="evaluate-content-list-item-reply-item-name">{{ item.mem_name }}：</text>
							<text class="evaluate-content-list-item-reply-item-content">{{ item.content }}</text>
						</view>
						<text class="evaluate-content-list-item-reply-more" >查看全部{{ item.sum ? item.sum : 0 }}条评论</text>
					</view>
				</view>
				
				<u-loadmore v-if="commentsData.length" bg-color="transparent" height="30" marginTop="0" fontSize="24" marginBottom="32" :status="loadingStatus" loadingIcon="spinner" />
			</view>
		</view>
	</view>
</template>

<script>
	import { mapState } from "vuex";
	
	export default {
		computed: {
			...mapState({
				userInfo: "userInfo"
			})
		},
		data() {
			return {
				// cc 游戏ID
				game_id: 0,
				// cc 游戏详情评论列表数据
				evaluateData: null,
				// cc 评论相关数据请求参数
				commentParams: {
					page: 1,
					offset: 10,
					type_name: "game",
				},
				// cc 评论相关数据数量 默认0
				commentsCount: 0,
				// cc 评论相关数据
				commentsData: [],
				// cc 是否加载中 默认false
				isLoading: false,
				// cc loadmore状态
				loadingStatus: 'loading',
				// cc 是否在请求数据 默认请求中  0 为请求中  因为有2个数据同时请求 所以每返回一个数据则+1 2为请求完成
				loadingData: 0,
			}
		},
		onLoad(option){
			this.game_id = option.gameId
			
			// cc 获取评论数据
			this.getEvaluateData()
			this.getComments()
		},
		onReachBottom() {
			this.loadMoreCommentsData()
		},
		methods: {
			// cc 返回上一级页面
			back() {
				uni.navigateBack({
					delta: 1
				});
			},
			// cc 获取评论页面数据
			getEvaluateData() {
				this.$api.get("/game/detail", {
					game_id: this.game_id
				}).then(res => {
					this.evaluateData = res.data.data
					console.log('evaluateData', this.evaluateData)
					this.loadingData++
				})
			},
			// cc 动态加载评论相关数据响应事件
			loadMoreCommentsData() {
				console.log('loadMoreCommentsData');
				if (Object.keys(this.commentsData).length < this.commentsCount && !this.isLoading) {
					this.commentParams.page++
					this.isLoading = true
					this.loadingStatus = 'loading'
					this.getComments()
				} else {
					this.loadingStatus = 'nomore'
					this.isLoading = false
				}
			},
			// cc 获取评论相关数据
			getComments() {
				this.$api.get('/v8/comments/list', {
					...this.commentParams,
					object_id: this.game_id
				}).then(res => {
					if (res.data.code == 200) {
						console.log('log', res);
						this.commentsCount = res.data.data.count
						let listData = res.data.data.list
						listData.forEach(item => {
							item.commentShowMore = false
						})
						
						this.commentsData = this.commentsData.concat(listData)
						this.isLoading = false
						console.log('commentsData', res.data.data, this.commentsData);
						
						if (this.commentsData.length >= this.commentsCount) {
							this.loadingStatus = 'nomore'
						}
						
						this.loadingData++
						
						console.log('loadingData', this.loadingData);
					}
				})
			},
			// cc 点赞点踩响应事件
			handleSupport(item, index, b) {
				console.log('111');
				if (this.$common.isLogin()) {
					let params = {
						game_id: this.game_id,
						comment_id: item.id,
						comment_type: 0,
						type: 0
					}
					
					if (b) {
						params.comment_type = 1
						
						if (item.is_like == 2) {
							params.type = 1
						} else {
							params.type = 2
						}
					} else {
						params.comment_type = 2
						
						if (item.is_hate == 2) {
							params.type = 1
						} else {
							params.type = 2
						}
					}
					
					this.$api.get("comments/like", {
						...params
					}).then(res => {
						if (res.data.code == 200) {
							if (item.is_like == 1 && item.is_hate == 1) {
								if (b) {
									item.like_cnt++;
									item.is_like = 2
								} else {
									item.hate_cnt++;
									item.is_hate = 2
								}
							} else if (item.is_like == 1 && item.is_hate == 2) {
								if (b) {
									item.like_cnt++;
									item.is_like = 2;
									item.hate_cnt--;
									item.is_hate = 1;
								} else {
									item.hate_cnt--;
									item.is_hate = 1;
								}
							} else if (item.is_like == 2 && item.is_hate == 1) {
								if (b) {
									item.like_cnt--;
									item.is_like = 1;
								} else {
									item.hate_cnt++;
									item.is_hate = 2;
									item.like_cnt--;
									item.is_like = 1;
								}
							}
						} else {
							uni.showToast({
								title: res.data.msg,
								icon: 'none'
							})
						}
					})
				}
			},
			// cc 发表评论
			handleComments() {
				if (this.$common.isLogin()) {
					uni.navigateTo({
						url: `/pages/view/gameDetail/children/comments?gameid=${ this.game_id }`
					})
				}
			},
			// cc 子评论详情页面
			commentsDetail(item) {
				console.log('222');
				let itemStr = JSON.stringify(item)
				uni.navigateTo({
					url: `/pages/view/gameDetail/children/commentDetail?gameId=${ this.game_id }&gameName=${ this.evaluateData.gamename }&gameIcon=${ this.evaluateData.new_icon || this.evaluateData.icon }&item=${ itemStr }`
				})
			}
		}
	}
</script>

<style lang="scss" scoped>
	.container { 
		background-color: #FFFFFF;
		width: 750rpx;
		height: 100vh;
		padding-bottom: 24rpx;
	}
	
	.evaluate {
		
		&-loading {
			width: 750rpx;
			top: 176rpx !important;
		}
		
		&-topTitle {
			position: fixed;
			// background-color: #FFFFFF;
			background: linear-gradient(to bottom, #CCCCCC, #FFFFFF env(safe-area-inset-top));
			z-index: 999;
			top: 0;
			width: 750rpx;
			height: 176rpx;
			padding-left: 34rpx;
			padding-bottom: 16rpx;
			box-sizing: border-box;
			display: flex;
			flex-direction: column;
			justify-content: flex-end;
			box-shadow: 0rpx 0rpx 12rpx rgba(0, 0, 0, 0.16);
			
			&-box {
				box-sizing: border-box;
				display: flex;
				flex-direction: row;
				align-items: center;
				
				&-left {
					// width: 22rpx;
					height: 34rpx;
				}
				
				&-text {
					margin-left: 48rpx;
					font-size: 40rpx;
					line-height: 56rpx;
					font-family: PingFang SC;
					font-weight: 600;
					color: #1C1C1C;
				}
			}
		}
		
		&-content {
			width: 750rpx;
			padding: 224rpx 32rpx 0;
			box-sizing: border-box;
			color: #1C1C1C;
			font-family: PingFang SC;
			
			&-statistics {
				height: 168rpx;
				display: flex;
				flex-direction: row;
				justify-content: space-between;
				margin-bottom: 72rpx;
				
				&-left {
					display: flex;
					flex-direction: column;
					align-items: center;
					align-self: flex-start;
					
					&-score {
						font-size: 80rpx;
						line-height: 112rpx;
						color: #FF5927;
						font-family: PingFang SC;
						font-weight: 600;
					}
					
					&-text {
						font-size: 24rpx;
						font-family: PingFang SC;
						font-weight: 400;
						color: #C1C1C1;
						letter-spacing: 2rpx;
						margin-top: 8rpx;
					}
				}
				
				&-right {
					display: flex;
					flex-direction: column;
					align-items: flex-end;
					align-self: flex-end;
					
					&-item {
						display: flex;
						flex-direction: row;
						justify-content: flex-end;
						align-items: center;
						margin-top: 8rpx;
					}
				}
			}
		
			&-info {
				box-sizing: border-box;
				
				&-sendBtn {
					display: flex;
					flex-direction: row;
					align-items: center;
					justify-content: center;
					font-size: 28rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #666666;
					letter-spacing: 2rpx;
					margin-bottom: 48rpx;
					
					& > *:first-child {
						margin-right: 16rpx;
					}
				}
				
				& > *:nth-child(2) {
					justify-content: center;
					margin-bottom: 72rpx;
				}
			}
			
			&-list {
				padding-top: 64rpx;
				
				&-item {
					padding: 48rpx 0;
					border-bottom: 2rpx solid #EFEFEF;
					
					&-top {
						font-size: 20rpx;
						font-family: PingFang SC;
						font-weight: 400;
						color: #666666;
						
						&-box {
							display: flex;
							flex-direction: row;
							align-content: center;
							
							& > *:first-child {
								margin-right: 24rpx;
							}
							
							&-name {
								font-size: 28rpx;
								font-weight: 600;
								color: #1C1C1C;
								letter-spacing: 2rpx;
							}
						}
					}
					
					&-content {
						width: 100%;
						font-size: 24rpx;
						font-family: PingFang SC;
						position: relative;
						
						&-text {
							// overflow: hidden;
							// text-overflow: ellipsis;
							// display: -webkit-box;
							// -webkit-box-orient: vertical;
							// -webkit-line-clamp: 2;
							display: inline-block;
							padding-top: 28rpx;
							// line-height: 48rpx;
							color: #121212;
							text-align: justify;
							text-align-last: left;
							padding-bottom: 32rpx;
						}
						
						&-img {
							height: 320rpx;
							width: 100%;
							border-radius: 40rpx;
							margin-bottom: 32rpx;
						}
						
						&-more {
							color: #C1C1C1;
							font-size: 24rpx;
							float: left;
							background-color: #FFFFFF;
							width: 180rpx;
							height: 48rpx;
							line-height: 48rpx;
							position: absolute;
							bottom: 0;
							right: 0;
							text-align: end;
							background: linear-gradient(to right, transparent, #FFF 30%);
						}
						
						&-zan {
							display: flex;
							flex-direction: row;
							align-items: center;
							font-size: 24rpx;
							font-family: PingFang SC;
							font-weight: 400;
							color: #666666;
							letter-spacing: 2rpx;
							// margin-bottom: 40rpx;
							
							& > *:nth-child(n) {
								margin-right: 16rpx;
							}
							
							& > *:nth-child(2n) {
								margin-right: 56rpx;
							}
							
							& > *:nth-child(5) {
								width: 24rpx;
								height: 24rpx;
							}
						}
					}
					
					&-reply {
						margin-top: 40rpx;
						padding: 16rpx;
						width: 686rpx;
						background-color: #F4F4F4;
						border-radius: 24rpx;
						font-size: 24rpx;
						font-family: PingFang SC;
						font-weight: 400;
						line-height: 34rpx;
						letter-spacing: 2rpx;
						box-sizing: border-box;
						
						&-item {
							display: flex;
							flex-direction: row;
							align-items: center;
							margin-bottom: 8rpx;
							
							&-name {
								color: #121212;
							}
							
							&-content { 
								color: #666666;
							}
						}
						
						&-more {
							display: inline-block;
							padding-top: 16rpx;
							color: #C1C1C1;
						}
					}
				}
			}
		}
	}
</style>