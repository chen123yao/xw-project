<template>
	<!-- cc 搜索页面 -->
	<view class="container search">
		<!-- cc 搜索页面顶部标题 -->
		<view class="search-topTitle">
			<view class="search-topTitle-box">
				<image class="search-topTitle-box-left" src="@/static/images/left_search.png" mode="heightFix" @click="back" />
				<u--input placeholder="去找你要看到的" v-model="keywords" prefixIcon="search" :customStyle="{background: '#F4F4F4', height: '72rpx', boxSizing: 'border-box'}" 
					prefixIconStyle="font-size: 48rpx;margin: 0 6rpx 0 8rpx; color: rgba(193, 193, 193, .5)" placeholderStyle="font-size: 28rpx; color: rgba(193, 193, 193, .5)" 
					fontSize="28" color="#1c1c1c" clearable shape="circle" confirmType="search" @confirm="handleSearch"></u--input>
				<text class="search-topTitle-box-text" @click="handleSearch">搜索</text>
			</view>
		</view>
		
		<u-empty v-if="isSended && !searchData.length" class="gameList-right-scroll-empty"
			:width="400" :height="400" :textSize="0" :marginTop="400" mode="data" icon="http://cdn.uviewui.com/uview/empty/car.png"></u-empty>
		<!-- cc 是否请求数据中 显示loading界面 -->
		<u-loading-page class="search-loading" :loading="isSearch && !searchData.length" icon-size="72" font-size="30" loading-mode="spinner"></u-loading-page>
		
		<!-- cc 搜索页面内容显示区域 -->
		<view v-if="tagsList" class="search-content">
			<!-- cc 搜索历史记录 -->
			<view v-if="!isSearch && historyData.length && !isSended" class="search-content-history">
				<view v-if="index < (showAllHistory ? 2 : 5)" class="search-content-history-item" v-for="(value, index) in historyData" :key="'history' + index">
					<view class="search-content-history-item-left" @click="clickSearch(value)">
						<image class="search-content-history-item-left-img" src="@/static/images/timer-icon.png" mode="scaleToFill"></image>
						<text class="search-content-history-item-left-text">{{ value }}</text>
					</view>
					<image class="search-content-history-item-right" src="@/static/images/comment-close.png" mode="scaleToFill" @click="removeHistory(index)"></image>
				</view>
				
				<view v-if="historyData.length > 2 && showAllHistory" class="search-content-history-showAll" @click="showAllHistory = false">显示全部</view>
			</view>
			
			<!-- cc 热门游戏标签 -->
			<view v-if="!isSearch && !isSended" class="search-content-hot">
				<text class="search-content-hot-title">热门游戏标签</text>
				<view class="search-content-hot-cate" v-if="userFormat.hotSearch" >
					<view class="search-content-hot-hotItem" v-for="value in tagsList" @click="handleToGameList('tags', value.id, value.name)">
						<text class="search-content-hot-hotItem-text">{{ value.name }}</text>
					</view>
					<view class="search-content-hot-hotItem" v-for="(value, index) in cateList" v-if="index < 6" :key="'cate' + index" @click="handleToGameList('cate', value.id, value.name)">
						<text class="search-content-hot-hotItem-text">{{ value.name }}</text>
					</view>
				</view>
			</view>
			
			<!-- cc 热门功能 -->
			<view v-if="!isSearch && !isSended" class="search-content-hot">
				<text class="search-content-hot-title">热门功能</text>
				<view class="search-content-hot-cate" v-if="userFormat.hotSearch">
					<view class="search-content-hot-box" v-for="(v, count) in 2">
						<view class="search-content-hot-hotItem2" v-if="(index >= count * 3) && (index < (count + 1) * 3)" v-for="(item, index) in commonList" :key="'hot' + index" @click="handleRouter(item.router,item.type)">
							<image class="search-content-hot-hotItem2-img" :src="item.url" mode="scaleToFill"></image>
							<text class="search-content-hot-hotItem2-text">{{ item.name }}</text>
						</view>
					</view>
				</view>
			</view>
			
			<!-- cc 搜索结果面板 -->
			<view v-else class="search-content-searchPanel">
				<view class="search-content-searchPanel-item"  v-for="(value, index) in searchData" :key="index">
					<vue-gameItem v-if="gameColorArray[index]" :itemData='value' :contentTagsColor="[gameColorArray[(index) * 2],gameColorArray[(index) * 2 + 1]]" :itemWidth="686" :itemRankIndex="index" :itemBMargin="32" :iconWidth="144" :hasPadding="false" :isShowMaxWidth="true"></vue-gameItem>
					<view class="search-content-searchPanel-item-line"></view>
				</view>
				
				<u-loadmore v-if="searchData.length" bg-color="transparent" height="30" marginTop="0" fontSize="24" marginBottom="32" :status="loadingStatus" loadingIcon="spinner" />
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				// cc 搜索内容
				keywords: '',
				// cc 历史搜索记录
				historyData: [],
				// cc 显示所有5个历史搜索记录  默认隐藏所有
				showAllHistory: true,
				// cc 是否正在发送搜索请求 默认false
				isSearch: false,
				// cc 是否请求过数据
				isSended: false,
				// cc 搜索页面请求数据
				searchData: [],
				// cc loadmore状态
				loadingStatus: 'nomore',
				// cc 热门分类、热门标签
				cateList: [],
				tagsList: [],
				// cc 底部快捷方式数据
				commonList: [{
						url: '../../../static/images/view/swyx.png',
						router: '/pages/getMoney/index',
						name: '试玩游戏',
						type: 3
					},
					{
						url: '../../../static/images/view/jfsc.png',
						name: '积分商城',
						router: '/pages/my/children/pointMall/index',
						type: 1
					},
					{
						url: '../../../static/images/view/qmtg.png',
						name: '全民推广',
						router: '/pages/my/children/share/index',
						type: 1
					},
				
					{
						url: '../../../static/images/view/xyzp.png',
						name: '幸运转盘',
						router: '/pages/getMoney/index',
						type: 4
					},
				
					{
						url: '../../../static/images/view/lqzx.png',
						name: '领券中心',
						router: '/pages/my/children/couponsCore/index',
						type: 1
					},
				
					{
						url: '../../../static/images/view/rwzx.png',
						name: '任务中心',
						router: '/pages/getMoney/index',
						type: 5,
					}],
					
					// cc 新开服游戏列表、游戏列表 item tags color
					gameColorArray: [],
			}
		},
		onLoad(option){
			// cc 获取热门分类数据
			this.getHotClassifyData()
			// cc 获取搜索历史记录
			this.getHistory();
		},
		onReachBottom() {
			// this.loadMoreSpecialData()
		},
		watch:{
			keywords(val){
				console.log('watch', val);
				if(!val){	
					this.isSearch = false
					this.isSended = false
					this.searchData =[]
				}
			}
		},
		computed: {
			userFormat() {
				return this.$store.state.userFormat
			}
		},
		methods: {
			// cc 返回上一级页面
			back() {
				uni.navigateBack({
					delta: 1
				});
			},
			// cc 获取搜索数据
			getSearchData(data = {}) {
				this.$api.get('game/search', {
					...data
				}).then(res => {
					if (res.data.code == 200) {
						this.searchData = res.data.data.list
						console.log('getSearchData', this.searchData);
						this.isSearch = false
						
						if (this.searchData.length == 0) {
							this.isSended = true
						}
						
						if (this.searchData.length) {
							// console.log('gameColorArrayLength: ', res.data.data.list.length);
							let gameColorIndexArray = [ ...this.$common.getRandomColorIndexArray([], this.searchData.length * 2) ]
							// console.log('gameColorIndexArray: ', this.gameColorIndexArray);
							this.gameColorArray = { ...this.$common.getRandomColorArray(gameColorIndexArray) }
							// console.log('gameColorArray: ', this.gameColorArray);
						}
						
					}
				})
			},
			// cc 获取热门分类数据
			getHotClassifyData() {
				this.$api.get('/game/getcategorynew').then(res => {
					if (res.data.code == 200) {
						console.log('getHotClassifyData', res);
						this.cateList = res.data.data.cate;
						this.tagsList = res.data.data.tags;
					}
				})
			},
			// cc 跳转大厅
			handleToGameList(type, id, name) {
				uni.setStorage({
					key:'gameHall',
					data: `${type}-${id}-${name}`,
					success: function () {
						console.log('success', `${type}-${id}-${name}`);
					}
				})
				uni.switchTab({
					url: '/pages/gameList/index'
				})
			},
			// cc 获取历史记录
			getHistory() {
				this.historyData = uni.getStorageSync('history') || []
			},
			// cc 设置搜索记录
			setHistory(keywords) {
				this.historyData.unshift(keywords)
				this.historyData = [...new Set(this.historyData)];
				
				this.historyData.length > 5 && this.historyData.slice(0, 5)
				uni.setStorageSync('history', this.historyData)
			},
			// cc 删除搜索记录
			removeHistory(index) {
				console.log('删除搜索记录：', index);
				this.historyData.splice(index, 1)
				uni.setStorageSync('history', this.historyData)
			},
			// cc 点击搜索
			clickSearch(value){
				if(value){
				  this.keywords = value
				}
				this.handleSearch()
			},
			// cc 搜索响应事件
			handleSearch() {	
				if (!this.keywords) {
					return;
				}
				this.isSearch = true
				this.isSended = true
				// 数据存入本地
				this.setHistory(this.keywords);
				// 关键字搜索
				let params = {
					page: 1,
					offset: 30,
					keywords: this.keywords
				}
				this.getSearchData(params)
			},
			// cc 点击跳转路由页面
			handleRouter(url, type) {
				console.log('handleRouter', url);
				if (type == 1) {
					if (this.$common.isLogin()) {
						uni.navigateTo({
							url
						})
					}
				} else if (type==3||type==4||type==5){
					if(this.$common.isLogin()){
						if(type==3){
							uni.setStorage({
								key: 'active',
								data: 1
							})
						}else if(type==4){
							uni.setStorage({
								key: 'active',
								data: 2
							})
						}else if(type==5){
							uni.setStorage({
								key: 'active',
								data: 0
							})
						}
						uni.switchTab({
							url
						})
					}
				}else{
					uni.navigateTo({
						url
					})
				}
			}
		}
	}
</script>

<style lang="scss" scoped>
	.container { 
		background-color: #FFFFFF;
		width: 750rpx;
		height: 100vh;
		padding-bottom: 24rpx;
	}
	
	.search {
		
		&-loading {
			width: 750rpx;
			top: 176rpx !important;
		}
		
		&-topTitle {
			position: fixed;
			// background-color: #FFFFFF;
			background: linear-gradient(to bottom, #CCCCCC, #FFFFFF env(safe-area-inset-top));
			z-index: 999;
			top: 0;
			width: 750rpx;
			height: 176rpx;
			padding: 0 32rpx 16rpx 34rpx;
			box-sizing: border-box;
			display: flex;
			flex-direction: column;
			justify-content: flex-end;
			box-shadow: 0rpx 0rpx 12rpx rgba(0, 0, 0, 0.16);
			
			&-box {
				box-sizing: border-box;
				display: flex;
				flex-direction: row;
				align-items: center;
				
				&-left {
					// width: 22rpx;
					height: 34rpx;
					margin-right: 40rpx;
				}
				
				&-text {
					margin-left: 48rpx;
					font-size: 32rpx;
					line-height: 44rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #666666;
				}
			}
		}
		
		&-content {
			width: 750rpx;
			padding-top: 176rpx;
			box-sizing: border-box;
			color: #1C1C1C;
			font-family: PingFang SC;
			
			&-history {
				padding: 16rpx 32rpx 0;
				border-bottom: 16rpx solid #F4F4F4;
				
				&-item {
					// height: 96rpx;
					padding: 32rpx 0;
					display: flex;
					flex-direction: row;
					justify-content: space-between;
					align-items: center;
					border-bottom: 2rpx solid #EFEFEF;;
					
					&-left {
						width: 500rpx;
						display: flex;
						flex-direction: row;
						align-items: center;
						
						&-img {
							width: 24rpx;
							height: 24rpx;
							margin-right: 24rpx;
						}
						
						&-text {
							font-size: 28rpx;
							font-family: PingFang SC;
							font-weight: 400;
							// line-height: 40rpx;
							color: #1C1C1C;
						}
					}
					
					&-right {
						 width: 16rpx;
						 height: 16rpx;
						 margin-right: 22rpx;
					}
				}
				
				&-showAll {
					font-size: 24rpx;
					font-family: PingFang SC;
					font-weight: 600;
					line-height: 34rpx;
					text-align: center;
					color: #666666;
					letter-spacing: 4rpx;
					margin: 24rpx 0;
				}
			}
			
			&-hot {
				padding: 40rpx 32rpx 44rpx;
				
				&-title {
					font-size: 32rpx;
					font-family: PingFang SC;
					font-weight: 600;
					color: #1C1C1C;
					letter-spacing: 4rpx;
				}
				
				&-cate {
					padding-top: 52rpx;
					display: flex;
					flex-direction: row;
					flex-wrap: wrap;
				}
				
				&-hotItem {
					padding: 4rpx 24rpx;
					margin-right: 24rpx;
					margin-bottom: 32rpx;
					background-color: #F4F4F4;
					border-radius: 24rpx;
					
					&-text {
						font-size: 28rpx;
						font-family: PingFang SC;
						font-weight: 400;
						color: #666666;
					}
				}
				
				&-box {
					display: flex;
					flex-direction: row;
					justify-content: space-between;
					margin-bottom: 32rpx;
					width: 686rpx;
				}
				
				&-hotItem2 {
					padding: 16rpx;
					background-color: #F8F8F8;
					border-radius: 40rpx;
					display: flex;
					flex-direction: row;
					justify-content: center;
					align-items: center;
					
					&-img {
						width: 48rpx;
						height: 48rpx;
						margin-right: 16rpx;
					}
					
					&-text {
						font-size: 28rpx;
						font-family: PingFang SC;
						font-weight: 400;
						color: #666666;
					}
				}
			}
			
			&-searchPanel {
				padding: 48rpx 32rpx 0;
				
				&-item {
					margin-bottom: 64rpx;
					position: relative;
					
					&-line {
						height: 2rpx;
						background-color: #EFEFEF;
						width: 550rpx;
						position: absolute;
						right: -32rpx;
					}
				}
			}
		}
	}
</style>