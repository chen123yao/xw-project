<template>
	<view class="demoGame">
		<view class="lineShowdow"></view>
		<view class="game-list">
			<view class="head">
				<view class="str">1.点击试玩领取任务后，进入游戏详情</view>
				<view class="str">2.在达到试玩要求后，自己发放奖励到您账户中</view>
				<view class="str">3.使用获得的奖励兑换其他福利</view>
			</view>
			<view class="" v-if="pageData.length">
				<view v-for="(item, index) in pageData" :key="index" @scrolltolower="scrolltolower">
					<view class="bottom_item">
						<view class="item_head" :style="{width:$store.state.myWidth-32+'px'}"
							@click="handleRouter(item.app_id)">
							<image class="item_img" :src="item.game.ext_info.hot_image" mode="widthFix"></image>
							<view class="blurs" :style="{width:$store.state.myWidth-32+'px'}"
								v-if="$store.state.platform=='android'">
								<view class="blurs"></view>
								<view style=" left: 16rpx;position: absolute;bottom:18rpx ;">
									<text
										style="color: #FFFFFF;font-size:26rpx ;font-weight: 400;">{{item.content}}</text>
								</view>
							</view>
							<view class="blursIos" :style="{width:$store.state.myWidth-32+'px'}" v-else>
								<view class="blursIos"></view>
								<view style=" left: 16rpx;position: absolute;bottom:18rpx ;">
									<text
										style="color: #FFFFFF;font-size:26rpx ;font-weight: 400;">{{item.content}}</text>
								</view>
							</view>
						</view>
						<view class="item_bottom">
							<view class="item_1" @click="handleRouter(item.app_id)">
								<image class="item_1" :src="item.game.new_icon||item.game.icon" mode="widthFix"></image>
							</view>
							<view class="item_2">
								<text class="item_2_text1">{{item.game.name}}</text>
								<view class="item_2text">
									<text class="item_2_text2">截止时间：{{item.end_time|dateFormat('yyyy-MM-dd')}}</text>
									<text class="item_2_text2">|</text>
									<text class="item_2_text2">{{item.popularity_cnt}}在玩</text>
								</view>

							</view>
							<view class="item_3" v-if="item.is_complete==1">
								<text v-if="item.is_recevie==1" class="item_3_text" style="color:#666">已领取</text>
								<text v-else @click="handleClick(item)" class="item_3_text"
									style="color:#19BFFF">未领取</text>
							</view>
							<view class="item_3" v-if="item.is_complete==2" @click="handleRouter(item.app_id)">
								<text class="item_3_text" style="color:#19BFFF">试 玩</text>
							</view>
						</view>
					</view>
				</view>
				<u-loadmore :status="status" loading-text="努力加载中" loadmore-text="加载更多" nomore-text="没有更多了"
				 fontSize="28" line height="80" iconColor="#ff5927"  iconSize="48" loadingIcon="circle" style="padding-bottom: 40rpx;" />
			</view>
			<vue-loading :isNoData="isNoData" v-else duration="500"></vue-loading>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isNoData: false,
				pageData: [],
				totalCount: 0,
				formData: {
					page: 1,
					offset: 15
				},
				status: "loadmore"
			}
		},
		methods: {
			getpageData(data = false) {
				this.$api.get('/task/listgame', {
					client_id: this.$store.state.client_id,
					...this.formData
				}).then(res => {
					console.log(res);
					if(res.data.data&&res.data.data.list) {
						this.pageData = this.pageData.concat(res.data.data.list)
						this.totalCount = res.data.data.count
						this.status = "loadmore"
					}
					if(!res.data.data.count) {
						this.isNoData = true
					}
					if (this.pageData.length >= this.totalCount) {
						this.status = "nomore"
					}
				})
			},
			// 加载更多数据
			getMoreData() {
				console.log('触底');
				if (this.totalCount > this.pageData.length && this.status == "loadmore") {
					this.status = "loading"
					this.formData.page++
					this.getpageData()
				}
			},
			handleRouter(id){
				if(this.$common.isLogin()){
					uni.navigateTo({
						url: `/pages/view/gameDetail/gameDetail?gameId=${id}`
					})
				}
			},
			handleClick(item) {
				this.$api.get("/task/receive",{task_id: item.id}).then(res => {
			    if (res.data.code == 200) {
					uni.showToast({
						icon: 'none',
						title: '领取成功' + ',' + (item.reward_type == 1 ? '积分' : item.reward_type == 2 ?
						'平台币' : '现金红包') + '＋' + item.reward_amount,
						success: () => {
							this.formData.page = 1
							this.pageData = []
							setTimeout(() => {
							this.$common.getuserInfo()
							this.getpageData(true)
						  }, 100)
						}
					})		
			    } else {
						uni.showToast({
							icon: 'none',
							title: res.data.msg
						})
					}		
				})
			},
		},
		created() {
			this.getpageData()
		},
	}
</script>

<style lang="scss">

	.demoGame {
		background-color: #fff;
		.lineShowdow {
			height: 4rpx;
			background-image: linear-gradient(to top, rgba(255, 255, 255, 0.1), rgba(160, 160, 160, 0.1));
		}

		.game-list {
			padding: 0 32rpx;
			box-sizing: border-box;
			.head {
				padding: 48rpx 0;
			}

			.str {
				margin-bottom: 26rpx;
				font-size: 24rpx;
				color: #666666;
			}

			.bottom_item {
				.item_head {
					position: relative;
					height: 384rpx;
					border-radius: 20rpx;

					.item_img {
						display: block;
						position: relative;
						width: 100%;
						height: 384rpx;
						border-radius: 20rpx;
					}

					.blurs {
						display: flex;
						position: absolute;
						bottom: 0;
						background: rgba(0, 0, 0, 0);
						height: 66rpx;
						border-radius: 20rpx;
						background-image: linear-gradient(to top, rgba(0, 0, 0, .8), rgba(255, 255, 255, 0.1));
					}

					.blursIos {
						/* border: 1px  solid red; */
						display: flex;
						position: absolute;
						bottom: 0;
						background: rgba(0, 0, 0, 0);
						height: 66rpx;
						border-radius: 20rpx;
						background-image: linear-gradient(to top, rgba(0, 0, 0, .8), rgba(255, 255, 255, 0.1));
					}
				}

				.item_bottom {
					position: relative;
					display: flex;
					align-items: center;
					margin-top: 24rpx;
					margin-bottom: 80rpx;
				}

				.item_1 {
					width: 88rpx;
					height: 88rpx;
					border-radius: 24rpx;
				}

				.item_2 {
					margin-left: 16rpx;
				}

				.item_2_text1 {
					color: #1C1C1C;
					font-size: 32rpx;
					font-weight: 600;
				}

				.item_2text {
					display: flex;
					margin-top: 10rpx;
				}

				.item_2_text2 {
					margin-right: 16rpx;
					color: #666666;
					font-size: 26rpx;
					font-weight: 400;
				}

				.item_3 {
					position: absolute;
					right: 0;
					top: 24rpx;
					height: 48rpx;
					padding: 6rpx 24rpx;
					border-radius: 24rpx;
					border: 1rpx solid #E4E4E4;
					justify-content: center;
				}

				.item_3_text {
					color: #19BFFF;
					font-weight: 600;
					font-size: 26rpx;
				}

				.refreshImages {
					display: flex;
					justify-content: center;
				}
			}
		}
	}
</style>
