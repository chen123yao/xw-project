<template>
	<view class="integral-task">
		<!-- 顶部大图 -->
		<view class="banner">
			<image src="@/static/images/getMoney/rwzx-banner.png" mode="scaleToFill" style="height: 380rpx;width: 100%;display: block;"></image>
			<view class="myjf">
				<text class="myjf_text" style="font-weight: 700;font-size: 32rpx;">当前剩余积分</text>
				<view class="jfrouter" @click="handlerRouter('/pages/my/integral/integral')">
					<text class="myjf_text" style="font-weight: 900;font-size: 48rpx;">{{userInfo.my_integral}}</text>
					<text class="myjf_text" style="margin: 0 6rpx;font-weight: 700;font-size: 32rpx;">积分</text>
					<view  class="icon">
						<image src="@/static/images/getMoney/right_white.png" style="width: 25rpx;height: 25rpx;"></image>
					</view>
				</view>
			</view>
			<view class="btn" @click="handlerRouter('/pages/getMoney/taskCenter/signRule')">
				任务规则
			</view>
		</view>
		<!-- 签到 -->
		<view class="qdjf">
			<view class="qdjf_tit">
				<text class="title">已连续签到</text>
				<text style="color: #FF5927;font-size: 38rpx;">{{userInfo.continuous_sign}}</text>
				<text class="title">天,明天签到+2积分</text>
			</view>
			<view class="qdjf_body">
				<view class="qdjf_item" v-for="(item,index) in 7" :key='index'>
					<view class="" style="display: flex;align-items: center;justify-content:">
						<view class="qdjf_raidus" :style="{borderColor:index<(userInfo.continuous_sign&&userInfo.continuous_sign%7==0?7:userInfo.continuous_sign%7)?'#FF5927':'#999'}">
							<image src="@/static/images/getMoney/yes_icon.png" v-if="index<(userInfo.continuous_sign&&userInfo.continuous_sign%7==0?7:userInfo.continuous_sign%7)" mode="widthFix" style="width: 28rpx;height: 28rpx;"></image>
							<text class="text" v-else>+{{index+1}}</text>
						</view>
						<view class="qdjf_line" v-if="index<6" :style="{backgroundColor:index<(userInfo.continuous_sign&&userInfo.continuous_sign%7==0?7:userInfo.continuous_sign%7)?'#FF5927':'#999'}"></view>
					</view>
					<text class="text" v-if="index==((pageData&&pageData.daily.list[0].finish_flag ==1)?(userInfo.continuous_sign&&userInfo.continuous_sign%7==0?7:userInfo.continuous_sign%7) : (userInfo.continuous_sign&&userInfo.continuous_sign%7==0?7:userInfo.continuous_sign%7)-1)" >今天</text>
					<text class="text" v-else-if="(userInfo.continuous_sign&&userInfo.continuous_sign%7==0?7:userInfo.continuous_sign%7)" >{{new Date()/1000+(86400*(index+((pageData&&pageData.daily.list[0].finish_flag ==1)?0 : 1)-(userInfo.continuous_sign&&userInfo.continuous_sign%7==0?7:userInfo.continuous_sign%7)))|dateFormat('MM.dd')}}</text>
					<text class="text" v-else style="margin-left: -8rpx;">{{new Date()/1000+(86400*index)|dateFormat('MM.dd')}}</text>
				</view>
			</view>
		</view>
		<!-- 日常任务 -->
		<view class="rcrw" style="margin-bottom: 24rpx;">
			<text class="title">日常任务</text>
			<view class="rcrw_body" v-if="pageData">
				<view class="rcrw_item" v-for="(item,index) in pageData.daily.list" :key='index'>
					<view class="left">
						<image :src="/http/.test(item.icon)?item.icon:'https:'+item.icon" mode="widthFix" style="width: 60rpx; height: 60rpx;"></image>
					</view>
					<view class="right" style="margin-left: 32rpx;">
						<view>
							<view class="right_title">{{item.ia_name}}</view>
							<view class="text">{{item.ia_desc}}</view>
						</view>
						<view>
							<text v-if="item.ia_code == 'sign'" @click="signIn(item.finish_flag)"	:class="{active:item.finish_flag==2}" class="button">{{item.finish_flag == 1 ? '领&emsp;取' : '已完成'}}</text>
							<text v-else class="button" @click="handleClick(item.finish_flag,item.ia_id)" :class="{active:item.finish_flag==2}">{{item.finish_flag == 1 ? '去完成' : '已完成'}}</text>
						</view>
					</view>
				</view>
			</view>
		</view>
		<!-- 新手任务 -->
		<view class="rcrw">
			<text class="title">新手任务</text>
			<view class="rcrw_body" v-if="pageData">
				<view class="rcrw_item" v-for="(item,index) in pageData.one.list" :key='index'>
					<view class="left">
						<image :src="/http/.test(item.icon)?item.icon:'https:'+item.icon" mode="widthFix" style="width: 60rpx; height: 60rpx;"></image>
					</view>
					<view class="right" style="margin-left: 32rpx;">
						<view>
							<view class="right_title">{{item.ia_name}}</view>
							<view class="text">{{item.ia_desc}}</view>
						</view>
						<view>
							<text class="button" :class="{active:item.finish_flag==2}"	@click="handleClick(item.finish_flag,item.ia_id)">{{item.finish_flag == 1 ? '去完成' : '已完成'}}</text>
						</view>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
			data() {
				return {
					pageData: null
				}
			},
			computed: {
				userInfo() {
					return this.$store.state.userInfo
				},
				loginInfo() {
					return this.$store.state.loginInfo
				}
			},
			methods: {
				//路由跳转
				handlerRouter(url) {
					if(this.$common.isLogin()){
						uni.navigateTo({
							url
						})
					}
				},
				// 获取数据
				getpageData() {
					this.$api.get("app/integral/task/home", ).then(res => {
						this.pageData = res.data.data;
						console.log(res)
					})
				},
				// 签到
				signIn(type) {
					if (type ==1 && this.$common.isLogin()) {
					   this.$api.get("user/sign/add", {
							token: this.$store.state.user_token
						}).then(res => {
							console.log(res);
							this.getpageData();
							uni.showToast({
								title: '签到成功！',
								icon: 'none',
								success: () => {
									setTimeout(() => {
										this.$common.getuserInfo()
									}, 200)
								}
							})
				
						})
					}
				},
				//任务跳转
				handleClick(type, ia_id) {
					console.log('type: ', type, 'ia_id: ', ia_id);
					
					if (type == 1) {
						switch (ia_id) {
							// 每日新游
							case 27:
								uni.navigateTo({
									url: `/pages/index/children/specialDetail?specialName=每日新游&specialId=3`
								})
								break;
							case 5:
							case 24:
							case 25:
								uni.switchTab({
									url: `/pages/gameList/index`
								})
								break;
							case 26:
								uni.navigateTo({
									url: `/pages/customerService/index`,
								})
								break;
							case 2:
							case 23:
							case 9:
							case 7:
								uni.navigateTo({
									url: `/pages/my/myAdministration/index`
								})
								break;
						}
					}
				},
			},
			created(){
				this.getpageData()
			},
			mounted() {
				uni.$on('refreshTaskCenter', () => {
					this.getpageData()
				})
			},
			onShow() {
				this.getpageData()
			}
		}
</script>

<style lang="scss">
	.integral-task {
		.text {
			font-size: 26rpx;
			color: #999;
		}
		.button {
			padding:8rpx 18rpx;
			border-radius: 32rpx;
			border: 1px solid #efefef;
			color: #FF5927;
			font-weight: 700;
			font-size: 26rpx;
			lines: 1;
		}
		.banner {
			position: relative;
			.myjf {
				position: absolute;
				left: 32rpx;
				top: 50%;
				transform: translateY(-50%);
				font-size: 32rpx;
				.myjf_text{
				  color: #fff;
				}
				.jfrouter {
					display: flex;
					align-items: center;
					justify-content: flex-start;
				}
			}
			.btn {
				position: absolute;
				right: 0;
				top: 50rpx;
				padding: 0 6rpx 0 30rpx;
				line-height: 56rpx;
				height: 60rpx;
				color: #FAF7F3;
				text-align: right;
				background-color:#879fb4;
				border-top-left-radius: 40rpx;
				border-bottom-left-radius: 40rpx;
			}
		}
		.qdjf {
			padding: 40rpx 32rpx;
			background-color: #fff;
			margin-bottom: 20rpx;
			.qdjf_tit {
				display: flex;
				align-items: center;
				margin-bottom: 24rpx;
			}
			.qdjf_body {
				display: flex;
				align-items: center;
				font-size: 26rpx;
				color: #999;
				.qdjf_raidus {
					display: flex;
					align-items: center;
					justify-content: center;
					width: 50rpx;
					height: 50rpx;
					border: 1px solid #CECECE;
					border-radius: 50rpx;
					margin-bottom: 10rpx;
				}
				.qdjf_line {
					margin-left: 4rpx;
					width: 50rpx;
					height: 4rpx;
					background-color: #CECECE;
				}
			}
		}
		.rcrw {
			padding: 20rpx 32rpx;
			background-color: #fff;
			.title {
				color: #1C1C1C;
				font-weight: 700;
				font-size: 32rpx;
				/* margin-bottom: 20rpx; */
			}
			.rcrw_body{
				margin-top: 32rpx;
				.rcrw_item {
					display: flex;
					align-items: center;
					justify-content: flex-start;
					margin-bottom: 40rpx;
					.right {
						display: flex;
						flex: 1;
						padding-bottom: 20rpx;
						justify-content: space-between;
						border-bottom:1px solid #efefef ;
						.right_title {
							font-weight: 700;
							font-size: 32rpx;
							margin-bottom: 4rpx;
						}
					}
				}
			}
		}
	}
	
	.text {
		font-size: 26rpx;
		color: #999;
	}
	
	.active {
		background-color: #C1C1C1 !important;
		color: #fff !important;
		border: 1px solid #C1C1C1 !important;
	}
</style>
