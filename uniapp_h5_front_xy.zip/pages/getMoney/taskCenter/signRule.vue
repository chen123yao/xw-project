<template>
	<view class="signRule">
		<view class="signRule-topTitle">
			<view class="signRule-topTitle-box">
				<view class="signRule-topTitle-box-left">
					<image class="signRule-topTitle-box-left-img" src="@/static/images/left.png" mode="heightFix" @click="back" />
					<text class="signRule-topTitle-box-left-text">积分记录</text>
				</view>
			</view>
		</view>
		
		<view class="signRule-content">
			<view class="myshadowLine" v-if='$store.state.platform=="ios"'/>
			<view class="myshadowLineAnd" v-else elevation="5rpx"/>
			<view class="body">
				<text class="title" style="margin-bottom: 32rpx;">规则</text>
				 <text class="title1">1. 签到领积分：同一账号每天可签到1次，签到可以获 得平台积分，积分直接发放至用户账号；根据用户连续签到的天数，每日积分发放数不同。 </text>
				 <text class="title1">2. 连续签到规则： </text>
				 <view  style="margin-bottom: 32rpx;">
					<text class="text">1）当连续签到天数小于7天时，签到首日可得1个积分，每日递增1个积分；</text>
					<text class="text">2）当连续签到天数达到7天以上时，每日可得7个积分；</text>
					<text class="text">3）若用户断签，则重新开始计算连续签到天数。</text>
				 </view>
				 <text class="title1">3. 举例：</text>
				 <text class="text" style="margin-bottom: 32rpx;">您连续签到10天，则每日可获积分数分别为1，2,  3，4，5, 6，7；若第11天断签，则第12天签到时，重新计算签到天数，发放1个积分。</text>
				 <text class="title" style="margin-bottom: 32rpx;">其他说明</text>
				 <view class="">
					<text class="title1">1.每日签到+1积分，连续签到翻倍，单日+30封顶  </text>
					<text class="title1">2.如用户存在违规刷积分行为，我们有权取消用户获得积分的资格，已领取的积分将被扣回。</text>
				 </view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		methods: {
			back() {
				uni.navigateBack()
			},
		}
}
</script>

<style  lang="scss">
	.signRule {
		&-topTitle {
			position: fixed;
			// background-color: #FFFFFF;
			background: linear-gradient(to bottom, #CCCCCC, #FFFFFF env(safe-area-inset-top));
			z-index: 999;
			top: 0;
			width: 750rpx;
			height: 176rpx;
			padding: 0 34rpx 16rpx;
			box-sizing: border-box;
			display: flex;
			flex-direction: column;
			justify-content: flex-end;
			box-shadow: 0rpx 0rpx 12rpx rgba(0, 0, 0, 0.16);
			
			&-box {
				box-sizing: border-box;
				display: flex;
				flex-direction: row;
				justify-content: space-between;
				align-items: center;
				
				&-left {
					display: flex;
					flex-direction: row;
					align-items: center;
					
					&-img {
						height: 34rpx;
					}
					
					&-text {
						margin-left: 48rpx;
						font-size: 40rpx;
						line-height: 56rpx;
						font-family: PingFang SC;
						font-weight: 600;
						color: #1C1C1C;
					}
				}
			}
		}
		
		&-content {
			width: 750rpx;
			padding: 176rpx 0 0;
			box-sizing: border-box;
			color: #1C1C1C;
			font-family: PingFang SC;
			min-height: 100vh;
			
			.text{
					display: block;
					font-size: 28rpx;
			}
			.signRule {
				padding-top: 44px;
				flex: 1;
				overflow: hidden;
				background-color: #fff;
			}
			.title{
				display: block;
				color: #1C1C1C;
				font-weight: 700;
				font-size: 34rpx;
			}
			.title1{
				display: block;
				color: #1C1C1C;
				font-weight: 600;
				font-size: 32rpx;
				margin-bottom: 24rpx;
			}

			.body {
				padding: 0 32rpx;
			}

			.myshadowLine {
				width: 100%;
				height: 0;
				box-shadow: 0px 0px 8rpx 0px rgba(210, 210, 210, 0.8);
				margin-bottom: 60rpx;
			}
			.myshadowLineAnd {
				width: 100%;
				height: 0;
				margin-bottom: 60rpx;
			}
		}
	}
</style>
