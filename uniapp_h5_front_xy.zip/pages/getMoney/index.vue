<template>
	<view class="get-money" :style="{paddingTop:$store.state.statusBarHeight+140+'rpx'}">
		<view class="top-box" :style="{height:$store.state.statusBarHeight+140+'rpx'}">
			<view class="safeArea-box" :style="{height:$store.state.statusBarHeight+'rpx'}"></view>
			<vue-topBar left_url="/pages/view/search/search" right_url="/pages/my/myMessage/index" :topBarStyle="topBarStyle"></vue-topBar>
			<view class="nav-tabs">
				<u-tabs :list="TitleList" @click="click"  lineWidth="60rpx" lineHeight="2px" lineColor="#ff5927" :activeStyle="{color: '#ff5927',fontWeight: 'bold'}" 
				:inactiveStyle="{color: '#1c1c1c'}" :current="active" itemStyle="padding-left: 15px; padding-right: 15px; height: 70rpx;"></u-tabs>
			</view>
		</view>
			<taskCenter ref="taskCenter1" v-if="0==active"></taskCenter>
			<demoGame ref="demoGame" v-else-if="1==active"></demoGame>
			<bigTurntable v-else></bigTurntable>
	</view>
</template>

<script>
	import taskCenter from '@/pages/getMoney/taskCenter/index'
	import demoGame from '@/pages/getMoney/demoGame/index'
	import bigTurntable from '@/pages/getMoney/bigTurntable/index'
	export default {
		components: {
			taskCenter,
			demoGame,
			bigTurntable
		},
		data() {
			return {
				topBarStyle: {
					searchColor: '#c1c1c1',
					textColor: '#c1c1c1',
					bellColor: '#000',
				},
				TitleList: [{
						id: 0,
						name: '积分任务'
					},
					{
						id: 1,
						name: '试玩赚金'
					},
					{
						id: 2,
						name: '幸运转盘'
					},
				],
				isActive: false,
				active: 0,
			}
		},
		methods: {
			click(item) {
					// console.log('item', item);
					this.active = item.id
					uni.setStorage({
						key:'active',
						data:this.active
					})
					console.log('active: ', this.active)
			},
			swiperChange(e) {
				this.active = e.detail.current
				uni.setStorage({
					key:'active',
					data:this.active
				})
				console.log('active: ', this.active);
			},
		},
		onPullDownRefresh() {
			if(!this.active) {
				setTimeout(() => {
					uni.stopPullDownRefresh();
				}, 500);
			} else if (1 == this.active) {
				this.$refs.demoGame.pageData = []
				this.$refs.demoGame.formData.page = 1
				setTimeout(() => {
					this.$refs.demoGame.getpageData()
					uni.stopPullDownRefresh();
				}, 500);
			} else {
				setTimeout(() => {
					uni.stopPullDownRefresh();
				}, 500);
			}
		},
		onReachBottom() {
			if(this.$refs.demoGame) {
				this.$refs.demoGame.getMoreData()
			}
		},
		onShow() {
			uni.getStorage({
				key:'active',
				success:(res)=>{
					this.active = res.data
				}
			})
			
			if(this.active == 0) {
				uni.$emit('refreshTaskCenter')
			}
			
		}
	}
</script>

<style lang="scss">
	.get-money {
		padding-top: 140rpx;
		box-sizing: border-box;
	.top-box {
			position: fixed;
			left: 0;
			top: 0;
			width: 100%;
			background-color: #fff;
			z-index: 999;
			.safeArea-box {
				background: linear-gradient(to bottom, #CCCCCC, #fff 100%);
			}
			.nav-tabs {
				width: 100%;
				height: 84rpx;
				padding-top: 10rpx;
				::v-deep .u-tabs__wrapper__nav__item {
					flex: 1;
				}
			}
		}

		.swiper {
			height: 100%;
			display: flex;
			align-items: center;
			justify-content: center;
		}
	}
</style>
