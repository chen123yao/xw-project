<template>
	<view class="bigTurntable">
		<image src="@/static/images/getMoney/bigturntablebgi1.png" mode="scaleToFill" class="turntable-img"></image>
		<view class="integral-record" @click="handlerRouter('/pages/my/integral/integral')">积分记录</view>
		<view class="big-title">
			<text class="dzpjh" v-if="is_free==1">您有一次免费抽奖机会</text>
			<text class="dzpjh" v-else>您今天免费次数已用完</text>
			<view class="my_integral">我的积分：{{userInfo.my_integral}}</view>
			<view class="" style="display: flex;justify-content: center;margin-top: 30rpx;">
				<LotteryDraw class="trans" @click='handleShowClick' :grid_info_arr='grid_info_arr' :type='type'
					:order='order' @get_winingIndex='get_winingIndex' @luck_draw_finish='luck_draw_finish'>
				</LotteryDraw>
			</view>
		</view>
		<u-modal :show="show" title="" :showConfirmButton="false" class="modal_box">
			<view class="slot-content">
				<!-- 兑换抽奖机会 -->
				<view class="dzp-tc" v-if="handleShow"
					style="display: flex;align-items: center; justify-content: center;width:750rpx;height:600rpx">
					<image src="@/static/images/getMoney/dzp-tck.png" mode="scaleToFill"
						style="display:block;width:100%;height:600rpx"></image>
					<view class="dzp-tc-content">
						<image src="@/static/images/getMoney/dzp-jf.png" mode="widthFix" style="width:100rpx;" />
						<text class="dzp-tc-content-text1" v-if="is_free==2">幸运大转盘一次抽奖</text>
						<text class="dzp-tc-content-text1" v-else>幸运大转盘免费一次抽奖</text>
						<text class="dzp-tc-content-text2" v-if="is_free==2">您将消耗50积分</text>
						<text class="dzp-tc-content-text2" v-else>您本次不消耗积分</text>
						<view v-if="userInfo.my_integral<50&&is_free==2">
							<text class="dzp-tc-content-text3">您的积分不足，快去完成任务赚钱吧</text>
						</view>
						<view class="dzp-tc-content-text4">
							<text class="buttons" style="color: #1C1C1C;margin-right: 24rpx;"
								@click="show=false;">我再想想</text>
							<text class="buttons"
								:style="{color:userInfo.my_integral<50&&is_free==2?'#1C1C1C':'#ff5927'}"
								@click="handleClick">确认兑换</text>
						</view>
					</view>
				</view>
				<!-- 未中奖 -->

				<view class="dzp-tc" v-else-if="order.is_win==2"
					style="display: flex;align-items: center; justify-content: center;width:750rpx;height:600rpx">
					<image src="@/static/images/getMoney/dzp-wzj.png" mode="scaleToFill"
						style="display:block;width:100%;height:600rpx"></image>

					<view class="dzp-tc-content">
						<image src="@/static/images/getMoney/0.png" mode="widthFix"
							style="width:200rpx;height: 300rpx" />
						<text class="dzp-tc-content-xx"
							style="color: #999;font-size: 32rpx;margin-bottom:12rpx">{{order.prize_name}}</text>
						<view class="" style="display: flex; justify-content: center;">
							<text class="buttons" @click="handleNo" style="margin-bottom: 5rpx;">再来一次</text>
						</view>

					</view>
				</view>
				<!-- 中奖 -->

				<view class="dzp-tc" v-else
					style="display: flex;align-items: center; justify-content: center;width:750rpx;height:600rpx">
					<image src="@/static/images/getMoney/dzp-zj.png" mode="scaleToFill"
						style="display:block;width:100%;height:600rpx"></image>
					<view class="dzp-tc-content">
						<image :src="order.prize_img" mode="widthFix"
							style="width:200rpx;height:120rpx;margin-top: 48rpx;" />
						<text
							style="margin:10rpx 0;color: #ff5927;font-size: 32rpx;font-weight: 700;">{{order.prize_name}}</text>
						<view class="" style="display: flex; justify-content: center;">
							<text class="buttons" style="color: #FF5927;" @click="handleReceive">立即领取</text>
						</view>
					</view>
				</view>

			</view>
		</u-modal>
	</view>
</template>

<script>
	import LotteryDraw from '@/components/SJ-LotteryDraw/SJ-LotteryDraw.vue';
	export default {
		components: {
			LotteryDraw,
		},
		data() {
			return {
				is_free: 1,
				bigShow: true,
				show: false,
				handleShow: true,
				order: "",
				type: 1,
				timeer: 0,
				grid_info_arr: [],
				lottery_draw_param: {
					startIndex: 0, //开始抽奖位置，从0开始
					totalCount: 4, //一共要转的圈数
					winingIndex: 0, //中奖的位置，从0开始
					speed: 100, //抽奖动画的速度 [数字越大越慢,默认100]
					domData: [] //长度为九的数组
				}
			}
		},
		computed: {
			userInfo() {
				return this.$store.state.userInfo
			},
			myWidth() {
				return uni.getSystemInfoSync().windowWidth
			},
		},
		methods: {
			getPrizeList() {
				//请求奖品列表
				this.$api.get("app/shop/big_wheel_list").then((res) => {
					console.log(res)
					this.is_free = res.data.data.is_free;
					this.grid_info_arr = res.data.data.list.sort((a, b) => {
						return a.prize_order - b.prize_order;
					});
					this.grid_info_arr.splice(4, 0, {
						prize_img: '../../../../static/images/cjbutton.png',
						prize_name: '抽奖'
					})
					this.lottery_draw_param.domData = this.grid_info_arr
				})
			},
			//确认抽奖显示
			handleShowClick() {
				if (!this.$common.isLogin()) return
				if (this.bigShow) {
					this.show = true;
					this.handleShow = true;
				}
			},
			//未中奖
			handleNo() {
				this.show = false
				// this.grid_info_arr = []
				this.type = 1
				this.bigShow = true
				// this.getPrizeList()
			
			},
			//确认兑换
			handleClick() {
				if (this.userInfo.my_integral<50&&this.is_free==2) {
					return
				}
				this.type = 2
				this.show = false;
				if (this.is_free == 2) {
					this.userInfo.my_integral = this.userInfo.my_integral - 50;
				}
				this.is_free = 2
			},
			//领取
			handleReceive() {
				uni.showToast({
					icon: "none",
					title: "领取成功！",
					success: () => {
						setTimeout(() => {
							this.$common.getuserInfo();
							// this.grid_info_arr = []
							this.type = 1
							// this.getPrizeList()
							this.show = false;
							this.bigShow = true
							setTimeout(() => {
								this.handleShow = true;
							}, 100);
						}, 200);
					},
				});
			},
			// 修改获奖位置（可以在这里获取后台的数据
			get_winingIndex(callback) {
				if (this.bigShow) {
					this.show = false;
					this.$api.get(
						"app/shop/lucky_draw", {
							is_free: this.is_free,
							mem_id: this.userInfo.mem_id,
						},
					).then((res) => {
						let index = 0
						let a = 0
						if (res.data.data.prize_order - 1 < 4) {

							index = res.data.data.prize_order - 1
						} else {
							index = res.data.data.prize_order - 1
						}

						this.order = res.data.data;
						this.handleShow = false;
						switch (index) {
							case 5:
								a = 6
								this.timeer = 2500
								break;
							case 3:
								this.timeer = 3000
								a = 7
								break;
							case 6:
								this.timeer = 2000
								a = 5
								break;
							case 4:
								this.timeer = 1000
								a = 3
								break;
							case 7:
								this.timeer = 1600
								a = 4
								break;
							default:
								this.timeer = 0
								a = index;
								break;
						}
						let timer = setTimeout(() => {
							this.show = true;
						}, 6000 + this.timeer);

						this.lottery_draw_param.winingIndex = a;
						callback(this.lottery_draw_param);
						this.bigShow = false

					});
				}
			},
			// 抽奖完成
			luck_draw_finish(param) {

			},
			handlerRouter(url) {
				if (!this.$common.isLogin()) return
				uni.navigateTo({
					url
				})
			}
		},
		created() {
			this.getPrizeList()
		}
	}
</script>

<style lang="scss">
	.bigTurntable {
		position: relative;
		.turntable-img {
			display: block;
			width: 100%;
			height: 1636rpx;
		}

		.integral-record {
			position: absolute;
			right: 0;
			top: 36rpx;
			width: 170rpx;
			padding-left: 20rpx;
			height: 60rpx;
			text-align: center;
			line-height: 60rpx;
			color: #FAF7F3;
			font-size: 30rpx;
			background-color: #FFC564;
			border-top-left-radius: 60rpx;
			border-bottom-left-radius: 60rpx;
		}

		.big-title {
			position: absolute;
			top: 462rpx;
			width: 100%;
			text-align: center;

			.dzpjh {
				color: #BF4137;
				font-size: 32rpx;
				font-weight: 700;
			}

			.my_integral {
				margin-top: 78rpx;
				color: #fff;
				font-size: 28rpx;
			}
		}

		.modal_box {
			::v-deep .u-popup__content {
				background-color: transparent;
			}

			::v-deep.u-line {
				border-bottom: none !important;
			}

			.dzp-tc {
				margin-top: 80rpx;

				.dzp-tc-content {
					display: flex;
					flex-direction: column;
					position: absolute;
					align-items: center;
					margin-top: 40rpx;
				}

				.dzp-tc-content-text1 {
					margin-top: 10rpx;
					font-size: 32rpx;
					font-weight: 700;
				}

				.dzp-tc-content-text2 {
					color: red;
					font-size: 32rpx;
					margin-bottom: 10rpx;
				}

				.dzp-tc-content-text3 {
					font-size: 26rpx;
					font-weight: 700;
				}

				.dzp-tc-content-text4 {
					display: flex;
					margin-top: 40rpx;
					flex-direction: row;
					align-items: center;
					justify-content: space-between;
				}

				.buttons {
					display: block;
					border: 1px solid #efefef;
					padding: 6rpx 36rpx;
					border-radius: 40rpx;
					font-size: 28rpx;
				}
			}
		}
	}
</style>
