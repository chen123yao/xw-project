<template>
	<view class="container">
		<!-- cc 游戏专题详情页面顶部标题 -->
		<view class="container-topTitle">
			<view class="container-topTitle-box">
				<view class="container-topTitle-box-left">
					<image class="container-topTitle-box-left-img" src="@/static/images/left.png" mode="heightFix" @click="back" />
					<text class="container-topTitle-box-left-text">返利申请</text>
				</view>
			
				<image class="container-topTitle-box-right" src="@/static/images/my_details.png" mode="heightFix" @click="handleRouter('/pages/customerService/children/rechargeRebate/children/applicatRecord',1)"C></image>
			</view>
		</view>
		
		<view class="container-content">
			<view class="content">
				<view class="inputs">
					<image src="@/static/images/search-gren.png" mode="widthFix" style="width: 30rpx;height: 30rpx;"></image>
					<input class="input" v-model="formData.game_name" type="text"  placeholder='去找你的想要的游戏'
						placeholder-style='font-size:28rpx;color:#c1c1c1'  @input='search'></input>
				</view>
				<view class="list" v-if="list.length">
					<view class="list-item" v-for="(item,index) in list" :key="index" @click="handleRouter(item,2)">
						<image :src="item.new_icon||item.icon" mode="scaleToFill" class="game-icon"></image>
						<view class="item-right" :style="index==list.length-1?'border:none;':''">
							<view class="text-box">
								<view class="game-name">{{item.name}}</view>
								<view class="game-area">当前对应区服：{{item.server_name}}</view>
								<view class="fanli-status">
									<text>当前返利状态：</text>
									<text class="text3" :style="{color:item.is_rebate==1?'#FC6170':item.is_rebate==2?'#2BC8F9':'#000'}">{{item.is_rebate==1?'可申请返利':item.is_rebate==2?'已申请返利':item.is_rebate==3?'不可申请返利':'返利已发放'}}</text>
								</view>
							</view>
							<u-icon name="arrow-right" color="#666" size="24" class="arrow-right"></u-icon>
						</view>
					</view>
					<u-loadmore :status="status" loading-text="努力加载中" loadmore-text="加载更多" nomore-text="没有更多了"
					 fontSize="28" line height="80" iconColor="#ff5927"  iconSize="48" loadingIcon="circle"	/>
				</view>
				<vue-loading :isNoData="isNoData" v-else></vue-loading>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				formData: {
					game_name: '',
					page: 1,
					list_rows: 15
				},
				status: 'loadmore',
				list: [],
				isNoData: false
			}
		},
		methods: {
			back() {
				uni.navigateBack()
			},
			handleRouter(data,type) {
				if(type==1) {
					if(this.$common.isLogin()){
						uni.navigateTo({
							url: data
						})
					}
				} else {
					if(data.is_rebate==1){
						uni.navigateTo({
							url: `/pages/customerService/children/rechargeRebate/children/applicationform?game_id=${data.app_id}&role_id=${data.role_id}&game_name=${data.name}`
						})
					}
				}
			},
			search() {
				this.list = []
				this.count = 0
				this.formData.page = 1
				this.getPageData(2)
			},
			getPageData(type=1) {
				if (this.formData.game_name == ''||this.formData.game_name == ' ') {
					delete this.formData.game_name
				}
				this.$api.get('rebate/list',{...this.formData}).then(res => {
					if (res.data.code == 200) {
						this.status="loadmore"
						if(type==2) {
							this.list = res.data.data.list
						} else {
							this.list = this.list.concat(res.data.data.list)
						}
						this.count = res.data.data.count
						if(this.list.length>=this.count) {
							this.status="nomore"
						}
						if (!this.count) {
							this.isNoData = true
						}
					}
				})
			},
		},
		onLoad() {
			this.getPageData()
		},
		onReachBottom() {
			if(this.count>this.list.length&&this.status=="loadmore") {
				this.status = "loading"
				this.formData.page++
				this.getPageData()
			}
		}
	}
</script>

<style lang="scss">
	.container {
		background-color: #FFFFFF;
		width: 750rpx;
		height: 100vh;
		
		&-topTitle {
			position: fixed;
			// background-color: #FFFFFF;
			background: linear-gradient(to bottom, #CCCCCC, #FFFFFF env(safe-area-inset-top));
			z-index: 999;
			top: 0;
			width: 750rpx;
			height: 176rpx;
			padding: 0 34rpx 16rpx;
			box-sizing: border-box;
			display: flex;
			flex-direction: column;
			justify-content: flex-end;
			box-shadow: 0rpx 0rpx 12rpx rgba(0, 0, 0, 0.16);
			
			&-box {
				box-sizing: border-box;
				display: flex;
				flex-direction: row;
				justify-content: space-between;
				align-items: center;
				
				&-left {
					display: flex;
					flex-direction: row;
					align-items: center;
					
					&-img {
						height: 34rpx;
					}
					
					&-text {
						margin-left: 48rpx;
						font-size: 40rpx;
						line-height: 56rpx;
						font-family: PingFang SC;
						font-weight: 600;
						color: #1C1C1C;
					}
				}
				
				&-right {
					display: block;
					width: 35rpx;
					height: 35rpx;
				}
			}
		}
		
		&-content {
			width: 750rpx;
			padding: 205rpx 0 0;
			box-sizing: border-box;
			color: #1C1C1C;
			font-family: PingFang SC;
			min-height: 100vh;
			
			.content {
				padding: 32rpx;
				.inputs {
					display: flex;
					align-items: center;
					background-color: #F4F4F4;
					border-radius: 40rpx;
					padding: 12rpx 32rpx;
					margin-bottom: 15rpx;
					.input {
						flex: 1;
						font-size: 28rpx;
						margin-left: 12rpx;
					}
				}
				.list {
					.list-item {
						display: flex;
						padding-top: 48rpx;
						.game-icon {
							width: 160rpx;
							height: 160rpx;
							margin-right: 24rpx;
						}
						.item-right {
							flex: 1;
							display: flex;
							height: 160rpx;
							align-items: center;
							justify-content: space-between;
							padding-bottom: 48rpx;
							border-bottom: 2rpx solid #efefef;
							font-size: 24rpx;
							.game-name {
								padding-top: 10rpx;
								font-size: 28rpx;
								font-weight: 500;
								line-height: 20px;
								white-space: nowrap;
								color: #1C1C1C;
							}
							.game-area {
								margin: 16rpx 0;
								font-weight: 400;
								line-height: 34rpx;
								color: #666666;
							}
							.fanli-status {
								line-height: 34rpx;
								color: #666;
							}
						}
					}
				}
			}
		}
	}
</style>