<template>
	<view class="container">
		<view class="top-bar">
			<view class="bar-left" @click="toback">				
				<u-icon name="arrow-left" color="#000" size="42" class="arrow-left"></u-icon>
				<text>申请填写</text>
			</view>
			<view class="bar-right">
				<image src="@/static/images/customerService/time.png" mode="widthFix" @click="handleRouter('/pages/customerService/children/rechargeRebate/children/guide',1)" class="right-icon"></image>
			</view>
		</view>
		<view class="content">
			<view class="input-box">
				<view class="input-text1">游戏名</view>
				<view class="input-text2">{{game_name}}</view>
			</view>
			<view class="input-box">
				<view class="input-text1">充值小号</view>
				<view class="input-text2">{{formData.nickname}}</view>
			</view>
			<view class="input-box">
				<view class="input-text1">游戏角色</view>
				<view class="input-text2">{{formData.role_name}}</view>
			</view>
			<view class="input-box">
				<view class="input-text1">角色ID</view>
				<view class="input-text2">{{formData.role_id}}</view>
			</view>
			<view class="input-box">
				<view class="input-text1">游戏区服</view>
				<view class="input-text2">{{formData.server_name}}</view>
			</view>
			<view class="input-box">
				<view class="input-text1">充值金额</view>
				<view class="input-text2">{{formData.money}}</view>
				<view style="color: #666;">元</view>
			</view>
			<view class="input-box">
				<view class="input-text1">申请档位内容</view>
				<view style="flex: 1;overflow: hidden;">
					<textarea v-model="formData.gear_content" :auto-height="true" :maxlength="100" class="input2" type="text"  placeholder="请按照返利表格里的档位内容填" placeholder-style="font-size:28rpx;"/>
				</view>
			</view>
			<view class="input-box" style="height: 155rpx;align-items: flex-start;padding-top: 16rpx;">
				<view class="input-text1">备注</view>
				<view style="flex: 1;overflow: hidden;height: 100%;">
					<textarea v-model="formData.content" :maxlength="50" class="input2" type="text"  placeholder="选填，50字以内" placeholder-style="font-size:28rpx;"/>
				</view>
			</view>
			<view class="button" @click='handleSub'>确认信息无误，提交申请</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				game_id: '',
				role_id: '',
				game_name: '',
				formData: {
					content: '',
					gear_content:''
				}
			}
		},
		methods: {
			toback() {
				uni.navigateBack()
			},
			handleRouter(url) {
				uni.navigateTo({
					url
				})
			},
			getDetailData() {
				this.$api.get('rebate/getRoleData',{
						role_id: this.role_id,
						game_id: this.game_id
				}).then(res => {
					if (res.data.code == 200) {
						this.pageData = res.data.data[0]
						this.formData = {
							...this.pageData
						}
					}
				})
			},
			//提交
			handleSub() {
				this.formData.game_id = this.game_id
				this.$api.get('rebate/addRebate',{	...this.formData})
				.then(res => {
					 if(res.data.code == 200) {
						uni.showToast({
							title: '申请成功',
							success: () => {
								setTimeout(() => {
									uni.navigateBack({
										delta: 1
									})
								}, 300)
							}
						})
					}else{
						uni.showToast({
							title: res.data.msg,
							icon:'none'
						})
						return
					}
				})
			},
		},
		onLoad(option) {
			this.role_id = option.role_id
			this.game_id = option.game_id
			this.game_name = option.game_name
			this.getDetailData()
		},
	}
</script>

<style lang="scss">
	.container {
		padding-top: 88rpx;
		.top-bar {
			position: fixed;
			left: 0;
			top: 0;
			width: 100%;
			padding: 0 32rpx 0 16rpx;
			display: flex;
			align-items: center;
			justify-content: space-between;
			height: 88rpx;
			box-sizing: border-box;
			font-size: 16px;
			color: #000;
			background-color: #fff;
			box-shadow: 0px 0px 5px 0px rgba(221,221,221,0.8);
			z-index: 99;
			.bar-left {
				display: flex;
				justify-content: center;				
				.arrow-left {
					margin-right: 32rpx;
				}
			}
			.right-icon {
				display: block;
				width: 35rpx;
				height: 35rpx;
			}
		}
		
		.content {
			padding: 40rpx 36rpx 0;
			.input-box {
				display: flex;
				align-items: center;
				height: 72rpx;
				padding: 0 24rpx;
				margin-bottom: 40rpx;
				font-size: 28rpx;
				background: rgba(255,255,255,0.39);
				border: 2rpx solid #E4E4E4;
				box-sizing: border-box;
				border-radius: 36rpx;
				.input-text1 {
					width: 200rpx;
					min-width: 200rpx;
					white-space: nowrap;
					font-weight: 600;
					color: #1C1C1C;
				}
				.input-text2 {
					flex: 1;
					font-weight: 400;
					color: #1C1C1C;
				}
			}
			.button {
				height: 80rpx;
				text-align: center;
				line-height: 76rpx;
				font-size: 28rpx;
				color: #ff5927;
				background: rgba(255,255,255,0.39);
				border: 2rpx solid #E4E4E4;
				box-sizing: border-box;
				border-radius: 40rpx;
			}
		}
	}
</style>