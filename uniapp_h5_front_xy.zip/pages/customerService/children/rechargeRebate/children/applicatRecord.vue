<template>
	<view class="container">
		<view class="container-topTitle">
			<view class="container-topTitle-box">
				<view class="container-topTitle-box-left">
					<image class="container-topTitle-box-left-img" src="@/static/images/left.png" mode="heightFix" @click="back" />
					<text class="container-topTitle-box-left-text">申请记录</text>
				</view>
			</view>
		</view>
		
		<view class="container-content">
			<view class="content">
				<view class="list" v-if="list.length">
					<view class="item" v-for="(item,index) in list" :key="index">
						<view class="head_text1">游戏名称：{{item.name}}</view>
						<view class="head_text1">游戏账号：{{item.nickname}}</view>
						<view class="head_text1">角色名称：{{item.role_name}}</view>
						<view class="head_text1">角色ID：   {{item.role_id}}</view>
						<view class="head_text1">区服：       {{item.server_name}}</view>
						<view class="head_text1" style="margin-bottom: 18rpx;">充值金额：{{item.money}}元</view>
						<view class="head_1">
							<text class="head_text2" v-if="item.status == 1">状态：待处理</text>
							<text class="head_text2" v-else-if="item.status == 2">状态：审核通过</text>
							<text class="head_text2" v-else-if="item.status == 3">状态：审核不通过</text>
							<view class="">
								<view v-if="item.status==1" class="head_2" @click="handleClick(item,3)">
									取消申请
								</view>
								<view v-if="item.status==3" class="head_2 restart" @click="handleClick(item,1)">
									重新申请
								</view>
							</view>
						</view>
					</view>
					<u-loadmore :status="status" loading-text="努力加载中" loadmore-text="加载更多" nomore-text="没有更多了"
					 fontSize="28" line height="80" iconColor="#ff5927"  iconSize="48" loadingIcon="circle"	/>
				</view>
				<vue-loading :isNoData="isNoData" v-else></vue-loading>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				list: [],
				formData: {
					offset: 10,
					page: 1
				},
				count: 0,
				status: 'loadmore',
				isNoData: false
			}
		},
		methods: {
			back() {
				uni.navigateBack()
			},
			getPageData() {
				this.$api.get('rebate/applyList',
					this.formData
				).then(res => {
					if (res.data.code == 200) {
						this.isNoData = true
						this.status="loadmore"
						this.list = this.list.concat(res.data.data.list)
						this.count = res.data.data.count
						if(this.list.length>=this.count) {
							this.status="nomore"
						}
					}
				})
			},
			handleClick(item, status) {
				let that = this
				uni.showModal({
					title: '提示',
					confirmColor: '#FF5927',
					content: `确认${status==3?'取消申请？':'重新申请？'}`,
					success: function(res) {
						if (res.confirm) {
								that.$api.get('rebate/cancel', {
								id:item.id,
								game_id:item.app_id,
								status
							}).then(res => {
								uni.showToast({
									icon:'none',
									title:res.data.msg,
								})
								that.list=[]
								that.formData.page=1
								that.getPageData()
							})
						} else if (res.cancel) {
							return
						}
					}
				})
			}
		},
		onLoad() {
			this.getPageData()
		},
		onReachBottom() {
			if(this.count>this.list.length&&this.status=="loadmore") {
				this.status = "loading"
				this.formData.page++
				this.getPageData()
			}
		}
	}
</script>

<style lang="scss">
	.container {
		background-color: #FFFFFF;
		width: 750rpx;
		height: 100vh;
		
		&-topTitle {
			position: fixed;
			// background-color: #FFFFFF;
			background: linear-gradient(to bottom, #CCCCCC, #FFFFFF env(safe-area-inset-top));
			z-index: 999;
			top: 0;
			width: 750rpx;
			height: 176rpx;
			padding: 0 34rpx 16rpx;
			box-sizing: border-box;
			display: flex;
			flex-direction: column;
			justify-content: flex-end;
			box-shadow: 0rpx 0rpx 12rpx rgba(0, 0, 0, 0.16);
			
			&-box {
				box-sizing: border-box;
				display: flex;
				flex-direction: row;
				justify-content: space-between;
				align-items: center;
				
				&-left {
					display: flex;
					flex-direction: row;
					align-items: center;
					
					&-img {
						height: 34rpx;
					}
					
					&-text {
						margin-left: 48rpx;
						font-size: 40rpx;
						line-height: 56rpx;
						font-family: PingFang SC;
						font-weight: 600;
						color: #1C1C1C;
					}
				}
				
				&-right {
					display: block;
					width: 35rpx;
					height: 35rpx;
				}
			}
		}
		
		&-content {
			width: 750rpx;
			padding: 206rpx 0 0;
			box-sizing: border-box;
			color: #1C1C1C;
			font-family: PingFang SC;
			min-height: 100vh;
			
			.content {
				padding: 40rpx 36rpx 36rpx;
				.item {
					margin-bottom: 32rpx;
					padding: 24rpx;
					border-radius: 28rpx;
					border: 1px solid #E4E4E4;
					.head_text1 {
						margin-bottom: 8rpx;
						font-size: 28rpx;
						font-weight: 400;
						line-height: 20px;
						color: #666666;
					}
					.head_1{
						display: flex;
						justify-content: space-between;
						align-items: center;
						.head_text2{
							color: #1C1C1C;
							font-weight: bold;
							font-size: 36rpx;
						}
					}
					.head_2 {
						width: 144rpx;
						height: 48rpx;
						font-size: 24rpx;
						font-weight: 400;
						color: #ff5927;
						text-align: center;
						line-height: 44rpx;
						background: rgba(255,255,255,0.39);
						border: 2rpx solid #E4E4E4;
						border-radius: 14px;
						box-sizing: border-box;
						&.restart {
							color: #fff;
							background: rgba(204,204,204,0.39);
							border-color: transparent;
						}
					}
				}
			}
		}
	}
</style>