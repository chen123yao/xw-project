<template>
	<view class="container">
		<!-- cc 游戏专题详情页面顶部标题 -->
		<view class="container-topTitle">
			<view class="container-topTitle-box">
				<view class="container-topTitle-box-left">
					<image class="container-topTitle-box-left-img" src="@/static/images/left.png" mode="heightFix" @click="back" />
					<text class="container-topTitle-box-left-text">常见问题</text>
				</view>
			
				<image class="container-topTitle-box-right" src="@/static/images/clear-icon.png" mode="heightFix" @click="clear"></image>
			</view>
		</view>
		
		<view class="container-content">
			<view class="body">
				<!-- 客服回复 -->
				<view class="kfItem">
					<view class="kfItem_left">
						<image class="images" src="@/static/images/customerService/kf.png" mode="widthFix"></image>
					</view>
					<view class="kfItem_Right" style="width:60%">
						<text class="kftext">HI，您好，请在底部选择你要咨询的问题！</text>
					</view>
				</view>
				<view class="cards-list">
					<view class="cards">
						<!-- 问题列表 -->
						<view v-for="(item,index) in mem_List" :key='index' >
							<view class="cardsItem" :style="{borderBottom:index<mem_List.length-1?'1px solid #efefef':'',marginBottom:index<mem_List.length-1?'24rpx':''}" @click="handleClik(item.name)">
							<text class="itemname" >{{item.name}}</text> 
							<image src="@/static/images/left-gred.png" mode="widthFix" style="width: 24rpx;"></image>
							</view>
						</view>
					</view>
					<!-- 发送问题 -->
					<view v-for="(item,index) in serviceList" v-if="serviceList.length>0">
						<view class="yhItem" v-if="item.type==1">
							<view class="yhItem_Right" style="width:60%">
								<text class="yhtext">{{item.content}}</text>
							</view>
							<view class="yhItem_left">
								<image class="images" :src="userInfo.avatar"></image>
							</view>
						</view>
						<view class="kfItem" v-if="item.type==2">	
							<view class="kfItem_left">
								<image class="images" src="@/static/images/customerService/kf.png" mode="widthFix"></image>
							</view>
							<view class="kfItem_Right" style="width:60%">
								<text class="kftitle" v-if="item.title">{{item.title}}</text>
								<text class="kftext">{{item.content}}</text>
							</view>
						</view>
						<view  v-if="item.type==3">
							<view class="kfItem">
								<view class="kfItem_left" >
									<image class="images" src="@/static/images/customerService/kf.png" mode="widthFix">	</image>
								</view>
								<view>
									<view class="kfItem_Right" style="width:60%">
										<text class="kftext">你是想问以下问题吗？可以直接点击查看哦！</text>
									</view>
								</view>
							</view>
							<view  class="cards kfItem_Right">
								<view class="" v-for="(v,i) in item.list" :key='i'>
									<view class="cardsItem" :style="{borderBottom:i<item.list.length-1?'1px solid #efefef':'',marginBottom:i<item.list.length-1?'24rpx':''}"	@click="handleClik(v.title,v.id)">
										<text class="itemname" style="font-size: 28rpx;max-width: 50%;">{{v.title}}</text>
										<image src="@/static/images/left-gred.png" mode="widthFix" style="width: 24rpx;height: 24rpx;"></image>
									</view>
								</view>
							</view>
						</view>
					</view>
				</view>
			</view>
			<view class="bottom" >
				<view class="scroll">
					<view class="text">您可能想问</view>
					<scroll-view scroll-x="true" class="problem-scroll">
						<text class="problemItem" v-for="(item,index) in problemList" :key='index'	@click="handleClik(item.name)">{{item.name}}</text>
					</scroll-view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				scrollTop: this.$store.state.scrollTop || 0,
				istrue: true,
				mem_List: [{
						type: 1,
						name: '什么是游戏返利？'
					},
					{
						type: 2,
						name: '哪些游戏可以申请返利？'
					},
					{
						type: 3,
						name: '返利是返还到哪里？'
					},
					{
						type: 4,
						name: '返利多久会到？'
					},
					{
						type: 5,
						name: '充值了，但是返利申请没有可以申请的东西？'
					},
					{
						type: 6,
						name: '怎么知道会返还多少元宝？'
					},
					{
						type: 8,
						name: '角色ID怎么查看？'
					},
					{
						type: 9,
						name: '道具奖励去哪里申请？'
					}
				],
				problemList: [{
						type: 1,
						name: '返利问题'
					},
					{
						type: 2,
						name: '道具奖励'
					},
					{
						type: 3,
						name: '账号安全'
					},
					{
						type: 4,
						name: '防沉迷'
					},
					{
						type: 5,
						name: '其他问题'
					}
				]
			}
		},
		computed: {
			serviceList() {
				return this.$store.state.serviceList
			},
			userInfo() {
				return this.$store.state.userInfo
			},
		},
		methods: {
			back() {
				uni.navigateBack()
			},
			//清空问题
			clear() {
				uni.showModal({
					title: '清空',
					content: '确定清空对话？',
					success: res => {
						if (res.confirm) {
			
							this.$store.commit('setServiceList', [])
			
						} else if (res.cancel) {
							return
						}
					}
				})
			},
			//点击回复
			handleClik(content) {
				if (this.istrue) {
					this.istrue = false
					setTimeout(() => {
						this.istrue = true
					}, 600)
					let arrlist = this.serviceList
					arrlist.push({
						type: 1,
						title: '',
						content
					})
					this.$store.commit('setServiceList', arrlist)
					this.getServeData(content)
				}
				this.$nextTick(function() {
					setTimeout(() => {
						this.scrollTop += 400
						this.$store.commit('setScrollTop',this.scrollTop)
						uni.pageScrollTo({
							scrollTop: this.scrollTop,
							duration: 300
						});

					}, 200)
				});
			},
			//获取客服数据
			getServeData(content) {
				this.$api.get("/service/service_message", {
					content
				}).then(res => {
					if (res.data.code == 200) {
						if (res.data.data) {
							let list = res.data.data[0]
							let arrlist = this.serviceList
							if (res.data.data.length == 1) {
								arrlist.push({
									type: 2,
									title: list.title,
									content: list.content
								})
							} else {
								arrlist.push({
									type: 3,
									list: res.data.data
								})
							}
							this.$store.commit('setServiceList', arrlist)
						} else {
							let arrlist = this.serviceList
							arrlist.push({
								type: 2,
								title: '',
								content: '这个问题小闲暂时还没有学会，请联系人工客服！'
							})
							this.$store.commit('setServiceList', arrlist)
						}
					}
				})
			},
		},
	}
</script>

<style lang="scss">
	.container {
		background-color: #FFFFFF;
		width: 750rpx;
		height: 100vh;
		
		&-topTitle {
			position: fixed;
			// background-color: #FFFFFF;
			background: linear-gradient(to bottom, #CCCCCC, #FFFFFF env(safe-area-inset-top));
			z-index: 999;
			top: 0;
			width: 750rpx;
			height: 176rpx;
			padding: 0 34rpx 16rpx;
			box-sizing: border-box;
			display: flex;
			flex-direction: column;
			justify-content: flex-end;
			box-shadow: 0rpx 0rpx 12rpx rgba(0, 0, 0, 0.16);
			
			&-box {
				box-sizing: border-box;
				display: flex;
				flex-direction: row;
				justify-content: space-between;
				align-items: center;
				
				&-left {
					display: flex;
					flex-direction: row;
					align-items: center;
					
					&-img {
						height: 34rpx;
					}
					
					&-text {
						margin-left: 48rpx;
						font-size: 40rpx;
						line-height: 56rpx;
						font-family: PingFang SC;
						font-weight: 600;
						color: #1C1C1C;
					}
				}
				
				&-right {
					display: block;
					width: 35rpx;
					height: 35rpx;
				}
			}
		}
		
		&-content {
			width: 750rpx;
			padding: 205rpx 0 0;
			box-sizing: border-box;
			color: #1C1C1C;
			font-family: PingFang SC;
			min-height: 100vh;
			
			.body {
				padding: 0 32rpx 0;
				.kfItem {
					display: flex;
					align-items: center;
					align-items: flex-start;
					justify-content: flex-start;
					padding: 10rpx 2rpx;
					margin-bottom: 40rpx;
					.kfItem_left {
						margin-right: 24rpx;
						display: flex;
						align-items: center;
						justify-content: center;
						.images {
							width: 80rpx;
							height: 80rpx;
							border-radius: 80rpx;
							border: 1px solid #efefef;
						}
					}
					.kfItem_Right {
						border: 1px solid #efefef;
						border-radius: 20rpx;
						padding: 16rpx 32rpx;
					}
					.kftitle {
						font-size: 32rpx;
						color: #1C1C1C;
						font-weight: 700;
						margin-bottom: 20rpx;
					}
					.kftext {
						font-size: 30rpx;
						color: #1C1C1C;
					}
				}
				.cards-list {
					.cards {
						padding: 24rpx 24rpx 0;
						margin-bottom: 32rpx;
						border: 1px solid #efefef;
						border-radius: 20rpx;
					}
					.cardsItem {
						display: flex;
						align-items: center;
						justify-content: space-between;
						padding-bottom: 24rpx;
					}
					.itemname{
					 font-size: 28rpx;
					 color: #1C1C1C;
					 font-weight: 700;
					 text-overflow: ellipsis;
					 lines: 2;
					 overflow:hidden
					}
					.yhItem {
						display: flex;
						align-items: flex-start;
						justify-content: flex-end;
						margin-bottom: 40rpx;
						 .yhItem_left {
							margin-left: 24rpx;
							display: flex;
							align-items: center;
							justify-content: center;
						 }
						 .images {
							width: 80rpx;
							height: 80rpx;
							border-radius: 80rpx;
							border: 1px solid #efefef;
						 }
						 .yhItem_Right {
							border: 1px solid #efefef;
							border-radius: 20rpx;
							padding: 16rpx 32rpx;
						 }
						 .yhtext {
							font-size: 32rpx;
							color: #FF5927;
						 }
					}
				}
			}
			.bottom {
				position: fixed;
				bottom: 0;
				left: 0;
				width: 100%;
				height: 100rpx;
				display: flex;
				align-items: center;
				box-sizing: border-box;
				padding: 0 32rpx;
				background-color: #fff;
				.scroll {
					display: flex;
					align-items: center;
					height: 60rpx;
					.problem-scroll {
						height: 60rpx;
						width: calc(100vw - 212rpx);
						margin-left: 180rpx;
						line-height: 60rpx;
						white-space: nowrap;
					}
					.problemItem {
						border: 1px solid #E4E4E4;
						border-radius: 30rpx;
						padding: 6rpx 18rpx;
						margin-right: 24rpx;
						lines: 1;
						font-size: 28rpx;
					}
					.text {
						position: absolute;
						color: #666;
						font-size: 28rpx;
						lines: 1;
					}
				}
			}
		}
	}
</style>