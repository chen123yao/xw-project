<template>
	<view class="container">
		<!-- cc 游戏专题详情页面顶部标题 -->
		<view class="container-topTitle">
			<view class="container-topTitle-box">
				<view class="container-topTitle-box-left">
					<image class="container-topTitle-box-left-img" src="@/static/images/left.png" mode="heightFix" @click="back" />
					<text class="container-topTitle-box-left-text">客服中心</text>
				</view>
			
				<image class="container-topTitle-box-right" src="@/static/images/customerService/kfzx-icon.png" mode="heightFix" @click="handleRouter('/pages/my/comprehensive/feedback/feedback')"></image>
			</view>
		</view>
		
		<view class="container-content">
			<view class="content">
				<view class="content-title">在使用中遇到任何问题请联系在线客服</view>
				<view class="box1">
					<view class="box1-left backimg" @click="handleRouter('/pages/customerService/children/problem')">
						<image src="@/static/images/customerService/serverBackgorund1.png" style="width:calc(100vw / 2);height:240rpx;" mode="scaleToFill"></image>
						<view class="box-absloute">
							<view class="backitem">
								<text class="backName">常见问题</text>
								<text class="backsname">FAQ答疑</text>
							</view>
							<view>
								<image src="@/static/images/customerService/cjwt.png" mode="scaleToFill" style="width: 72rpx;height: 72rpx;"></image>
							</view>
						</view>
					</view>
					<view class="box1-right backimg"  @click="handleRouter('/pages/customerService/children/rechargeRebate/index')">
						<image src="@/static/images/customerService/serverBackgorund2.png"  style="width:calc(100vw / 2);height:240rpx;"></image>
						<view class="box-absloute">
							<view class="backitem">
								<text class="backName">返利申请</text>
								<text class="backsname">更多福利	</text>
							</view>
							<view class="">
								<image src="@/static/images/customerService/flsq.png" mode="scaleToFill" style="width: 64rpx;height: 72rpx;"></image>
							</view>
						</view>
					</view>
				</view>
				<view class="kfqq-Item">
					<view class="kfqq-Item__left">
					<image src="@/static/images/qq-icon.png"  class="images"  mode="widthFix"></image>
						<view class="detail">
							<text class="detailname">游戏客服QQ: {{userFormat.QQ_customerService}}</text>
							<text class="detailtell">在线时间：09:00-22:00</text>
						</view>
					</view>
					<a :href="'mqq://im/chat?chat_type=wpa&uin='+userFormat.QQ_customerService+'&version=1&src_type=web'" class="kfqq-Item__Right">去联系</a>
				</view>
				<view class="kfqq-Item">
					<view class="kfqq-Item__left">
					<image src="@/static/images/phone-icon.png" class="images" mode="widthFix"></image>
						<view class="detail">
							<text class="detailname">游戏客服电话:{{userFormat.footer_mobile}}</text>
							<text class="detailtell">在线时间：09:00-22:00</text>
						</view>
					</view>
					<text class="kfqq-Item__Right" @click="go">拨 打</text>
				</view>
				<view class="kfqq-Item">
					<view class="kfqq-Item__left">
					<image src="@/static/images/wx-icon.png"  class="images"  mode="widthFix"></image>
						<view class="detail">
							<text class="detailname">游戏客服微信: {{userFormat.footer_wechat_number}}</text>
							<text class="detailtell">在线时间：09:00-22:00</text>
						</view>
					</view>
					<text class="kfqq-Item__Right" @click="weixinGo">复 制</text>
				</view>
				<view class="bottom">
					<image @click="saveImage" :src="userFormat.footer_wechatCode_number" class="erweima" mode="widthFix"></image>
					<view class="scanning" @click="saveImage" >
						<image src="@/static/images/erweima.png" mode="widthFix" style="width: 28rpx;height: 28rpx;margin-right: 8rpx;"></image>
						<text class="text" style="color: #fff;font-size: 24rpx;" >微信扫码</text>
					</view>
				</view>	
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				key: ''
			}
		},
		computed: {
			userFormat() {
				return this.$store.state.userFormat
			},
		},
		methods: {
			back() {
				uni.navigateBack()
			},
			//路由跳转
			handleRouter(url){
				if(this.$common.isLogin()){
					uni.navigateTo({
						url
					})
				}
			},
			go() {
				uni.makePhoneCall({
					// 手机号
					phoneNumber: this.userFormat.footer_mobile,
					// 成功回调
					success: (res) => {
					},
					// 失败回调
					fail: (res) => {
					}
				});
			},
			//微信复制
			weixinGo(){
				uni.setClipboardData({
					data: this.userFormat.footer_wechat_number,
					success:() => {
						uni.showToast({
							title: '复制成功',
							icon: 'none',
							success: () => {
								setTimeout(() => {
									window.open("weixin://profile/CESVjbDE9e2KrfTu9xEa")
								}, 600)
							}
						})
					}
				})
			},
			//保存图片
			saveImage(){
				uni.previewImage({
					current:1,
					urls: [this.userFormat.footer_wechatCode_number],
					longPressActions: {
						itemList: ['保存图片'],
						itemColor:'#ff5927',		
						success: data => {
							uni.downloadFile({
									url: this.userFormat.footer_wechatCode_number, 
									success: res => {
											if (res.statusCode === 200) {
												uni.saveImageToPhotosAlbum({
													filePath: res.tempFilePath,
													success: res => {
												 plus.nativeUI.alert('保存成功')
													}
												});
											}
									}
							});
						},
						fail: function(err) {
							console.log(err.errMsg);
						}
					}
				});
			},
		}
	}
</script>

<style lang="scss">
	.container {
		background-color: #FFFFFF;
		width: 750rpx;
		height: 100vh;
		
		&-topTitle {
			position: fixed;
			// background-color: #FFFFFF;
			background: linear-gradient(to bottom, #CCCCCC, #FFFFFF env(safe-area-inset-top));
			z-index: 999;
			top: 0;
			width: 750rpx;
			height: 176rpx;
			padding: 0 34rpx 16rpx;
			box-sizing: border-box;
			display: flex;
			flex-direction: column;
			justify-content: flex-end;
			box-shadow: 0rpx 0rpx 12rpx rgba(0, 0, 0, 0.16);
			
			&-box {
				box-sizing: border-box;
				display: flex;
				flex-direction: row;
				justify-content: space-between;
				align-items: center;
				
				&-left {
					display: flex;
					flex-direction: row;
					align-items: center;
					
					&-img {
						height: 34rpx;
					}
					
					&-text {
						margin-left: 48rpx;
						font-size: 40rpx;
						line-height: 56rpx;
						font-family: PingFang SC;
						font-weight: 600;
						color: #1C1C1C;
					}
				}
				
				&-right {
					display: block;
					width: 35rpx;
					height: 35rpx;
				}
			}
		}
		
		&-content {
			width: 750rpx;
			padding: 205rpx 0 0;
			box-sizing: border-box;
			color: #1C1C1C;
			font-family: PingFang SC;
			min-height: 100vh;
			
			.content {
				padding: 0 32rpx 0;
				.content-title {
					color: #666;
					margin-bottom: 48rpx;
					font-size: 28rpx;
				}
				.box1 {
					display: flex;
					align-items: center;
					justify-content: space-between;
					margin-top: -80rpx;
					overflow:hidden;
					.backimg{
						position: relative;
						.box-absloute{
							width: 100%;
							padding:0 112rpx 0 24rpx;
							position: absolute;
							left: 0;
							top: 120rpx;
							display: flex;
							align-items: center;
							justify-content: space-between;
							box-sizing: border-box;
						}
						.Bodytitle {
							color: #666;
							margin: 48rpx 0;
							font-size: 28rpx;
						}
						.backName{
							display: block;
							font-size: 32rpx;
							color: #fff;
							font-weight: 700;
							margin-bottom: 8rpx;
						}
						.backsname {
							font-size: 26rpx;
							color: #fff;
						}
					}
				}
				.kfqq-Item{
					margin-top: 60rpx;
					display: flex;
					align-items: center;
					justify-content: space-between;
					padding-bottom: 46rpx;
					border-bottom: 1px solid #EFEFEF;	
					.kfqq-Item__left{
						display: flex;
						align-items: center;
						justify-content: center;
					}
					.images {
						width: 88rpx;
						height: 88rpx;
						margin-right: 20rpx;
					}
					.detailname {
						display: block;
						color: #1C1C1C;
						font-size:30rpx;
						font-weight: 700;
						margin-bottom: 14rpx;
						white-space: nowrap;
					}
					.detailtell {
						display: block;
						color:#999;
						font-size: 26rpx;
					}
					.kfqq-Item__Right{
						border: 1px solid #E4E4E4;
						border-radius: 32rpx;
						padding: 8rpx 0;
						color: #FF5927;
						font-size:26rpx;
						font-weight: 700;
						lines: 1;
						width: 114rpx;
						text-align: center;
						text-decoration: none;
					}
				}
				.bottom{
					display: flex;
					flex-direction: column;
					align-items: center;
					.erweima {
						margin-top: 48rpx;
						width: 300rpx;
						height: 300rpx;
					}
					.scanning{
						display: flex;
						align-items: center;
						padding: 10rpx 20rpx;
						background-color: #C1C1C1;
						border-radius: 30rpx;
					}
				}
			}
		}
	}
</style>