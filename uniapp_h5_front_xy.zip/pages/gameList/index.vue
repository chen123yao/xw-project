<template>
	<view class="container">
		<!-- cc 顶部状态栏 用来设置渐变背景 -->
		<view class="topStatusBarBgc"></view>
		
		<!-- cc 游戏列表顶部标题导航栏 固定定位不动 -->
		<view class="topTitel_layout">
			
			<!-- cc 搜索框、消息 -->
			<vue-topBar left_url="/pages/view/search/search" right_url="/pages/my/myMessage/index" :topBarStyle="topBarStyle"></vue-topBar>
			
			<!-- cc 游戏列表选项框 -->
			<view class="typeSelect_layout">
				<view class="typeSelect_layout-left">
					<text class="typeSelect_layout-left-text">{{ typeSelectText }}</text>
				</view>
				<view class="typeSelect_layout-right">
					<view class="typeSelect_layout-right-radius radius1" :class="isShowTypePanel ? 'showTypePanel' : 'notShowTypePanel'" @click="toggleTypePanel">
						<image src="@/static/images/game/down.png" mode="widthFix" style="width: 36rpx;height:36rpx;"></image>
					</view>
					<view class="typeSelect_layout-right-radius radius2" :class="[ isShowCate ? 'showCate' : 'notShowCate', isShowTypePanel && 'hideCate' ]" @click="isShowCate = !isShowCate">
						<image src="@/static/images/game/selete.png" mode="widthFix" style="width: 36rpx;height:36rpx;"></image>
					</view>
				</view>
			</view>
		</view>
		
		<view class="topTitel_layout_border"></view>
		
		<!-- cc 游戏列表内容部分 -->
		<view class="gameList">
			<!-- cc 游戏列表内容部分 左侧游戏类型筛选项 -->
			<view class="gameList-left" :style="isShowCate ? '' : 'transform: translateX(-136rpx);'">
				<scroll-view class="gameList-left-scroll" :scroll-y="true" :scroll-with-animation="true" :refresher-enabled="false" :scroll-into-view="'leftItem' + (activeIndex > 5 ? (activeIndex - 5) : 0)">
					<view class="gameList-left-scroll-item" :id="'leftItem' + index" v-for="(item, index) in pageList" :key="'item' + index" @click="changeLeftCate(item, index)">
						<image v-if="index != 0 && pageList[index - 1] && pageList[index - 1].id == activeId" class="gameList-left-scroll-item-img"
							src="@/static/images/game/tab-tr.png" mode="scaleToFill">
						</image>
						<image v-else-if="index != (pageList.lenght - 1) && pageList[index + 1] && pageList[index + 1].id == activeId" class="gameList-left-scroll-item-img" 
							src="@/static/images/game/tab-br.png" mode="scaleToFill">
						</image>
						<image v-else-if="item.id == activeId" class="gameList-left-scroll-item-img" 
							src="@/static/images/game/tab.png" mode="scaleToFill">
						</image>
						<text v-if="item.id == activeId" class="gameList-left-scroll-item-active"></text>
						<text class="gameList-left-scroll-item-text">{{ item.name }}</text>
					</view>
				</scroll-view>
			</view>
			
			<!-- cc 游戏列表内容部分 右侧游戏列表 -->
			<view class="gameList-right" :style="isShowCate ? 'width: 614rpx;' : 'width: 750rpx; transform: translateX(-136rpx);'">
				<scroll-view class="gameList-right-scroll" :style="{ backgroundColor: (!activeId && isShowCate) ? '#ffffff' : '#f4f4f4', width: isShowCate ? '614rpx' : '750rpx' }" :scroll-y="true" :scroll-with-animation="true" 
					:refresher-enabled="false" @scrolltolower="loadMoreGameData" :scroll-top="scrollTop" @scroll="scroll">
					<u-empty v-if="(loadingData == 2) && !Object.keys(serverData).length && !gameList.length" class="gameList-right-scroll-empty" 
						:width="400" :height="400" :textSize="0" :marginTop="-160" mode="data" icon="http://cdn.uviewui.com/uview/empty/car.png"></u-empty>
					
					<!-- cc 是否请求数据中 显示loading界面 -->
					<u-loading-page class="gameList-right-scroll-loading" :loading="(loadingData < 2) && !Object.keys(serverData).length && !gameList.length" icon-size="72" font-size="30" loading-mode="spinner"></u-loading-page>
					
					<!-- cc 今日新服标题 -->
					<view v-if="Object.keys(serverData).length > 0" class="gameList-right-scroll-title">今日新服</view>
					
					<!-- cc 今日新服数据 -->
					<view v-for="(item, index) in serverList[getMonth]" :key="'server' + index" v-if="serverList[getMonth].length">
						<vue-gameItem v-if="serverColorArray[2 * index]" :itemData="item" :contentTagsColor="serverColorArray && [serverColorArray[(index) * 2],serverColorArray[(index) * 2 + 1]]" :itemWidth="isShowCate ? 614 : 702" 
							:hasPadding="false" :tagType="3" :itemBMargin="32" :iconWidth="120" :isShowMaxWidth="!isShowCate"></vue-gameItem>
					</view>
					
					<!-- cc 游戏列表标题 -->
					<view v-if="gameList.length" class="gameList-right-scroll-title">所有游戏</view>
					
					<!-- cc 今日新服数据 -->
					<view v-for="(item, index) in gameList" :key="'game' + index">
						<vue-gameItem v-if="gameColorArray[index]" :itemData="item" :contentTagsColor="gameColorArray && [gameColorArray[(index) * 2],gameColorArray[(index) * 2 + 1]]" :itemWidth="isShowCate ? 614 : 702" 
							:hasPadding="false" :tagType="3" :itemBMargin="32" :iconWidth="120" :isShowMaxWidth="!isShowCate"></vue-gameItem>
					</view>
					
					<u-loadmore v-if="gameList.length" bg-color="transparent" height="30" marginTop="0" fontSize="24" marginBottom="32" :status="loadingStatus" loadingIcon="spinner" />
				</scroll-view>
			</view>
		</view>
		
		<!-- cc 顶部游戏类型下拉面板 -->
		<u-popup class="typePanel" :show="isShowTypePanel" zIndex="10085" :round="40" mode="top" @close="toggleTypePanel">
			<view class="typePanel-layout">
				<!-- cc 下拉面板内容区scroll -->
				<scroll-view class="typePanel-layout-scroll" :scroll-y="true">
					<view class="typePanel-layout-scroll-h5">
						<text class="h5-select" :class="(selectTypeObject.h5 == item.type) && 'h5-select-active'" v-for="(item, index) in h5List" :key="'h5Select' + index"	@click="selectH5(item)">
							{{ item.name }}
						</text>
					</view>
					<view class="typePanel-layout-scroll-tags">
						<text class="tags_title">游戏福利</text>
						<view class="tags_select">
							<text class="tags_select-text" :class="(selectTypeObject.tag == item.id) && 'tags_select-text-active'" v-for="(item, index) in tagsList" :key="'tag' + index" @click="selectTags(item)">
								{{ item.name }}
							</text>
						</view>
					</view>
					<view v-if="!isShowCate" class="typePanel-layout-scroll-cates">
						<text class="cates_title">游戏类型</text>
						<view class="cates_select">
							<text class="cates_select-text" :class="(selectTypeObject.cate == item.id) && 'cates_select-text-active'" v-for="(item, index) in pageList" :key="'tag' + index" @click="selectCates(item, index)"
								:style="{ 'backgroundImage': 'url(' + '../../../static/images/game/' + (selectTypeObject.cate == item.id ? 'black' : 'grey') + '/'+ item.id +'.png)' }">
								{{ item.name }}
								<image src="@/static/images/game/active2.png" mode="scaleToFill"
									v-if="selectTypeObject.cate == item.id" class="cates_select-text-activeImg"></image>
							</text>
						</view>
					</view>
				</scroll-view>
				<!-- cc 下拉面板确定取消按钮layout -->
				<view class="typePanel-layout-confirmLayout">
					<!-- cc 重置 -->
					<view class="typePanel-layout-confirmLayout-reset" @click="selectReset">重置</view>
					<!-- cc 确认 -->
					<view class="typePanel-layout-confirmLayout-confirm" @click="selectConfirm">确认</view>
				</view>
			</view>
		</u-popup>
	</view>
</template>

<script>
	export default {
		components: {
		},
		data() {
			return {
				// cc topBar样式
				topBarStyle: {
					searchColor: '#c1c1c1',
					textColor: '#c1c1c1',
					bellColor: '#000'
				},
				// cc 当前游戏列表参数
				typeSelectParams: {
					is_h5: 2, // 0--全部 1--H5 2--手游
					page: 1, // 当前分页
					offset: 15, // 每次请求数据的数量
					tags: 0, // 福利类型
					is_mp4: 0,
					cates: 0 // 游戏类型
				},
				//cc 显示的类型标签
				formData: {
					is_h5name: '手游',
					tagsname: '',
					catesname: ''
				},
				// cc 当前页面左边显示的游戏类型导航中被选中的类型 id 和 下标
				activeId: 0,
				activeIndex: 0,
				// cc 顶部游戏标签列表
				tagsList: [],
				// cc 当前左侧类型列表数据
				pageList: [],
				// cc 是否在请求数据中心 默认请求中  0 为请求中  因为有2个数据同时请求 所以每返回一个数据则+1 2为
				loadingData: 0,
				// cc 今日新服列表数据
				serverList: {},
				serverData: [],
				// cc 当前游戏列表数据
				gameList: [],
				// cc 当前类型游戏列表总数
				gameCount: 0,
				// cc 是否显示左侧类型选择列表 默认显示
				isShowCate: true,
				// cc 是否显示下拉类型选择面板 默认不显示
				isShowTypePanel: false,
				// cc 类型选择面板临时存储对象
				selectTypeObject: {
					h5: 2,
					cate: 0,
					tag: 0,
					cateIndex: 0,
					h5name: '手游',
					tagsname: '',
					catesname: ''
				},
				// cc 类型选择面板第一排 手游/H5
				h5List: [{
						name: '全部',
						type: 0,
					},	
					{  
						name: '手游',
						type: 2,
					},
					{
						name: 'H5',
						type: 1,
					}
				],
				// cc 动态加载 加载状态
				loadingStatus: 'loading',
				isLoading: false,
				
				// cc 新开服游戏列表、游戏列表 item tags color
				serverColorArray: [],
				gameColorIndexArray: [],
				gameColorArray: [],
				
				// cc 游戏列表scroll 滚动位置  用来设置重置类型之后 刷新游戏列表数据 将滚动条设置到顶部  及 scrollTop = 0
				scrollTop: 0,
				old: {
					scrollTop: 0
				}
			}
		},
		computed: {
			// cc 根据赋完的值来设置当前顶部应该显示的游戏类型文字
			typeSelectText() {
				return (this.formData.is_h5name || '全部') + (this.formData.tagsname && '·') + this.formData.tagsname + (this.formData.catesname && '·') + this.formData.catesname
			},
			getMonth() {
				return (((new Date().getMonth() + 1) < 10 ? '0' : '') + (new Date().getMonth() + 1) + '-' + ( new Date().getDate() < 10 ? '0' : '') + new Date().getDate())
			},
		},
		onLoad() {
			console.log('game_list_onLoad');
			// cc 获取游戏列表类型筛选中的所有类型数据
			this.typeSelectData()
			
			// cc 获取游戏列表 新服和游戏数据
			this.loadingData = 0
			this.getPageData()
			this.getServerList()
		},
		onShow() {
			console.log('gameList-onShow')
			
			// cc 获取缓存判断是否是从其他页面点击跳转过来 需要带上参数请求数据 并显示对应的游戏类型列表
			let typeSelectData = uni.getStorageSync('gameHall').split('-')
			uni.removeStorageSync('gameHall');
			console.log('typeSelectData:', typeSelectData)
			
			// cc 判断是有数据 是否是点击跳转
			if (typeSelectData && typeSelectData != '') {
				// cc 默认初始化当前页面的部分数据 页面初始化
				this.initData()
				
				// cc 利用拿到的缓存数据来重新给变量赋值
				switch(typeSelectData[0]) {
					case 'tags':
						this.typeSelectParams.tags = typeSelectData[1]
						this.selectTypeObject.tag = typeSelectData[1]
						this.formData.tagsname = typeSelectData[2]
						this.selectTypeObject.tagsname = typeSelectData[2]
						this.typeSelectParams.cates = 0
						this.selectTypeObject.cate = 0
						this.formData.catesname = ''
						break
					case 'cate':
						this.activeId = typeSelectData[1];
						this.typeSelectParams.cates = typeSelectData[1]
						this.selectTypeObject.cate = typeSelectData[1]
						this.formData.catesname = typeSelectData[2]
						this.selectTypeObject.catesname = typeSelectData[2]
						this.selectTypeObject.tag = 0
						this.selectTypeObject.tagsname = ''
						this.formData.tagsname = ''
						break
					case 'h5':
						this.typeSelectParams.is_h5 = typeSelectData[1]
						this.selectTypeObject.h5 = typeSelectData[1]
						this.formData.is_h5name = typeSelectData[2]
						this.typeSelectParams.h5name = typeSelectData[2]
						this.selectTypeObject.tag = 0
						this.selectTypeObject.tagsname = ''
						this.formData.tagsname = ''
						this.typeSelectParams.cates = 0
						this.selectTypeObject.cate = 0
						this.formData.catesname = ''
						break
				}
				// cc 获取游戏列表 新服和游戏数据
				this.loadingData = 0
				this.getPageData()
				this.getServerList()
			}
		},
		methods: {
			scroll: function(e) {
				// console.log(e)
				this.old.scrollTop = e.detail.scrollTop
			},
			// cc 获取列表类型数据
			typeSelectData() {
				this.$api.get('/game/getcategorynew', {
					client_id: this.$store.state.client_id
				}).then(res => {
					this.pageList = res.data.data.cate
					this.tagsList = res.data.data.tags
					
					// cc 给类型和标签数组前添加全部类型
					this.pageList.unshift({
						name: '全部',
						id: 0,
					})
					this.tagsList.unshift({
						name: '全部',
						id: 0,
					})
					
					console.log('pageList:', this.pageList);
					console.log('tagsList:', this.tagsList);
				})
			},
			// cc 初始化部分数据
			initData() {
				// cc 页面左边游戏类型列表下标 和 游戏类型数据
				this.activeId = 0
				this.activeIndex = 0
				
				Object.keys(this.formData).forEach((key) => (this.formData[key] = ''))
				
				this.typeSelectParams = {
					is_h5: 2,
					page: 1,
					offset: 15,
					tags: 0,
					is_mp4: 0,
					cates: 0
				}
				
				// cc 页面主体部分游戏列表显示所需要的数据
				this.resetData()
				
				// cc 页面内容请求
				// this.loadingData = 0
				// this.getServerList()
				// this.getPageData()
			},
			// cc 重置页面数据和参数
			resetData() {
				this.gameList = []
				this.typeSelectParams.page = 1
				this.typeSelectParams.offset = 15
				
				this.serverColorArray = []
				this.gameColorIndexArray = []
				this.gameColorArray = []
				
				// 解决view层不同步的问题
				this.scrollTop = this.old.scrollTop
				this.$nextTick(function() {
					this.scrollTop = 0
				});
				// this.scrollTop = 0
			},
			// cc 左侧游戏类型点击切换响应事件
			changeLeftCate(cates, index) {
				// cc 先重置页面数据和请求参数
				this.resetData()
				// cc 将当前选中的类型复制给请求参数对象中的类型属性 用来请求新的类型数据
				this.typeSelectParams.cates = cates.id
				// cc 将当前类型id 存储起来用来显示选中状态
				this.activeId = cates.id
				this.activeIndex = index
				
				// cc 给顶部下拉类型筛选面板赋值
				this.selectTypeObject.cate = cates.id
				this.selectTypeObject.cateIndex = index
				
				this.formData.catesname = cates.id ? cates.name : ''
				
				// cc 重新获取页面数据
				this.loadingData = 0
				this.getPageData()
				this.getServerList()
							
				// let el = this.$refs['item' + (index > 2 ? index - 2 : 0)][0]
				// dom.scrollToElement(el, {
				// 	offset: 0
				// })
			},
			// cc 获取新服数据
			getServerList() {
				this.$api.get('/gameserver/newlist', {
					page: 1,
					...this.typeSelectParams,
					client_id: this.$store.state.client_id
				}).then(res => {
					if (Object.keys(res.data.data.list).length > 0) {
						this.serverList = res.data.data.list
					} else {
						this.serverList = {}
					}
					
					this.serverData = res.data.data.list
					this.serverList = res.data.data.list
					// console.log('serverList', res.data.data.list, this.serverList[this.getMonth]);
					
					let serverDatalength = 0
					for(let item in this.serverData) {
						serverDatalength += this.serverData[item].length
					}
					
					if (serverDatalength) {
						// console.log('serverDataLength: ', serverDatalength);
						let indexArray = this.$common.getRandomColorIndexArray([], serverDatalength * 2)
						// console.log('indexArray: ', indexArray);
						this.serverColorArray = { ...this.$common.getRandomColorArray(indexArray) }
						// console.log('serverColorArray: ', this.serverColorArray);
					}
					
					this.loadingData++
				})
			},
			// cc 获取游戏列表对应类型数据
			getPageData() {
				this.$api.get('/game/multilistnew', {
					...this.typeSelectParams,
					client_id: this.$store.state.client_id
				}).then(res => {
					if(res.data.code==200){
						this.gameCount = res.data.data.count
						this.gameList = this.gameList.concat(res.data.data.list);
						
						if (res.data.data.list.length) {
							// console.log('gameColorArrayLength: ', res.data.data.list.length);
							this.gameColorIndexArray = [ ...this.$common.getRandomColorIndexArray(this.gameColorIndexArray, res.data.data.list.length * 2) ]
							// console.log('gameColorIndexArray: ', this.gameColorIndexArray);
							this.gameColorArray = { ...this.$common.getRandomColorArray(this.gameColorIndexArray) }
							// console.log('gameColorArray: ', this.gameColorArray);
						}
						
						this.isLoading = false
						// console.log('gameList', res.data.data, this.gameList);
						
						if (this.gameList.length >= this.gameCount) {
							this.loadingStatus = 'nomore'
						}
					}
					this.loadingData++
				})
			},
			// cc 动态加载响应事件
			loadMoreGameData() {
				console.log('loadMoreGameData');
				if (Object.keys(this.gameList).length < this.gameCount && !this.isLoading) {
					this.typeSelectParams.page++
					this.isLoading = true
					this.loadingStatus = 'loading'
					this.getPageData()
				} else {
					this.loadingStatus = 'nomore'
					this.isLoading = false
				}
			},
			// cc 顶部类型选择面板显示隐藏响应事件
			toggleTypePanel() {
				this.isShowTypePanel = !this.isShowTypePanel
			},
			// cc 顶部类型选择面手游/H5响应事件
			selectH5(item) {
				this.selectTypeObject.h5 = item.type
				this.selectTypeObject.h5name = item.name
			},
			// cc 顶部类型选择面游戏福利筛选响应事件
			selectTags(item) {
				this.selectTypeObject.tag = item.id
				this.selectTypeObject.tagsname = item.id ? item.name : ''
			},
			// cc 顶部类型选择面游戏类型筛选响应事件
			selectCates(item, index) {
				this.selectTypeObject.cate = item.id
				this.selectTypeObject.catesname = item.id ? item.name : ''
				this.selectTypeObject.cateIndex = index
			},
			// cc 顶部类型选择下拉面板中重置按钮的响应事件
			selectReset() {
				Object.keys(this.selectTypeObject).forEach((key) => (this.selectTypeObject[key] = 0))
				this.selectTypeObject.h5name = '',
				this.selectTypeObject.tagsname = '',
				this.selectTypeObject.catesname = ''
			},
			// cc 顶部类型选择下拉面板中确定按钮的响应事件
			selectConfirm() {
				this.formData.is_h5name = this.selectTypeObject.h5name
				this.formData.tagsname = this.selectTypeObject.tagsname
				this.formData.catesname = this.selectTypeObject.catesname
				
				this.typeSelectParams.is_h5 = this.selectTypeObject.h5
				this.typeSelectParams.tags = this.selectTypeObject.tag
				this.typeSelectParams.cates = this.selectTypeObject.cate
				
				this.activeId = this.selectTypeObject.cate
				this.activeIndex = this.selectTypeObject.cateIndex
				
				// cc 页面主体部分游戏列表显示所需要的数据
				this.resetData()
				
				// cc 重新获取页面数据
				this.loadingData = 0
				this.getPageData();
				this.getServerList()
				
				// cc 收起下拉面板
				this.toggleTypePanel()
			}
		}
	}
</script>

<style lang="scss" scoped>
	::v-deep .u-slide-down-enter-active {
		top: calc(156rpx + env(safe-area-inset-top)) !important;
	}
	
	::v-deep .u-loadmore {
		// display: none;
	}
	
	.showCate {
		transform: rotateY(0deg);
	}
	
	.notShowCate {
		transform: rotateY(180deg);
	}
	
	.hideCate {
		opacity: 0;
	}
	
	.radius1 {
		transition: all .6s;
		z-index: 10095;
	}
	
	.radius2 {
		transition: all .6s cubic-bezier(0, -1, 1, 2);
	}
	
	.showTypePanel {
		transform: translateX(88rpx) rotate(180deg);
	}
	
	.notShowTypePanel {
		transform: translateX(0rpx) rotate(0deg);
	}
	
	.container {
		font-size: 14px;
		width: 750rpx;
		height: calc(100vh - 50px - env(safe-area-inset-bottom));
		background-color: #f4f4f4;
		
		.topStatusBarBgc {
			width: 750rpx;
			height: env(safe-area-inset-top);
			background: linear-gradient(to bottom, #CCCCCC, #ffffff);
			top: 0;
			left: 0;
			position: fixed;
			z-index: 10090;
		}
		
		.topTitel_layout {
			height: 156rpx;
			position: fixed;
			z-index: 10090;
			top: env(safe-area-inset-top);
			left: 0;
			background-color: #FFFFFF;
			box-sizing: border-box;
		}
		
		.typeSelect_layout {
			display: flex;
			flex-direction: row;
			width: 750rpx;
			height: 100rpx;
			padding: 10rpx 16px;
			box-sizing: border-box;
			justify-content: space-between;
			
			&-left,
			&-right {
				height: 100%;
				display: flex;
				flex-direction: row;
				align-items: center;
				justify-content: space-between;
				color: #1C1C1C;
				font-size: 40rpx;
				font-weight: 600;
				box-sizing: border-box;
				
				&-text {
					display: inline-block;
					// padding-bottom: 15rpx;
				}
				
				&-radius {
					display: flex;
					align-items: center;
					justify-content: center;
					padding: 20rpx 20rpx;
					width: 64rpx;
					height: 64rpx;
					border-radius: 40rpx;
					background-color: #FFFFFF;
					margin-left: 24rpx;
					box-sizing: border-box;
					box-shadow: 0rpx 0rpx 16rpx rgba(0, 0, 0, 0.16);
				}
			}
		}
		
		.topTitel_layout_border {
			background-color: rgba(0, 0, 0, 0.16);
			height: 8rpx;
			box-shadow: 0px 0px 4rpx rgba(0, 0, 0, 0.16);
			width: 750rpx;
			position: fixed;
			top: calc(154rpx + env(safe-area-inset-top));
			left: 0;
			z-index: 10080;
		}
	
		.gameList {
			position: fixed;
			top: 0;
			left: 0;
			z-index: 10;
			padding-top: calc(168rpx + env(safe-area-inset-top));
			width: 100%;
			height: calc(100vh - env(safe-area-inset-top) - env(safe-area-inset-bottom));
			box-sizing: border-box;
			display: flex;
			flex-direction: row;
			
			&-left {
				width: 136rpx;
				transition: all .4s cubic-bezier(0, -0.3, 1, 1.3);
				
				&-scroll {
					height: calc(100vh - 50px - 168rpx - env(safe-area-inset-top) - env(safe-area-inset-bottom));
					background-color: #f4f4f4;
					width: 100%;
					
					::-webkit-scrollbar {
						display: none;
					}
					
					&-item {
						width: 136rpx;
						height: 96rpx;
						position: relative;
						display: flex;
						justify-content: center;
						align-items: center;
						
						&-img {
							left: 0;
							top: 0;
							z-index: 20;
							width: 136rpx;
							height: 96rpx;
							position: absolute;
						}
						
						&-active {
							width: 8rpx;
							height: 48rpx;
							background-color: #FF5927;
							border-radius: 4rpx;
							position: absolute;
							left: 0;
							top: 24rpx;
							z-index: 40;
						}
						
						&-text {
							z-index: 30;
							font-size: 28rpx;
							color: #666666;
						}
					}
				}
			}
			
			&-right {
				transition: all .2s cubic-bezier(0, -0.2, 1, 1.2);
				
				&-scroll {
					height: calc(100vh - 50px - 168rpx - env(safe-area-inset-top) - env(safe-area-inset-bottom));
					width: 100%;
					background-image: url('@/static/images/game/list-bg.png');
					background-size: 100% 100%;
					padding: 0rpx 24rpx 0rpx 24rpx;
					box-sizing: border-box;
					
					::-webkit-scrollbar {
						display: none;
					}
					
					&-empty {
						width: 100%;
						height: 100%;
					}
					
					&-loading {
						width: 100%;
						height: 100%;
						position: absolute !important;
					}
					
					&-title {
						margin: 32rpx 0;
						font-size: 36rpx;
						font-weight: 700;
						color: #1C1C1C;
					}
				}
			}
		}
	
		.typePanel {
			
			&-layout {
				background-color: #FFFFFF;
				border-radius: 0 0 40rpx 40rpx;
				padding: 38rpx 32rpx 24rpx;
				
				&-scroll {
					width: 750rpx;
					margin-bottom: 48rpx;
					max-height: calc(100vh - 50px - 356rpx - env(safe-area-inset-top) - env(safe-area-inset-bottom));
					
					::-webkit-scrollbar {
						display: none;
					}
					
					&-h5 {
						display: flex;
						flex-direction: row;
						justify-content: flex-start;
						align-items: center;
						margin-bottom: 46rpx;
						
						.h5-select {
							margin-right: 48rpx;
							padding: 0 32rpx;
							height: 64rpx;
							background-color: #F8F8F8;
							border-radius: 32rpx;
							font-size: 28rpx;
							box-sizing: border-box;
							font-family: PingFang SC;
							color: #666666;
							font-weight: 400;
							display: flex;
							justify-content: center;
							align-items: center;
							border: 2rpx solid transparent;
							
							&-active {
								border: 2rpx solid #FF5927;
								color: #FF5927;
								font-weight: 600;
							}
						}
					}
					
					&-tags {
						margin-bottom: 46rpx;
						
						.tags_title {
							// width: 142px;
							display: inline-block;
							height: 44rpx;
							font-size: 32rpx;
							font-family: PingFang SC;
							font-weight: 600;
							line-height: 44rpx;
							color: #1C1C1C;
							margin-bottom: 28rpx;
						}
						
						.tags_select {
							display: flex;
							flex-direction: row;
							justify-content: flex-start;
							align-items: center;
							
							&-text {
								margin-right: 48rpx;
								padding: 0 32rpx;
								height: 64rpx;
								background-color: #F8F8F8;
								border-radius: 32rpx;
								font-size: 28rpx;
								box-sizing: border-box;
								font-family: PingFang SC;
								color: #666666;
								font-weight: 400;
								display: flex;
								justify-content: center;
								align-items: center;
								border: 2rpx solid transparent;
								
								&-active {
									border: 2rpx solid #FF5927;
									color: #FF5927;
									font-weight: 600;
								}
							}
						}
					}
					
					&-cates {
						margin-bottom: 46rpx;
						
						.cates_title {
							// width: 142px;
							display: inline-block;
							height: 44rpx;
							font-size: 32rpx;
							font-family: PingFang SC;
							font-weight: 600;
							line-height: 44rpx;
							color: #1C1C1C;
							margin-bottom: 28rpx;
						}
						
						.cates_select {
							display: flex;
							flex-direction: row;
							justify-content: flex-start;
							flex-wrap: wrap;
							align-items: center;
							
							&-text {
								margin-right: 24rpx;
								width: 212rpx;
								height: 88rpx;
								padding-left: 80rpx;
								background-color: #F8F8F8;
								border-radius: 44rpx;
								font-size: 28rpx;
								box-sizing: border-box;
								font-family: PingFang SC;
								color: #666666;
								font-weight: 400;
								display: flex;
								justify-content: flex-start;
								align-items: center;
								border: 2rpx solid transparent;
								background-size: 32rpx 32rpx;
								background-repeat: no-repeat;
								background-position: 24rpx center;
								position: relative;
								
								&:nth-child(n + 4) {
									margin-top: 32rpx;
								}
								
								&-active {
									border: 2rpx solid #FF5927;
									color: #1C1C1C;
									font-weight: 500;
								}
								
								&-activeImg {
									width: 66rpx;
									height: 32rpx;
									position: absolute;
									right: 0;
									bottom: 0;
								}
							}
						}
					}
				}
			
				&-confirmLayout {
					width: 100%;
					height: 80rpx;
					position: relative;
					
					&-reset {
						background-color: #EFEFEF;
						width: 434rpx;
						height: 100%;
						color: #666666;
						font-size: 32rpx;
						display: flex;
						padding-left: 136rpx;
						align-items: center;
						justify-content: flex-start;
						box-sizing: border-box;
						border-radius: 46rpx;
						position: absolute;
						left: 0;
					}
					
					&-confirm {
						background-color: #FFFFFF;
						width: 346rpx;
						height: 100%;
						color: #FF5927;
						font-style: 32rpx;
						display: flex;
						padding-right: 136rpx;
						align-items: center;
						justify-content: flex-end;
						box-sizing: border-box;
						border-radius: 0rpx 48rpx 48rpx 48rpx;
						position: absolute;
						right: 0;
						border: 2rpx solid #FF5927;
					}
				}
			}
		}
	}
</style>