<template>
	<view class="container">
		<view class="container-topTitle">
			<view class="container-topTitle-box">
				<view class="container-topTitle-box-left">
					<image class="container-topTitle-box-left-img" src="@/static/images/left.png" mode="heightFix" @click="back" />
					<text class="container-topTitle-box-left-text">交易</text>
				</view>
			</view>
		</view>
		
		<view class="container-content">
			<view class="nav-bar">
				<u-tabs :list="TitleList" @click="click"  lineWidth="40rpx" lineHeight="2px" lineColor="#ff5927" :activeStyle="{color: '#1c1c1c',fontWeight: 'bold'}"
				:inactiveStyle="{color: '#999'}" :current="active" itemStyle="padding-left: 32rpx; padding-right: 32rpx; height: 84rpx;"></u-tabs>
				<view class="bar-right">
					<view class="icon-box">
						<image src="@/static/images/my/my_details.png" mode="widthFix" @click="handleDelete" class="right-icon"></image>
					</view>
					<view class="icon-box">
						<image src="@/static/images/wen-icon.png" mode="widthFix" @click="show=true" class="right-icon"></image>
					</view>
				</view>
			</view>
			
			<view class="content">
				<buynumber v-if="!active" ref="buynumber"></buynumber>
				<sellingnumber v-if="active==1"></sellingnumber>
			</view>
		</view>
	</view>
</template>

<script>
	import buynumber from '@/pages/transaction/children/buynumber'
	import sellingnumber from '@/pages/transaction/children/sellingnumber'
	export default {
		components: {
			buynumber,
			sellingnumber
		},
		data() {
			return {
				show: false,
				active: 0,
				TitleList: [{
						id: 0,
						name: '买号'
					},
					{
						id: 1,
						name: '卖号'
					},
					{
						id: 2,
						name: '回收'
					}
				],
			}
		},
		methods: {
			back() {
				uni.navigateBack()
			},
			click(item) {
					this.active = item.id
			},
		},
		onReachBottom() {
			if(!this.active) {
				this.$refs.buynumber.getMoreData()
			}
		}
	}
</script>

<style lang="scss">
	.container {
		background-color: #FFFFFF;
		width: 750rpx;
		height: 100vh;
		
		&-topTitle {
			position: fixed;
			// background-color: #FFFFFF;
			background: linear-gradient(to bottom, #CCCCCC, #FFFFFF env(safe-area-inset-top));
			z-index: 999;
			top: 0;
			width: 750rpx;
			height: 176rpx;
			padding: 0 34rpx 16rpx;
			box-sizing: border-box;
			display: flex;
			flex-direction: column;
			justify-content: flex-end;
			box-shadow: 0rpx 0rpx 12rpx rgba(0, 0, 0, 0.16);
			
			&-box {
				box-sizing: border-box;
				display: flex;
				flex-direction: row;
				justify-content: space-between;
				align-items: center;
				
				&-left {
					display: flex;
					flex-direction: row;
					align-items: center;
					
					&-img {
						height: 34rpx;
					}
					
					&-text {
						margin-left: 48rpx;
						font-size: 40rpx;
						line-height: 56rpx;
						font-family: PingFang SC;
						font-weight: 600;
						color: #1C1C1C;
					}
				}
				
				&-right {
					display: block;
					width: 35rpx;
					height: 35rpx;
				}
			}
		}
		
		&-content {
			width: 750rpx;
			padding: 176rpx 0 0;
			box-sizing: border-box;
			color: #1C1C1C;
			font-family: PingFang SC;
			min-height: 100vh;
			position: sticky;
			
			.nav-bar {
				background-color: #FFFFFF;
				display: flex;
				align-items: center;
				justify-content: space-between;
				height: 90rpx;
				position: sticky;
				top: 176rpx;
				z-index: 99;
				.bar-right {
					display: flex;
					padding-right: 32rpx;
					.icon-box {
						display: flex;
						align-items: center;
						justify-content: center;
						width: 64rpx;
						height: 64rpx;
						margin-left: 24rpx;
						background: rgba(255,255,255,0.39);
						box-shadow: 0px 0px 8px rgba(0,0,0,0.16);
						border-radius: 44rpx;
						.right-icon {
							display: block;
							width: 35rpx;
							height: 35rpx;
						}
					}
				}
			}
			
			.content {
				position: sticky;
				top: 250rpx;
				padding: 0 32rpx;
			}
		}
	}
</style>