<template>
	<view class="buynumber">
		<view class="search">
			<view class="inputs">
				<image src="@/static/images/search-gren.png" mode="widthFix" style="width: 30rpx;margin-right: 24rpx;"></image>
				<input class="input" type="text" v-model="params.game_name" placeholder='去找你的想要的游戏'
					placeholder-style='font-size:32rpx;color:#c1c1c1' @input='search'></input>
			</view>
		</view>
		<view class="list" v-if="pageData.length">
			<view class="list-item" v-for="(item,index) in pageData" :key="index">
				<vue-transaItem :item="item"></vue-transaItem>
			</view>
			<u-loadmore :status="status" loading-text="努力加载中" loadmore-text="加载更多" nomore-text="没有更多了"
			 fontSize="28" line height="80" iconColor="#ff5927"  iconSize="48" loadingIcon="circle"	/>
		</view>
		<vue-loading :isNoData="isNoData" v-else></vue-loading>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				params: {
					page: 1,
					offset: 20,
					status: 2,
					sort_type: 1,
					game_name: ''
				},
				status: 'loadmore',
				count: 0,
				pageData: [],
				isNoData: false
			}
		},
		methods: {
			search() {
				this.pageData = []
				this.count = 0
				this.params.page = 1
				this.getPageData(2)
			},
			getPageData(type=1) {
				if (this.params.game_name == '') {
					delete this.params.game_name
				}
				this.$api.get("account/goods/list", {
					...this.params
				}).then(res => {
					if (res.data.code == 200) {
						if(type==2) {
							this.pageData = res.data.data.list
							console.log(type,this.pageData);
						} else {
							this.pageData = this.pageData.concat(res.data.data.list)
						}
						this.count = res.data.data.count
						this.status="loadmore"
						if(this.pageData.length>=this.count) {
							this.status="nomore"
						}
						if (!this.count) {
							this.isNoData = true
						}
					}
				})
			},
			getMoreData() {
				if(this.count>this.pageData.length&&this.status=="loadmore") {
					this.status = "loading"
					this.params.page++
					this.getPageData()
				}
			}
		},
		mounted() {
			this.getPageData()
		}
	}
</script>

<style lang="scss">
	.buynumber {
		.search {
			position: sticky;
			top: 178rpx;
			width: 100%;
			padding: 32rpx;
			background-color: #fff;
			box-sizing: border-box;
			z-index: 90;
			.inputs {
				width: 100%;
				height: 72rpx;
				padding: 0 32rpx;
				display: flex;
				align-items: center;
				justify-content: center;
				background: rgba(244,244,244,0.39);
				border-radius: 36rpx;
				box-sizing: border-box;
				.input {
					flex: 1 1 auto;
				}
			}
		}
		.list {
			padding: 16rpx 32rpx;
			.list-item {
				margin-bottom: 32rpx;
			}
		}
	}
</style>