<template>
	<view class="sellingnumber">
		<view class="input-box">
			<view class="input-left">添加游戏</view>
			<view class="input-right" @click="addxh">
				<text>{{form.gamename}}</text>
				<image src="@/static/images/999_right.png" mode="widthFix" class="right-icon"></image>
			</view>
		</view>
		<view class="input-box">
			<view class="input-left">
				添加小号
			</view>
			<view class="input-right">
				<text>{{form.role_name}}</text>
				<image src="@/static/images/999_right.png" mode="widthFix" class="right-icon"></image>
			</view>
		</view>
		<view class="input-box">
			<view class="input-left">
				区服
			</view>
			<view class="input-right">
				<text>{{form.server_name}}</text>
			</view>
		</view>
		<view class="input-box">
			<view class="input-left">标题</view>
			<input type="text" class="inputs" v-model="form.title" placeholder="请输入核心卖点" maxlength="20" placeholder-style="color:#e1e1e1"/>
		</view>
		<view class="input-box">
			<textarea class="textarea" v-model="form.description" maxlength="210" placeholder="可描述角色等级，装备，属性等，10-199字，完善描述可以快速有效的促成交易哦！" placeholder-style="color:#e1e1e1"></textarea>
		</view>
		<view class="input-box">
			<view class="input-left">售价</view>
			<input type="number" class="inputs" v-model="form.price" placeholder="请填写价格最低6元" maxlength="20" style="width: 260rpx;" placeholder-style="color:#e1e1e1"/>
		</view>
		<view class="box1">
			<view class="box1-title">游戏截图</view>
			<view class="upload">
				<vue-upLoadImage :max_number='3' @upLoadSuccess='uploadSuccess' :clearImageList="clearImageList"></vue-upLoadImage>
			</view>
		</view>
		<view class="button">提交审核</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				form: {
					gamename: '选择游戏',
					role_name: '选择小号',
					mg_mem_id: "",
					mg_role_id: "",
					server_name: "",
					server_id: "",
					price: "",
					title: "",
					description: "",
					image: "",
					"sms-code": "",
					account_id: ""
				},
				fileList: [],
				clearImageList:0,
			}
		},
		computed: {
			userInfo() {
				return this.$store.state.userInfo
			},
		},
		methods: {
			addxh() {
				if(this.$common.isLogin()){
					this.resetForm()
					this.handleRouter('/pages/transaction/children/sellingnumber/addGame/addGame')
				}
			},
			//跳转
			handleRouter(url, type) {
				if (!type) {
					uni.navigateTo({
						url
					})
				} else if (!this.game_id) {
					uni.showToast({
						title: '请选择游戏',
						icon: 'none'
					})
				} else {
					uni.navigateTo({
						url
					})
				}
			},
			// 图片上传
			upLoadSuccess(data) {
				this.fileList = data;
				console.log(data,'this.fileList')
				this.form.image = JSON.stringify(this.fileList);
			},
			// 重置表单
			resetForm() {
				this.form = {
					gamename: "选择游戏",
					role_name: "选择小号",
					mg_mem_id: "",
					mg_role_id: "",
					server_name: "",
					server_id: "",
					price: "",
					title: "",
					description: "",
					image: "",
					"sms-code": ""
				}
				this.clearImageList++
			},
		}
	}
</script>

<style lang="scss" scoped>
	.sellingnumber {
		padding: 8rpx 32rpx;
		.input-box {
			display: flex;
			align-items: center;
			justify-content: space-between;
			padding: 34rpx 20rpx 38rpx;
			line-height: 30rpx;
			border-bottom: 2rpx solid #ececec;
			.input-left {
				font-size: 32rpx;
				font-weight: 600;
				color: #252525;
			}
			.input-right {
				display: flex;
				align-items: center;
				font-size: 30rpx;
				font-weight: 500;
				color: #999999;
				.right-icon {
					width: 20rpx;
					margin-left: 16rpx;
				}
			}
			.inputs {
				flex: 1;
				margin-left: 50rpx;
				font-size: 30rpx;
				text-align: right;
			}
			.textarea {
				width: 100%;
				height: 200rpx;
				font-size: 30rpx;
			}
		}
		.box1 {
			.box1-title {
				padding: 32rpx 20rpx 40rpx;
				font-size: 32rpx;
				font-weight: 600;
				color: #252525;
			}
		}
		.button {
			width: 400rpx;
			height: 80rpx;
			margin: 40rpx auto;
			border: 2rpx solid #E1E1E1;
			border-radius: 40rpx;
			font-size: 34rpx;
			font-weight: bold;
			color: #FF4810;
			line-height: 80rpx;
			text-align: center;
		}
	}
</style>