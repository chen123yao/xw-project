<template>
	<view class="container">
		<view class="top-bar">
			<view class="bar-left" @click="toback">				
				<u-icon name="arrow-left" color="#000" size="42" class="arrow-left"></u-icon>
				<text>选择游戏</text>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			toback() {
				uni.navigateBack()
			},
		}
	}
</script>

<style lang="scss">
	.container {
		padding-top: 88rpx;
		.top-bar {
			position: fixed;
			left: 0;
			top: 0;
			width: 100%;
			padding: 0 32rpx 0 16rpx;
			display: flex;
			align-items: center;
			justify-content: space-between;
			height: 88rpx;
			box-sizing: border-box;
			font-size: 16px;
			color: #000;
			background-color: #fff;
			box-shadow: 0px 0px 5px 0px rgba(221,221,221,0.8);
			z-index: 99;
			.bar-left {
				display: flex;
				justify-content: center;				
				.arrow-left {
					margin-right: 32rpx;
				}
			}
			.right-icon {
				display: block;
				width: 35rpx;
				height: 35rpx;
			}
		}
	}
</style>
