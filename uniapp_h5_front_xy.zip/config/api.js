import { request } from '@/config/request.js' // 全局挂载引入

const api = {
	get(url, data) {
		return request.get(url, {
			params: data
		});
	},
	post(url, data) {
		return request.post(url, data);
	}
}

export default api