<template>
	<view class="coupons-item">
		<view class="cell-left">
			<view class="coupons-amount">
				<text style="font-size: 50rpx;">{{item.coupons_amount}}</text>
			</view>
			<view class="left_text1" v-if="!item.game_name">满{{parseInt(item.order_amount_min)}}元使用</view>
			<view class="left_text1" v-else>{{item.title}}</view>
		</view>
		<view class="cell-right">
			<view class="right-date">
				<view class="date">
					<view class="date-title">
						有效期至：{{item.get_time_end | dateFormat('yyyy-MM-dd')}}
					</view>
					<text class="right_text">领取时间：{{item.get_time_begin | dateFormat('yyyy-MM-dd')}}后</text>
				</view>
				<view class="button" v-if="item.status==1" @click="handleRouterdetail(item.game_id)">去使用</view>
				<view class="button disabled" v-if="item.status==2">已使用</view>
				<view class="button disabled" v-if="item.status==3">已过期</view>
			</view>
			<view class="coupons-details">
				<text v-if="!item.game_name">通用券 （部分游戏无法使用）</text>
				<text v-else>适用于《{{item.game_name}}》</text>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		props: ['item'],
		methods:{
			handleRouterdetail(id) {
				uni.navigateTo({
					url: `/pages/view/gameDetail/gameDetail?gameId=${ id }`
				})
			},
		}
	}
</script>

<style lang="scss">
	.coupons-item{
		display: flex;
		margin: 48rpx 0;
		height: 162rpx;
		border-radius: 40rpx;
		overflow: hidden;
		box-sizing: border-box;
		// display: flex;
		// width: 100%;
		// height: 100%;
		.cell-left {
			width: 190rpx;
			height: 100%;
			background: #E9E9E9;
			text-align: center;
			.coupons-amount {
				padding-top: 24rpx;
				height: 82rpx;
				line-height: 82rpx;
				font-size: 24rpx;
				color: #1c1c1c;
				font-weight: 600;
			}
			.left_text1 {
				height: 28rpx;
				font-size: 24rpx;
				font-weight: 500;
				line-height: 28rpx;
				color: #666666;
				// transform: scale(0.8);
				// transform-origin: center;
			}
		}
		.cell-right {
			flex: 1;
			padding: 0 24rpx;
			font-size: 24rpx;
			color: #c1c1c1;
			box-sizing: border-box;
			background-color: #F8F8F8;
			.right-date {
				height: 102rpx;
				display: flex;
				align-items: center;
				justify-content: space-between;
				border-bottom: 1px solid #c1c1c1;
				box-sizing: border-box;
				.date-title {
					font-size: 28rpx;
					color: #666;
				}
				.button {
					width: 104rpx;
					height: 48rpx;
					text-align: center;
					line-height: 44rpx;
					font-size: 24rpx;
					font-weight: 600;
					color: #ff5927;
					box-sizing: border-box;
					border: 2rpx solid #E4E4E4;
					border-radius: 32rpx;
					&.disabled {
						background:rgba(28,28,28,0.39);
						color: #fff;
					}
				}
			}
			.coupons-details {
				height: 60rpx;
				line-height: 60rpx;
			}
		}
	}
</style>