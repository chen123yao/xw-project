<template>
	<view class="">
		<image v-if="!isNoData" src="@/static/images/Refreshmore.gif" mode="widthFix" style="width: 300rpx;height: 300rpx;display: block;margin: 0 auto;" />
		<view class="" style="display: flex;flex-direction: column;align-items: center;justify-content: center;" v-else>
			<image src="@/static/images/loading-noData.png" mode="widthFix" style="width: 100%;"></image>
			<view class="" style="font-size: 30rpx;font-weight: 300;color: #666;white-space: nowrap;">暂时找不到，去看看别的~</view>
		</view>
	</view>
</template>

<script>
	export default {
		props: {
			isNoData: {
				type: Boolean,
				default: false
			}
		}
	}
</script>

<style lang="scss">
</style>