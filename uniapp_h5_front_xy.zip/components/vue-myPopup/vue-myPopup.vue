<template>
	<view class="myPopup"  @touchmove.prevent.stop="toucnMove" v-if="isShowMyPopup">
		<view class="box1">
			<view class="share-image">
				<image src="@/static/images/fx-share.png" mode="scaleToFill" style="width: 46rpx;height: 46rpx;transform: rotate(-45deg);"></image>
			</view>
			<view class="close-share" @click="close">
				<image src="@/static/images/comment-close.png" mode="widthFix" style="width: 34rpx;height: 34rpx;transform: rotate(-45deg);"></image>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		props: ['isShowMyPopup'],
		data() {
			return {
				key: ''
			}
		},
		
		methods: {
			toucnMove(e) {
				e.stopPropagation()
			},
			close() {
				this.$emit('close')
			} 
		}
	}
</script>

<style lang="scss">
	@keyframes run {
		from {
			transform-origin: 800rpx 800rpx;
			transform: rotate(-90deg);
		}
		to {
			transform-origin: 800rpx 800rpx;
			transform: rotate(45deg);
		}
	}
	.myPopup {
		position: fixed;
		top: 0;
		left: 0;
		width: 100%;
		height: 100%;
		background-color: rgba(0, 0, 0, 0.8);
		z-index: 900;
		display: flex;
		align-items: flex-end;
		.box1 {
			position: absolute;
			bottom: -440rpx;
			right: 375rpx;
			background-color: #fff;
			width: 800rpx;
			height: 800rpx;
			border-radius: 800rpx 0 0 0;
			animation: run 0.5s forwards;
			.share-image {
				display: flex;
				align-items: center;
				justify-content: center;
				width: 106rpx;
				height: 106rpx;
				background: #F6F6F6;
				border-radius: 50%;
				margin: 260rpx 0 0 260rpx;
			}
			.close-share {
				display: flex;
				align-items: center;
				justify-content: center;
				width: 80rpx;
				height: 80rpx;
				background: #F2F2F2;
				border-radius: 50%;
				margin: 16rpx 0 0 380rpx;
			}
		}
	}
</style>