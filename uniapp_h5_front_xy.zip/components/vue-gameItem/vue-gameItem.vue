<template>
	<view class="gameItem_layout" @click="handleRouter(itemData.game_id || itemData.id)" :style="{ marginBottom: itemBMargin + 'rpx', width: itemWidth + 'rpx', padding: !hasPadding ? '0' : ''}" v-if="itemData">
		<!-- cc 游戏图标部分 包含游戏icon和tag -->
		<view class="gameItem-icon" :style="{ width: iconWidth + 'rpx', height: iconWidth + 'rpx', minWidth: iconWidth + 'rpx' }">
			<!-- cc 游戏图标 -->
			<image class="gameIcon" mode="scaleToFill" :src="itemData.new_icon || itemData.icon" />
			
			<!-- cc 游戏图标上的tag -->
			<!-- cc 排名显示 -->
			<view class="gameIcon-tag" v-if="tagType == 1 && itemRankIndex < 100">
				<image class="iconTag-bground" src="@/static/images/icon-rate.png" mode="scaleToFill"></image>
				<text class="iconTag-text">NO:{{ itemRankIndex }}</text>
			</view>
			<!-- cc 打分显示 -->
			<view class="gameIcon-tag" v-if="tagType == 2" >
				<image class="iconTag-bground" src="@/static/images/icon-rate.png" mode="scaleToFill"></image>
				<text class="iconTag-text">{{ itemData.star_cnt }}分</text>
			</view>
			<!-- cc 福利显示 优先级:折扣 > 优惠券 > 返利 -->
			<view class="gameIcon-tag" v-if="tagType == 3" >
				<image class="iconTag-bground" v-if="itemData.rate < 1" src="@/static/images/icon-rate.png" mode="scaleToFill" ></image>
				<image class="iconTag-bground" v-else-if="itemData.has_coupons || itemData.has_rebate" src="@/static/images/yhq-rate1.png" mode="scaleToFill"></image>
				<text class="iconTag-text" v-if="itemData.rate < 1">{{ (itemData.rate * 10).toFixed(1) }} 折</text>
				<text class="iconTag-text" v-else-if="itemData.has_coupons">优惠券</text>
				<text class="iconTag-text" v-else-if="itemData.has_rebate">返 利</text>
			</view>
		</view>
		<!-- cc 游戏相关信息显示部分 包含游戏tag和类型、在玩人数等 -->
		<view class="gameItem-detail" :style="{ height: iconWidth + 'rpx' }">
			<!-- cc 根据排名信息在左上角显示排名信息 一般用于排行榜专题 前三名的显示 -->
			<view v-if="tagType == 4 && itemRankIndex < 3" class="content-rank">
				<image class="content-rank-img" :src="require('@/static/images/remen' + (itemRankIndex + 1) + '.png')" mode="scaleToFill" />
			</view>
			<!-- cc 游戏相关信息 详情显示部分 -->
			<view class="content-main">
				<!-- cc 游戏名称 -->
				<text class="content-main-gameName h1">{{ itemData.gamename }}</text>
				<!-- cc 游戏福利标签 -->
				<view class="content-main-tags">
					<text class="content-main-tags-tag" v-for="(value, index) in (itemData.selling_point.split(',').slice(0,2))"
						:style="{ color: contentTagsColor[index].color, backgroundColor: contentTagsColor[index].bgc }">{{ value }}</text>
				</view>
				<!-- cc 游戏类型、在线人数 -->
				<view class="content-main-types">
					<view v-if="itemData.start_time.length || typeof itemData.start_time == 'number'" class="content-main-types-time" >
						<text v-if="typeof itemData.start_time == 'number'" class="content-main-types-time-text"> {{ itemData.start_time | dateFormat('hh:mm') }}</text>
						<text v-else class="content-main-types-time-text"> {{ itemData.start_time[0] | dateFormat('hh:mm') }}</text>
						<text> 开服 | </text>
					</view>
					<text class="content-main-types-type content-main-types-time" v-if="itemData.classify == 5">H5</text>
					<text class="content-main-types-type content-main-types-time content-main-types-time-text" v-for="(v, i) in itemData.type" :key="i" v-if="i < 2">{{ v }}</text>
					<text class="content-main-types-user_cnt content-main-types-time"> | 已有{{ itemData.popularity_cnt }}人在玩</text>
				</view>
			</view>
			<!-- cc 部分组件右侧添加打星的部分 -->
			<view v-if="tagType == 5" class="content-star">
				<image class="content-star-img" src="@/static/images/star_red.png" mode="scaleToFill"></image>
				<text class="content-star-text">{{ itemData.star_cnt }}</text>
			</view>
		</view>
		<!-- cc 右侧的类型显示部分 -->
		<view  v-if="isShowMaxWidth" class="gameItem-rightType">
			<view v-if="itemData.rate < 1" class="gameItem-rightType-item">
				<text class="gameItem-rightType-text">{{ (itemData.rate * 10).toFixed(1) }} </text>
				<text class="gameItem-rightType-text" style="font-size: 20rpx;"> 折</text>
			</view>
			<text v-else-if="itemData.has_coupons" class="gameItem-rightType-item">优惠券</text>
			<text v-else-if="itemData.has_rebate" class="gameItem-rightType-item">返  利</text>
		</view>
	</view>
</template>

<script>
	export default {
		props: {
			itemData: {
				type: Object,
				default: () => {
					return {}
				}
			},
			// cc item的宽度
			itemWidth: {
				type: Number,
				default: 750 // 默认rpx
			},
			// cc 游戏icon上的tag类型 1排名 2打分 3福利 4icon上不显示tag，在icon右上角外侧显示排名奖牌标记 5附带打星的部分
			tagType: {
				type: Number,
				default: 0 // 默认不显示tag
			},
			// cc 是否显示右侧福利标记
			isShowMaxWidth: {
				type: Boolean,
				default: false //默认不显示 一般用于游戏大厅页面
			},
			// cc 游戏排名展示名次
			itemRankIndex: {
				type: Number,
				default: 1 // 默认排列第一
			},
			// cc 游戏item内容区域的tag展示颜色 默认显示两个tag
			contentTagsColor: {
				type: Array,
				default: () => {
					return [{color: '#FEAF36', bgc: '#FEF7EC'},
						{color: '#28D58B', bgc: '#E9FBF3'}]
				}
			},
			// cc 游戏item内容区的宽度是否因为左边list元素而隐藏最右边的部分
			contentHiddenW: {
				type: Boolean,
				default: false // 默认不隐藏
			},
			// cc 游戏item底部外边距高度
			itemBMargin: {
				type: Number,
				default: 40 // 默认40rpx
			},
			// cc	游戏icon整体宽度/icon图标高度
			iconWidth: {
				type: Number,
				default: 140 // 默认140rpx
			},
			// cc 是否有左右边距
			hasPadding: {
				type: Boolean,
				default: true
			}
		},
		data() {
			return {
				
			}
		},
		methods: {
			// cc 点击跳转该游戏详情页面
			handleRouter(gameId) {
				uni.navigateTo({
					url: `/pages/view/gameDetail/gameDetail?gameId=${gameId}`
				})
			}
		}
	}
</script>

<style lang="scss" scoped>
	.gameItem_layout {
		// width: 750rpx;
		display: flex;
		align-items: center;
		flex-direction: row;
		padding: 0rpx 32rpx;
		box-sizing: border-box;
		
		.gameItem-icon {
			position: relative;
			
			.gameIcon,
			.gameIcon-tag,
			.iconTag-bground,
			.iconTag-text {
				top: 0;
				left: 0;
				width: 100%;
				height: 100%;
				position: absolute;
			}
			
			.iconTag-text {
				left: 5rpx;
				color: #fff;
				font-weight:700;
				font-size: 20rpx;
				width: 70rpx;
				text-align: center;
			}
		}
		
		.gameItem-detail {
			flex: 1;
			display: flex;
			overflow: hidden;
			position: relative;
			align-items: center;
			flex-direction: row;
			box-sizing: border-box;
			justify-content: flex-end;
			padding: 0rpx 40rpx 0rpx 20rpx;

			.content-rank {
				min-width: 36rpx;
				margin-right: 20rpx;
				align-self: flex-start;
				
				&-img {
					width: 36rpx;
					height: 44rpx;
				}
			}
			
			.content-main {
				flex: 1;
				height: 100%;
				display: flex;
				overflow: hidden;
				flex-direction: column;
				justify-content: space-between;
				
				&-gameName {
					width: 100%;
					font-size: 32rpx;
					font-weight: 500;
					font-family: PingFang SC;
					color: #000000;
					display: block;
					overflow: hidden;
					text-overflow: ellipsis;
					white-space: nowrap;
				}
				
				&-tags {
					display: flex;
					flex-direction: row;
					align-items: center;
					
					&-tag {
						font-size: 24rpx;
						margin-right: 15rpx;
						border-radius: 20rpx;
						padding: 4rpx 10rpx 4rpx 10rpx;
						overflow: hidden;
						text-overflow: ellipsis;
						white-space: nowrap;
					}
				}
				
				&-types {
					display: flex;
					overflow: hidden;
					flex-direction: row;
					align-items: center;
					white-space: nowrap;
					
					&-type {
						margin-right: 10rpx;
					}
					
					&-time {
						color: #666666;
						font-size: 24rpx;
						font-weight: 300;
						
						&-text {
							color: #ff5927;
						}
					}
					
					&-user_cnt {
						overflow: hidden;
						white-space: nowrap;
						text-overflow: ellipsis;
					}
				}
			}
			
			.content-star {
				height: 100%;
				padding-top: 30rpx;
				margin-left: 18rpx;
				flex-direction: row;
				align-items: center;
				justify-self: flex-end;
				
				&-img {
					width: 24rpx;
					height: 24rpx;
				}
				
				&-text {
					color: #ff5927;
					font-size: 32rpx;
					margin-left: 10rpx;
				}
			}
		}
	
		.gameItem-rightType {
			width: 120rpx;
			text-align: center;
			
			&-item {
				width: 100%;
				display: block;
				color:#19BFFF;
				font-size: 26rpx;
				font-weight: 600;
				padding: 8rpx 0rpx;
				border-radius: 32rpx;
				box-sizing: border-box;
				border: 2rpx solid #E4E4E4;
			}
			
			&-text {
				color: #FF5927;
				font-size: 28rpx;
			}
		}
	}
</style>