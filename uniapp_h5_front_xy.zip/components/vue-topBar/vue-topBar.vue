<template>
	<view class="top-bar">
		<view class="left-box" @click="handleRouter(left_url)">
			<u-icon name="search" :color="topBarStyle.searchColor" size="40" style="margin: 0 8px;"></u-icon>
			<text class="search_text" :style="{ color: topBarStyle.textColor }">去找你要看到的</text>
		</view>
		<view class="right-box">
			<u-icon name="bell" :color="topBarStyle.bellColor" size="56" style="margin-left: 24rpx;" @click="handleRouter(right_url)"></u-icon>
		</view>
	</view>
</template>

<script>
	export default {
		props: {
			left_url: {
				Type: String,
				default: ''
			},
			right_url: {
				Type: String,
				default: ''
			},
			topBarStyle: {
				Type: Object,
				default: {
					searchColor: '#fff',
					textColor: '#c1c1c1',
					bellColor: '#fff'
				}
			}
		},
		methods:{
			handleRouter(url) {
				console.log(url);
				uni.navigateTo({
					url: url
				})
			}
		}
	}
</script>

<style lang="scss">
	.top-bar {
		display: flex;
		align-items: center;
		justify-content: space-between;
		padding: 0 32rpx;
		background-color: transparent;
		.left-box {
			display: flex;
			align-items: center;
			height: 56rpx;
			flex: 1;
			border-radius: 36rpx;
			background-color: rgba(204, 204, 204, .2);
			.search_text {
				font-size: 24rpx;
				line-height: 34rpx;
			}
		}
		.right-box {
			
		}
	}
</style>