<template>
	<view class="gameIcon_layout" @click="handleRouter(iconData.game_id || iconData.id)" :style="{ width: iconWidth + 'rpx', marginBottom: iconBMargin + 'rpx' }" v-if="iconData">
		<!-- cc 游戏图标 -->
		<image class="gameIcon" mode="scaleToFill" :src="iconData.new_icon||iconData.icon" :style="{ width: iconWidth + 'rpx', height: iconWidth + 'rpx' }" />
		
		<!-- cc 游戏图标上的tag -->
		<view v-if="iconData.rate < 1" class="gameIcon-tag" :style="{ width: iconWidth + 'rpx', height: iconWidth + 'rpx' }">
			<image class="tag-img" mode="scaleToFill" src="@/static/images/icon-rate.png" :style="{ width: iconWidth + 'rpx', height: iconWidth + 'rpx' }" />
			<text class="tag-text" :style="iconTagStyle">{{(iconData.rate*10).toFixed(1)}}折</text>
		</view>
		
		<view v-else-if="iconData.has_coupons" class="gameIcon-tag" :style="{ width: iconWidth + 'rpx', height: iconWidth + 'rpx' }">
			<image class="tag-img" mode="scaleToFill" src="@/static/images/yhq-rate1.png" :style="{ width: iconWidth + 'rpx', height: iconWidth + 'rpx' }" />
			<text class="tag-text" :style="iconTagStyle">优惠券</text>
		</view>
		
		<!-- cc 游戏图标对应的游戏名称 -->
		<text class="gameIcon-title" :style="{ ...iconTitleStyle , width: iconWidth + 'rpx'}">{{iconData.game_name || iconData.name}}</text>
	</view>
</template>

<script>
	export default {
		props: {
			// cc 游戏icon组件数据
			iconData: {
				type: Object,
				default: () => {
					return {}
				}
			},
			// cc 游戏icon底部外边距高度
			iconBMargin: {
				type: Number,
				default: 32 // 默认32rpx
			},
			// cc	游戏icon整体宽度/icon图标高度
			iconWidth: {
				type: Number,
				default: 120 // 默认120rpx
			},
			// cc 游戏icon上的tag样式
			iconTagStyle: {
				type: Object,
				default: () => {
					return {
						fontSize: '16rpx', // 默认16rpx
						color: '#fff', // 默认白色
						fontWeight: '400' // 默认normal粗细
					}
				}
			},
			// cc 游戏icon对应的游戏名称样式
			iconTitleStyle: {
				type: Object,
				default: () => {
					return {
						fontSize: '24rpx', // 默认24rpx
						color: '#666666', // 默认666
						fontWeight: '400' // 默认normal粗细
					}
				}
			}
		},
		data() {
			return {
				
			}
		},
		methods: {
			// cc 点击跳转该游戏详情页面
			handleRouter(gameId) {
				uni.navigateTo({
					url: `/pages/view/gameDetail/gameDetail?gameId=${gameId}`
				})
			}
		}
	}
</script>

<style lang="scss" scoped>
	.gameIcon_layout {
		position: relative;
		display: flex;
		flex-direction: column;
		
		.gameIcon-tag {
			position: absolute;
			top: 0;
			left: 0;
			
			.tag-text {
				position: absolute;
				top: 0;
				left: 0;
				width: 70rpx;
				text-align: center;
				font-family: PingFang SC;
			}
			
			.tag-img {
				position: absolute;
				top: 0;
				left: 0;
			}
		}
		
		.gameIcon-title {
			font-family: PingFang SC;
			overflow: hidden; //默认超出的文本隐藏
			text-overflow: ellipsis; //默认超出省略号显示
			display: -webkit-box;
			-webkit-box-orient: vertical;
			-webkit-line-clamp: 2;
			line-height: 34rpx;
			white-space: normal;
		}
	}
</style>