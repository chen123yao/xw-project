<template>
	<view class="titleLine_layout">
		<scroll-view ref="scroller" class="scroller" :show-scrollbar="false" :scroll-x="scrollAble" :scroll-left="scrollLeft">
			<view class="scroller-nav">
				<view class="tabItem" :ref="`tabItem-${index}`" v-for="(item, index) in titleList" :key="index" :style="{ height: itemHeight + 'rpx', flex: scrollAble ? '' : 1 }" 
					@tap="handleClick(item, index)">
					<text class="tabItem__text" ref="tabItem__text" :class="[item.disabled && 'tabItem__text--disabled', (index == innerCurrent) && 'tabItem__text--active']"
					 :style="{ color: textColor, fontSize: itemSize + 'rpx'}">{{ item.name }}</text>
					<view class="tabItem__line" ref="tabItem__line" :style="{ width: lineWidth + 'rpx', height: lineHeight + 'rpx', background: lineColor, backgroundSize: lineBgSize }"></view>
				</view>
			</view>
		</scroll-view>
	</view>
</template>

<script>
	export default {
		props: {
			titleList: {
				type: Array,
				default: () => []
			},
			lineColor: {
				type: String,
				default: '#FF5927'
			},
			duration: {
				type: Number,
				default: 300
			},
			lineWidth: {
				type: Number,
				default: 40
			},
			lineHeight: {
				type: Number,
				default: 6
			},
			lineBgSize: {
				type: String,
				default: 'cover'
			},
			itemSize: {
				type: Number,
				default: 30
			},
			itemHeight: {
				type: Number,
				default: 88
			},
			scrollAble: {
				type: Boolean,
				default: true
			},
			current: {
				type: Number,
				default: 0
			},
			scrollMove: {
				type: Number,
				default: 0
			},
			textColor: {
				type: String,
				default: '#666666'
			},
			isCanChange: {
				type: Boolean,
				default: true
			},
			isActives: {
				type: Boolean,
				default: false
			}
		},
		data() {
			return {
				firstTime: true,
				scrollLeft: 0,
				scrollViewWidth: 0,
				lineOffsetLeft: 0,
				tabsRect: {
					left: 0
				},
				tabsRectLineOffsetL: [],
				innerCurrent: 0,
				titleItemWidth:0,
				isActive: false
			}
		},
		mounted() {
			
		},
		methods: {
			
		}
	}
</script>

<style lang="scss" scoped>
	.titleLine_layout {
		
		.scroller {
			
			.scroller-nav {
				display: flex;
				flex-direction: row;
				position: relative;
				
				.tabItem {
					padding: 0 22rpx;
					
				}
			}
		}
	}
</style>