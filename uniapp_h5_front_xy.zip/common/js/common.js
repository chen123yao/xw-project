/*
 * 全局公用方法
 */
import Vue from 'vue'
import Store from '@/store/store';
import api from '@/config/api.js';
import md5 from 'js-md5'
const crypto = require('crypto');

export default {

	//登出
	logOut() {       
	    // api.get('/user/logout')
		// 清空本地存储的登录数据
		uni.setStorageSync('mem-username', '')
		uni.setStorageSync('mem-password', '')
		uni.setStorageSync('sms-mobile', '')
		uni.setStorageSync('mem-openid', '')
		Store.commit('setUserToken', {});
		Store.commit('setUserInfo', {});
		return
	},
	// 获取用户信息
	getuserInfo() {
		return api.get("/user/detail").then(res => {
			let username = uni.getStorageSync('mem-username')||uni.getStorageSync('sms-mobile');
			if (res.data.code == 200) {
				console.log('username=',username,'res.data=',res.data.data);
				// 当记录的用户登录账户与登录之后返回的账户不匹配时，就不允许登录成功
				if (username == res.data.data.mobile || username == res.data.data.username) {
					Store.commit('setUserInfo', res.data.data);
				} else {	
			    this.logOut()
				}
			} else {
				this.logOut()

			}
		})

	},
	
	number(value) {
		return /^[\+-]?(\d+\.?\d*|\.\d+|\d\.\d+e\+\d+)$/.test(value)
	},
	
	getPx(value, unit = false) {
		if (this.number(value)) {
			return unit ? `${value}px` : Number(value)
		}
		// 如果带有rpx，先取出其数值部分，再转为px值
		if (/(rpx|upx)$/.test(value)) {
			return unit ? `${uni.upx2px(parseInt(value))}px` : Number(uni.upx2px(parseInt(value)))
		}
		return unit ? `${parseInt(value)}px` : parseInt(value)
	},

	//获取节点
	getEl(el) {
		if (typeof el === 'string' || typeof el === 'number') return el;
		if (WXEnvironment) {
			return el.ref;
		} else {
			return el instanceof HTMLElement ? el : el.$el;
		}
	},
	// 节流函数：规定在一个单位时间内，只能触发一次函数。如果这个单位时间内触发多次函数，只有一次生效
	// throttle(canRun, func, wait) {
	// 	return function() {
	// 		console.log(canRun, 'canRuncanRun')
	// 		if (!canRun) return;
	// 		canRun = false;
	// 		setTimeout(() => {
	// 			func.apply(this, arguments);
	// 			canRun = true;
	// 			return canRun;
	// 		}, wait);
	// 		return canRun;
	// 	};
	// },
	// 判断是否登录，评论时需要先登录
	isLogin() {
		console.log('isLogin', Object.keys(Store.state.userInfo).length);
		if (Object.keys(Store.state.userInfo).length == 0) {
			uni.showToast({
				title: '您还未登录，快去登录吧~',
				icon: 'none',
				success: () => {
					setTimeout(() => {
						uni.navigateTo({
							url: '/pages/my/children/login',
						})
						return false;
					}, 600)
				}
			})
		} else {
			return true;
		}
	},

	//复制 
	copyText(text) {
		uni.setClipboardData({
			data: text,
		})
	},
	/* 深拷贝 */
	getClone(obj) {
		if (obj === null) return null
		if (typeof obj !== 'object') return obj;
		if (obj.constructor === Date) return new Date(obj);
		if (obj.constructor === RegExp) return new RegExp(obj);
		var newObj = new obj.constructor(); //保持继承链
		for (var key in obj) {
			if (obj.hasOwnProperty(key)) { //不遍历其原型链上的属性
				var val = obj[key];
				// newObj[key] = typeof val === 'object' ? arguments.callee(val) : val; // 使用arguments.callee解除与函数名的耦合
			}
		}
		return newObj;
	},
	// 预览图片
	previewImage(index, arr) {
		//uniapp预览图片
		uni.previewImage({
			current: index, //预览图片的下标
			urls: arr //预览图片的地址，必须要数组形式，如果不是数组形式就转换成数组形式就可以
		});
	},
	getNatve() {
		const infoSync = Store.state.infoSync
		const system = Store.state.infoSync.platform
		console.log(infoSync, 'infoSync')
		const navheight = 0


	},
	gaussBlur(imgData) {
		var pixes = imgData.data;
		var width = imgData.width;
		var height = imgData.height;
		var gaussMatrix = [],
			gaussSum = 0,
			x, y,
			r, g, b, a,
			i, j, k, len;

		var radius = 10;
		var sigma = 5;

		a = 1 / (Math.sqrt(2 * Math.PI) * sigma);
		b = -1 / (2 * sigma * sigma);
		//生成高斯矩阵
		for (i = 0, x = -radius; x <= radius; x++, i++) {
			g = a * Math.exp(b * x * x);
			gaussMatrix[i] = g;
			gaussSum += g;

		}

		//归一化, 保证高斯矩阵的值在[0,1]之间
		for (i = 0, len = gaussMatrix.length; i < len; i++) {
			gaussMatrix[i] /= gaussSum;
		}
		//x 方向一维高斯运算
		for (y = 0; y < height; y++) {
			for (x = 0; x < width; x++) {
				r = g = b = a = 0;
				gaussSum = 0;
				for (j = -radius; j <= radius; j++) {
					k = x + j;
					if (k >= 0 && k < width) { //确保 k 没超出 x 的范围
						//r,g,b,a 四个一组
						i = (y * width + k) * 4;
						r += pixes[i] * gaussMatrix[j + radius];
						g += pixes[i + 1] * gaussMatrix[j + radius];
						b += pixes[i + 2] * gaussMatrix[j + radius];
						// a += pixes[i + 3] * gaussMatrix[j];
						gaussSum += gaussMatrix[j + radius];
					}
				}
				i = (y * width + x) * 4;
				// 除以 gaussSum 是为了消除处于边缘的像素, 高斯运算不足的问题
				// console.log(gaussSum)
				pixes[i] = r / gaussSum;
				pixes[i + 1] = g / gaussSum;
				pixes[i + 2] = b / gaussSum;
				// pixes[i + 3] = a ;
			}
		}
		//y 方向一维高斯运算
		for (x = 0; x < width; x++) {
			for (y = 0; y < height; y++) {
				r = g = b = a = 0;
				gaussSum = 0;
				for (j = -radius; j <= radius; j++) {
					k = y + j;
					if (k >= 0 && k < height) { //确保 k 没超出 y 的范围
						i = (k * width + x) * 4;
						r += pixes[i] * gaussMatrix[j + radius];
						g += pixes[i + 1] * gaussMatrix[j + radius];
						b += pixes[i + 2] * gaussMatrix[j + radius];
						// a += pixes[i + 3] * gaussMatrix[j];
						gaussSum += gaussMatrix[j + radius];
					}
				}
				i = (y * width + x) * 4;
				pixes[i] = r / gaussSum;
				pixes[i + 1] = g / gaussSum;
				pixes[i + 2] = b / gaussSum;
			}
		}
		return imgData;
	},
	
	// 视频地址处理
	setVideoUrl(url) {
		if (url && (url.indexOf('rs.sy12306.com') == -1)) {
			return url;
		}
		let host_str = 'rs.sy12306.com'
		let host_arr = host_str.split('.')
		host_str = host_arr[host_arr.length-1].toString()
		// console.log(url,'mp4_url');
		let arr = url.split('?');
		// console.log(arr[0],'arr');
		
		let arr1 = arr[0].split(host_str);
		// console.log(arr1[1], 'arr1');
		
		let time = Date.parse( new Date());//获取到毫秒的时间戳，精确到毫秒
		// console.log(time, 'time');
		time = time / 1000;//精确到秒
		// console.log(time, 'time');
		
		const newUrl = arr1[1] + '-' + time.toString() + '-0-0-' + Store.state.auth_key + '5vk33mpbbot9hvcfiw';
		// console.log(newUrl, 'newUrl');
		
		const newUrl_md5 = md5(newUrl);
		// console.log(newUrl_md5, 'newUrl_md5');
		
		const videoUrl = arr1[0] + host_str + arr1[1] + '?auth_key=' + time.toString() + '-0-0-' + newUrl_md5;
		// console.log(videoUrl, 'videoUrl');
	
		return videoUrl;
	},
	
	// 随机字符串
	randomString(len) {
		len = len || 32;
		let $chars = 'ABCDEFGHJKMNPQRSTWXYZabcdefhijkmnprstwxyz2345678';    /****默认去掉了容易混淆的字符oOLl,9gq,Vv,Uu,I1****/
		let maxPos = $chars.length;
		let pwd = '';
		for (let i = 0; i < len; i++) {
			pwd += $chars.charAt(Math.floor(Math.random() * maxPos));
		}
		return pwd;
	},
	
	// 生成下载鉴权sign
	downLoadUrl_sign() {
		let key = 'QyWbpzcfbJgtppSA';
		let code = this.randomString(5);
		let timestamp = Date.parse(new Date()) / 1000;
		let sign_key = String(timestamp.toString() + key + code);
		let sign1 = md5(code + timestamp + sign_key);
		let sign = code + '-' + timestamp + '-' + sign1;
		return sign;
	},
	
	// 加密
	aesEncrypt(data, key) {
		console.log(data, key);
		try {
			var salt = key.toString() + 'dyyz'; // 定义盐值
			const cipher = crypto.createCipher('aes192', salt); // 采用aes192加密方式
			var crypted = cipher.update(data, 'utf8', 'hex'); // 加密
			crypted += cipher.final('hex');
			return crypted;
		} catch (e) { // 加捕获是为了在验证失败的时候，直接让用户重新登陆
			// alert("检测到存在安全异常，请检查当前网络环境并重新登录！");
			// window.location.href = '/login'
		}
	},
	// 读取主域名
	getDomainName() {
		let link = location.host;
		let arr = link.split('.');
	
		// 判断是否是数字开头域名
		if (!isNaN(arr[0])) {
			arr.splice(0, 2)
			link = arr.join('.');
		} else if (arr[0] == 'm') {
			arr.shift();
			link = arr.join('.');
		}
		return link;
	},
	
	// cc 随机生出gameItem tags 颜色数据
	getRandomColorIndexArray(oldArray, arrlength) {
			
		// 先拿到原来数组的长度
		let oldLength = oldArray && oldArray.length || 0
		
		// new一个给定长度的array
		let randomN = new Array(arrlength)
		// 通过for循环给new Array 附上0~4的随机值
		for (let i = 0; i < randomN.length; i++) {
			randomN[i] = Math.ceil(Math.random() * 4)
		}
		
		// 创建一个新的array 用来拼接原来数组和新建数组
		let newArray = oldArray.concat(randomN)
		
		// 通过for循环 判断拼接数组中从新建首元素的下标开始 判断是否和前2个元素值相等
		for (let i = oldLength || 1; i < newArray.length; i++) {
			// 判断是否和前2个元素值相等
			if (newArray[i] == newArray[i - 1] || (i > 1 && newArray[i] == newArray[i - 2])) {
				// 如果相等则重新赋上一个0~4的值 并且将for循环索引值往前退回一个值重新进行上面的if判断 直到该索引所对应的值达成条件 与前两个值不相等 则往下走
				newArray[i] = Math.ceil(Math.random() * 4)
				i--;
			}
		}
		
		return newArray
	},
	
	// cc 根据数组的下标索引 返回所对应的颜色数组
	getRandomColorArray(randomIndexArray) {
		
		// 目前gameItem tags 所用到的颜色数组
		let colorArray = [
			{color: '#FEAF36', bgc: '#FEF7EC'}, 
			{color: '#28D58B', bgc: '#E9FBF3'},
			{color: '#2F58F2', bgc: '#EAEEFD'},
			{color: '#FD6F50', bgc: '#FFF0EC'},
			{color: '#3DA3EE', bgc: '#EDF6FF'}]
		
		// 创建一个跟下标索引长度 一样的随机颜色数组
		let randomColorArray = []
		
		// 通过for循环将每一个索引数组所对应的值 作为下标 从上面所定义的颜色数组中 获取一组颜色 然后存放进这个新建的 随机颜色数组
		for (let i = 0; i < randomIndexArray.length; i++) {
			randomColorArray.push(colorArray[randomIndexArray[i]])
		}
		
		return randomColorArray
	}
}
