/*
 * 这里存放公共数据状态
 */
// 版本环境
export default {
	// api请求头
	httpAPI: "https://api.sy12306.com/",   // sy12306.com
	// 系统信息
	systemInfoSync: uni.getSystemInfoSync(),
	// app运行的平台
	platform: uni.getSystemInfoSync().platform,
	// cc 判断是否是safari浏览器打开
	isSafari: /Safari/.test(navigator.userAgent) && !/Chrome/.test(navigator.userAgent),
	// 设备高度 rpx
	myHeight: uni.getSystemInfoSync().windowHeight * (750 / uni.getSystemInfoSync().windowWidth),
	// 设备宽度 px
	myWidth: uni.getSystemInfoSync().windowWidth,
	// 导航栏高度 rpx
	statusBarHeight: uni.getSystemInfoSync().statusBarHeight * (750 / uni.getSystemInfoSync().windowWidth),
	// 屏幕高度 rpx
	mySHeight: uni.getSystemInfoSync().screenHeight * (750 / uni.getSystemInfoSync().windowWidth),
	
	// app_id
	app_id: uni.getSystemInfoSync().platform=='android'?100:101,
	// client_id
	client_id: '',
	// 用户信息
	userInfo: {},
	// 用户定制数据
	userFormat: {},
	// cc 记录登录token
	user_token: '',

	// 管理客服回复
	serviceList: [],
	//常见问题滚动位置
	scrollTop: 0,
	auth_key: 'edwvrn45u5gone',
	
}

