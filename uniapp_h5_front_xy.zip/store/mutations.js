/*
 * 这里修改state中的数据
 */

export default {
	setClientId(state, data) {
		state.client_id = data
	},
	setUserInfo(state, data) {
		state.userInfo = data
	},
	setUserFormat(state, data) {
		state.userFormat = data
	},
	setUserToken(state, data) {
		state.user_token = data
	},
	setServiceList(state, data){
		state.serviceList = data
	},
	setScrollTop(state, data){
		state.scrollTop = data
	},
	setSystemInfoSync(state, data) {
		state.systemInfoSync = data
		state.platform = data.platform
		state.myWidth = data.windowWidth
		state.myHeight = data.windowHeight * (750 / data.windowWidth)
		state.mySHeight = data.screenHeight * (750 / data.windowWidth)
		state.statusBarHeight = data.statusBarHeight * (750 / data.windowWidth)
	},
}
