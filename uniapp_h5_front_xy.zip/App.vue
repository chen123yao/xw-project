<script>
	export default {
		// cc 当uni-app 初始化完成时触发（全局只触发一次）
		onLaunch: function() {
			// cc 获取用户定制信息
			this.userFormat();
			// plus.navigator.setStatusBarStyle("dark");
		},
		// cc 当 uni-app 启动，或从后台进入前台显示
		onShow: function() {
			console.log('---onShow---');
		},
		// cc 当 uni-app 从前台进入后台
		onHide: function() {
			
		},
		methods: {
			// cc 获取客户信息
			userFormat() {
				let domain = this.$common.getDomainName()
				console.log('doamin:', domain)
				// domain = '200youxi.com'
				// domain = '4000yx.com'
				
				this.$api.get(`system/h5_front_setup`, {
					link: domain
				}).then(res => {
					
					let front_setup = res.data.data.front_setup
					
					// cc 默认为4231渠道 如果域名附带渠道id 则覆盖默认4231渠道id 
					let client_id = 4231;
					
					console.log('locationHost:', location.host, front_setup);
					
					if (!isNaN(location.host.split(".")[0])) {
						// cc 设置客户渠道
						client_id = location.host.split(".")[0];
					} else {
						client_id = front_setup.channel_id;
					}
					
					// cc 拼接app下载地址
					front_setup.down_app_url += client_id;
					
					// cc 存储渠道id
					this.$store.commit('setClientId', client_id);
					
					this.dataInit();
					// cc 存储客户信息
					this.$store.commit('setUserFormat', front_setup);
					
					// cc 本机信息
					this.$store.commit("setSystemInfoSync", uni.getSystemInfoSync());
					
					this.autoLogin();
				})
			},
			// cc 页面初始化
			dataInit() {
				this.$api.get("system/appinit").then(res => {
					this.$store.commit("setUserToken", res.data.data.user_token);
				})
			},
			
			// cc 自动登录
			autoLogin() {
				console.log('autoLogin', this.$store.state.client_id);
				
				if (uni.getStorageSync('mem-username') && uni.getStorageSync('mem-password')) {
					let username = uni.getStorageSync('mem-username')
					let password = uni.getStorageSync('mem-password')
					this.$api.get("user/login", {
						'mem-username': username,
						'mem-password': password,
						client_id: this.$store.state.client_id,
						equipmentCode: this.equipmentCode
					}).then(res => {
						if (res.data.code == 200) {
							// cc 将登录之后获取到的token保存起来
							this.$store.commit("setUserToken", res.data.data.user_token);
							// 获取用户信息
							this.$common.getuserInfo();
						}
					})
				} else if (uni.getStorageSync('mem-openid')) {
					this.$api.get("user/login", {
						"mem-openid": uni.getStorageSync('mem-openid'),
						"mem-username": uni.getStorageSync('mem-username'),
						"mem-oauth_type": uni.getStorageSync('mem-oauth_type'),
						client_id: this.$store.state.client_id
					}).then(res => {
						if (res.data.code == 200) {
							// cc 将登录之后获取到的token保存起来
							this.$store.commit("setUserToken", res.data.data.user_token);
							// 获取用户信息
							this.$common.getuserInfo();
						}
					})
				} else if (uni.getStorageSync('sms-mobile')) {
					this.$api.get("v8/user/loginm", {
						"sms-mobile": uni.getStorageSync('sms-mobile'),
						"sms-phone": '1',
						"sms-type": '2',
						client_id: this.$store.state.client_id
					}).then(res => {
						// 将登录获取的数据记录下来
						if (res.data.code == 200) {
							if (res.data.data.is_pwd) {
								uni.setStorageSync('mem-username', res.data.data.username)
								uni.setStorageSync('sms-mobile',uni.getStorageSync('sms-mobile'))
							// cc 将登录之后获取到的token保存起来
							this.$store.commit("setUserToken", res.data.data.user_token);
								// 获取用户信息
								this.$common.getuserInfo();
							}
						}
					})
				} else {
					// cc 清空本地存储的登录数据
					this.$store.commit("setUserInfo", {});
					this.$store.commit('setUserToken', '');
					uni.setStorageSync('mem-openid', '')
					uni.setStorageSync('mem-username', '')
					uni.setStorageSync('mem-password', '')
					uni.setStorageSync('sms-mobile','')
				}
			}
		}
	}
</script>

<style lang="scss">
	/* #ifndef APP-NVUE */
	// 设置整个项目的背景色
	page {
		background-color: #fff;
	}
	
	body, html {
		// -webkit-filter: grayscale(100%);
		// -moz-filter: grayscale(100%);
		// -ms-filter: grayscale(100%);
		// -o-filter: grayscale(100%);
		// filter: grayscale(100%);
		// filter: gray;
		// filter: progid:DXImageTransform.Microsoft.BasicImage(grayscale=1);
	}
	/* #endif */
</style>
